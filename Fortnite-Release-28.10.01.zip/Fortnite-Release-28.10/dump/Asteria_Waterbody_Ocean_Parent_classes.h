// BlueprintGeneratedClass Asteria_Waterbody_Ocean_Parent.Asteria_Waterbody_Ocean_Parent_C
// Size: 0x418 (Inherited: 0x408)
struct AAsteria_Waterbody_Ocean_Parent_C : AFortWaterBodyBP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x408(0x08)
	struct UFortSplineWaterAudioComponent* FortSplineWaterAudio; // 0x410(0x08)

	void ReceiveBeginPlay(); // Function Asteria_Waterbody_Ocean_Parent.Asteria_Waterbody_Ocean_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_Asteria_Waterbody_Ocean_Parent(int32_t EntryPoint); // Function Asteria_Waterbody_Ocean_Parent.Asteria_Waterbody_Ocean_Parent_C.ExecuteUbergraph_Asteria_Waterbody_Ocean_Parent // (Final|UbergraphFunction) // @ game+0x211c0a0
};

