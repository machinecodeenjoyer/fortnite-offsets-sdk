// BlueprintGeneratedClass Border-SolidBG-StatItem.Border-SolidBG-StatItem_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-SolidBG-StatItem_C : UBorder-ShellTopBar_C {
};

