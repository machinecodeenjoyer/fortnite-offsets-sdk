// WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C
// Size: 0x2c0 (Inherited: 0x2c0)
struct UArrowCursorWidget_C : UUserWidget {

	struct FSlateBrush (); // Function ArrowCursorWidget.ArrowCursorWidget_C. // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
};

