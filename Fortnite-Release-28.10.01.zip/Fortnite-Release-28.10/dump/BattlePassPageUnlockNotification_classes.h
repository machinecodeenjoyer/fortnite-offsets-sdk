// BlueprintGeneratedClass BattlePassPageUnlockNotification.BattlePassPageUnlockNotification_C
// Size: 0x130 (Inherited: 0x130)
struct UBattlePassPageUnlockNotification_C : UFortUIBattlePassPageUnlockNotification {
};

