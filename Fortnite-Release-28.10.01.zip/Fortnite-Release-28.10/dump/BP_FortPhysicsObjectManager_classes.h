// BlueprintGeneratedClass BP_FortPhysicsObjectManager.BP_FortPhysicsObjectManager_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct ABP_FortPhysicsObjectManager_C : AFortPhysicsObjectManager {
};

