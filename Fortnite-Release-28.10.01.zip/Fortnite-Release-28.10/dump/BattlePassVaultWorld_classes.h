// BlueprintGeneratedClass BattlePassVaultWorld.BattlePassVaultWorld_C
// Size: 0x430 (Inherited: 0x349)
struct ABattlePassVaultWorld_C : AVaultWorld_C {
	char pad_349[0x7]; // 0x349(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct UStaticMeshComponent* floor; // 0x358(0x08)
	float TransitionForward_FX_Transition_Fade_46DACBD74D0A8B2278950785C007984A; // 0x360(0x04)
	float TransitionForward_Fade_46DACBD74D0A8B2278950785C007984A; // 0x364(0x04)
	float TransitionForward_Forward_46DACBD74D0A8B2278950785C007984A; // 0x368(0x04)
	enum class ETimelineDirection TransitionForward__Direction_46DACBD74D0A8B2278950785C007984A; // 0x36c(0x01)
	char pad_36D[0x3]; // 0x36d(0x03)
	struct UTimelineComponent* TransitionForward; // 0x370(0x08)
	float BackgroundIntenstiy_Intensity_8C51F99C4026F0204F2184AD9661CD23; // 0x378(0x04)
	enum class ETimelineDirection BackgroundIntenstiy__Direction_8C51F99C4026F0204F2184AD9661CD23; // 0x37c(0x01)
	char pad_37D[0x3]; // 0x37d(0x03)
	struct UTimelineComponent* BackgroundIntenstiy; // 0x380(0x08)
	float ItemDetailsIntensity_TextureIntensity_1EC6205345E5A708DA53B5A9449F1700; // 0x388(0x04)
	enum class ETimelineDirection ItemDetailsIntensity__Direction_1EC6205345E5A708DA53B5A9449F1700; // 0x38c(0x01)
	char pad_38D[0x3]; // 0x38d(0x03)
	struct UTimelineComponent* ItemDetailsIntensity; // 0x390(0x08)
	float Background_Effects_SetStreaks_50767E4640E86998EC96B7B2D57E5E27; // 0x398(0x04)
	enum class ETimelineDirection Background_Effects__Direction_50767E4640E86998EC96B7B2D57E5E27; // 0x39c(0x01)
	char pad_39D[0x3]; // 0x39d(0x03)
	struct UTimelineComponent* Background-Effects; // 0x3a0(0x08)
	float IconDissolve_NewTrack_0_983A4DA644BE5CFAED0C378063FC66FC; // 0x3a8(0x04)
	enum class ETimelineDirection IconDissolve__Direction_983A4DA644BE5CFAED0C378063FC66FC; // 0x3ac(0x01)
	char pad_3AD[0x3]; // 0x3ad(0x03)
	struct UTimelineComponent* IconDissolve; // 0x3b0(0x08)
	float ItemDetails_Icon_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781; // 0x3b8(0x04)
	float ItemDetails_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781; // 0x3bc(0x04)
	enum class ETimelineDirection ItemDetails__Direction_F4D1C4E246C708FA1F53EDA5A3FEE781; // 0x3c0(0x01)
	char pad_3C1[0x7]; // 0x3c1(0x07)
	struct UTimelineComponent* ItemDetails; // 0x3c8(0x08)
	float Floor_Visibility_FloorMask_CE7E338346E82397065B65AA77823F50; // 0x3d0(0x04)
	enum class ETimelineDirection Floor_Visibility__Direction_CE7E338346E82397065B65AA77823F50; // 0x3d4(0x01)
	char pad_3D5[0x3]; // 0x3d5(0x03)
	struct UTimelineComponent* Floor-Visibility; // 0x3d8(0x08)
	float TransitionBackward_fx_Transition_fade_7073CD0840227233D3A64795A5A1B1B8; // 0x3e0(0x04)
	float TransitionBackward_Fade_7073CD0840227233D3A64795A5A1B1B8; // 0x3e4(0x04)
	float TransitionBackward_Backward_7073CD0840227233D3A64795A5A1B1B8; // 0x3e8(0x04)
	enum class ETimelineDirection TransitionBackward__Direction_7073CD0840227233D3A64795A5A1B1B8; // 0x3ec(0x01)
	char pad_3ED[0x3]; // 0x3ed(0x03)
	struct UTimelineComponent* TransitionBackward; // 0x3f0(0x08)
	struct UMaterialInstance* FloorMI; // 0x3f8(0x08)
	struct UMaterialInstanceDynamic* FloorMID; // 0x400(0x08)
	double BG_Intensity_Max; // 0x408(0x08)
	double BG_Intensity_Mid; // 0x410(0x08)
	double BG_Intensity_Min; // 0x418(0x08)
	bool bIsTransitioning; // 0x420(0x01)
	enum class EBackgroundIntensityLevel Intensity Transition; // 0x421(0x01)
	bool bIsPageA_Max; // 0x422(0x01)
	bool bIsPageB_Max; // 0x423(0x01)
	float PageA_X_Offset; // 0x424(0x04)
	float PageB_X_Offset; // 0x428(0x04)
	float X_Offset_Anim_Distance; // 0x42c(0x04)

	void Set Backgrounds Scalar Value(struct FName Param, double FloatValue); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Set Backgrounds Scalar Value // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PageTransitionIntensityUpdate(struct UMaterialInstanceDynamic* MID_Background, struct UMaterialInstanceDynamic* MID_Floor); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.PageTransitionIntensityUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void TransitionBackgroundBackward(double Backward, double Fade, double FXTransitionFade, struct UMaterialInstanceDynamic* Mid); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackgroundBackward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void TransitionBackgroundForward(double Forward, double Fade, double FXTransitionFade, struct UMaterialInstanceDynamic* Mid); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackgroundForward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetupBackgroundMaterial(struct UTexture2D*& TextureBackground, struct FVaultWorldBackgroundData& BackgroundInfo, struct UMaterialInstanceDynamic* Mid); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.SetupBackgroundMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UserConstructionScript(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void TransitionForward__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionForward__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void TransitionForward__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionForward__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void TransitionBackward__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackward__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void TransitionBackward__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.TransitionBackward__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void Background-Effects__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Background-Effects__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void Background-Effects__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Background-Effects__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void Floor-Visibility__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Floor-Visibility__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void Floor-Visibility__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.Floor-Visibility__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void ItemDetails__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ItemDetails__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void ItemDetails__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ItemDetails__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void IconDissolve__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.IconDissolve__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void IconDissolve__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.IconDissolve__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void ItemDetailsIntensity__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ItemDetailsIntensity__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void ItemDetailsIntensity__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ItemDetailsIntensity__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void BackgroundIntenstiy__FinishedFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.BackgroundIntenstiy__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void BackgroundIntenstiy__UpdateFunc(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.BackgroundIntenstiy__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnTransitionBackground(bool bPlayForward, enum class EBackgroundIntensityLevel IntensityTransition); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnTransitionBackground // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnUpdateDisplay(bool bShowFloor, bool bShowEffects); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnUpdateDisplay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnInitialBackgroundTransition(); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnInitialBackgroundTransition // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnTransitionItemDetails(bool bShowItemDetails); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnIntensityChange(bool bToLowIntensity); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnIntensityChange // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnSetupTextureBackground(struct UTexture2D* LoadedBackgroundTexture, struct FVaultWorldBackgroundData& BackgroundInfo); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnSetupTextureBackground // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnSetupMaterialBackground(struct UMaterialInterface* LoadedBackgroundMaterial, struct FVaultWorldBackgroundData& BackgroundInfo); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.OnSetupMaterialBackground // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BattlePassVaultWorld(int32_t EntryPoint); // Function BattlePassVaultWorld.BattlePassVaultWorld_C.ExecuteUbergraph_BattlePassVaultWorld // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

