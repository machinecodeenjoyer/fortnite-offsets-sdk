// ScriptStruct Blueprint_Paper_VIM.Blueprint_Paper_VIM_C.AnimBlueprintGeneratedConstantData
// Size: 0x210 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName ; // 0x04(0x04)
	struct FName ; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FAnimNodeFunctionRef ; // 0x10(0x18)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x28(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0xa8(0x18)
	struct FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root; // 0xc0(0x30)
	struct FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_MeshRefPose; // 0xf0(0x30)
	struct FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace; // 0x120(0x30)
	struct FAnimNodeExposedValueHandler_PropertyAccess ; // 0x150(0x30)
	struct FAnimNodeExposedValueHandler_PropertyAccess ; // 0x180(0x30)
	struct FAnimNodeExposedValueHandler_PropertyAccess ; // 0x1b0(0x30)
	struct FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_AnimDynamics; // 0x1e0(0x30)
};

