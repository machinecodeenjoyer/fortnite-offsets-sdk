// BlueprintGeneratedClass CameraShake_Ascender_LineAttach1.CameraShake_Ascender_LineAttach1_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Ascender_LineAttach1_C : ULegacyCameraShake {
};

