// BlueprintGeneratedClass BBE_TankExit.BBE_TankExit_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_TankExit_C : UFortMobileActionButtonBehaviorExtension {
};

