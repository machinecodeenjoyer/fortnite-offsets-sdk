// UserDefinedStruct AnimCurveParameterPair.AnimCurveParameterPair
// Size: 0x08 (Inherited: 0x00)
struct FAnimCurveParameterPair {
	struct FName UserVariableName_5_C3E793D64B2060301331AC805C0B1026; // 0x00(0x04)
	struct FName AnimCurveName_6_457883094DB38A3EF423919EDE4D33C1; // 0x04(0x04)
};

