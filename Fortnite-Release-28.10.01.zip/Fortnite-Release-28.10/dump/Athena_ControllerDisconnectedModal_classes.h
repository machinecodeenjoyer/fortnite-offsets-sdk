// WidgetBlueprintGeneratedClass Athena_ControllerDisconnectedModal.Athena_ControllerDisconnectedModal_C
// Size: 0x458 (Inherited: 0x418)
struct UAthena_ControllerDisconnectedModal_C : UAthenaControllerDisconnectedModal {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x418(0x08)
	struct UWidgetAnimation* Intro; // 0x420(0x08)
	struct UCommonActionWidget* ; // 0x428(0x08)
	struct UImage* ; // 0x430(0x08)
	struct UImage* Image_Separator_Down; // 0x438(0x08)
	struct UImage* Image_Separator_Up; // 0x440(0x08)
	struct ULightbox_C* Lightbox; // 0x448(0x08)
	struct UImage* ProgressSpinner; // 0x450(0x08)

	void BP_OnActivated(); // Function Athena_ControllerDisconnectedModal.Athena_ControllerDisconnectedModal_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_Athena_ControllerDisconnectedModal(int32_t EntryPoint); // Function Athena_ControllerDisconnectedModal.Athena_ControllerDisconnectedModal_C.ExecuteUbergraph_Athena_ControllerDisconnectedModal // (Final|UbergraphFunction) // @ game+0x211c0a0
};

