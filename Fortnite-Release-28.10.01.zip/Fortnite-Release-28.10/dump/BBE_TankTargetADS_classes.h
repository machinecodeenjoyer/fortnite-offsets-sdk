// BlueprintGeneratedClass BBE_TankTargetADS.BBE_TankTargetADS_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_TankTargetADS_C : UFortMobileActionButtonBehaviorExtension {
};

