// BlueprintGeneratedClass B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C
// Size: 0x850 (Inherited: 0x700)
struct AB_SparksOnActorPreviewDefault_C : ASparksItemPreviewOnPawnActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x700(0x08)
	struct UArrowComponent* Temp_IASDerezAbsorbPoint; // 0x708(0x08)
	struct UArrowComponent* Arrow1; // 0x710(0x08)
	struct UDirectionalLightComponent* Directional Light For Atmosphere_PC; // 0x718(0x08)
	struct USkyLightComponent* SkyLightPC; // 0x720(0x08)
	struct UArrowComponent* Arrow; // 0x728(0x08)
	struct USkyLightComponent* SkyLightLowMobile; // 0x730(0x08)
	struct UDirectionalLightComponent* DirectionalLightMobile; // 0x738(0x08)
	struct USpotLightComponent* KeyLight_StandaloneForSwitch; // 0x740(0x08)
	struct USpotLightComponent* KeyLight5; // 0x748(0x08)
	struct USpotLightComponent* KeyLight6; // 0x750(0x08)
	struct USpotLightComponent* KeyLigh3; // 0x758(0x08)
	struct USpotLightComponent* KeyLight2; // 0x760(0x08)
	struct USpotLightComponent* BounceRear1; // 0x768(0x08)
	struct USpotLightComponent* RimLowerRight1; // 0x770(0x08)
	struct USpotLightComponent* RimLeft1; // 0x778(0x08)
	struct USpotLightComponent* RimTopRight1; // 0x780(0x08)
	struct USpotLightComponent* RimBottomLeft1; // 0x788(0x08)
	struct USpotLightComponent* Bounce1; // 0x790(0x08)
	struct USceneComponent* LightTransform; // 0x798(0x08)
	struct UStaticMeshComponent* Plane; // 0x7a0(0x08)
	struct USkeletalMeshComponent* Sample Mesh; // 0x7a8(0x08)
	float RezInMaterialEffectTimeLine2_NewTrack_0_EE684F644FE38B4A30D17FB8CF917357; // 0x7b0(0x04)
	enum class ETimelineDirection RezInMaterialEffectTimeLine2__Direction_EE684F644FE38B4A30D17FB8CF917357; // 0x7b4(0x01)
	char pad_7B5[0x3]; // 0x7b5(0x03)
	struct UTimelineComponent* RezInMaterialEffectTimeLine2; // 0x7b8(0x08)
	float RezInMaterialEffectTimeLine_NewTrack_0_9C89220943F4EBA1DF12D38A05B1FC5C; // 0x7c0(0x04)
	enum class ETimelineDirection RezInMaterialEffectTimeLine__Direction_9C89220943F4EBA1DF12D38A05B1FC5C; // 0x7c4(0x01)
	char pad_7C5[0x3]; // 0x7c5(0x03)
	struct UTimelineComponent* RezInMaterialEffectTimeLine; // 0x7c8(0x08)
	bool AlwaysOn; // 0x7d0(0x01)
	bool IsActive; // 0x7d1(0x01)
	bool debugConstructionLighting; // 0x7d2(0x01)
	char pad_7D3[0x5]; // 0x7d3(0x05)
	struct UParticleSystemComponent* ObscuringLoopEmitter; // 0x7d8(0x08)
	struct FRotator ToonLightRotatio; // 0x7e0(0x18)
	bool bIsBattlePassReward; // 0x7f8(0x01)
	char pad_7F9[0x7]; // 0x7f9(0x07)
	struct FTimerHandle LOD_StreamingSafetyTimer; // 0x800(0x08)
	struct UMaterialInterface* DefaultFloorMaterial; // 0x808(0x08)
	struct UMaterialInterface* CustomFloorMaterial; // 0x810(0x08)
	struct FStateTransitionPauseRequestHandle ItemsPendingTransitionOutHandle; // 0x818(0x10)
	struct UFXSystemComponent* IASLoadingFX_LoopFX; // 0x828(0x08)
	bool Use Secondary Transition Effects; // 0x830(0x01)
	bool Show Floor; // 0x831(0x01)
	char pad_832[0x6]; // 0x832(0x06)
	struct FTimerHandle IASLoadingDelayTimer; // 0x838(0x08)
	struct FTimerHandle IASLoadingFXDestroyDelayTimer; // 0x840(0x08)
	struct FTimerHandle IASResinDelayTimer; // 0x848(0x08)

	void IsSkyDiveContrailItem(bool& bSuccess); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.IsSkyDiveContrailItem // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void OutroAndDestroyLoadingEffects(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OutroAndDestroyLoadingEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HandleLightingSettingsChanged(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.HandleLightingSettingsChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void DestroyLoadingEffects(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.DestroyLoadingEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SpawnLoadingEffects(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SpawnLoadingEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetupLighting(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SetupLighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SpawnResInEffects(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SpawnResInEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetupFloor(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SetupFloor // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Get LOD Streaming Safety Duration(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.Get LOD Streaming Safety Duration // (Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void SwitchErebusLighting(bool Visibility); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SwitchErebusLighting // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetFloorEnabled(bool Show Floor); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SetFloorEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void LightControl(bool Active); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.LightControl // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SwitchPCLighting(bool Visibility); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SwitchPCLighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SwitchMobileLighting(bool NewParam); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SwitchMobileLighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void RezInMaterialEffectTimeLine__FinishedFunc(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.RezInMaterialEffectTimeLine__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void RezInMaterialEffectTimeLine__UpdateFunc(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.RezInMaterialEffectTimeLine__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void RezInMaterialEffectTimeLine2__FinishedFunc(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.RezInMaterialEffectTimeLine2__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void RezInMaterialEffectTimeLine2__UpdateFunc(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.RezInMaterialEffectTimeLine2__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void SpawnSoundPlayback(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.SpawnSoundPlayback // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnUpdateFloorMaterial(bool bEnableAutotestBackground); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnUpdateFloorMaterial // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnItemsPendingTransitionOut(struct FStateTransitionControllerHandle& TransitionController); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnItemsPendingTransitionOut // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void Internal_ItemsPendingTransitionOutComplete(struct FStateTransitionControllerHandle TransitionController); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.Internal_ItemsPendingTransitionOutComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnItemsPendingTransitionOut_SpawnResOutEffects(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnItemsPendingTransitionOut_SpawnResOutEffects // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void FinishShowingResOutEffects(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.FinishShowingResOutEffects // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnItemsPendingTransitionOut_EnsureAllResOutEffectsAreCleanedUp(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnItemsPendingTransitionOut_EnsureAllResOutEffectsAreCleanedUp // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnSetFloorMaterial(struct UMaterialInterface* InMaterialInstance); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnSetFloorMaterial // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnPreviewVisualsSpawned(bool bUseSecondaryTransitionEffects, bool bShowFloor); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnPreviewVisualsSpawned // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnAllLODStreamingComplete(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnAllLODStreamingComplete // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnPreviewVisualsBeginLoading(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnPreviewVisualsBeginLoading // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnCurrentVisualsCleanedUp(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.OnCurrentVisualsCleanedUp // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void Backup_LODStreamingFailed(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.Backup_LODStreamingFailed // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void RezInMaterialEffect(); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.RezInMaterialEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_B_SparksOnActorPreviewDefault(int32_t EntryPoint); // Function B_SparksOnActorPreviewDefault.B_SparksOnActorPreviewDefault_C.ExecuteUbergraph_B_SparksOnActorPreviewDefault // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

