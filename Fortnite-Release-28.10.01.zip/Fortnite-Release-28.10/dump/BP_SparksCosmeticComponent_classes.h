// BlueprintGeneratedClass BP_SparksCosmeticComponent.BP_SparksCosmeticComponent_C
// Size: 0x468 (Inherited: 0x450)
struct UBP_SparksCosmeticComponent_C : USparksCosmeticComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x450(0x08)
	struct UGameplayEventRouterComponent* Event Router; // 0x458(0x08)
	struct UWBP_Sparks_Dbg_CosmeticPicker_C* DebugWidget; // 0x460(0x08)

	void ReceiveBeginPlay(); // Function BP_SparksCosmeticComponent.BP_SparksCosmeticComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void Debug_BP_ShowCosmeticPicker(bool bShow); // Function BP_SparksCosmeticComponent.BP_SparksCosmeticComponent_C.Debug_BP_ShowCosmeticPicker // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BP_SparksCosmeticComponent(int32_t EntryPoint); // Function BP_SparksCosmeticComponent.BP_SparksCosmeticComponent_C.ExecuteUbergraph_BP_SparksCosmeticComponent // (Final|UbergraphFunction) // @ game+0x211c0a0
};

