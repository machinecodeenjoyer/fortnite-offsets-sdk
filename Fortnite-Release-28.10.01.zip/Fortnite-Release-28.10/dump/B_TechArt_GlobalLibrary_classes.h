// BlueprintGeneratedClass B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UB_TechArt_GlobalLibrary_C : UBlueprintFunctionLibrary {

	void BindScalabilitySettings(struct FDelegate& Delegate, struct UObject* __WorldContext); // Function B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C.BindScalabilitySettings // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void IsLumenEnabled(struct UObject* __WorldContext, bool& IsEnabled); // Function B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C.IsLumenEnabled // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void GetDynamicMaterialInstance(struct UMeshComponent* MeshComponent, int32_t MaterialIndex, struct UObject* __WorldContext, struct UMaterialInstanceDynamic*& Material Instance Dynamic); // Function B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C.GetDynamicMaterialInstance // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void AreBoundsOverlapping?(struct FBox BoundsA, struct FBox BoundsB, struct UObject* __WorldContext, bool& BoundsOverlap?); // Function B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C.AreBoundsOverlapping? // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void AddActorTag(struct AActor* Actor, struct FName& tag, struct UObject* __WorldContext); // Function B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C.AddActorTag // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HoudiniInstanceHISMBuilder(struct UInstancedStaticMeshComponent* InstancedStaticMeshComponent, struct UDataTable* InstanceDataTable, double InstancesCountToImport, bool RandomScale, double RandomScaleMin, double RandomScaleMax, bool RandomRotationZ, double RandomRotationZMin, double RandomRotationZMax, bool UseWorldSpacePositions, struct UObject* __WorldContext); // Function B_TechArt_GlobalLibrary.B_TechArt_GlobalLibrary_C.HoudiniInstanceHISMBuilder // (Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

