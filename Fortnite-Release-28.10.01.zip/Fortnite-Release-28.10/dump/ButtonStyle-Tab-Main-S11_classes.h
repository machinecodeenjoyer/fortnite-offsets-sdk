// BlueprintGeneratedClass ButtonStyle-Tab-Main-S11.ButtonStyle-Tab-Main-S11_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Tab-Main-S11_C : UCommonButtonStyle {
};

