// BlueprintGeneratedClass BP_AnimPreviewFoleyComponent.BP_AnimPreviewFoleyComponent_C
// Size: 0x158 (Inherited: 0x158)
struct UBP_AnimPreviewFoleyComponent_C : USoundLibraryComponent {
};

