// BlueprintGeneratedClass ButtonStyle-Skew_Desirable.ButtonStyle-Skew_Desirable_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Skew_Desirable_C : UCommonButtonStyle {
};

