// WidgetBlueprintGeneratedClass Athena_ProgressModal.Athena_ProgressModal_C
// Size: 0x430 (Inherited: 0x410)
struct UAthena_ProgressModal_C : UAthenaProgressModal {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)
	struct UWidgetAnimation* Intro; // 0x418(0x08)
	struct UWBP_UIKit_Dialog_Base_C* WBP_UIKit_Dialog_Base; // 0x420(0x08)
	struct UWBP_UIKit_Throbber_C* WBP_UIKit_Throbber; // 0x428(0x08)

	void BP_OnActivated(); // Function Athena_ProgressModal.Athena_ProgressModal_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_Athena_ProgressModal(int32_t EntryPoint); // Function Athena_ProgressModal.Athena_ProgressModal_C.ExecuteUbergraph_Athena_ProgressModal // (Final|UbergraphFunction) // @ game+0x211c0a0
};

