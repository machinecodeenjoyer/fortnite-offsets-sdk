// BlueprintGeneratedClass AI_skill_phoebe_bot_attacking.AI_skill_phoebe_bot_attacking_C
// Size: 0x5b0 (Inherited: 0x5b0)
struct UAI_skill_phoebe_bot_attacking_C : UFortAthenaAIBotAttackingSkillSet {
};

