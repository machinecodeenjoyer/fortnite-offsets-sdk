// BlueprintGeneratedClass ButtonStyle_PageChevron_Right.ButtonStyle_PageChevron_Right_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_PageChevron_Right_C : UButtonStyle-MediumTransparentNoCues_C {
};

