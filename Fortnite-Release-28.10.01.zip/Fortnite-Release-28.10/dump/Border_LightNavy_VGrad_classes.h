// BlueprintGeneratedClass Border_LightNavy_VGrad.Border_LightNavy_VGrad_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder_LightNavy_VGrad_C : UCommonBorderStyle {
};

