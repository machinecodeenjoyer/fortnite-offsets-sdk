// BlueprintGeneratedClass AnimNotify_FootStep_Left.AnimNotify_FootStep_Left_C
// Size: 0x78 (Inherited: 0x78)
struct UAnimNotify_FootStep_Left_C : UAnimNotify_FootStep_C {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AnimNotify_FootStep_Left.AnimNotify_FootStep_Left_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
};

