// BlueprintGeneratedClass CameraShake_ZipLine_DownhillSpeed.CameraShake_ZipLine_DownhillSpeed_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_ZipLine_DownhillSpeed_C : ULegacyCameraShake {
};

