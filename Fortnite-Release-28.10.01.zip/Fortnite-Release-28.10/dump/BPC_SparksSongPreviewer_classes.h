// BlueprintGeneratedClass BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C
// Size: 0xe9 (Inherited: 0xa0)
struct UBPC_SparksSongPreviewer_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct UFortBaseStreamingVideo* Streamer; // 0xa8(0x08)
	struct FName CurrentSong; // 0xb0(0x04)
	struct FName PendingSong; // 0xb4(0x04)
	double FadeInDuration; // 0xb8(0x08)
	double FadeOutDuration; // 0xc0(0x08)
	double PreviewDuration; // 0xc8(0x08)
	struct FTimerHandle LoopPointFadeTimerHandle; // 0xd0(0x08)
	double LoopFadeOutDurationFromEnd; // 0xd8(0x08)
	struct FTimerHandle FadeOutForStopTimerHandle; // 0xe0(0x08)
	bool IsFadingOut; // 0xe8(0x01)

	void InitPreview(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.InitPreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ForceStopPreviewImmediate(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.ForceStopPreviewImmediate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StopPreviewingSong(bool WithFadeout, struct FName SongShortName); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.StopPreviewingSong // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void IsPlayingPreview(struct FName Song, bool& Is Playing Or Pending, bool& Is Playing, bool& Is Pending); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.IsPlayingPreview // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void StopPreview(bool WithFadeout); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.StopPreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Clear Current Preview and Start Pending Preview(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.Clear Current Preview and Start Pending Preview // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StartPreview(struct FName SongShortName); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.StartPreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Fade Out And Stop(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.Fade Out And Stop // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void VideoOnClosed_Event(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.VideoOnClosed_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void VideoOnSuccess_Event(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.VideoOnSuccess_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPlaybackResumed_Event(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.OnPlaybackResumed_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void FadeOutAtLoop(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.FadeOutAtLoop // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void FadeInAfterLoop(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.FadeInAfterLoop // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void VideoOnTerminalError_Event(enum class EBaseMediaTerminalErrorReason Reason); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.VideoOnTerminalError_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnVideoResumed(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.OnVideoResumed // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void DoneFadingOutForStop(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.DoneFadingOutForStop // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BPC_SparksSongPreviewer(int32_t EntryPoint); // Function BPC_SparksSongPreviewer.BPC_SparksSongPreviewer_C.ExecuteUbergraph_BPC_SparksSongPreviewer // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

