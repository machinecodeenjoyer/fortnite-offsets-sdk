// BlueprintGeneratedClass BoarRidableComponent.BoarRidableComponent_C
// Size: 0xe24 (Inherited: 0xde0)
struct UBoarRidableComponent_C : UCreatureBaseRidableComponent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xde0(0x08)
	struct USoundBase* BurtChargeStartSound; // 0xde8(0x08)
	struct UAudioComponent* ChargeSoundComp; // 0xdf0(0x08)
	double SprintCooldDownTime; // 0xdf8(0x08)
	struct UGameplayEffect* GESprintImpactPawn; // 0xe00(0x08)
	struct FGameplayTag SprintImpactGameplayCueTag; // 0xe08(0x04)
	char pad_E0C[0x4]; // 0xe0c(0x04)
	struct UGameplayEffect* GESprintImpactVehicle; // 0xe10(0x08)
	struct FGameplayTag SprintChargeImpact_Default_CueTag; // 0xe18(0x04)
	struct FGameplayTag SprintChargeImpact_Pawn_CueTag; // 0xe1c(0x04)
	struct FGameplayTag SprintChargeImpact_DestroyBuild_CueTag; // 0xe20(0x04)

	void OnReaction(struct UObject* Object, struct FHitResult HitResult); // Function BoarRidableComponent.BoarRidableComponent_C.OnReaction // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HandleRiderStoppedRiding(struct URiderComponent* Rider); // Function BoarRidableComponent.BoarRidableComponent_C.HandleRiderStoppedRiding // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void HandleRiderStartedRiding(struct URiderComponent* Rider); // Function BoarRidableComponent.BoarRidableComponent_C.HandleRiderStartedRiding // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void HandleAbilityStarted(); // Function BoarRidableComponent.BoarRidableComponent_C.HandleAbilityStarted // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function BoarRidableComponent.BoarRidableComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnReactionEvent(struct AActor* HitActor, bool bFromAsyncSweepBox, enum class FCollisionReactionType CollisionReactionType, bool bIsFirstContinuousReactionOnDelayableActor, struct FHitResult& HitResult); // Function BoarRidableComponent.BoarRidableComponent_C.OnReactionEvent // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BoarRidableComponent.BoarRidableComponent_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BoarRidableComponent(int32_t EntryPoint); // Function BoarRidableComponent.BoarRidableComponent_C.ExecuteUbergraph_BoarRidableComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

