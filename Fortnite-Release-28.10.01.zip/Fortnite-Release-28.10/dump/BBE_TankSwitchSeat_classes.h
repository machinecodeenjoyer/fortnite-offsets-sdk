// BlueprintGeneratedClass BBE_TankSwitchSeat.BBE_TankSwitchSeat_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_TankSwitchSeat_C : UFortMobileActionButtonBehaviorExtension {
};

