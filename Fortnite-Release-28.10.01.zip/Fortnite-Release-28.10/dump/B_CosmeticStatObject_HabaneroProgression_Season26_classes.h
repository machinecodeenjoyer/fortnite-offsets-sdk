// BlueprintGeneratedClass B_CosmeticStatObject_HabaneroProgression_Season26.B_CosmeticStatObject_HabaneroProgression_Season26_C
// Size: 0xe0 (Inherited: 0xe0)
struct UB_CosmeticStatObject_HabaneroProgression_Season26_C : UFortCosmeticStatObject_HabaneroProgressionSeasonal {
};

