// Enum BattlePassS28UI.EBattlePassStatusBarTypeS28
enum class EBattlePassStatusBarTypeS28 : uint8 {
	Hidden = 0,
	Prerequisite = 1,
	Delayed = 2,
	Unclaimable = 3,
	Claimable = 4,
	Special = 5,
	Owned = 6,
	EBattlePassStatusBarTypeS28_MAX = 7
};

// Enum BattlePassS28UI.ERewardWarningTooltipType28
enum class ERewardWarningTooltipType28 : uint8 {
	None = 0,
	Custom = 1,
	AgeGating = 2,
	Sparks = 3,
	DelMar = 4,
	Juno = 5,
	Max = 6
};

