// Enum BeatSyncedAnimRuntime.ESyncAnimBeatTo
enum class ESyncAnimBeatTo : uint8 {
	None = 0,
	Now = 1,
	PrevBeat = 2,
	Num = 3,
	ESyncAnimBeatTo_MAX = 4
};

// Enum BeatSyncedAnimRuntime.EBeatSyncAnimNodeLogging
enum class EBeatSyncAnimNodeLogging : uint8 {
	Enabled = 0,
	Disabled = 1,
	Default = 2,
	EBeatSyncAnimNodeLogging_MAX = 3
};

// ScriptStruct BeatSyncedAnimRuntime.AnimNode_PlayBeatSyncedAnim
// Size: 0x98 (Inherited: 0x40)
struct FAnimNode_PlayBeatSyncedAnim : FAnimNode_SequenceEvaluator {
	struct UAnimSequenceBase* InSequence; // 0x40(0x08)
	struct UMusicClockComponent* MusicClock; // 0x48(0x08)
	float PreviewBPM; // 0x50(0x04)
	bool bAlwaysAllowPreviewBPM; // 0x54(0x01)
	enum class ESyncAnimBeatTo SyncAnimBeatTo; // 0x55(0x01)
	enum class EBeatSyncAnimNodeLogging Logging; // 0x56(0x01)
	bool bSideloadedLipSync; // 0x57(0x01)
	char pad_58[0x40]; // 0x58(0x40)
};

// ScriptStruct BeatSyncedAnimRuntime.FMontageBeatSyncInfo
// Size: 0x08 (Inherited: 0x00)
struct FFMontageBeatSyncInfo {
	float PlayRate; // 0x00(0x04)
	float Offset; // 0x04(0x04)
};

