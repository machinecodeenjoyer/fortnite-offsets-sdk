// BlueprintGeneratedClass BBE_TankHonk.BBE_TankHonk_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_TankHonk_C : UFortMobileActionButtonBehaviorExtension {
};

