// BlueprintGeneratedClass BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C
// Size: 0xb83 (Inherited: 0xa90)
struct ABGA_Athena_SCMachine_Pickup_C : ABuildingGameplayActorSpawnChip {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa90(0x08)
	struct UCapsuleComponent* OverlapCollision; // 0xa98(0x08)
	struct UStaticMeshComponent* ParentMesh; // 0xaa0(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0xaa8(0x08)
	struct UAudioComponent* SC_Machine_Memory_Card_Loop_Cue; // 0xab0(0x08)
	struct UParticleSystemComponent* SpawninEffect; // 0xab8(0x08)
	struct UStaticMeshComponent* BackgroundGlow; // 0xac0(0x08)
	struct UStaticMeshComponent* Card; // 0xac8(0x08)
	int32_t UnHide; // 0xad0(0x04)
	char pad_AD4[0x4]; // 0xad4(0x04)
	double DelayBeforeUnhide; // 0xad8(0x08)
	char OwnerTeam; // 0xae0(0x01)
	char pad_AE1[0x7]; // 0xae1(0x07)
	struct FTimerHandle Timer_DestroyPickup; // 0xae8(0x08)
	struct FScalableFloat Row_PickupLife; // 0xaf0(0x28)
	struct FText InteractText; // 0xb18(0x18)
	struct UParticleSystem* SpawnOutParticle; // 0xb30(0x08)
	struct USoundBase* PickupSound; // 0xb38(0x08)
	bool SpawnSoundPlayed; // 0xb40(0x01)
	char pad_B41[0x7]; // 0xb41(0x07)
	struct USoundBase* SpawnInSound; // 0xb48(0x08)
	bool IsPendingKill; // 0xb50(0x01)
	bool HideAndKill; // 0xb51(0x01)
	char pad_B52[0x6]; // 0xb52(0x06)
	struct FScalableFloat Row_PickUpInteractTime; // 0xb58(0x28)
	bool IsDelayingDeath; // 0xb80(0x01)
	bool OwnerDiedInVortex; // 0xb81(0x01)
	bool CollectedPickup; // 0xb82(0x01)

	bool BuildDataRegistryResolverScope(struct TArray<struct FName>& InOutResolverScopes, int32_t& InOutPriority); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BuildDataRegistryResolverScope // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	struct UObject* GetCacheContextOverride(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.GetCacheContextOverride // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	void Enable Hide and Kill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Enable Hide and Kill // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Mark as Pending Kill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Mark as Pending Kill // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Mark Spawn Sound As Played(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Mark Spawn Sound As Played // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Set Un Hide(int32_t UnHide); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Set Un Hide // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Mark As Collected(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Mark As Collected // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_CollectedPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_CollectedPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float& OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	bool CanHandleCleanupEvents(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.CanHandleCleanupEvents // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	void OnRep_HideAndKill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_HideAndKill // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void OnRep_UnHide(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_UnHide // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UserConstructionScript(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void DestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DestroyPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void CollectPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.CollectPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnDestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnDestroyPickup // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void SpawnSound(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.SpawnSound // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void HideAndKillPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.HideAndKillPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void DelayDestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DelayDestroyPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void BndEvt__Collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BndEvt__Collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void BndEvt__BGA_Athena_SCMachine_Pickup_FortLinkToActor_K2Node_ComponentBoundEvent_4_OnLinkedActorDestroyed__DelegateSignature(struct AActor* DamageCauser); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BndEvt__BGA_Athena_SCMachine_Pickup_FortLinkToActor_K2Node_ComponentBoundEvent_4_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BGA_Athena_SCMachine_Pickup(int32_t EntryPoint); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ExecuteUbergraph_BGA_Athena_SCMachine_Pickup // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

