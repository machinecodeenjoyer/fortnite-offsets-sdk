// BlueprintGeneratedClass BB_NevadaTractorBeam.BB_NevadaTractorBeam_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_NevadaTractorBeam_C : UFortMobileActionButtonBehavior {
};

