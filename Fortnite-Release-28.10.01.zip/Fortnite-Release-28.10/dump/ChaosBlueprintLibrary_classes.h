// Class ChaosBlueprintLibrary.ChaosBlueprintLibraryBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UChaosBlueprintLibraryBPLibrary : UBlueprintFunctionLibrary {

	void ClothControllerWriteToSimulation(struct UCustomCharacterPartAnimInstance* CharacterPartAnimInstance, struct FString& ClothingAssetName, struct FClothCoreSettings& ClothCoreSettings, struct FClothParameters& ClothSettings, struct FVector& WindVelocity, struct FClothParameters& OutWorldSpaceClothSettings, struct FVector& OutWorldSpaceWindVelocity); // Function ChaosBlueprintLibrary.ChaosBlueprintLibraryBPLibrary.ClothControllerWriteToSimulation // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xc30aa8c
};

