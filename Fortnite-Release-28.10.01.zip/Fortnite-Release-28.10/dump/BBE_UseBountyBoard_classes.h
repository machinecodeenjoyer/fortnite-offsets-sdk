// BlueprintGeneratedClass BBE_UseBountyBoard.BBE_UseBountyBoard_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_UseBountyBoard_C : UFortMobileActionButtonBehaviorExtension {
};

