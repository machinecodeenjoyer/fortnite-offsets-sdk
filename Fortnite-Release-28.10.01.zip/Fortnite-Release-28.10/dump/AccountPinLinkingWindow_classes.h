// WidgetBlueprintGeneratedClass AccountPinLinkingWindow.AccountPinLinkingWindow_C
// Size: 0x688 (Inherited: 0x670)
struct UAccountPinLinkingWindow_C : UFortAccountPinLinkingWindow {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x670(0x08)
	struct UImage* ; // 0x678(0x08)
	struct USafeZone* ; // 0x680(0x08)

	void BndEvt__Switcher_Main_K2Node_ComponentBoundEvent_0_OnActiveWidgetChanged__DelegateSignature(struct UWidget* ActiveWidget, int32_t ActiveWidgetIndex); // Function AccountPinLinkingWindow.AccountPinLinkingWindow_C.BndEvt__Switcher_Main_K2Node_ComponentBoundEvent_0_OnActiveWidgetChanged__DelegateSignature // (BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_AccountPinLinkingWindow(int32_t EntryPoint); // Function AccountPinLinkingWindow.AccountPinLinkingWindow_C.ExecuteUbergraph_AccountPinLinkingWindow // (Final|UbergraphFunction) // @ game+0x211c0a0
};

