// BlueprintGeneratedClass BBE_NevadaSwitchSeat.BBE_NevadaSwitchSeat_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_NevadaSwitchSeat_C : UFortMobileActionButtonBehaviorExtension {
};

