// BlueprintGeneratedClass B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C
// Size: 0x17d8 (Inherited: 0x1748)
struct AB_Athena_Pickaxe_Generic_C : AFortWeaponPickaxeAthena {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1748(0x08)
	struct UParticleSystemComponent* MeleeHeavy_PSC; // 0x1750(0x08)
	struct UParticleSystem* MeleeHeavy_ParticleSystem; // 0x1758(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0x1760(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0x1768(0x08)
	bool UseDestroyEffect; // 0x1770(0x01)
	char pad_1771[0x7]; // 0x1771(0x07)
	struct UNiagaraComponent* Alteration Ambient PS; // 0x1778(0x08)
	struct FVector Effects_Color_Level; // 0x1780(0x18)
	bool Equipped; // 0x1798(0x01)
	bool bEquipPendingInstigator; // 0x1799(0x01)
	bool UseTimeofDayControl; // 0x179a(0x01)
	bool Swing_Right?; // 0x179b(0x01)
	char pad_179C[0x4]; // 0x179c(0x04)
	struct UFXSystemComponent* Impact FX; // 0x17a0(0x08)
	struct FRotator Left Swing Rotation; // 0x17a8(0x18)
	struct FRotator Right Swing Rotation; // 0x17c0(0x18)

	void Melee_Effect_Color(struct FVector& Melee_Color_Set); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.Melee_Effect_Color // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	int32_t Setup Swing Montage Section Index(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.Setup Swing Montage Section Index // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Binding Time of Day Control(bool F)); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.Binding Time of Day Control // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UnbindSwingAnimTrailEvents(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.UnbindSwingAnimTrailEvents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void BindSwingAnimTrailEvents(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.BindSwingAnimTrailEvents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayCQCPickaxeEnemyAudio(struct FHitResult Hit Result); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.PlayCQCPickaxeEnemyAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetActiveAlterationIdleParticles(bool Active, bool Reset); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.SetActiveAlterationIdleParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetWpnRarity(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UserConstructionScript(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnStatChanged_F171C56748FEA3E19F93088E968D3E21(struct FName StatName, int32_t StatValue); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnStatChanged_F171C56748FEA3E19F93088E968D3E21 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnLoaded_5BC5DA3B4E308BE7A188FBB2571333D2(struct UObject* Loaded); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnLoaded_5BC5DA3B4E308BE7A188FBB2571333D2 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void MeleeSwingRight(bool First Right); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.MeleeSwingRight // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void MeleeSwingLeft(bool First Left); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.MeleeSwingLeft // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void FootStepLeft(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.FootStepLeft // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void FootStepRight(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.FootStepRight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void MeleeSwingRight_End(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.MeleeSwingRight_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void MeleeSwingLeft_End(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.MeleeSwingLeft_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void PlayRClickImpacts(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.PlayRClickImpacts // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnEquippedWeaponDestory(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponAttached(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponDetached(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnWeaponDetached // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnInitWeaponCosmetics(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnInitWeaponCosmetics // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void HandleKillWatch(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.HandleKillWatch // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UpdateBasedOnKills(int32_t Watched Kills); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.UpdateBasedOnKills // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Anim Trails Notify(bool bActive); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.Anim Trails Notify // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Anim Trails Disable(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.Anim Trails Disable // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SwingRight(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.SwingRight // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SwingLeft(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.SwingLeft // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SwingRightEnd(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.SwingRightEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SwingLeftEnd(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.SwingLeftEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnInstigatorSet(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnInstigatorSet // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void K2_OnUnEquip(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void TODCheck(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.TODCheck // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPlayImpactFX(struct FHitResult& HitResult, enum class EPhysicalSurface ImpactPhysicalSurface, struct UFXSystemComponent* SpawnedPSC); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.OnPlayImpactFX // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void HandleWeaponHolstered(); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.HandleWeaponHolstered // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Vehicle Passenger(struct AFortPlayerPawn* FortPlayerPawn, struct AActor* NewVehicle, struct AActor* OldVehicle); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.Vehicle Passenger // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_B_Athena_Pickaxe_Generic(int32_t EntryPoint); // Function B_Athena_Pickaxe_Generic.B_Athena_Pickaxe_Generic_C.ExecuteUbergraph_B_Athena_Pickaxe_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

