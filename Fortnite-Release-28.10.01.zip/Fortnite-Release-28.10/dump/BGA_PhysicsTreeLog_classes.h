// BlueprintGeneratedClass BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C
// Size: 0xe88 (Inherited: 0xbc8)
struct ABGA_PhysicsTreeLog_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc8(0x08)
	struct UNiagaraComponent* NS_Physics_Tree_InWater_Ripples; // 0xbd0(0x08)
	struct UFortSoundIndicatorComponent* FortSoundIndicator; // 0xbd8(0x08)
	struct UCapsuleComponent* WaterInteractMiddle; // 0xbe0(0x08)
	struct UCapsuleComponent* WaterInteractBottom; // 0xbe8(0x08)
	struct UCapsuleComponent* WaterInteractTop; // 0xbf0(0x08)
	struct UNiagaraComponent* NS_Physics_Tree_Environment_Impact; // 0xbf8(0x08)
	struct TArray<struct FScalableFloat> PlayerImpactTiers; // 0xc00(0x10)
	struct TArray<struct FScalableFloat> PlayerImpulseTiers; // 0xc10(0x10)
	struct FVector LastImpactNormal; // 0xc20(0x18)
	struct FScalableFloat VerticalImpulseRatio; // 0xc38(0x28)
	struct UBuoyancyComponent* BuoyancyComponent; // 0xc60(0x08)
	double NextImminentCollisionTime; // 0xc68(0x08)
	double TimeBetweenImminentCollisions; // 0xc70(0x08)
	struct UMaterialInstanceDynamic* MatReference; // 0xc78(0x08)
	double BreakTreeDamage; // 0xc80(0x08)
	double NextPotentialLaunchTime; // 0xc88(0x08)
	double LaunchDelay; // 0xc90(0x08)
	struct FGameplayTag TreeDestructionBurstCue; // 0xc98(0x04)
	char pad_C9C[0x4]; // 0xc9c(0x04)
	struct FTransform TreeDestructionTransform; // 0xca0(0x60)
	int32_t CachedDamageValue; // 0xd00(0x04)
	char pad_D04[0x4]; // 0xd04(0x04)
	double SnowTimerValue; // 0xd08(0x08)
	struct FTimerHandle SnowRemovalTimerHandle; // 0xd10(0x08)
	struct UFXSystemComponent* WaterFxPhysicsTreeMiddle; // 0xd18(0x08)
	struct TArray<struct UFXSystemComponent*> FxSystemArray; // 0xd20(0x10)
	double WaterFxPlaneDepth; // 0xd30(0x08)
	struct FVector WaterFxPlaneLocation; // 0xd38(0x18)
	int32_t WaterFxIndex; // 0xd50(0x04)
	char pad_D54[0x4]; // 0xd54(0x04)
	struct UFXSystemComponent* WaterFxPhysicsTreeTop; // 0xd58(0x08)
	struct UFXSystemComponent* WaterFxPhysicsTreeBottom; // 0xd60(0x08)
	struct FTimerHandle WaterSurfaceInfoTimer; // 0xd68(0x08)
	struct FVector WaterFxPlaneNormal; // 0xd70(0x18)
	struct ABP_FluidSim_FN_C* FluidSim; // 0xd88(0x08)
	struct TMap<struct FName, struct FName> Sockets And Endpoints; // 0xd90(0x50)
	struct FFluidForceDynamic Fluid Force Dynamic; // 0xde0(0x70)
	double LogLength; // 0xe50(0x08)
	bool CanPlayDeathEffects; // 0xe58(0x01)
	char pad_E59[0x7]; // 0xe59(0x07)
	struct FScalableFloat bSplitWhenCutBySaber; // 0xe60(0x28)

	void CalculateSplitOffset(bool bSmallSide, double SplitPercentage, double& LocalZOffset); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.CalculateSplitOffset // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CalculateSplitScale(bool bSmallSide, double SplitPercentage, double& SplitScale); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.CalculateSplitScale // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	struct AB_PhysicsTree_Reporter_C* GetAnalyticsReporterActor(bool& Success); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.GetAnalyticsReporterActor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReportTreeFellingToAnalytics(struct AActor* FelledBy); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.ReportTreeFellingToAnalytics // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_BreakTreeDamage(); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.OnRep_BreakTreeDamage // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetPlayerImpulseVelocityFromImpactVelocity(double Impact, bool& Minimum Met, double& Impulse); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.GetPlayerImpulseVelocityFromImpactVelocity // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void (struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C. // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void LogDamaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.LogDamaged // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void RemoveSnow(); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.RemoveSnow // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CE_SplashInWater(struct FVector SplashLocation); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.CE_SplashInWater // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void AdjustWaterSettings(); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.AdjustWaterSettings // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Update Water FX(); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.Update Water FX // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AwakeStateChanged(struct UPrimitiveComponent* SimulatingComponent, bool bIsAwake); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.AwakeStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Control2dSimForces(); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.Control2dSimForces // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPontoonEnteredWater(struct FSphericalPontoon& Pontoon); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.OnPontoonEnteredWater // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPontoonExitedWater(struct FSphericalPontoon& Pontoon); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.OnPontoonExitedWater // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BGA_PhysicsTreeLog(int32_t EntryPoint); // Function BGA_PhysicsTreeLog.BGA_PhysicsTreeLog_C.ExecuteUbergraph_BGA_PhysicsTreeLog // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

