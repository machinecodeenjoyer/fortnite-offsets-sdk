// BlueprintGeneratedClass B_CosmeticStatObject_TotalRoyalRoyales.B_CosmeticStatObject_TotalRoyalRoyales_C
// Size: 0xa0 (Inherited: 0xa0)
struct UB_CosmeticStatObject_TotalRoyalRoyales_C : UFortCosmeticStatObject_TotalRoyalRoyales {
};

