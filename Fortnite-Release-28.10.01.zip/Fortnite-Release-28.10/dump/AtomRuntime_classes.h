// Class AtomRuntime.AtomAssetImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomAssetImportData : UAssetImportData {
};

// Class AtomRuntime.AtomModelMergedMeshImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomModelMergedMeshImportData : UAssetImportData {
};

// Class AtomRuntime.AtomModelGeometryCollectionImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomModelGeometryCollectionImportData : UAssetImportData {
};

// Class AtomRuntime.AtomDatabaseSubsystemBase
// Size: 0x30 (Inherited: 0x30)
struct UAtomDatabaseSubsystemBase : UEngineSubsystem {
};

// Class AtomRuntime.AtomModelActor
// Size: 0x2a8 (Inherited: 0x290)
struct AAtomModelActor : AActor {
	struct UAtomModel* AtomModel; // 0x290(0x08)
	struct FString PrimitiveStyleName; // 0x298(0x10)
};

// Class AtomRuntime.AtomModelAssetUserData
// Size: 0xc8 (Inherited: 0x28)
struct UAtomModelAssetUserData : UAssetUserData {
	struct TSoftObjectPtr<UAtomModel> AtomModelAsset; // 0x28(0x20)
	struct FSerializedConnectivityObjects AtomModelConnections; // 0x48(0x20)
	struct FAtomCommonPartInstancesCache CommonPartCache; // 0x68(0x50)
	struct TArray<struct FName> Tags; // 0xb8(0x10)
};

// Class AtomRuntime.AtomCommonPartModelAssetUserData
// Size: 0x38 (Inherited: 0x28)
struct UAtomCommonPartModelAssetUserData : UAssetUserData {
	struct FAtomCommonPartAssetDescription AssetDescription; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class AtomRuntime.AtomPartsCollectionBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomPartsCollectionBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetName(struct FAtomModelPartsCollection& PartsCollection, struct FString Name); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.SetName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb85853c
	void ReplacePartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartInstanceInfo& SourcePartInstance, struct FAtomModelPartGuid& TargetPartInstanceId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.ReplacePartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb857cb0
	void RemovePartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartGuid& PartInstanceId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.RemovePartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb857b9c
	struct FAtomModelPartsCollection InitializeCommonParts(struct FAtomModelPartsCollection& PartsCollection, struct UAtomModel* Model, float Scale, bool bRemoveConnectedParts, bool bRemoveAllKnobs, bool bRemoveAllTubes, bool bRemoveAllPins); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.InitializeCommonParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb857560
	struct TArray<struct FAtomModelPartInstanceInfo> GetParts(struct FAtomModelPartsCollection& PartsCollection); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb857498
	struct FString GetName(struct FAtomModelPartsCollection& PartsCollection); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb856cf8
	struct FAtomModelPartsCollection FilterTransparent(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterTransparent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb856aac
	struct FAtomModelPartsCollection FilterSelectionSet(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString SelectionSetName, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterSelectionSet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb8567c4
	struct FAtomModelPartsCollection FilterNonTransparent(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterNonTransparent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb8565dc
	struct FAtomModelPartsCollection FilterGroup(struct UAtomModel* Model, struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString GroupName, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterGroup // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb8562b8
	struct FAtomModelPartColorInfo CreateColorInfoFromColorId(int32_t ColorId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.CreateColorInfoFromColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb856174
	struct FAtomModelPartGuid Conv_StringToModelPartGuid(struct FString InString); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_StringToModelPartGuid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb8553b4
	struct FString Conv_ModelPartGuidToString(struct FAtomModelPartGuid& InModelPartGuid); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_ModelPartGuidToString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb855300
	void AddPartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartInstanceInfo& PartInstance); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.AddPartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb854ca4
};

// Class AtomRuntime.AtomPrimitiveBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomPrimitiveBlueprintLibrary : UBlueprintFunctionLibrary {

	float GetDefaultPrimitiveScale(); // Function AtomRuntime.AtomPrimitiveBlueprintLibrary.GetDefaultPrimitiveScale // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb856c94
};

// Class AtomRuntime.AtomPrimitiveGeometry
// Size: 0x2e8 (Inherited: 0x28)
struct UAtomPrimitiveGeometry : UObject {
	char pad_28[0x2c0]; // 0x28(0x2c0)

	struct UStaticMesh* ToSimplifiedStaticMesh(float Scale, struct UObject* Outer, struct FString Name, bool bFastBuild); // Function AtomRuntime.AtomPrimitiveGeometry.ToSimplifiedStaticMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb858890
	struct TArray<struct UAtomPrimitiveGeometry*> SplitByPolygonGroup(); // Function AtomRuntime.AtomPrimitiveGeometry.SplitByPolygonGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb858824
	struct UAtomPrimitiveGeometry* SetVertexColor(struct FColor& Color); // Function AtomRuntime.AtomPrimitiveGeometry.SetVertexColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb85878c
	struct UAtomPrimitiveGeometry* SetTiledUVs(float TileSize); // Function AtomRuntime.AtomPrimitiveGeometry.SetTiledUVs // (Final|Native|Public|BlueprintCallable) // @ game+0xb8586fc
	struct UAtomPrimitiveGeometry* SetMaterialName(struct FString Name, int32_t PolygonGroupIndex); // Function AtomRuntime.AtomPrimitiveGeometry.SetMaterialName // (Final|Native|Public|BlueprintCallable) // @ game+0xb857e68
	int32_t GetNumberOfCommonPartLODs(struct FString ExportStyleName, enum class EAtomCommonPartType CommonPartType); // Function AtomRuntime.AtomPrimitiveGeometry.GetNumberOfCommonPartLODs // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb856dd4
	struct TArray<struct FString> GetMaterialNames(); // Function AtomRuntime.AtomPrimitiveGeometry.GetMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb856cbc
	struct UAtomPrimitiveGeometry* DuplicateGeometry(); // Function AtomRuntime.AtomPrimitiveGeometry.DuplicateGeometry // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb85627c
	struct UAtomPrimitiveGeometry* CreateEmptyAtomGeometry(); // Function AtomRuntime.AtomPrimitiveGeometry.CreateEmptyAtomGeometry // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb856228
	struct UAtomPrimitiveGeometry* CreateAtomGeometryFromCommonPart(struct FString ExportStyleName, enum class EAtomCommonPartType CommonPartType, int32_t LODIndex); // Function AtomRuntime.AtomPrimitiveGeometry.CreateAtomGeometryFromCommonPart // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb855a7c
	struct UAtomPrimitiveGeometry* BakeTransforms(struct TArray<struct FTransform3f>& Transforms); // Function AtomRuntime.AtomPrimitiveGeometry.BakeTransforms // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb855254
	struct UAtomPrimitiveGeometry* BakeTransform(struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.BakeTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb855188
	struct UAtomPrimitiveGeometry* BakeScale(float Scale); // Function AtomRuntime.AtomPrimitiveGeometry.BakeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xb8550f8
	struct UAtomPrimitiveGeometry* AppendAndWeld(struct UAtomPrimitiveGeometry* GeometryToAppend, struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.AppendAndWeld // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb854f58
	struct UAtomPrimitiveGeometry* Append(struct UAtomPrimitiveGeometry* GeometryToAppend, struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.Append // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb854e08
};

// Class AtomRuntime.AtomPrimitiveGeometryContainer
// Size: 0xf8 (Inherited: 0x28)
struct UAtomPrimitiveGeometryContainer : UObject {
	struct TSoftObjectPtr<UStaticMesh> SourceMesh; // 0x28(0x20)
	struct FString ExportStyleName; // 0x48(0x10)
	struct TMap<struct FString, int32_t> GeometryCount; // 0x58(0x50)
	char pad_A8[0x50]; // 0xa8(0x50)

	struct FAtomPrimitiveGeometryAndTransform GetShellGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetShellGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85d338
	struct FAtomPrimitiveGeometryAndTransform GetScaledShellGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledShellGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85d284
	struct UAtomPrimitiveGeometry* GetScaledGeometry(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85d1c0
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledDetailsGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledDetailsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85d118
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledCapsGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85d070
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetPartsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetPartsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85cd28
	struct UAtomPrimitiveGeometry* GetGeometryWithMaterialNames(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, struct FString ShellMaterial, struct FString UndersideMaterial); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometryWithMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85c290
	struct UAtomPrimitiveGeometry* GetGeometry(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85c200
	struct FString GetExportStyleName(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetExportStyleName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa4ed544
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetDetailsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetDetailsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85c080
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetCapsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85b278
};

// Class AtomRuntime.AtomRuntimeBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomRuntimeBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FAtomColorInfo GetInfoForColorId(int32_t ColorId); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetInfoForColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb85c9b8
	void GetCommonPartDescriptionFromType(enum class EAtomCommonPartType CommonPartType, struct FAtomCommonPartDescription& OutDescription); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartDescriptionFromType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb85b868
	enum class EAtomCommonPartCategory GetCommonPartCategoryFromType(enum class EAtomCommonPartType CommonPartType); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartCategoryFromType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb85b7e8
	void GetCommonPartAssetDescriptionFromStaticMesh(struct UStaticMesh* StaticMesh, struct FAtomCommonPartAssetDescription& OutDescription, enum class EGetCommonPartDescriptionResult& OutIsValid); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartAssetDescriptionFromStaticMesh // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb85b668
	int32_t GetBitPackForColorId(int32_t AtomColorId); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb85b1c0
	int32_t GetBitPackForColor(struct FColor& Color); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColor // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xb85b128
	struct TMap<int32_t, struct FAtomColorInfo> GetAllColorInfo(); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetAllColorInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb85b004
};

// Class AtomRuntime.AtomRuntimeSettings
// Size: 0x78 (Inherited: 0x30)
struct UAtomRuntimeSettings : UDeveloperSettings {
	float PrimitiveGlobalScale; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TSoftObjectPtr<UDataTable> ColorDataTableOverride; // 0x38(0x20)
	float CommonPartsScale; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FDirectoryPath CommonPartMeshesBasePath; // 0x60(0x10)
	bool bEnableWorldConnectivity; // 0x70(0x01)
	bool bCookContent; // 0x71(0x01)
	char pad_72[0x6]; // 0x72(0x06)

	struct UDataTable* GetColorDataTable(); // Function AtomRuntime.AtomRuntimeSettings.GetColorDataTable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb85b644
};

// Class AtomRuntime.WorldConnectivitySubsystem
// Size: 0x180 (Inherited: 0x30)
struct UWorldConnectivitySubsystem : UWorldSubsystem {
	char pad_30[0x150]; // 0x30(0x150)

	void UnregisterConnectivityActor(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.UnregisterConnectivityActor // (Final|Native|Public|BlueprintCallable) // @ game+0xb85e6dc
	bool TryConnectObjectAtLocation(struct FWorldConnectivityHandle ObjectToConnect, struct FTransform& DesiredObjectTransform, struct TArray<struct FWorldConnectivityHandle>& ConnectionCandidates, bool PerformConnection); // Function AtomRuntime.WorldConnectivitySubsystem.TryConnectObjectAtLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb85dd28
	struct TArray<struct FConnectivityQueryResult> RunPlanarConnectivityQuery(struct AActor* AtomModelActorToPlace, struct AActor* AtomModelActorToConnect, struct FVector& QueryStartLocation, struct FVector& QueryEndLocation, enum class ECollisionChannel QueryCollisionChannel, int32_t QueryRadius); // Function AtomRuntime.WorldConnectivitySubsystem.RunPlanarConnectivityQuery // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb85d844
	void RegisterModelActor(struct AActor* Actor, struct FSerializedConnectivityObjects& Connections); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterModelActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb85d750
	void RegisterCustomConnectivityActor(struct AActor* Actor, struct FSerializedConnectivityObjects& ConnectivityObject); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterCustomConnectivityActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb85d750
	void RegisterConnectivityActor(struct AActor* Actor, struct UAtomModel* Model); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterConnectivityActor // (Final|Native|Public|BlueprintCallable) // @ game+0xb85d680
	double PlanarGridStepSize(); // Function AtomRuntime.WorldConnectivitySubsystem.PlanarGridStepSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb85d660
	struct FTransform GetTransform(struct FWorldConnectivityHandle Handle); // Function AtomRuntime.WorldConnectivitySubsystem.GetTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb85d4f8
	struct TArray<struct FPlanarFieldInfo> GetPlanarFields(struct FWorldConnectivityHandle Handle, enum class EConnectionFieldGender Type); // Function AtomRuntime.WorldConnectivitySubsystem.GetPlanarFields // (Final|Native|Public|BlueprintCallable) // @ game+0xb85ce40
	struct FVector GetPlanarFieldCenter(struct FPlanarFieldInfo& Field); // Function AtomRuntime.WorldConnectivitySubsystem.GetPlanarFieldCenter // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xb85cd64
	struct FVector GetOverlapPenetrationDepth(struct AStaticMeshActor* Actor1, struct AStaticMeshActor* Actor2, struct FVector Offset); // Function AtomRuntime.WorldConnectivitySubsystem.GetOverlapPenetrationDepth // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb85ca64
	struct TArray<struct FWorldConnectivityHandle> GetConnectivityHandles(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandles // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb85be3c
	struct FWorldConnectivityHandle GetConnectivityHandle(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb85bc04
	struct TArray<struct FWorldConnectivityHandle> GetConnectedObjectsRecursively(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjectsRecursively // (Final|Native|Public|BlueprintCallable) // @ game+0xb85baac
	struct TArray<struct FWorldConnectivityHandle> GetConnectedObjects(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjects // (Final|Native|Public|BlueprintCallable) // @ game+0xb85b954
	struct FPlanarFieldInfo GetClosestFieldToPoint(struct FWorldConnectivityHandle Handle, struct FVector& WorldLocation, enum class EConnectionFieldGender Type, bool& bSuccess); // Function AtomRuntime.WorldConnectivitySubsystem.GetClosestFieldToPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb85b2b4
	struct UAtomModelAssetUserData* GetAtomModelAssetUserData(struct UObject* Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetAtomModelAssetUserData // (Final|Native|Public|BlueprintCallable) // @ game+0xb85b0a8
	struct AActor* GetActor(struct FWorldConnectivityHandle Handle); // Function AtomRuntime.WorldConnectivitySubsystem.GetActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb85aec4
	void DisconnectObjects(struct FWorldConnectivityHandle ObjectA, struct FWorldConnectivityHandle ObjectB); // Function AtomRuntime.WorldConnectivitySubsystem.DisconnectObjects // (Final|Native|Public|BlueprintCallable) // @ game+0xb85abb4
	void DisconnectAllObjectConnections(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.DisconnectAllObjectConnections // (Final|Native|Public|BlueprintCallable) // @ game+0xb85aa84
};

// Class AtomRuntime.WorldConnectivityBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWorldConnectivityBlueprintLibrary : UBlueprintFunctionLibrary {

	bool IsValid(struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa22b9e0
	struct FTransform GetTransform(struct UObject* WorldContext, struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xb85d3a8
	struct FVector GetFieldCenter(struct UObject* WorldContext, struct FPlanarFieldInfo& Field); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetFieldCenter // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xb85c0bc
	struct AActor* GetActor(struct UObject* WorldContext, struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb85adcc
};

// Class AtomRuntime.AtomModel
// Size: 0x258 (Inherited: 0x28)
struct UAtomModel : UObject {
	struct FAtomModelAssetSettings Settings; // 0x28(0x38)
	struct TArray<struct FAtomModelPrimitive> Primitives; // 0x60(0x10)
	struct TArray<struct FAtomHingedElement> Elements; // 0x70(0x10)
	struct TArray<struct FAtomModelSelectionSet> SelectionSets; // 0x80(0x10)
	struct TArray<struct FAtomModelConfigurationGroup> Groups; // 0x90(0x10)
	struct TMap<enum class EAtomCommonPartType, struct TSoftObjectPtr<UStaticMesh>> CommonPartOverrides; // 0xa0(0x50)
	char CommonPartOptimization; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct FSerializedConnectivityObjects SerializedConnectivityObjects; // 0xf8(0x20)
	struct TMap<struct FString, struct TSoftObjectPtr<UTexture>> TextureNameToAsset; // 0x118(0x50)
	char pad_168[0x50]; // 0x168(0x50)
	struct FAtomSourceModel SourceModel; // 0x1b8(0xa0)

	struct UTexture* GetTextureForDecorationTextureName(struct FString TextureName); // Function AtomRuntime.AtomModel.GetTextureForDecorationTextureName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb88acf4
	void GetPrimitivesForChildArray(int32_t InChildIdx, struct TArray<struct FAtomModelPrimitiveInstance>& OutPrimitives); // Function AtomRuntime.AtomModel.GetPrimitivesForChildArray // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb88a4d4
	struct FAtomModelPartsCollection GetPartsCollection(); // Function AtomRuntime.AtomModel.GetPartsCollection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb88a470
	struct FString GetModelPath(); // Function AtomRuntime.AtomModel.GetModelPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb88a314
	struct FString GetModelName(); // Function AtomRuntime.AtomModel.GetModelName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb88a2d4
	struct TArray<struct TSoftObjectPtr<UStaticMesh>> GetGeneratedMergedMeshes(); // Function AtomRuntime.AtomModel.GetGeneratedMergedMeshes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb889adc
	struct FString GetChildIdentifier(int32_t InChildIdx); // Function AtomRuntime.AtomModel.GetChildIdentifier // (Final|Native|Public|BlueprintCallable) // @ game+0xb889450
};

// Class AtomRuntime.AtomModelComponent
// Size: 0x330 (Inherited: 0x290)
struct UAtomModelComponent : USceneComponent {
	struct UAtomModel* AtomModel; // 0x290(0x08)
	enum class EAtomModelInstanceType InstanceType; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct FString RenderStyle; // 0x2a0(0x10)
	struct FString FallbackRenderStyle; // 0x2b0(0x10)
	bool bUseCombinedMeshes; // 0x2c0(0x01)
	bool bUseColorPayload; // 0x2c1(0x01)
	bool bCreateRigidElements; // 0x2c2(0x01)
	bool bEnableConnectivity; // 0x2c3(0x01)
	struct FName SelectionSetFilter; // 0x2c4(0x04)
	char CommonPartOptimization; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct TArray<struct USceneComponent*> RigidElementComponents; // 0x2d0(0x10)
	struct TMap<struct FName, struct FModelPrimitiveEntry> ComponentToPrimitive; // 0x2e0(0x50)
};

// Class AtomRuntime.AtomPrimitiveComponent
// Size: 0x660 (Inherited: 0x630)
struct UAtomPrimitiveComponent : UStaticMeshComponent {
	struct UAtomPrimitive* AtomPrimitive; // 0x630(0x08)
	struct FString RenderStyle; // 0x638(0x10)
	struct FString FallbackRenderStyle; // 0x648(0x10)
	bool bUseCombinedMeshes; // 0x658(0x01)
	char pad_659[0x7]; // 0x659(0x07)
};

// Class AtomRuntime.AtomModelProcessor
// Size: 0x58 (Inherited: 0x28)
struct UAtomModelProcessor : UObject {
	bool bEnableRebuildProgress; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float DialogDelay; // 0x2c(0x04)
	int32_t NumProgressSteps; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString ProgressMessage; // 0x38(0x10)
	char pad_48[0x10]; // 0x48(0x10)

	struct FAtomProcessorResult OnProcessPrimitive(struct UAtomModel* DummyModel, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct FAtomOnProcessPrimitiveSettings& Settings); // Function AtomRuntime.AtomModelProcessor.OnProcessPrimitive // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	struct FAtomProcessorResult OnProcessModel(struct UAtomModel* Model, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct TArray<struct TSoftObjectPtr<UObject>>& ExistingObjects); // Function AtomRuntime.AtomModelProcessor.OnProcessModel // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	struct FString OnGetTargetAssetPath(struct UAtomModel* Model, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection); // Function AtomRuntime.AtomModelProcessor.OnGetTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	struct FString OnGetProcessPrimitiveTargetAssetPath(struct UAtomModel* Model, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct FAtomOnProcessPrimitiveSettings& Settings); // Function AtomRuntime.AtomModelProcessor.OnGetProcessPrimitiveTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	struct FString OnGetProcessModelTargetAssetPath(struct UAtomModel* Model, struct FAtomModelPartsCollection& AtomModelPartsCollection); // Function AtomRuntime.AtomModelProcessor.OnGetProcessModelTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void IncrementProgress(int32_t NumSteps, struct FString Message); // Function AtomRuntime.AtomModelProcessor.IncrementProgress // (Final|Native|Public|BlueprintCallable) // @ game+0xb88b3a4
};

// Class AtomRuntime.AtomProcessorBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomProcessorBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetModelProcessor(struct FAtomModelProcessorInstance& ProcessorInstance, struct UAtomModelProcessor* ModelProcessor, bool bUseCustomSettings); // Function AtomRuntime.AtomProcessorBlueprintLibrary.SetModelProcessor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb88bbb4
	bool IsValid(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb88bae8
	struct UObject* GetProcessorClass(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.GetProcessorClass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb88ab9c
	struct UAtomModelProcessor* GetModelProcessor(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.GetModelProcessor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb88a378
	struct FAtomProcessorResult AppendAtomProcessorResult(struct FAtomProcessorResult& Result, struct FAtomProcessorResult& ResultToAppend); // Function AtomRuntime.AtomProcessorBlueprintLibrary.AppendAtomProcessorResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb8892b8
};

// Class AtomRuntime.AtomPrimitive
// Size: 0x1f0 (Inherited: 0x28)
struct UAtomPrimitive : UObject {
	int32_t PartId; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FString PartRevision; // 0x30(0x10)
	struct FName DesignName; // 0x40(0x04)
	bool bIsFlex; // 0x44(0x01)
	bool bIsVariant; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	struct TArray<struct FString> DecorationSurfaceNames; // 0x48(0x10)
	int32_t NumberOfColorSurfaces; // 0x58(0x04)
	enum class EAtomPlatform AtomPlatform; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	int32_t AtomMainGroupId; // 0x60(0x04)
	int32_t AtomSubMainGroupId; // 0x64(0x04)
	struct TMap<enum class EAtomCommonPartType, struct FAtomPrimitiveCommonPart> PrimitiveCommonParts; // 0x68(0x50)
	struct TMap<struct FName, struct FAtomPrimitiveCommonPart> CommonParts; // 0xb8(0x50)
	bool bOverrideConnectionFields; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FBoxSphereBounds Bounds; // 0x110(0x38)
	struct FBoxSphereBounds UnscaledBounds; // 0x148(0x38)
	struct TArray<struct UAtomPrimitiveGeometryContainer*> GeometryContainers; // 0x180(0x10)
	struct FConnectionFieldContainer ConnectionFields; // 0x190(0x30)
	struct FConnectionFieldContainer ConnectionFieldsOverride; // 0x1c0(0x30)

	bool IsFlexElement(); // Function AtomRuntime.AtomPrimitive.IsFlexElement // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb88bad4
	struct FName GetSubMainGroupName(int32_t SubMainGroupId); // Function AtomRuntime.AtomPrimitive.GetSubMainGroupName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb88ac70
	struct FName GetMainGroupName(int32_t MainGroupId); // Function AtomRuntime.AtomPrimitive.GetMainGroupName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb88a250
	struct UAtomPrimitiveGeometryContainer* GetGeometryContainerForExportStyle(struct FString ExportStyleName, struct FString FallbackExportStyleName); // Function AtomRuntime.AtomPrimitive.GetGeometryContainerForExportStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb889b68
};

