// BlueprintGeneratedClass Border-PowerBar.Border-PowerBar_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-PowerBar_C : UCommonBorderStyle {
};

