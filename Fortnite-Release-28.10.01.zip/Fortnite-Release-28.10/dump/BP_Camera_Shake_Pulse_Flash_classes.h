// BlueprintGeneratedClass BP_Camera_Shake_Pulse_Flash.BP_Camera_Shake_Pulse_Flash_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UBP_Camera_Shake_Pulse_Flash_C : ULegacyCameraShake {
};

