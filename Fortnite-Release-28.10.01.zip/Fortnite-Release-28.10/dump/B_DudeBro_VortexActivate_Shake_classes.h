// BlueprintGeneratedClass B_DudeBro_VortexActivate_Shake.B_DudeBro_VortexActivate_Shake_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UB_DudeBro_VortexActivate_Shake_C : ULegacyCameraShake {
};

