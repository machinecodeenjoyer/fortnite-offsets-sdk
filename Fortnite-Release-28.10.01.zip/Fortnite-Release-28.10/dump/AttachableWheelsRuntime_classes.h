// Class AttachableWheelsRuntime.AttachableWheel
// Size: 0x328 (Inherited: 0x290)
struct AAttachableWheel : AActor {
	struct UStaticMeshComponent* WheelMeshComponent; // 0x290(0x08)
	struct FRotator WheelOrientation; // 0x298(0x18)
	float WheelDistance; // 0x2b0(0x04)
	float AxleDamping; // 0x2b4(0x04)
	struct UPhysicsConstraintComponent* AxleConstraint; // 0x2b8(0x08)
	struct FAttachableWheelAttachData AttachData; // 0x2c0(0x58)
	bool bAutoCreateAttachableWheelsComponent; // 0x318(0x01)
	bool bEnableWheelWheelCollision; // 0x319(0x01)
	char pad_31A[0x6]; // 0x31a(0x06)
	struct AActor* ActorRef; // 0x320(0x08)

	void SetAxleDamping(float InWheelDamping); // Function AttachableWheelsRuntime.AttachableWheel.SetAxleDamping // (Final|Native|Protected|BlueprintCallable) // @ game+0xb453f60
	void SetActorRef(struct AActor* NewActorRef); // Function AttachableWheelsRuntime.AttachableWheel.SetActorRef // (Native|Public|BlueprintCallable) // @ game+0x849f430
	void OnRep_AttachData(struct FAttachableWheelAttachData& AttachDataPrev); // Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData // (Final|Native|Protected|HasOutParms) // @ game+0xb453ea8
	void OnPhysicsStateChanged(struct UPrimitiveComponent* PrimitiveComponent, enum class EComponentPhysicsStateChange StateChange); // Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged // (Final|Native|Protected) // @ game+0xb453de4
	void OnDetached(struct UPrimitiveComponent* DetachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnDetached // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnAttached(struct UPrimitiveComponent* AttachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnAttached // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	bool GetWorldSpaceAttachData(struct FAttachableWheelAttachData& OutAttachData, struct UPrimitiveComponent* PrimitiveComponent, struct FName BodyName); // Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb453a54
	struct UPrimitiveComponent* GetAttachedComponent(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb453790
	struct FAttachableWheelAttachData GetAttachData(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb453738
	struct AActor* GetActorRef(); // Function AttachableWheelsRuntime.AttachableWheel.GetActorRef // (Final|Native|Public|BlueprintCallable) // @ game+0x3f21d5c
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheel.DrawDebug // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x32e4b44
	bool DetachFrom(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.DetachFrom // (Final|Native|Public|BlueprintCallable) // @ game+0xb453690
	void Detach(); // Function AttachableWheelsRuntime.AttachableWheel.Detach // (Final|Native|Public|BlueprintCallable) // @ game+0xb4535fc
	bool AttachTo(struct UPrimitiveComponent* InComponent, struct FVector& WorldLocation, struct FVector& AxleDirection); // Function AttachableWheelsRuntime.AttachableWheel.AttachTo // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb45345c
	bool AttachInPlace(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace // (Final|Native|Public|BlueprintCallable) // @ game+0xb4533cc
};

// Class AttachableWheelsRuntime.AttachableWheelsComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UAttachableWheelsComponent : UActorComponent {
	struct TSet<struct AAttachableWheel*> AttachedWheels; // 0xa0(0x50)

	void OnWheelDetached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnWheelAttached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	bool HandleWheelDetached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal // (Final|Native|Protected) // @ game+0xb453d54
	bool HandleWheelAttached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal // (Final|Native|Protected) // @ game+0xb453cc4
	struct TArray<struct AAttachableWheel*> GetAttachedWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4539e8
	struct AAttachableWheel* GetAttachedWheelClosestOnAxis(struct FVector& Point, float& OutClosetDistanceToAxis, struct FVector& OutClosestPointOnAxis, struct FVector& OutClosestAxis); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4537b4
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x32e4b44
	int32_t DetachAllWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb453610
};

