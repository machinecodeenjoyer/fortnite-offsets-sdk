// Class AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAutoAimWeaponKismetLibrary : UBlueprintFunctionLibrary {

	struct UAutoAimWeaponPawnComponent* GetAutoAimWeaponPawnComponent(struct AFortPawn* SourcePawn); // Function AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.GetAutoAimWeaponPawnComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2e51744
	void FindBestAutoAimTarget(struct AFortPawn*& OutTargetPawn, float& OutReticleDistance, struct AFortPlayerPawn* SourcePawn, float ReticleSize, float Range); // Function AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.FindBestAutoAimTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb24d9d0
	bool DoesAutoAimWeaponReticleIntersectTarget(float& OutReticleDistance, struct AFortPawn* SourcePawn, struct AFortPawn* TargetPawn, float ReticleSize); // Function AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.DoesAutoAimWeaponReticleIntersectTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb24d7a8
	bool DoesAutoAimWeaponHaveLineOfSight(struct AFortPawn* SourcePawn, struct AFortPawn* TargetPawn); // Function AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.DoesAutoAimWeaponHaveLineOfSight // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb24d6d4
};

// Class AutoAimWeaponRuntime.AutoAimWeaponPawnComponent
// Size: 0x188 (Inherited: 0xa8)
struct UAutoAimWeaponPawnComponent : UFortPawnComponent {
	struct FGameplayTagContainer UseSingleLocationTargetingPawnTags; // 0xa8(0x20)
	struct FGameplayTagContainer LowPriorityTargetPawnTags; // 0xc8(0x20)
	struct TArray<struct FAutoAimWeaponBoneSegmentData> MultiSocketTargetingBoneSegmentDatas; // 0xe8(0x10)
	struct FScalableFloat LockOnTimeReticleCenter; // 0xf8(0x28)
	struct FScalableFloat LockOnTimeReticleEdge; // 0x120(0x28)
	struct FScalableFloat MaxLockOns; // 0x148(0x28)
	float ProgressTowardNextLockOn; // 0x170(0x04)
	int32_t CurrentLockOnCount; // 0x174(0x04)
	float TargetToReticleDistanceNormalized; // 0x178(0x04)
	struct TWeakObjectPtr<struct AFortPawn> LockOnTarget; // 0x17c(0x08)
	char pad_184[0x4]; // 0x184(0x04)

	float GetTargetToReticleDistanceNormalized(); // Function AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetTargetToReticleDistanceNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x62b2060
	bool GetLockOnTargetLocation(struct FVector& OutLockTargetLocation); // Function AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetLockOnTargetLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const) // @ game+0x2e4ff9c
	float GetLockOnProgress(); // Function AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetLockOnProgress // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2d8164c
	int32_t GetCurrentLockOnCount(); // Function AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetCurrentLockOnCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb24dda8
};

