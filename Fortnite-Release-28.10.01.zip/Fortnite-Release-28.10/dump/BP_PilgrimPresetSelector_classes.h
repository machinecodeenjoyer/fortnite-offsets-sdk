// BlueprintGeneratedClass BP_PilgrimPresetSelector.BP_PilgrimPresetSelector_C
// Size: 0x58 (Inherited: 0x48)
struct UBP_PilgrimPresetSelector_C : UPilgrimPresetSelector {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x48(0x08)
	struct UPilgrimPresetSwitcher* As Pilgrim Preset Switcher Widget; // 0x50(0x08)

	void OnComplete_274EE33944C9AE07DF8BE0B56A5DE4BC(struct UUserWidget* UserWidget); // Function BP_PilgrimPresetSelector.BP_PilgrimPresetSelector_C.OnComplete_274EE33944C9AE07DF8BE0B56A5DE4BC // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void DialogResult_4F9481524E7A6435C967A0AEA571B86B(enum class EFortDialogResult Result, struct FName ResultName); // Function BP_PilgrimPresetSelector.BP_PilgrimPresetSelector_C.DialogResult_4F9481524E7A6435C967A0AEA571B86B // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPresetSelectionRequested(struct APlayerController* Player); // Function BP_PilgrimPresetSelector.BP_PilgrimPresetSelector_C.OnPresetSelectionRequested // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BP_PilgrimPresetSelector(int32_t EntryPoint); // Function BP_PilgrimPresetSelector.BP_PilgrimPresetSelector_C.ExecuteUbergraph_BP_PilgrimPresetSelector // (Final|UbergraphFunction) // @ game+0x211c0a0
};

