// BlueprintGeneratedClass AnimNotify_NiagaraNotify_SetBodyType.AnimNotify_NiagaraNotify_SetBodyType_C
// Size: 0xa0 (Inherited: 0x88)
struct UAnimNotify_NiagaraNotify_SetBodyType_C : UFortAnimNotifyState_TimedNiagaraEffectVariant {
	enum class EFortCustomPartType Part Type; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FString Skeletal Mesh User Name; // 0x90(0x10)

	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration, struct FAnimNotifyEventReference& EventReference); // Function AnimNotify_NiagaraNotify_SetBodyType.AnimNotify_NiagaraNotify_SetBodyType_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
};

