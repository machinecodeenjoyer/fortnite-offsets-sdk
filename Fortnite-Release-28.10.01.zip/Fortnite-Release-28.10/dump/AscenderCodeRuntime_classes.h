// Class AscenderCodeRuntime.FortCheatManager_AscenderZipline
// Size: 0x28 (Inherited: 0x28)
struct UFortCheatManager_AscenderZipline : UChildCheatManager {

	void RemoveAscenders(bool bRemoveAscendersOn); // Function AscenderCodeRuntime.FortCheatManager_AscenderZipline.RemoveAscenders // (Final|Exec|Native|Public) // @ game+0x60325ec
};

// Class AscenderCodeRuntime.FortAscenderZipline
// Size: 0xff0 (Inherited: 0xc98)
struct AFortAscenderZipline : AFortAthenaSplineZipline {
	struct FMulticastInlineDelegate OnAscenderSetupComplete; // 0xc98(0x10)
	struct FName SplineTopAttachPointName; // 0xca8(0x04)
	bool bAutoFindSplineEndLocation; // 0xcac(0x01)
	char pad_CAD[0x3]; // 0xcad(0x03)
	float SplineOffsetFromGround; // 0xcb0(0x04)
	float CableOffsetFromSplineEnd; // 0xcb4(0x04)
	float SplineLength; // 0xcb8(0x04)
	char pad_CBC[0x4]; // 0xcbc(0x04)
	struct UStaticMesh* SplineStaticMesh; // 0xcc0(0x08)
	enum class ESplineMeshAxis MeshForwardAxis; // 0xcc8(0x01)
	bool bHandleReturning; // 0xcc9(0x01)
	char pad_CCA[0x2]; // 0xcca(0x02)
	float HandleReturnSpeed; // 0xccc(0x04)
	bool bCableDropping; // 0xcd0(0x01)
	char pad_CD1[0x3]; // 0xcd1(0x03)
	float CableDropSpeed; // 0xcd4(0x04)
	float YawRotationOffsetWhileUsingHandle; // 0xcd8(0x04)
	float YawRotationOffsetWhileSlidingDown; // 0xcdc(0x04)
	bool bUseComplexSplineCollision; // 0xce0(0x01)
	char pad_CE1[0x3]; // 0xce1(0x03)
	float SimpleSplineCollisionRadius; // 0xce4(0x04)
	float SimpleSplineCollisionHeightExtension; // 0xce8(0x04)
	char pad_CEC[0x4]; // 0xcec(0x04)
	struct FScalableFloat DescendMinDistanceFromBottom; // 0xcf0(0x28)
	struct FScalableFloat AscendReachedEndHorizontalLaunchSpeed; // 0xd18(0x28)
	struct FScalableFloat AscendReachedEndVerticalLaunchSpeed; // 0xd40(0x28)
	struct FScalableFloat AscendJumpedOffHorizontalLaunchSpeed; // 0xd68(0x28)
	struct FScalableFloat AscendJumpedOffVerticalLaunchSpeed; // 0xd90(0x28)
	struct FScalableFloat DescendReachedEndHorizontalLaunchSpeed; // 0xdb8(0x28)
	struct FScalableFloat DescendReachedEndVerticalLaunchSpeed; // 0xde0(0x28)
	struct FScalableFloat DescendJumpedOffHorizontalLaunchSpeed; // 0xe08(0x28)
	struct FScalableFloat DescendJumpedOffVerticalLaunchSpeed; // 0xe30(0x28)
	struct FScalableFloat HandleActorHitPlayerHorizontalLaunchSpeed; // 0xe58(0x28)
	struct FScalableFloat HandleActorHitPlayerVerticalLaunchSpeed; // 0xe80(0x28)
	struct FVector HandleDestroyBuildingsOverlapExtents; // 0xea8(0x18)
	struct FVector PlayerDestroyBuildingsOverlapExtents; // 0xec0(0x18)
	struct FVector InitialSplineEndLocation; // 0xed8(0x18)
	struct FVector CurrentSplineEndLocation; // 0xef0(0x18)
	struct FVector TargetSplineEndLocation; // 0xf08(0x18)
	struct FVector CurrentHandleLocation; // 0xf20(0x18)
	struct TWeakObjectPtr<struct UPrimitiveComponent> CurrentInteractComponent; // 0xf38(0x08)
	struct TWeakObjectPtr<struct AFortPlayerPawn> PawnUsingHandle; // 0xf40(0x08)
	struct TWeakObjectPtr<struct AFortPlayerPawn> PreviousPawnUsingHandle; // 0xf48(0x08)
	struct USplineMeshComponent* SplineMesh; // 0xf50(0x08)
	struct UCapsuleComponent* SimpleSplineMeshCollision; // 0xf58(0x08)
	struct TWeakObjectPtr<struct ABuildingActor> FloorActor; // 0xf60(0x08)
	struct TArray<struct TWeakObjectPtr<struct AFortPlayerPawn>> RotationLockedPawns; // 0xf68(0x10)
	char pad_F78[0x68]; // 0xf78(0x68)
	struct UFortLinkToActorComponent* LinkToActorComponent; // 0xfe0(0x08)
	struct UFortZiplineLinkComponent* ZiplineLinkComponent; // 0xfe8(0x08)

	void SetupAscender(bool bFromConstruction, bool bFromReplication); // Function AscenderCodeRuntime.FortAscenderZipline.SetupAscender // (Final|Native|Protected|BlueprintCallable) // @ game+0xa85d8d0
	void OnRep_TargetSplineEndLocation(); // Function AscenderCodeRuntime.FortAscenderZipline.OnRep_TargetSplineEndLocation // (Final|Native|Protected) // @ game+0x3aa72bc
	void OnRep_PawnUsingHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.OnRep_PawnUsingHandle // (Final|Native|Protected) // @ game+0x232c32c
	void OnRep_InitialSplineEndLocation(); // Function AscenderCodeRuntime.FortAscenderZipline.OnRep_InitialSplineEndLocation // (Final|Native|Protected) // @ game+0x39eab94
	void HandlePawnUsingHandleDied(struct AFortPawn* DeadPawn); // Function AscenderCodeRuntime.FortAscenderZipline.HandlePawnUsingHandleDied // (Final|Native|Protected) // @ game+0xa85d850
	void HandleFloorActorHealthChanged(); // Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorHealthChanged // (Final|Native|Protected) // @ game+0xa85d83c
	void HandleFloorActorDestroyed(struct AActor* Actor); // Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorDestroyed // (Final|Native|Protected) // @ game+0xa85d7bc
	struct UPrimitiveComponent* GetTopComponent(); // Function AscenderCodeRuntime.FortAscenderZipline.GetTopComponent // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	struct AFortPlayerPawn* GetPawnUsingHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.GetPawnUsingHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x387387c
	struct UPrimitiveComponent* GetInteractComponentOverride(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent); // Function AscenderCodeRuntime.FortAscenderZipline.GetInteractComponentOverride // (Native|Event|Public|BlueprintEvent|Const) // @ game+0xa85d6f0
	struct UPrimitiveComponent* GetHandleComponent(); // Function AscenderCodeRuntime.FortAscenderZipline.GetHandleComponent // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void BP_HandleUpdatedLoweringHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandleUpdatedLoweringCable(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandleStoppedLoweringHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandleStoppedLoweringCable(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandleStartedLoweringHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandleStartedLoweringCable(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandlePlayerStoppedUsingHandle(struct AFortPlayerPawn* Player); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStoppedUsingHandle // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandlePlayerStartedUsingHandle(struct AFortPlayerPawn* Player); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStartedUsingHandle // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ApplyStructureDamage(struct ABuildingSMActor* BuildingActor, struct AActor* DamageSource); // Function AscenderCodeRuntime.FortAscenderZipline.ApplyStructureDamage // (Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
};

