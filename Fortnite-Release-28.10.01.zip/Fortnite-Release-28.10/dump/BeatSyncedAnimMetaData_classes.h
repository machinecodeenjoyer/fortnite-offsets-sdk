// Class BeatSyncedAnimMetaData.BeatSyncedAnimMetaData
// Size: 0x30 (Inherited: 0x28)
struct UBeatSyncedAnimMetaData : UAnimMetaData {
	bool bAllowBeatsyncing; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class BeatSyncedAnimMetaData.PreciseBeatSyncedAnimMetaData
// Size: 0x48 (Inherited: 0x30)
struct UPreciseBeatSyncedAnimMetaData : UBeatSyncedAnimMetaData {
	float FirstBeatAtFrame; // 0x30(0x04)
	float BeatB; // 0x34(0x04)
	bool bShouldHalfOrDoublePlayRate; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float MaxPlayRateBeforeHalf; // 0x3c(0x04)
	float MinPlayRateBeforeDouble; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class BeatSyncedAnimMetaData.TimeSyncedBeatSyncedAnimMetaData
// Size: 0x38 (Inherited: 0x30)
struct UTimeSyncedBeatSyncedAnimMetaData : UBeatSyncedAnimMetaData {
	float AnimTimeZeroOffsetSeconds; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

