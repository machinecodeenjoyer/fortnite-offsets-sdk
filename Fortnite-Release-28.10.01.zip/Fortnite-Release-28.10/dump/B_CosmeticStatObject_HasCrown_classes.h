// BlueprintGeneratedClass B_CosmeticStatObject_HasCrown.B_CosmeticStatObject_HasCrown_C
// Size: 0x90 (Inherited: 0x90)
struct UB_CosmeticStatObject_HasCrown_C : UFortCosmeticStatObject_HasCrown {
};

