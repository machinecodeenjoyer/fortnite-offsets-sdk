// BlueprintGeneratedClass B_Small_Vertical_Jolt_CameraShake.B_Small_Vertical_Jolt_CameraShake_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UB_Small_Vertical_Jolt_CameraShake_C : ULegacyCameraShake {
};

