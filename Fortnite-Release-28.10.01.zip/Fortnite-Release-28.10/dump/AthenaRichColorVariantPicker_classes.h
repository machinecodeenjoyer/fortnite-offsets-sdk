// WidgetBlueprintGeneratedClass AthenaRichColorVariantPicker.AthenaRichColorVariantPicker_C
// Size: 0x408 (Inherited: 0x408)
struct UAthenaRichColorVariantPicker_C : UFortVariantRichColorPicker {
};

