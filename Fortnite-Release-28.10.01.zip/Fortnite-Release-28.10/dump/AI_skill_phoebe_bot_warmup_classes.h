// BlueprintGeneratedClass AI_skill_phoebe_bot_warmup.AI_skill_phoebe_bot_warmup_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAI_skill_phoebe_bot_warmup_C : UFortAthenaAIBotWarmupSkillSet {
};

