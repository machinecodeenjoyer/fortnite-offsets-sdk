// BlueprintGeneratedClass AI_skill_phoebe_bot_unstuck.AI_skill_phoebe_bot_unstuck_C
// Size: 0x468 (Inherited: 0x468)
struct UAI_skill_phoebe_bot_unstuck_C : UFortAthenaAIBotUnstuckSkillSet {
};

