// ScriptStruct BlendStack.BlendStackAnimNodeReference
// Size: 0x10 (Inherited: 0x10)
struct FBlendStackAnimNodeReference : FAnimNodeReference {
};

// ScriptStruct BlendStack.BlendStackAnimPlayer
// Size: 0x380 (Inherited: 0x00)
struct FBlendStackAnimPlayer {
	char pad_0[0x20]; // 0x00(0x20)
	struct FAnimNode_SequencePlayer_Standalone SequencePlayerNode; // 0x20(0x90)
	struct FAnimNode_BlendSpacePlayer_Standalone BlendSpacePlayerNode; // 0xb0(0x90)
	struct FAnimNode_Mirror_Standalone MirrorNode; // 0x140(0x60)
	char pad_1A0[0x1e0]; // 0x1a0(0x1e0)
};

// ScriptStruct BlendStack.BlendStack_SampleGraphPoseLink
// Size: 0x30 (Inherited: 0x00)
struct FBlendStack_SampleGraphPoseLink {
	int32_t RootNodeIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FPoseLink Root; // 0x08(0x10)
	char pad_18[0x18]; // 0x18(0x18)
};

// ScriptStruct BlendStack.AnimNode_BlendStack_Standalone
// Size: 0xa0 (Inherited: 0x38)
struct FAnimNode_BlendStack_Standalone : FAnimNode_AssetPlayerBase {
	struct TArray<struct FBlendStack_SampleGraphPoseLink> SampleGraphPoseLinks; // 0x38(0x10)
	char pad_48[0x8]; // 0x48(0x08)
	struct TArray<struct FBlendStackAnimPlayer> AnimPlayers; // 0x50(0x10)
	bool bShouldFilterNotifies; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	int32_t MaxActiveBlends; // 0x64(0x04)
	bool bStoreBlendedPose; // 0x68(0x01)
	char pad_69[0x27]; // 0x69(0x27)
	float NotifyRecencyTimeOut; // 0x90(0x04)
	float MaxBlendInTimeToOverrideAnimation; // 0x94(0x04)
	float PlayerDepthBlendInTimeMultiplier; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// ScriptStruct BlendStack.AnimNode_BlendStack
// Size: 0x110 (Inherited: 0xa0)
struct FAnimNode_BlendStack : FAnimNode_BlendStack_Standalone {
	struct UAnimationAsset* AnimationAsset; // 0xa0(0x08)
	float AnimationTime; // 0xa8(0x04)
	bool bLoop; // 0xac(0x01)
	bool bMirrored; // 0xad(0x01)
	char pad_AE[0x2]; // 0xae(0x02)
	float WantedPlayRate; // 0xb0(0x04)
	float BlendTime; // 0xb4(0x04)
	float RootBoneBlendTime; // 0xb8(0x04)
	float MaxAnimationDeltaTime; // 0xbc(0x04)
	struct UBlendProfile* BlendProfile; // 0xc0(0x08)
	enum class EAlphaBlendOption BlendOption; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
	struct FVector BlendParameters; // 0xd0(0x18)
	struct UMirrorDataTable* MirrorDataTable; // 0xe8(0x08)
	bool bUseInertialBlend; // 0xf0(0x01)
	bool bResetOnBecomingRelevant; // 0xf1(0x01)
	char pad_F2[0x1e]; // 0xf2(0x1e)
};

// ScriptStruct BlendStack.AnimNode_BlendStackInput
// Size: 0x28 (Inherited: 0x10)
struct FAnimNode_BlendStackInput : FAnimNode_Base {
	int32_t SampleIndex; // 0x10(0x04)
	int32_t BlendStackAllocationIndex; // 0x14(0x04)
	bool bOverridePlayRate; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float PlayRate; // 0x1c(0x04)
	char pad_20[0x8]; // 0x20(0x08)
};

