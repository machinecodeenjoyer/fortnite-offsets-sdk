// BlueprintGeneratedClass ButtonStyle_VoiceHeader.ButtonStyle_VoiceHeader_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_VoiceHeader_C : UCommonButtonStyle {
};

