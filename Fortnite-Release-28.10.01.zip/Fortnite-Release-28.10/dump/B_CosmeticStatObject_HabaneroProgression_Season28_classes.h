// BlueprintGeneratedClass B_CosmeticStatObject_HabaneroProgression_Season28.B_CosmeticStatObject_HabaneroProgression_Season28_C
// Size: 0xe0 (Inherited: 0xe0)
struct UB_CosmeticStatObject_HabaneroProgression_Season28_C : UFortCosmeticStatObject_HabaneroProgressionSeasonal {
};

