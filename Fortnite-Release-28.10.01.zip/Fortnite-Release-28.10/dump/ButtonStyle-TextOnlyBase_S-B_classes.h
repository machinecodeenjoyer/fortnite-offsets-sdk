// BlueprintGeneratedClass ButtonStyle-TextOnlyBase_S-B.ButtonStyle-TextOnlyBase_S-B_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-TextOnlyBase_S-B_C : UButtonStyle-TextOnlyBase_C {
};

