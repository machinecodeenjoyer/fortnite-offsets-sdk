// BlueprintGeneratedClass AI_skill_phoebe_bot_playstyle.AI_skill_phoebe_bot_playstyle_C
// Size: 0x108 (Inherited: 0x108)
struct UAI_skill_phoebe_bot_playstyle_C : UFortAthenaAIBotPlayStyleSkillSet {
};

