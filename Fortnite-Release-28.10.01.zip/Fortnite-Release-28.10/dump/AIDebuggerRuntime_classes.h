// Class AIDebuggerRuntime.AIDebuggerCheatManager
// Size: 0x28 (Inherited: 0x28)
struct UAIDebuggerCheatManager : UChildCheatManager {

	void StartAIDebugger(struct FString AIDebuggerSoftClassPath); // Function AIDebuggerRuntime.AIDebuggerCheatManager.StartAIDebugger // (Final|Exec|Native|Public) // @ game+0x8c0e6d0
	void NextNavMesh(); // Function AIDebuggerRuntime.AIDebuggerCheatManager.NextNavMesh // (Final|Exec|Native|Public) // @ game+0x32e4b44
	void EnableNavMeshVisualizer(bool bEnable); // Function AIDebuggerRuntime.AIDebuggerCheatManager.EnableNavMeshVisualizer // (Final|Exec|Native|Public) // @ game+0x60325ec
};

// Class AIDebuggerRuntime.AIDebuggerRendererComponent
// Size: 0x620 (Inherited: 0x570)
struct UAIDebuggerRendererComponent : UPrimitiveComponent {
	char pad_570[0x98]; // 0x570(0x98)
	struct UMaterial* NavMeshMaterial; // 0x608(0x08)
	float NavLinkLineThickness; // 0x610(0x04)
	float NavLinkMaxDrawDistance; // 0x614(0x04)
	char pad_618[0x8]; // 0x618(0x08)
};

// Class AIDebuggerRuntime.FortControllerComponent_AIDebugger
// Size: 0x110 (Inherited: 0xa8)
struct UFortControllerComponent_AIDebugger : UFortControllerComponent {
	struct APlayerController* OwnerPC; // 0xa8(0x08)
	struct UAIDebuggerRendererComponent* NavMeshRendererComponentClass; // 0xb0(0x08)
	char DefaultEnabledVisualizers; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	int32_t DefaultNavDataIndexToDisplay; // 0xbc(0x04)
	char EnabledVisualizers; // 0xc0(0x01)
	char NumNavMeshes; // 0xc1(0x01)
	char pad_C2[0x4e]; // 0xc2(0x4e)

	void VisualizeNextNavMesh(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNextNavMesh // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x83b8590
	void VisualizeNavMeshID(int32_t NavMeshID); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNavMeshID // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x85a7ffc
	void SetVisualizationEnable(enum class EAIDebuggerVisualization VisualizationType, bool bEnable); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.SetVisualizationEnable // (RequiredAPI|Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0xa763be8
	void OnRep_EnabledVisualizers(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnRep_EnabledVisualizers // (Final|Native|Public) // @ game+0xa763bac
	void OnPlayerExitedIsland(struct FEventMessageTag Channel, struct FPlayerExitSpatialActorContextWithPawn& PlayerExitSpatialActorContext); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnPlayerExitedIsland // (Final|Native|Public|HasOutParms) // @ game+0xa763a28
	bool IsVisualizationEnabled(enum class EAIDebuggerVisualization VisualizationType); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.IsVisualizationEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa763998
	struct UAIDebuggerRendererComponent* GetOrCreateRenderer(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.GetOrCreateRenderer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa763974
};

