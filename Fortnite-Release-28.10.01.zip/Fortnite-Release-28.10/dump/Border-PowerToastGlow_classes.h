// BlueprintGeneratedClass Border-PowerToastGlow.Border-PowerToastGlow_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-PowerToastGlow_C : UCommonBorderStyle {
};

