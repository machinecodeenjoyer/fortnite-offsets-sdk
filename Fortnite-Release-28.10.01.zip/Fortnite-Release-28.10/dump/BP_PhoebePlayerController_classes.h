// BlueprintGeneratedClass BP_PhoebePlayerController.BP_PhoebePlayerController_C
// Size: 0x1770 (Inherited: 0x1750)
struct ABP_PhoebePlayerController_C : AFortAthenaAIBotController {
	struct UFortControllerComponent_RechargeWeapons* RechargingWeaponsComponent; // 0x1750(0x08)
	struct UFortBlackboardComponent* Blackboard1; // 0x1758(0x08)
	struct UFortAthenaAIBotBuildingComponent* FortAthenaAIBotBuilding; // 0x1760(0x08)
	struct UAIPerceptionComponent* AIPerception; // 0x1768(0x08)
};

