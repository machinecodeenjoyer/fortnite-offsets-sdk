// BlueprintGeneratedClass BBE_NevadaHonk.BBE_NevadaHonk_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_NevadaHonk_C : UFortMobileActionButtonBehaviorExtension {
};

