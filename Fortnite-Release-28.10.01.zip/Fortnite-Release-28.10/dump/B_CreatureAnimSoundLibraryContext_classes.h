// BlueprintGeneratedClass B_CreatureAnimSoundLibraryContext.B_CreatureAnimSoundLibraryContext_C
// Size: 0x98 (Inherited: 0x98)
struct UB_CreatureAnimSoundLibraryContext_C : USoundLibraryAnimContext {

	bool Play(struct FSoundLibraryContextEventInput& InEventData, struct TArray<struct UAudioComponent*>& OutComponents); // Function B_CreatureAnimSoundLibraryContext.B_CreatureAnimSoundLibraryContext_C.Play // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

