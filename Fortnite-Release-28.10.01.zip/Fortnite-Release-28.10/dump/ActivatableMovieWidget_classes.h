// WidgetBlueprintGeneratedClass ActivatableMovieWidget.ActivatableMovieWidget_C
// Size: 0x668 (Inherited: 0x650)
struct UActivatableMovieWidget_C : UFortActivatableVideoPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x650(0x08)
	struct USafeZone* MainSafeZone; // 0x658(0x08)
	struct USafeZone* ; // 0x660(0x08)

	void Construct(); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_ActivatableMovieWidget(int32_t EntryPoint); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.ExecuteUbergraph_ActivatableMovieWidget // (Final|UbergraphFunction) // @ game+0x211c0a0
};

