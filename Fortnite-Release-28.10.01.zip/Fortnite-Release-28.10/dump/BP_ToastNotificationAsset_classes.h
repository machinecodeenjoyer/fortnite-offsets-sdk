// BlueprintGeneratedClass BP_ToastNotificationAsset.BP_ToastNotificationAsset_C
// Size: 0x80 (Inherited: 0x30)
struct UBP_ToastNotificationAsset_C : UPrimaryDataAsset {
	struct TMap<enum class EFortNotificationType, struct FS_UI_ToastProperty> Data; // 0x30(0x50)
};

