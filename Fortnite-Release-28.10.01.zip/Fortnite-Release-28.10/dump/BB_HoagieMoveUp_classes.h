// BlueprintGeneratedClass BB_HoagieMoveUp.BB_HoagieMoveUp_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_HoagieMoveUp_C : UFortMobileActionButtonBehavior {
};

