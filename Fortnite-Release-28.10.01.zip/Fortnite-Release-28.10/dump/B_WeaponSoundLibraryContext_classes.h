// BlueprintGeneratedClass B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C
// Size: 0xf9 (Inherited: 0xb0)
struct UB_WeaponSoundLibraryContext_C : UFortWeaponSoundLibraryContext {
	bool bGatherSounds; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct TArray<struct USoundBase*> GatheredSounds; // 0xb8(0x10)
	struct TArray<struct UAudioComponent*> FireAudioComponents; // 0xc8(0x10)
	struct TArray<int32_t> IndexToClear; // 0xd8(0x10)
	struct TArray<struct UAudioComponent*> NeedRespawnComponent; // 0xe8(0x10)
	bool bAlmostFinished; // 0xf8(0x01)

	void OnAlmostFinished(struct FName OutputName, struct FMetaSoundOutput& Output); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.OnAlmostFinished // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CleanFireAudioComponents(bool& bParamRetriggered); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.CleanFireAudioComponents // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void EnableSoundRetrieval(); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.EnableSoundRetrieval // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ClearRetrievedSounds(); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.ClearRetrievedSounds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetRetrievedSounds(struct TArray<struct USoundBase*>& GatheredSounds); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.GetRetrievedSounds // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void GetRootComponent(struct AActor* Actor, struct FGameplayTag EventTag, struct USceneComponent*& RootComponent); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.GetRootComponent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	bool Play(struct FSoundLibraryContextEventInput& InEventData, struct TArray<struct UAudioComponent*>& OutComponents); // Function B_WeaponSoundLibraryContext.B_WeaponSoundLibraryContext_C.Play // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

