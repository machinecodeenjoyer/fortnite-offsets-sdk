// BlueprintGeneratedClass B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C
// Size: 0x259 (Inherited: 0x220)
struct UB_WeaponSoundLibraryComponent_C : UFortWeaponSoundLibraryComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct FGameplayTag FireEvent; // 0x228(0x04)
	char pad_22C[0x4]; // 0x22c(0x04)
	struct UMetaSoundSource* BaseGunfireMS; // 0x230(0x08)
	struct TArray<struct UMetaSoundPatch*> ModMS; // 0x238(0x10)
	struct USoundLibrary* ModSoundLibrary; // 0x248(0x08)
	struct UObject* ModDistanceCurveBank; // 0x250(0x08)
	bool bSuppressorAtt; // 0x258(0x01)

	void StopComponentOnDeath(struct AActor* DeadActor, float Damage, struct AFortPawn* InstigatedBy, struct FVector HitLocation, struct AActor* DamageCauser); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.StopComponentOnDeath // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void BuiltSoundFireRateInit(struct UMetaSoundBuilderBase* BuilderRef); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.BuiltSoundFireRateInit // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ValidateModMetasounds(struct UObject* 1pMetaSoundPatch, struct UObject* 3pMetaSoundPatch, bool& bShouldBuild); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.ValidateModMetasounds // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CheckIfSuppressor(struct UMetaSoundBuilderBase* BuilderRef, struct FMetaSoundNodeHandle& BaseNodeHandle, struct FMetaSoundNodeHandle ModNodeHandle, struct UObject* ModRef); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.CheckIfSuppressor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ConnectInterfaceInputs(struct UMetaSoundBuilderBase* BuilderRef, struct FMetaSoundNodeHandle& BaseWeaponNodeHandle, struct FName InputName); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.ConnectInterfaceInputs // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ConnectNodesIO(struct UMetaSoundBuilderBase* BuilderRef, struct FName InputName, struct FName OutputName, struct FMetaSoundNodeHandle BaseNodeHandle, struct FMetaSoundNodeHandle ModNodeHandle); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.ConnectNodesIO // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AddConnectedGraphInput(struct FName InputName, struct FName DataType, struct UMetaSoundSourceBuilder* BuilderRef, struct FMetaSoundNodeHandle BaseWeaponNodeHandleRef); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.AddConnectedGraphInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CreateModSoundLibrary(); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.CreateModSoundLibrary // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetModMS(); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.SetModMS // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetBaseMS(); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.SetBaseMS // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CreateModMetaSound(); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.CreateModMetaSound // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetSoundsFromEvent(struct FGameplayTag InEventName, struct TArray<struct USoundBase*>& Out Sounds); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.GetSoundsFromEvent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnSoundPlayed(struct FGameplayTag InEventName, struct UAudioComponent* InComponent); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.OnSoundPlayed // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnSoundStopped(struct FGameplayTag InEventName, struct UAudioComponent* InComponent, bool& bStopped); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.OnSoundStopped // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void TryHandleFireEvent(struct FGameplayTag Event, struct UAudioComponent* Component); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.TryHandleFireEvent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnModApplied(struct UFortWeaponModAudioData* InModAudioData); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.OnModApplied // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnModRemoved(struct UFortWeaponModAudioData* InModAudioData); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.OnModRemoved // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_B_WeaponSoundLibraryComponent(int32_t EntryPoint); // Function B_WeaponSoundLibraryComponent.B_WeaponSoundLibraryComponent_C.ExecuteUbergraph_B_WeaponSoundLibraryComponent // (Final|UbergraphFunction) // @ game+0x211c0a0
};

