// BlueprintGeneratedClass Border_Navy_VGrad.Border_Navy_VGrad_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder_Navy_VGrad_C : UCommonBorderStyle {
};

