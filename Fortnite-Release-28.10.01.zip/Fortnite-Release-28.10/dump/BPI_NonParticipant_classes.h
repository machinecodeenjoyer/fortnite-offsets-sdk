// BlueprintGeneratedClass BPI_NonParticipant.BPI_NonParticipant_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_NonParticipant_C : UInterface {

	void AttemptPlayVocalReinforcementSound(struct FGameplayTagContainer MetadataTagContainer); // Function BPI_NonParticipant.BPI_NonParticipant_C.AttemptPlayVocalReinforcementSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayVoiceSoundByTag(struct FGameplayTag SoundBankTag); // Function BPI_NonParticipant.BPI_NonParticipant_C.PlayVoiceSoundByTag // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

