// BlueprintGeneratedClass BB_ValetBoost.BB_ValetBoost_C
// Size: 0x140 (Inherited: 0x140)
struct UBB_ValetBoost_C : UFortMobileActionButtonBehavior_ValetBoost {
};

