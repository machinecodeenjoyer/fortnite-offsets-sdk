// BlueprintGeneratedClass Border-TabM-Solid-White60pc.Border-TabM-Solid-White60pc_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-TabM-Solid-White60pc_C : UBorder-TabM-Solid_C {
};

