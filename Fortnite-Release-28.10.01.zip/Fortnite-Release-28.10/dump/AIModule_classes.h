// Class AIModule.AIAsyncTaskBlueprintProxy
// Size: 0x68 (Inherited: 0x28)
struct UAIAsyncTaskBlueprintProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x28(0x10)
	struct FMulticastInlineDelegate OnFail; // 0x38(0x10)
	char pad_48[0x20]; // 0x48(0x20)

	void OnMoveCompleted(struct FAIRequestID RequestID, enum class EPathFollowingResult MovementResult); // Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted // (Final|RequiredAPI|Native|Public) // @ game+0x6e32ccc
};

// Class AIModule.AIResourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UAIResourceInterface : UInterface {
};

// Class AIModule.AISenseBlueprintListener
// Size: 0x108 (Inherited: 0x108)
struct UAISenseBlueprintListener : UUserDefinedStruct {
};

// Class AIModule.AISenseConfig
// Size: 0x48 (Inherited: 0x28)
struct UAISenseConfig : UObject {
	struct FColor DebugColor; // 0x28(0x04)
	float MaxAge; // 0x2c(0x04)
	char bStartsEnabled : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x17]; // 0x31(0x17)
};

// Class AIModule.AISenseConfig_Blueprint
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Blueprint : UAISenseConfig {
	struct UAISense_Blueprint* Implementation; // 0x48(0x08)
};

// Class AIModule.AISenseConfig_Hearing
// Size: 0x60 (Inherited: 0x48)
struct UAISenseConfig_Hearing : UAISenseConfig {
	struct UAISense_Hearing* Implementation; // 0x48(0x08)
	float HearingRange; // 0x50(0x04)
	float LoSHearingRange; // 0x54(0x04)
	char bUseLoSHearing : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c(0x04)
};

// Class AIModule.AISenseConfig_Prediction
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Prediction : UAISenseConfig {
};

// Class AIModule.AISenseConfig_Sight
// Size: 0x70 (Inherited: 0x48)
struct UAISenseConfig_Sight : UAISenseConfig {
	struct UAISense_Sight* Implementation; // 0x48(0x08)
	float SightRadius; // 0x50(0x04)
	float LoseSightRadius; // 0x54(0x04)
	float PeripheralVisionAngleDegrees; // 0x58(0x04)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c(0x04)
	float AutoSuccessRangeFromLastSeenLocation; // 0x60(0x04)
	float PointOfViewBackwardOffset; // 0x64(0x04)
	float NearClippingRadius; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class AIModule.AISenseConfig_Team
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Team : UAISenseConfig {
};

// Class AIModule.AISenseConfig_Touch
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Touch : UAISenseConfig {
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class AIModule.AISenseEvent
// Size: 0x28 (Inherited: 0x28)
struct UAISenseEvent : UObject {
};

// Class AIModule.AISenseEvent_Damage
// Size: 0x78 (Inherited: 0x28)
struct UAISenseEvent_Damage : UAISenseEvent {
	struct FAIDamageEvent Event; // 0x28(0x50)
};

// Class AIModule.AISenseEvent_Hearing
// Size: 0x60 (Inherited: 0x28)
struct UAISenseEvent_Hearing : UAISenseEvent {
	struct FAINoiseEvent Event; // 0x28(0x38)
};

// Class AIModule.CrowdAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UCrowdAgentInterface : UInterface {
};

// Class AIModule.EnvQueryTypes
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryTypes : UObject {
};

// Class AIModule.EQSQueryResultSourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UEQSQueryResultSourceInterface : UInterface {
};

// Class AIModule.GenericTeamAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UGenericTeamAgentInterface : UInterface {
};

// Class AIModule.PawnAction
// Size: 0x90 (Inherited: 0x28)
struct UPawnAction : UObject {
	struct UPawnAction* ChildAction; // 0x28(0x08)
	struct UPawnAction* ParentAction; // 0x30(0x08)
	struct UPawnActionsComponent* OwnerComponent; // 0x38(0x08)
	struct UObject* Instigator; // 0x40(0x08)
	struct UBrainComponent* BrainComp; // 0x48(0x08)
	char pad_50[0x30]; // 0x50(0x30)
	char bAllowNewSameClassInstance : 1; // 0x80(0x01)
	char bReplaceActiveSameClassInstance : 1; // 0x80(0x01)
	char bShouldPauseMovement : 1; // 0x80(0x01)
	char bAlwaysNotifyOnFinished : 1; // 0x80(0x01)
	char pad_80_4 : 4; // 0x80(0x01)
	char pad_81[0xf]; // 0x81(0x0f)

	enum class EAIRequestPriority GetActionPriority(); // Function AIModule.PawnAction.GetActionPriority // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x63cec8c
	void Finish(enum class EPawnActionResult WithResult); // Function AIModule.PawnAction.Finish // (RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x6e31c80
	struct UPawnAction* CreateActionInstance(struct UObject* WorldContextObject, struct UPawnAction* ActionClass); // Function AIModule.PawnAction.CreateActionInstance // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6e31b58
};

// Class AIModule.PawnActionsComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UPawnActionsComponent : UActorComponent {
	struct APawn* ControlledPawn; // 0xa0(0x08)
	struct TArray<struct FPawnActionStack> ActionStacks; // 0xa8(0x10)
	struct TArray<struct FPawnActionEvent> ActionEvents; // 0xb8(0x10)
	struct UPawnAction* CurrentAction; // 0xc8(0x08)
	char pad_D0[0x8]; // 0xd0(0x08)

	bool K2_PushAction(struct UPawnAction* NewAction, enum class EAIRequestPriority Priority, struct UObject* Instigator); // Function AIModule.PawnActionsComponent.K2_PushAction // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e32114
	bool K2_PerformAction(struct APawn* Pawn, struct UPawnAction* Action, enum class EAIRequestPriority Priority); // Function AIModule.PawnActionsComponent.K2_PerformAction // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6e3200c
	enum class EPawnActionAbortState K2_ForceAbortAction(struct UPawnAction* ActionToAbort); // Function AIModule.PawnActionsComponent.K2_ForceAbortAction // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e31f80
	enum class EPawnActionAbortState K2_AbortAction(struct UPawnAction* ActionToAbort); // Function AIModule.PawnActionsComponent.K2_AbortAction // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e31ecc
};

// Class AIModule.PawnAction_BlueprintBase
// Size: 0x90 (Inherited: 0x90)
struct UPawnAction_BlueprintBase : UPawnAction {

	void ActionTick(struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.PawnAction_BlueprintBase.ActionTick // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ActionStart(struct APawn* ControlledPawn); // Function AIModule.PawnAction_BlueprintBase.ActionStart // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ActionResume(struct APawn* ControlledPawn); // Function AIModule.PawnAction_BlueprintBase.ActionResume // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ActionPause(struct APawn* ControlledPawn); // Function AIModule.PawnAction_BlueprintBase.ActionPause // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ActionFinished(struct APawn* ControlledPawn, enum class EPawnActionResult WithResult); // Function AIModule.PawnAction_BlueprintBase.ActionFinished // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
};

// Class AIModule.PawnAction_Move
// Size: 0xf0 (Inherited: 0x90)
struct UPawnAction_Move : UPawnAction {
	struct AActor* GoalActor; // 0x90(0x08)
	struct FVector GoalLocation; // 0x98(0x18)
	float AcceptableRadius; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xb8(0x08)
	char bAllowStrafe : 1; // 0xc0(0x01)
	char bFinishOnOverlap : 1; // 0xc0(0x01)
	char bUsePathfinding : 1; // 0xc0(0x01)
	char bAllowPartialPath : 1; // 0xc0(0x01)
	char bProjectGoalToNavigation : 1; // 0xc0(0x01)
	char bUpdatePathToGoal : 1; // 0xc0(0x01)
	char bAbortSubActionOnPathChange : 1; // 0xc0(0x01)
	char pad_C0_7 : 1; // 0xc0(0x01)
	char pad_C1[0x2f]; // 0xc1(0x2f)
};

// Class AIModule.PawnAction_Repeat
// Size: 0xb0 (Inherited: 0x90)
struct UPawnAction_Repeat : UPawnAction {
	struct UPawnAction* ActionToRepeat; // 0x90(0x08)
	struct UPawnAction* RecentActionCopy; // 0x98(0x08)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0xa0(0x01)
	char pad_A1[0xf]; // 0xa1(0x0f)
};

// Class AIModule.PawnAction_Sequence
// Size: 0xb8 (Inherited: 0x90)
struct UPawnAction_Sequence : UPawnAction {
	struct TArray<struct UPawnAction*> ActionSequence; // 0x90(0x10)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct UPawnAction* RecentActionCopy; // 0xa8(0x08)
	char pad_B0[0x8]; // 0xb0(0x08)
};

// Class AIModule.PawnAction_Wait
// Size: 0xa0 (Inherited: 0x90)
struct UPawnAction_Wait : UPawnAction {
	float TimeToWait; // 0x90(0x04)
	char pad_94[0xc]; // 0x94(0x0c)
};

// Class AIModule.AIController
// Size: 0x3b8 (Inherited: 0x328)
struct AAIController : AController {
	char pad_328[0x38]; // 0x328(0x38)
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	char pad_360_7 : 1; // 0x360(0x01)
	char pad_361[0x7]; // 0x361(0x07)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
	char pad_3B0[0x8]; // 0x3b0(0x08)

	bool UseBlackboard(struct UBlackboardData* BlackboardAsset, struct UBlackboardComponent*& BlackboardComponent); // Function AIModule.AIController.UseBlackboard // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e33114
	void UnclaimTaskResource(struct UGameplayTaskResource* ResourceClass); // Function AIModule.AIController.UnclaimTaskResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e33080
	void SetPathFollowingComponent(struct UPathFollowingComponent* NewPFComponent); // Function AIModule.AIController.SetPathFollowingComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e32ff4
	void SetMoveBlockDetection(bool bEnable); // Function AIModule.AIController.SetMoveBlockDetection // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e32f70
	bool RunBehaviorTree(struct UBehaviorTree* BTAsset); // Function AIModule.AIController.RunBehaviorTree // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e32edc
	void OnUsingBlackBoard(struct UBlackboardComponent* BlackboardComp, struct UBlackboardData* BlackboardAsset); // Function AIModule.AIController.OnUsingBlackBoard // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased); // Function AIModule.AIController.OnGameplayTaskResourcesClaimed // (RequiredAPI|Native|Public) // @ game+0x6e32ab8
	enum class EPathFollowingRequestResult MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath); // Function AIModule.AIController.MoveToLocation // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6e3263c
	enum class EPathFollowingRequestResult MoveToActor(struct AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath); // Function AIModule.AIController.MoveToActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e323ec
	void K2_SetFocus(struct AActor* NewFocus); // Function AIModule.AIController.K2_SetFocus // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e32364
	void K2_SetFocalPoint(struct FVector FP); // Function AIModule.AIController.K2_SetFocalPoint // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6e3221c
	void K2_ClearFocus(); // Function AIModule.AIController.K2_ClearFocus // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e31f64
	bool HasPartialPath(); // Function AIModule.AIController.HasPartialPath // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31e90
	struct UPathFollowingComponent* GetPathFollowingComponent(); // Function AIModule.AIController.GetPathFollowingComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31e78
	enum class EPathFollowingStatus GetMoveStatus(); // Function AIModule.AIController.GetMoveStatus // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31e58
	struct FVector GetImmediateMoveDestination(); // Function AIModule.AIController.GetImmediateMoveDestination // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31e20
	struct AActor* GetFocusActor(); // Function AIModule.AIController.GetFocusActor // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31dfc
	struct FVector GetFocalPointOnActor(struct AActor* Actor); // Function AIModule.AIController.GetFocalPointOnActor // (RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31d54
	struct FVector GetFocalPoint(); // Function AIModule.AIController.GetFocalPoint // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31d1c
	struct UPawnActionsComponent* GetDeprecatedActionsComponent(); // Function AIModule.AIController.GetDeprecatedActionsComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e31d04
	struct UAIPerceptionComponent* GetAIPerceptionComponent(); // Function AIModule.AIController.GetAIPerceptionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x60aca00
	void ClaimTaskResource(struct UGameplayTaskResource* ResourceClass); // Function AIModule.AIController.ClaimTaskResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e31ac4
};

// Class AIModule.AIResource_Movement
// Size: 0x38 (Inherited: 0x38)
struct UAIResource_Movement : UGameplayTaskResource {
};

// Class AIModule.AIResource_Logic
// Size: 0x38 (Inherited: 0x38)
struct UAIResource_Logic : UGameplayTaskResource {
};

// Class AIModule.AISubsystem
// Size: 0x38 (Inherited: 0x28)
struct UAISubsystem : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UAISystem* AISystem; // 0x30(0x08)
};

// Class AIModule.AISystem
// Size: 0x178 (Inherited: 0x58)
struct UAISystem : UAISystemBase {
	struct FSoftClassPath PerceptionSystemClassName; // 0x58(0x18)
	struct FSoftClassPath HotSpotManagerClassName; // 0x70(0x18)
	struct FSoftClassPath EnvQueryManagerClassName; // 0x88(0x18)
	float AcceptanceRadius; // 0xa0(0x04)
	float PathfollowingRegularPathPointAcceptanceRadius; // 0xa4(0x04)
	float PathfollowingNavLinkAcceptanceRadius; // 0xa8(0x04)
	bool bFinishMoveOnGoalOverlap; // 0xac(0x01)
	bool bAcceptPartialPaths; // 0xad(0x01)
	bool bAllowStrafing; // 0xae(0x01)
	bool bAllowControllersAsEQSQuerier; // 0xaf(0x01)
	bool bEnableDebuggerPlugin; // 0xb0(0x01)
	bool bForgetStaleActors; // 0xb1(0x01)
	bool bAddBlackboardSelfKey; // 0xb2(0x01)
	bool bClearBBEntryOnBTEQSFail; // 0xb3(0x01)
	bool bBlackboardKeyDecoratorAllowsNoneAsValue; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct TSoftObjectPtr<UBlackboardData> DefaultBlackboard; // 0xb8(0x20)
	enum class ECollisionChannel DefaultSightCollisionChannel; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct UBehaviorTreeManager* BehaviorTreeManager; // 0xe0(0x08)
	struct UEnvQueryManager* EnvironmentQueryManager; // 0xe8(0x08)
	struct UAIPerceptionSystem* PerceptionSystem; // 0xf0(0x08)
	struct TArray<struct UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // 0xf8(0x10)
	struct UAIHotSpotManager* HotSpotManager; // 0x108(0x08)
	struct UNavLocalGridManager* NavLocalGrids; // 0x110(0x08)
	char pad_118[0x60]; // 0x118(0x60)

	void AILoggingVerbose(); // Function AIModule.AISystem.AILoggingVerbose // (RequiredAPI|Exec|Native|Public) // @ game+0x3c36b90
	void AIIgnorePlayers(); // Function AIModule.AISystem.AIIgnorePlayers // (RequiredAPI|Exec|Native|Public) // @ game+0x21c958c
};

// Class AIModule.BehaviorTree
// Size: 0x68 (Inherited: 0x28)
struct UBehaviorTree : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UBTCompositeNode* RootNode; // 0x30(0x08)
	struct UBlackboardData* BlackboardAsset; // 0x38(0x08)
	struct TArray<struct UBTDecorator*> RootDecorators; // 0x40(0x10)
	struct TArray<struct FBTDecoratorLogic> RootDecoratorOps; // 0x50(0x10)
	char pad_60[0x8]; // 0x60(0x08)
};

// Class AIModule.BrainComponent
// Size: 0xf8 (Inherited: 0xa0)
struct UBrainComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct UBlackboardComponent* BlackboardComp; // 0xa8(0x08)
	struct AAIController* AIOwner; // 0xb0(0x08)
	char pad_B8[0x40]; // 0xb8(0x40)

	void StopLogic(struct FString Reason); // Function AIModule.BrainComponent.StopLogic // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e94d48
	void StartLogic(); // Function AIModule.BrainComponent.StartLogic // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x219df9c
	void RestartLogic(); // Function AIModule.BrainComponent.RestartLogic // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e94000
	bool IsRunning(); // Function AIModule.BrainComponent.IsRunning // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e939d0
	bool IsPaused(); // Function AIModule.BrainComponent.IsPaused // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e939a8
};

// Class AIModule.BehaviorTreeComponent
// Size: 0x298 (Inherited: 0xf8)
struct UBehaviorTreeComponent : UBrainComponent {
	char pad_F8[0x20]; // 0xf8(0x20)
	struct TArray<struct UBTNode*> NodeInstances; // 0x118(0x10)
	char pad_128[0x148]; // 0x128(0x148)
	struct UBehaviorTree* DefaultBehaviorTreeAsset; // 0x270(0x08)
	char pad_278[0x20]; // 0x278(0x20)

	void SetDynamicSubtree(struct FGameplayTag InjectTag, struct UBehaviorTree* BehaviorAsset); // Function AIModule.BehaviorTreeComponent.SetDynamicSubtree // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e5cbb8
	double GetTagCooldownEndTime(struct FGameplayTag CooldownTag); // Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5a9e8
	void AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration); // Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e59030
};

// Class AIModule.BehaviorTreeManager
// Size: 0x50 (Inherited: 0x28)
struct UBehaviorTreeManager : UObject {
	int32_t MaxDebuggerSteps; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FBehaviorTreeTemplateInfo> LoadedTemplates; // 0x30(0x10)
	struct TArray<struct UBehaviorTreeComponent*> ActiveComponents; // 0x40(0x10)
};

// Class AIModule.BehaviorTreeTypes
// Size: 0x28 (Inherited: 0x28)
struct UBehaviorTreeTypes : UObject {
};

// Class AIModule.BlackboardAssetProvider
// Size: 0x28 (Inherited: 0x28)
struct UBlackboardAssetProvider : UInterface {

	struct UBlackboardData* GetBlackboardAsset(); // Function AIModule.BlackboardAssetProvider.GetBlackboardAsset // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x321779c
};

// Class AIModule.BlackboardComponent
// Size: 0x1a8 (Inherited: 0xa0)
struct UBlackboardComponent : UActorComponent {
	struct UBrainComponent* BrainComp; // 0xa0(0x08)
	struct UBlackboardData* DefaultBlackboardAsset; // 0xa8(0x08)
	struct UBlackboardData* BlackboardAsset; // 0xb0(0x08)
	char pad_B8[0x20]; // 0xb8(0x20)
	struct TArray<struct UBlackboardKeyType*> KeyInstances; // 0xd8(0x10)
	char pad_E8[0xc0]; // 0xe8(0xc0)

	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue); // Function AIModule.BlackboardComponent.SetValueAsVector // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6e5de74
	void SetValueAsString(struct FName& KeyName, struct FString StringValue); // Function AIModule.BlackboardComponent.SetValueAsString // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5d704
	void SetValueAsRotator(struct FName& KeyName, struct FRotator VectorValue); // Function AIModule.BlackboardComponent.SetValueAsRotator // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6e5d574
	void SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue); // Function AIModule.BlackboardComponent.SetValueAsObject // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5d468
	void SetValueAsName(struct FName& KeyName, struct FName NameValue); // Function AIModule.BlackboardComponent.SetValueAsName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5d348
	void SetValueAsInt(struct FName& KeyName, int32_t IntValue); // Function AIModule.BlackboardComponent.SetValueAsInt // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5d228
	void SetValueAsFloat(struct FName& KeyName, float FloatValue); // Function AIModule.BlackboardComponent.SetValueAsFloat // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5d11c
	void SetValueAsEnum(struct FName& KeyName, char EnumValue); // Function AIModule.BlackboardComponent.SetValueAsEnum // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5cffc
	void SetValueAsClass(struct FName& KeyName, struct UObject* ClassValue); // Function AIModule.BlackboardComponent.SetValueAsClass // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5ced8
	void SetValueAsBool(struct FName& KeyName, bool BoolValue); // Function AIModule.BlackboardComponent.SetValueAsBool // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5cdc8
	bool IsVectorValueSet(struct FName& KeyName); // Function AIModule.BlackboardComponent.IsVectorValueSet // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5b234
	struct FVector GetValueAsVector(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsVector // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5b0a8
	struct FString GetValueAsString(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsString // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5aff8
	struct FRotator GetValueAsRotator(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsRotator // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5af4c
	struct UObject* GetValueAsObject(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsObject // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5aeb4
	struct FName GetValueAsName(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5ae24
	int32_t GetValueAsInt(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsInt // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5ad8c
	float GetValueAsFloat(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsFloat // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5acf0
	char GetValueAsEnum(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsEnum // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5ac58
	struct UObject* GetValueAsClass(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsClass // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5abc0
	bool GetValueAsBool(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsBool // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5ab28
	bool GetRotationFromEntry(struct FName& KeyName, struct FRotator& ResultRotation); // Function AIModule.BlackboardComponent.GetRotationFromEntry // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5a8ec
	bool GetLocationFromEntry(struct FName& KeyName, struct FVector& ResultLocation); // Function AIModule.BlackboardComponent.GetLocationFromEntry // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5a6a4
	void ClearValue(struct FName& KeyName); // Function AIModule.BlackboardComponent.ClearValue // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6e59418
};

// Class AIModule.BlackboardData
// Size: 0x50 (Inherited: 0x30)
struct UBlackboardData : UDataAsset {
	struct UBlackboardData* Parent; // 0x30(0x08)
	struct TArray<struct FBlackboardEntry> Keys; // 0x38(0x10)
	char bHasSynchronizedKeys : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.BlackboardKeyType
// Size: 0x30 (Inherited: 0x28)
struct UBlackboardKeyType : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class AIModule.BlackboardKeyType_Bool
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Bool : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Class
// Size: 0x38 (Inherited: 0x30)
struct UBlackboardKeyType_Class : UBlackboardKeyType {
	ClassPtrProperty BaseClass; // 0x30(0x08)
};

// Class AIModule.BlackboardKeyType_Enum
// Size: 0x50 (Inherited: 0x30)
struct UBlackboardKeyType_Enum : UBlackboardKeyType {
	struct UEnum* EnumType; // 0x30(0x08)
	struct FString EnumName; // 0x38(0x10)
	char bIsEnumNameValid : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.BlackboardKeyType_Float
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Float : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Int
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Int : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Name
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Name : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_NativeEnum
// Size: 0x48 (Inherited: 0x30)
struct UBlackboardKeyType_NativeEnum : UBlackboardKeyType {
	struct FString EnumName; // 0x30(0x10)
	struct UEnum* EnumType; // 0x40(0x08)
};

// Class AIModule.BlackboardKeyType_Object
// Size: 0x38 (Inherited: 0x30)
struct UBlackboardKeyType_Object : UBlackboardKeyType {
	ClassPtrProperty BaseClass; // 0x30(0x08)
};

// Class AIModule.BlackboardKeyType_Rotator
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Rotator : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_String
// Size: 0x40 (Inherited: 0x30)
struct UBlackboardKeyType_String : UBlackboardKeyType {
	struct FString StringValue; // 0x30(0x10)
};

// Class AIModule.BlackboardKeyType_Vector
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Vector : UBlackboardKeyType {
};

// Class AIModule.BTNode
// Size: 0x58 (Inherited: 0x28)
struct UBTNode : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FString NodeName; // 0x30(0x10)
	struct UBehaviorTree* TreeAsset; // 0x40(0x08)
	struct UBTCompositeNode* ParentNode; // 0x48(0x08)
	char pad_50[0x8]; // 0x50(0x08)
};

// Class AIModule.BTAuxiliaryNode
// Size: 0x60 (Inherited: 0x58)
struct UBTAuxiliaryNode : UBTNode {
	char pad_58[0x8]; // 0x58(0x08)
};

// Class AIModule.BTCompositeNode
// Size: 0x80 (Inherited: 0x58)
struct UBTCompositeNode : UBTNode {
	struct TArray<struct FBTCompositeChild> Children; // 0x58(0x10)
	struct TArray<struct UBTService*> Services; // 0x68(0x10)
	char bApplyDecoratorScope : 1; // 0x78(0x01)
	char pad_78_1 : 7; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class AIModule.BTDecorator
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator : UBTAuxiliaryNode {
	char pad_60_0 : 7; // 0x60(0x01)
	char bInverseCondition : 1; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	enum class EBTFlowAbortMode FlowAbortMode; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
};

// Class AIModule.BTFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBTFunctionLibrary : UBlueprintFunctionLibrary {

	void StopUsingExternalEvent(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.StopUsingExternalEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x604b150
	void StartUsingExternalEvent(struct UBTNode* NodeOwner, struct AActor* OwningActor); // Function AIModule.BTFunctionLibrary.StartUsingExternalEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x69b67c4
	void SetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FVector Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6e5c9c4
	void SetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FString Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5c1b0
	void SetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FRotator Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6e5bfbc
	void SetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5bdec
	void SetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FName Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5bc1c
	void SetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int32_t Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5ba4c
	void SetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5b880
	void SetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, char Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5b6b0
	void SetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5b4e0
	void SetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e5b30c
	struct UBlackboardComponent* GetOwnersBlackboard(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.GetOwnersBlackboard // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e5a86c
	struct UBehaviorTreeComponent* GetOwnerComponent(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.GetOwnerComponent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e5a7dc
	struct FVector GetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6e5a564
	struct FString GetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e59e54
	struct FRotator GetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6e59d14
	struct UObject* GetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e59c18
	struct FName GetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e59b14
	int32_t GetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e59a04
	float GetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e598f0
	char GetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e597e0
	struct UObject* GetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e596d0
	bool GetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e595c0
	struct AActor* GetBlackboardValueAsActor(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6e594a4
	void ClearBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e59310
	void ClearBlackboardValue(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.ClearBlackboardValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6e59310
};

// Class AIModule.BTService
// Size: 0x70 (Inherited: 0x60)
struct UBTService : UBTAuxiliaryNode {
	float Interval; // 0x60(0x04)
	float RandomDeviation; // 0x64(0x04)
	char bCallTickOnSearchStart : 1; // 0x68(0x01)
	char bRestartTimerOnEachActivation : 1; // 0x68(0x01)
	char pad_68_2 : 6; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class AIModule.BTTaskNode
// Size: 0x70 (Inherited: 0x58)
struct UBTTaskNode : UBTNode {
	struct TArray<struct UBTService*> Services; // 0x58(0x10)
	char bIgnoreRestartSelf : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class AIModule.BTComposite_Selector
// Size: 0x80 (Inherited: 0x80)
struct UBTComposite_Selector : UBTCompositeNode {
};

// Class AIModule.BTComposite_Sequence
// Size: 0x80 (Inherited: 0x80)
struct UBTComposite_Sequence : UBTCompositeNode {
};

// Class AIModule.BTComposite_SimpleParallel
// Size: 0x88 (Inherited: 0x80)
struct UBTComposite_SimpleParallel : UBTCompositeNode {
	enum class EBTParallelMode FinishMode; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// Class AIModule.BTDecorator_BlackboardBase
// Size: 0x90 (Inherited: 0x68)
struct UBTDecorator_BlackboardBase : UBTDecorator {
	struct FBlackboardKeySelector BlackboardKey; // 0x68(0x28)
};

// Class AIModule.BTDecorator_Blackboard
// Size: 0xc0 (Inherited: 0x90)
struct UBTDecorator_Blackboard : UBTDecorator_BlackboardBase {
	int32_t IntValue; // 0x90(0x04)
	float FloatValue; // 0x94(0x04)
	struct FString StringValue; // 0x98(0x10)
	struct FString CachedDescription; // 0xa8(0x10)
	char OperationType; // 0xb8(0x01)
	enum class EBTBlackboardRestart NotifyObserver; // 0xb9(0x01)
	char pad_BA[0x6]; // 0xba(0x06)
};

// Class AIModule.BTDecorator_BlueprintBase
// Size: 0xa0 (Inherited: 0x68)
struct UBTDecorator_BlueprintBase : UBTDecorator {
	struct AAIController* AIOwner; // 0x68(0x08)
	struct AActor* ActorOwner; // 0x70(0x08)
	struct TArray<struct FName> ObservedKeyNames; // 0x78(0x10)
	char pad_88[0x10]; // 0x88(0x10)
	char bShowPropertyDetails : 1; // 0x98(0x01)
	char bCheckConditionOnlyBlackBoardChanges : 1; // 0x98(0x01)
	char pad_98_2 : 6; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function AIModule.BTDecorator_BlueprintBase.ReceiveTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveObserverDeactivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveObserverDeactivated(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveObserverActivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveObserverActivated(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveExecutionStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveExecutionStart(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveExecutionFinishAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EBTNodeResult NodeResult); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	bool PerformConditionCheck(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	bool IsDecoratorObserverActive(); // Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5b1cc
	bool IsDecoratorExecutionActive(); // Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e5b154
};

// Class AIModule.BTDecorator_CheckGameplayTagsOnActor
// Size: 0xc8 (Inherited: 0x68)
struct UBTDecorator_CheckGameplayTagsOnActor : UBTDecorator {
	struct FBlackboardKeySelector ActorToCheck; // 0x68(0x28)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FGameplayTagContainer GameplayTags; // 0x98(0x20)
	struct FString CachedDescription; // 0xb8(0x10)
};

// Class AIModule.BTDecorator_CompareBBEntries
// Size: 0xc0 (Inherited: 0x68)
struct UBTDecorator_CompareBBEntries : UBTDecorator {
	enum class EBlackBoardEntryComparison Operator; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FBlackboardKeySelector BlackboardKeyA; // 0x70(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x98(0x28)
};

// Class AIModule.BTDecorator_ConditionalLoop
// Size: 0xc0 (Inherited: 0xc0)
struct UBTDecorator_ConditionalLoop : UBTDecorator_Blackboard {
};

// Class AIModule.BTDecorator_ConeCheck
// Size: 0xf0 (Inherited: 0x68)
struct UBTDecorator_ConeCheck : UBTDecorator {
	float ConeHalfAngle; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FBlackboardKeySelector ConeOrigin; // 0x70(0x28)
	struct FBlackboardKeySelector ConeDirection; // 0x98(0x28)
	struct FBlackboardKeySelector Observed; // 0xc0(0x28)
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class AIModule.BTDecorator_Cooldown
// Size: 0x70 (Inherited: 0x68)
struct UBTDecorator_Cooldown : UBTDecorator {
	float CooldownTime; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class AIModule.BTDecorator_DoesPathExist
// Size: 0xc8 (Inherited: 0x68)
struct UBTDecorator_DoesPathExist : UBTDecorator {
	struct FBlackboardKeySelector BlackboardKeyA; // 0x68(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x90(0x28)
	char bUseSelf : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	enum class EPathExistanceQueryType PathQueryType; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	struct UNavigationQueryFilter* FilterClass; // 0xc0(0x08)
};

// Class AIModule.BTDecorator_ForceSuccess
// Size: 0x68 (Inherited: 0x68)
struct UBTDecorator_ForceSuccess : UBTDecorator {
};

// Class AIModule.BTDecorator_IsAtLocation
// Size: 0xd8 (Inherited: 0x90)
struct UBTDecorator_IsAtLocation : UBTDecorator_BlackboardBase {
	float AcceptableRadius; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FAIDataProviderFloatValue ParametrizedAcceptableRadius; // 0x98(0x38)
	enum class FAIDistanceType GeometricDistanceType; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	char bUseParametrizedRadius : 1; // 0xd4(0x01)
	char bUseNavAgentGoalLocation : 1; // 0xd4(0x01)
	char bPathFindingBasedTest : 1; // 0xd4(0x01)
	char pad_D4_3 : 5; // 0xd4(0x01)
	char pad_D5[0x3]; // 0xd5(0x03)
};

// Class AIModule.BTDecorator_IsBBEntryOfClass
// Size: 0x98 (Inherited: 0x90)
struct UBTDecorator_IsBBEntryOfClass : UBTDecorator_BlackboardBase {
	struct UObject* TestClass; // 0x90(0x08)
};

// Class AIModule.BTDecorator_KeepInCone
// Size: 0xc8 (Inherited: 0x68)
struct UBTDecorator_KeepInCone : UBTDecorator {
	float ConeHalfAngle; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FBlackboardKeySelector ConeOrigin; // 0x70(0x28)
	struct FBlackboardKeySelector Observed; // 0x98(0x28)
	char bUseSelfAsOrigin : 1; // 0xc0(0x01)
	char bUseSelfAsObserved : 1; // 0xc0(0x01)
	char pad_C0_2 : 6; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class AIModule.BTDecorator_Loop
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_Loop : UBTDecorator {
	int32_t NumLoops; // 0x68(0x04)
	bool bInfiniteLoop; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	float InfiniteLoopTimeoutTime; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class AIModule.BTDecorator_ReachedMoveGoal
// Size: 0x68 (Inherited: 0x68)
struct UBTDecorator_ReachedMoveGoal : UBTDecorator {
};

// Class AIModule.BTDecorator_SetTagCooldown
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_SetTagCooldown : UBTDecorator {
	struct FGameplayTag CooldownTag; // 0x68(0x04)
	float CooldownDuration; // 0x6c(0x04)
	bool bAddToExistingDuration; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class AIModule.BTDecorator_TagCooldown
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_TagCooldown : UBTDecorator {
	struct FGameplayTag CooldownTag; // 0x68(0x04)
	float CooldownDuration; // 0x6c(0x04)
	bool bAddToExistingDuration; // 0x70(0x01)
	bool bActivatesCooldown; // 0x71(0x01)
	char pad_72[0x6]; // 0x72(0x06)
};

// Class AIModule.BTDecorator_TimeLimit
// Size: 0x70 (Inherited: 0x68)
struct UBTDecorator_TimeLimit : UBTDecorator {
	float TimeLimit; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class AIModule.BTService_BlackboardBase
// Size: 0x98 (Inherited: 0x70)
struct UBTService_BlackboardBase : UBTService {
	struct FBlackboardKeySelector BlackboardKey; // 0x70(0x28)
};

// Class AIModule.BTService_BlueprintBase
// Size: 0x98 (Inherited: 0x70)
struct UBTService_BlueprintBase : UBTService {
	struct AAIController* AIOwner; // 0x70(0x08)
	struct AActor* ActorOwner; // 0x78(0x08)
	char pad_80[0x10]; // 0x80(0x10)
	char bShowPropertyDetails : 1; // 0x90(0x01)
	char bShowEventDetails : 1; // 0x90(0x01)
	char pad_90_2 : 6; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTService_BlueprintBase.ReceiveTickAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function AIModule.BTService_BlueprintBase.ReceiveTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveSearchStart(struct AActor* OwnerActor); // Function AIModule.BTService_BlueprintBase.ReceiveSearchStart // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveDeactivation(struct AActor* OwnerActor); // Function AIModule.BTService_BlueprintBase.ReceiveDeactivation // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTService_BlueprintBase.ReceiveActivationAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveActivation(struct AActor* OwnerActor); // Function AIModule.BTService_BlueprintBase.ReceiveActivation // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	bool IsServiceActive(); // Function AIModule.BTService_BlueprintBase.IsServiceActive // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e939f8
};

// Class AIModule.BTService_DefaultFocus
// Size: 0xa0 (Inherited: 0x98)
struct UBTService_DefaultFocus : UBTService_BlackboardBase {
	char FocusPriority; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class AIModule.BTService_RunEQS
// Size: 0xf8 (Inherited: 0x98)
struct UBTService_RunEQS : UBTService_BlackboardBase {
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x98(0x48)
	bool bUpdateBBOnFail; // 0xe0(0x01)
	char pad_E1[0x17]; // 0xe1(0x17)
};

// Class AIModule.BTTask_BlackboardBase
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_BlackboardBase : UBTTaskNode {
	struct FBlackboardKeySelector BlackboardKey; // 0x70(0x28)
};

// Class AIModule.BTTask_BlueprintBase
// Size: 0xa8 (Inherited: 0x70)
struct UBTTask_BlueprintBase : UBTTaskNode {
	struct AAIController* AIOwner; // 0x70(0x08)
	struct AActor* ActorOwner; // 0x78(0x08)
	struct FIntervalCountdown TickInterval; // 0x80(0x08)
	char pad_88[0x18]; // 0x88(0x18)
	char bShowPropertyDetails : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)

	void SetFinishOnMessageWithId(struct FName MessageName, int32_t RequestID); // Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x6e94504
	void SetFinishOnMessage(struct FName MessageName); // Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x6e94468
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTTask_BlueprintBase.ReceiveTickAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function AIModule.BTTask_BlueprintBase.ReceiveTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveExecute(struct AActor* OwnerActor); // Function AIModule.BTTask_BlueprintBase.ReceiveExecute // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveAbort(struct AActor* OwnerActor); // Function AIModule.BTTask_BlueprintBase.ReceiveAbort // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	bool IsTaskExecuting(); // Function AIModule.BTTask_BlueprintBase.IsTaskExecuting // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e93a6c
	bool IsTaskAborting(); // Function AIModule.BTTask_BlueprintBase.IsTaskAborting // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e93a50
	void FinishExecute(bool bSuccess); // Function AIModule.BTTask_BlueprintBase.FinishExecute // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x6e93290
	void FinishAbort(); // Function AIModule.BTTask_BlueprintBase.FinishAbort // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x6e93228
};

// Class AIModule.BTTask_FinishWithResult
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_FinishWithResult : UBTTaskNode {
	enum class EBTNodeResult Result; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class AIModule.BTTask_GameplayTaskBase
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_GameplayTaskBase : UBTTaskNode {
	char bWaitForGameplayTask : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class AIModule.BTTask_MakeNoise
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_MakeNoise : UBTTaskNode {
	float Loudnes; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class AIModule.BTTask_MoveTo
// Size: 0xb0 (Inherited: 0x98)
struct UBTTask_MoveTo : UBTTask_BlackboardBase {
	float AcceptableRadius; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xa0(0x08)
	float ObservedBlackboardValueTolerance; // 0xa8(0x04)
	char bObserveBlackboardValue : 1; // 0xac(0x01)
	char bAllowStrafe : 1; // 0xac(0x01)
	char bAllowPartialPath : 1; // 0xac(0x01)
	char bTrackMovingGoal : 1; // 0xac(0x01)
	char bRequireNavigableEndLocation : 1; // 0xac(0x01)
	char bProjectGoalLocation : 1; // 0xac(0x01)
	char bReachTestIncludesAgentRadius : 1; // 0xac(0x01)
	char bReachTestIncludesGoalRadius : 1; // 0xac(0x01)
	char bStopOnOverlap : 1; // 0xad(0x01)
	char bStopOnOverlapNeedsUpdate : 1; // 0xad(0x01)
	char pad_AD_2 : 6; // 0xad(0x01)
	char pad_AE[0x2]; // 0xae(0x02)
};

// Class AIModule.BTTask_MoveDirectlyToward
// Size: 0xb8 (Inherited: 0xb0)
struct UBTTask_MoveDirectlyToward : UBTTask_MoveTo {
	char bDisablePathUpdateOnGoalLocationChange : 1; // 0xb0(0x01)
	char bProjectVectorGoalToNavigation : 1; // 0xb0(0x01)
	char bUpdatedDeprecatedProperties : 1; // 0xb0(0x01)
	char pad_B0_3 : 5; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class AIModule.BTTask_PawnActionBase
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_PawnActionBase : UBTTaskNode {
};

// Class AIModule.BTTask_PlayAnimation
// Size: 0xb0 (Inherited: 0x70)
struct UBTTask_PlayAnimation : UBTTaskNode {
	struct UAnimationAsset* AnimationToPlay; // 0x70(0x08)
	char bLooping : 1; // 0x78(0x01)
	char bNonBlocking : 1; // 0x78(0x01)
	char pad_78_2 : 6; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct UBehaviorTreeComponent* MyOwnerComp; // 0x80(0x08)
	struct USkeletalMeshComponent* CachedSkelMesh; // 0x88(0x08)
	char pad_90[0x20]; // 0x90(0x20)
};

// Class AIModule.BTTask_PlaySound
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PlaySound : UBTTaskNode {
	struct USoundCue* SoundToPlay; // 0x70(0x08)
};

// Class AIModule.BTTask_PushPawnAction
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PushPawnAction : UBTTask_PawnActionBase {
	struct UPawnAction* Action; // 0x70(0x08)
};

// Class AIModule.BTTask_RotateToFaceBBEntry
// Size: 0xa0 (Inherited: 0x98)
struct UBTTask_RotateToFaceBBEntry : UBTTask_BlackboardBase {
	float Precision; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class AIModule.BTTask_RunBehavior
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_RunBehavior : UBTTaskNode {
	struct UBehaviorTree* BehaviorAsset; // 0x70(0x08)
};

// Class AIModule.BTTask_RunBehaviorDynamic
// Size: 0x88 (Inherited: 0x70)
struct UBTTask_RunBehaviorDynamic : UBTTaskNode {
	struct FGameplayTag InjectionTag; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct UBehaviorTree* DefaultBehaviorAsset; // 0x78(0x08)
	struct UBehaviorTree* BehaviorAsset; // 0x80(0x08)
};

// Class AIModule.BTTask_RunEQSQuery
// Size: 0x158 (Inherited: 0x98)
struct UBTTask_RunEQSQuery : UBTTask_BlackboardBase {
	struct UEnvQuery* QueryTemplate; // 0x98(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0xa0(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0xb0(0x10)
	enum class EEnvQueryRunMode RunMode; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // 0xc8(0x28)
	bool bUseBBKey; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xf8(0x48)
	bool bUpdateBBOnFail; // 0x140(0x01)
	char pad_141[0x17]; // 0x141(0x17)
};

// Class AIModule.BTTask_SetTagCooldown
// Size: 0x80 (Inherited: 0x70)
struct UBTTask_SetTagCooldown : UBTTaskNode {
	struct FGameplayTag CooldownTag; // 0x70(0x04)
	bool bAddToExistingDuration; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
	float CooldownDuration; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class AIModule.BTTask_Wait
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_Wait : UBTTaskNode {
	float WaitTime; // 0x70(0x04)
	float RandomDeviation; // 0x74(0x04)
};

// Class AIModule.BTTask_WaitBlackboardTime
// Size: 0xa0 (Inherited: 0x78)
struct UBTTask_WaitBlackboardTime : UBTTask_Wait {
	struct FBlackboardKeySelector BlackboardKey; // 0x78(0x28)
};

// Class AIModule.AIBlueprintHelperLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAIBlueprintHelperLibrary : UBlueprintFunctionLibrary {

	void UnlockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic); // Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x6e953f8
	struct APawn* SpawnAIFromClass(struct UObject* WorldContextObject, struct APawn* PawnClass, struct UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail, struct AActor* Owner); // Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6e94850
	void SimpleMoveToLocation(struct AController* Controller, struct FVector& Goal); // Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6e94758
	void SimpleMoveToActor(struct AController* Controller, struct AActor* Goal); // Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6e946a4
	void SendAIMessage(struct APawn* Target, struct FName Message, struct UObject* MessageSource, bool bSuccess); // Function AIModule.AIBlueprintHelperLibrary.SendAIMessage // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6e94288
	void LockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic); // Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x6e93e88
	bool IsValidAIRotation(struct FRotator Rotation); // Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6e93d48
	bool IsValidAILocation(struct FVector Location); // Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6e93c08
	bool IsValidAIDirection(struct FVector DirectionVector); // Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x6e93ac8
	int32_t GetNextNavLinkIndex(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e936e8
	struct TArray<struct FVector> GetCurrentPathPoints(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e935a8
	int32_t GetCurrentPathIndex(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e93504
	struct UNavigationPath* GetCurrentPath(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e933fc
	struct UBlackboardComponent* GetBlackboard(struct AActor* Target); // Function AIModule.AIBlueprintHelperLibrary.GetBlackboard // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6e93350
	struct AAIController* GetAIController(struct AActor* ControlledActor); // Function AIModule.AIBlueprintHelperLibrary.GetAIController // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x31257ec
	struct UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(struct UObject* WorldContextObject, struct APawn* Pawn, struct FVector Destination, struct AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap); // Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6e92de8
};

// Class AIModule.AIDataProvider
// Size: 0x28 (Inherited: 0x28)
struct UAIDataProvider : UObject {
};

// Class AIModule.AIDataProvider_QueryParams
// Size: 0x38 (Inherited: 0x28)
struct UAIDataProvider_QueryParams : UAIDataProvider {
	struct FName ParamName; // 0x28(0x04)
	float FloatValue; // 0x2c(0x04)
	int32_t IntValue; // 0x30(0x04)
	bool BoolValue; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// Class AIModule.AIDataProvider_Random
// Size: 0x48 (Inherited: 0x38)
struct UAIDataProvider_Random : UAIDataProvider_QueryParams {
	float Min; // 0x38(0x04)
	float Max; // 0x3c(0x04)
	char bInteger : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class AIModule.DetourCrowdAIController
// Size: 0x3b8 (Inherited: 0x3b8)
struct ADetourCrowdAIController : AAIController {
};

// Class AIModule.EnvQueryContext
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext : UObject {
};

// Class AIModule.EnvQueryContext_BlueprintBase
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryContext_BlueprintBase : UEnvQueryContext {
	char pad_28[0x8]; // 0x28(0x08)

	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x211c0a0
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x211c0a0
	void ProvideLocationsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct FVector>& ResultingLocationSet); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x211c0a0
	void ProvideActorsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct AActor*>& ResultingActorsSet); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x211c0a0
};

// Class AIModule.EnvQueryContext_Item
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext_Item : UEnvQueryContext {
};

// Class AIModule.EnvQueryContext_Querier
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext_Querier : UEnvQueryContext {
};

// Class AIModule.EnvQuery
// Size: 0x48 (Inherited: 0x30)
struct UEnvQuery : UDataAsset {
	struct FName QueryName; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TArray<struct UEnvQueryOption*> Options; // 0x38(0x10)
};

// Class AIModule.EnvQueryDebugHelpers
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryDebugHelpers : UObject {
};

// Class AIModule.EnvQueryNode
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryNode : UObject {
	int32_t VerNum; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// Class AIModule.EnvQueryGenerator
// Size: 0x50 (Inherited: 0x30)
struct UEnvQueryGenerator : UEnvQueryNode {
	struct FString OptionName; // 0x30(0x10)
	struct UEnvQueryItemType* ItemType; // 0x40(0x08)
	char bAutoSortTests : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.EnvQueryInstanceBlueprintWrapper
// Size: 0x78 (Inherited: 0x28)
struct UEnvQueryInstanceBlueprintWrapper : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	int32_t QueryID; // 0x30(0x04)
	char pad_34[0x24]; // 0x34(0x24)
	struct UEnvQueryItemType* ItemType; // 0x58(0x08)
	int32_t OptionIndex; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct FMulticastInlineDelegate OnQueryFinishedEvent; // 0x68(0x10)

	void SetNamedParam(struct FName ParamName, float Value); // Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6e945d8
	struct TArray<struct FVector> GetResultsAsLocations(); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e93968
	struct TArray<struct AActor*> GetResultsAsActors(); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e93928
	bool GetQueryResultsAsLocations(struct TArray<struct FVector>& ResultLocations); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x6e9387c
	bool GetQueryResultsAsActors(struct TArray<struct AActor*>& ResultActors); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x6e93794
	float GetItemScore(int32_t ItemIndex); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e9363c
	void EQSQueryDoneSignature__DelegateSignature(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x211c0a0
};

// Class AIModule.EnvQueryManager
// Size: 0x158 (Inherited: 0x38)
struct UEnvQueryManager : UAISubsystem {
	char pad_38[0x70]; // 0x38(0x70)
	struct TArray<struct FEnvQueryInstanceCache> InstanceCache; // 0xa8(0x10)
	struct TArray<struct UEnvQueryContext*> LocalContexts; // 0xb8(0x10)
	struct TArray<struct UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // 0xc8(0x10)
	char pad_D8[0x54]; // 0xd8(0x54)
	float MaxAllowedTestingTime; // 0x12c(0x04)
	bool bTestQueriesUsingBreadth; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	int32_t QueryCountWarningThreshold; // 0x134(0x04)
	double QueryCountWarningInterval; // 0x138(0x08)
	double ExecutionTimeWarningSeconds; // 0x140(0x08)
	double HandlingResultTimeWarningSeconds; // 0x148(0x08)
	double GenerationTimeWarningSeconds; // 0x150(0x08)

	struct UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(struct UObject* WorldContextObject, struct UEnvQuery* QueryTemplate, struct UObject* Querier, enum class EEnvQueryRunMode RunMode, struct UEnvQueryInstanceBlueprintWrapper* WrapperClass); // Function AIModule.EnvQueryManager.RunEQSQuery // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6e94018
};

// Class AIModule.EnvQueryOption
// Size: 0x40 (Inherited: 0x28)
struct UEnvQueryOption : UObject {
	struct UEnvQueryGenerator* Generator; // 0x28(0x08)
	struct TArray<struct UEnvQueryTest*> Tests; // 0x30(0x10)
};

// Class AIModule.EnvQueryTest
// Size: 0x1f8 (Inherited: 0x30)
struct UEnvQueryTest : UEnvQueryNode {
	int32_t TestOrder; // 0x30(0x04)
	enum class EEnvTestPurpose TestPurpose; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FString TestComment; // 0x38(0x10)
	enum class EEnvTestFilterOperator MultipleContextFilterOp; // 0x48(0x01)
	enum class EEnvTestScoreOperator MultipleContextScoreOp; // 0x49(0x01)
	enum class EEnvTestFilterType FilterType; // 0x4a(0x01)
	char pad_4B[0x5]; // 0x4b(0x05)
	struct FAIDataProviderBoolValue BoolValue; // 0x50(0x38)
	struct FAIDataProviderFloatValue FloatValueMin; // 0x88(0x38)
	struct FAIDataProviderFloatValue FloatValueMax; // 0xc0(0x38)
	char pad_F8[0x1]; // 0xf8(0x01)
	enum class EEnvTestScoreEquation ScoringEquation; // 0xf9(0x01)
	enum class EEnvQueryTestClamping ClampMinType; // 0xfa(0x01)
	enum class EEnvQueryTestClamping ClampMaxType; // 0xfb(0x01)
	enum class EEQSNormalizationType NormalizationType; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	struct FAIDataProviderFloatValue ScoreClampMin; // 0x100(0x38)
	struct FAIDataProviderFloatValue ScoreClampMax; // 0x138(0x38)
	struct FAIDataProviderFloatValue ScoringFactor; // 0x170(0x38)
	struct FAIDataProviderFloatValue ReferenceValue; // 0x1a8(0x38)
	bool bDefineReferenceValue; // 0x1e0(0x01)
	char pad_1E1[0xf]; // 0x1e1(0x0f)
	char bWorkOnFloatValues : 1; // 0x1f0(0x01)
	char pad_1F0_1 : 7; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
};

// Class AIModule.EQSRenderingComponent
// Size: 0x600 (Inherited: 0x5c0)
struct UEQSRenderingComponent : UDebugDrawComponent {
	char pad_5C0[0x40]; // 0x5c0(0x40)
};

// Class AIModule.EQSTestingPawn
// Size: 0x700 (Inherited: 0x660)
struct AEQSTestingPawn : ACharacter {
	char pad_660[0x8]; // 0x660(0x08)
	struct UEnvQuery* QueryTemplate; // 0x668(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0x670(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x680(0x10)
	float TimeLimitPerStep; // 0x690(0x04)
	int32_t StepToDebugDraw; // 0x694(0x04)
	enum class EEnvQueryHightlightMode HighlightMode; // 0x698(0x01)
	char pad_699[0x3]; // 0x699(0x03)
	char bDrawLabels : 1; // 0x69c(0x01)
	char bDrawFailedItems : 1; // 0x69c(0x01)
	char bReRunQueryOnlyOnFinishedMove : 1; // 0x69c(0x01)
	char bShouldBeVisibleInGame : 1; // 0x69c(0x01)
	char bTickDuringGame : 1; // 0x69c(0x01)
	char pad_69C_5 : 3; // 0x69c(0x01)
	char pad_69D[0x3]; // 0x69d(0x03)
	enum class EEnvQueryRunMode QueryingMode; // 0x6a0(0x01)
	char pad_6A1[0x7]; // 0x6a1(0x07)
	struct FNavAgentProperties NavAgentProperties; // 0x6a8(0x30)
	char pad_6D8[0x28]; // 0x6d8(0x28)
};

// Class AIModule.EnvQueryGenerator_ActorsOfClass
// Size: 0xd0 (Inherited: 0x50)
struct UEnvQueryGenerator_ActorsOfClass : UEnvQueryGenerator {
	struct AActor* SearchedActorClass; // 0x50(0x08)
	struct FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // 0x58(0x38)
	struct FAIDataProviderFloatValue SearchRadius; // 0x90(0x38)
	struct UEnvQueryContext* SearchCenter; // 0xc8(0x08)
};

// Class AIModule.EnvQueryGenerator_BlueprintBase
// Size: 0x88 (Inherited: 0x50)
struct UEnvQueryGenerator_BlueprintBase : UEnvQueryGenerator {
	struct FText GeneratorsActionDescription; // 0x50(0x18)
	struct UEnvQueryContext* Context; // 0x68(0x08)
	struct UEnvQueryItemType* GeneratedItemType; // 0x70(0x08)
	char pad_78[0x10]; // 0x78(0x10)

	struct UObject* GetQuerier(); // Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e93768
	void DoItemGenerationFromActors(struct TArray<struct AActor*>& ContextActors); // Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGenerationFromActors // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x211c0a0
	void DoItemGeneration(struct TArray<struct FVector>& ContextLocations); // Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x211c0a0
	void AddGeneratedVector(struct FVector GeneratedVector); // Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|Const) // @ game+0x6e92ca8
	void AddGeneratedActor(struct AActor* GeneratedActor); // Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x6e92c28
};

// Class AIModule.EnvQueryGenerator_Composite
// Size: 0x70 (Inherited: 0x50)
struct UEnvQueryGenerator_Composite : UEnvQueryGenerator {
	struct TArray<struct UEnvQueryGenerator*> Generators; // 0x50(0x10)
	char bAllowDifferentItemTypes : 1; // 0x60(0x01)
	char bHasMatchingItemType : 1; // 0x60(0x01)
	char pad_60_2 : 6; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct UEnvQueryItemType* ForcedItemType; // 0x68(0x08)
};

// Class AIModule.EnvQueryGenerator_ProjectedPoints
// Size: 0x88 (Inherited: 0x50)
struct UEnvQueryGenerator_ProjectedPoints : UEnvQueryGenerator {
	struct FEnvTraceData ProjectionData; // 0x50(0x38)
};

// Class AIModule.EnvQueryGenerator_Cone
// Size: 0x178 (Inherited: 0x88)
struct UEnvQueryGenerator_Cone : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue AlignedPointsDistance; // 0x88(0x38)
	struct FAIDataProviderFloatValue ConeDegrees; // 0xc0(0x38)
	struct FAIDataProviderFloatValue AngleStep; // 0xf8(0x38)
	struct FAIDataProviderFloatValue Range; // 0x130(0x38)
	struct UEnvQueryContext* CenterActor; // 0x168(0x08)
	char bIncludeContextLocation : 1; // 0x170(0x01)
	char pad_170_1 : 7; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
};

// Class AIModule.EnvQueryGenerator_CurrentLocation
// Size: 0x58 (Inherited: 0x50)
struct UEnvQueryGenerator_CurrentLocation : UEnvQueryGenerator {
	struct UEnvQueryContext* QueryContext; // 0x50(0x08)
};

// Class AIModule.EnvQueryGenerator_Donut
// Size: 0x1d8 (Inherited: 0x88)
struct UEnvQueryGenerator_Donut : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue InnerRadius; // 0x88(0x38)
	struct FAIDataProviderFloatValue OuterRadius; // 0xc0(0x38)
	struct FAIDataProviderIntValue NumberOfRings; // 0xf8(0x38)
	struct FAIDataProviderIntValue PointsPerRing; // 0x130(0x38)
	struct FEnvDirection ArcDirection; // 0x168(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x188(0x38)
	bool bUseSpiralPattern; // 0x1c0(0x01)
	char pad_1C1[0x7]; // 0x1c1(0x07)
	struct UEnvQueryContext* Center; // 0x1c8(0x08)
	char bDefineArc : 1; // 0x1d0(0x01)
	char pad_1D0_1 : 7; // 0x1d0(0x01)
	char pad_1D1[0x7]; // 0x1d1(0x07)
};

// Class AIModule.EnvQueryGenerator_OnCircle
// Size: 0x220 (Inherited: 0x88)
struct UEnvQueryGenerator_OnCircle : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue CircleRadius; // 0x88(0x38)
	enum class EPointOnCircleSpacingMethod PointOnCircleSpacingMethod; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xc8(0x38)
	struct FAIDataProviderIntValue NumberOfPoints; // 0x100(0x38)
	struct FEnvDirection ArcDirection; // 0x138(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x158(0x38)
	float AngleRadians; // 0x190(0x04)
	char pad_194[0x4]; // 0x194(0x04)
	struct UEnvQueryContext* CircleCenter; // 0x198(0x08)
	bool bIgnoreAnyContextActorsWhenGeneratingCircle; // 0x1a0(0x01)
	char pad_1A1[0x7]; // 0x1a1(0x07)
	struct FAIDataProviderFloatValue CircleCenterZOffset; // 0x1a8(0x38)
	struct FEnvTraceData TraceData; // 0x1e0(0x38)
	char bDefineArc : 1; // 0x218(0x01)
	char pad_218_1 : 7; // 0x218(0x01)
	char pad_219[0x7]; // 0x219(0x07)
};

// Class AIModule.EnvQueryGenerator_SimpleGrid
// Size: 0x100 (Inherited: 0x88)
struct UEnvQueryGenerator_SimpleGrid : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue GridSize; // 0x88(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xc0(0x38)
	struct UEnvQueryContext* GenerateAround; // 0xf8(0x08)
};

// Class AIModule.EnvQueryGenerator_PathingGrid
// Size: 0x178 (Inherited: 0x100)
struct UEnvQueryGenerator_PathingGrid : UEnvQueryGenerator_SimpleGrid {
	struct FAIDataProviderBoolValue PathToItem; // 0x100(0x38)
	struct UNavigationQueryFilter* NavigationFilter; // 0x138(0x08)
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x140(0x38)
};

// Class AIModule.EnvQueryGenerator_PerceivedActors
// Size: 0xa8 (Inherited: 0x50)
struct UEnvQueryGenerator_PerceivedActors : UEnvQueryGenerator {
	struct AActor* AllowedActorClass; // 0x50(0x08)
	struct FAIDataProviderFloatValue SearchRadius; // 0x58(0x38)
	struct UEnvQueryContext* ListenerContext; // 0x90(0x08)
	struct UAISense* SenseToUse; // 0x98(0x08)
	bool bIncludeKnownActors; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
};

// Class AIModule.EnvQueryItemType
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryItemType : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class AIModule.EnvQueryItemType_VectorBase
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_VectorBase : UEnvQueryItemType {
};

// Class AIModule.EnvQueryItemType_ActorBase
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_ActorBase : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryItemType_Actor
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Actor : UEnvQueryItemType_ActorBase {
};

// Class AIModule.EnvQueryItemType_Direction
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Direction : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryItemType_Point
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Point : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryTest_Distance
// Size: 0x208 (Inherited: 0x1f8)
struct UEnvQueryTest_Distance : UEnvQueryTest {
	enum class EEnvTestDistance TestMode; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct UEnvQueryContext* DistanceTo; // 0x200(0x08)
};

// Class AIModule.EnvQueryTest_Dot
// Size: 0x240 (Inherited: 0x1f8)
struct UEnvQueryTest_Dot : UEnvQueryTest {
	struct FEnvDirection LineA; // 0x1f8(0x20)
	struct FEnvDirection LineB; // 0x218(0x20)
	enum class EEnvTestDot TestMode; // 0x238(0x01)
	bool bAbsoluteValue; // 0x239(0x01)
	char pad_23A[0x6]; // 0x23a(0x06)
};

// Class AIModule.EnvQueryTest_GameplayTags
// Size: 0x268 (Inherited: 0x1f8)
struct UEnvQueryTest_GameplayTags : UEnvQueryTest {
	struct FGameplayTagQuery TagQueryToMatch; // 0x1f8(0x48)
	bool bRejectIncompatibleItems; // 0x240(0x01)
	bool bUpdatedToUseQuery; // 0x241(0x01)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x242(0x01)
	char pad_243[0x5]; // 0x243(0x05)
	struct FGameplayTagContainer GameplayTags; // 0x248(0x20)
};

// Class AIModule.EnvQueryTest_Overlap
// Size: 0x228 (Inherited: 0x1f8)
struct UEnvQueryTest_Overlap : UEnvQueryTest {
	struct FEnvOverlapData OverlapData; // 0x1f8(0x30)
};

// Class AIModule.EnvQueryTest_Pathfinding
// Size: 0x280 (Inherited: 0x1f8)
struct UEnvQueryTest_Pathfinding : UEnvQueryTest {
	enum class EEnvTestPathfinding TestMode; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct UEnvQueryContext* Context; // 0x200(0x08)
	struct FAIDataProviderBoolValue PathFromContext; // 0x208(0x38)
	struct FAIDataProviderBoolValue SkipUnreachable; // 0x240(0x38)
	struct UNavigationQueryFilter* FilterClass; // 0x278(0x08)
};

// Class AIModule.EnvQueryTest_PathfindingBatch
// Size: 0x2b8 (Inherited: 0x280)
struct UEnvQueryTest_PathfindingBatch : UEnvQueryTest_Pathfinding {
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x280(0x38)
};

// Class AIModule.EnvQueryTest_Project
// Size: 0x230 (Inherited: 0x1f8)
struct UEnvQueryTest_Project : UEnvQueryTest {
	struct FEnvTraceData ProjectionData; // 0x1f8(0x38)
};

// Class AIModule.EnvQueryTest_Random
// Size: 0x1f8 (Inherited: 0x1f8)
struct UEnvQueryTest_Random : UEnvQueryTest {
};

// Class AIModule.EnvQueryTest_Trace
// Size: 0x2e0 (Inherited: 0x1f8)
struct UEnvQueryTest_Trace : UEnvQueryTest {
	struct FEnvTraceData TraceData; // 0x1f8(0x38)
	struct FAIDataProviderBoolValue TraceFromContext; // 0x230(0x38)
	struct FAIDataProviderFloatValue ItemHeightOffset; // 0x268(0x38)
	struct FAIDataProviderFloatValue ContextHeightOffset; // 0x2a0(0x38)
	struct UEnvQueryContext* Context; // 0x2d8(0x08)
};

// Class AIModule.EnvQueryTest_Volume
// Size: 0x210 (Inherited: 0x1f8)
struct UEnvQueryTest_Volume : UEnvQueryTest {
	struct UEnvQueryContext* VolumeContext; // 0x1f8(0x08)
	struct AVolume* VolumeClass; // 0x200(0x08)
	char bDoComplexVolumeTest : 1; // 0x208(0x01)
	char bSkipTestIfNoVolumes : 1; // 0x208(0x01)
	char pad_208_2 : 6; // 0x208(0x01)
	char pad_209[0x7]; // 0x209(0x07)
};

// Class AIModule.GridPathAIController
// Size: 0x3b8 (Inherited: 0x3b8)
struct AGridPathAIController : AAIController {
};

// Class AIModule.AIHotSpotManager
// Size: 0x28 (Inherited: 0x28)
struct UAIHotSpotManager : UObject {
};

// Class AIModule.PathFollowingComponent
// Size: 0x2d0 (Inherited: 0xa0)
struct UPathFollowingComponent : UActorComponent {
	char pad_A0[0x38]; // 0xa0(0x38)
	struct UNavMovementComponent* MovementComp; // 0xd8(0x08)
	char pad_E0[0x10]; // 0xe0(0x10)
	struct ANavigationData* MyNavData; // 0xf0(0x08)
	char pad_F8[0x1d8]; // 0xf8(0x1d8)

	void OnNavDataRegistered(struct ANavigationData* NavData); // Function AIModule.PathFollowingComponent.OnNavDataRegistered // (Final|RequiredAPI|Native|Protected) // @ game+0x6ebe034
	void OnActorBump(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit); // Function AIModule.PathFollowingComponent.OnActorBump // (RequiredAPI|Native|Public|HasOutParms|HasDefaults) // @ game+0x6ebddb8
	struct FVector GetPathDestination(); // Function AIModule.PathFollowingComponent.GetPathDestination // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebda28
	enum class EPathFollowingAction GetPathActionType(); // Function AIModule.PathFollowingComponent.GetPathActionType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebd9b0
};

// Class AIModule.CrowdFollowingComponent
// Size: 0x320 (Inherited: 0x2d0)
struct UCrowdFollowingComponent : UPathFollowingComponent {
	char pad_2D0[0x18]; // 0x2d0(0x18)
	struct FVector CrowdAgentMoveDirection; // 0x2e8(0x18)
	char pad_300[0x20]; // 0x300(0x20)

	void SuspendCrowdSteering(bool bSuspend); // Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ebe60c
};

// Class AIModule.CrowdManager
// Size: 0xf0 (Inherited: 0x28)
struct UCrowdManager : UCrowdManagerBase {
	struct ANavigationData* MyNavData; // 0x28(0x08)
	struct TArray<struct FCrowdAvoidanceConfig> AvoidanceConfig; // 0x30(0x10)
	struct TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns; // 0x40(0x10)
	int32_t MaxAgents; // 0x50(0x04)
	float MaxAgentRadius; // 0x54(0x04)
	int32_t MaxAvoidedAgents; // 0x58(0x04)
	int32_t MaxAvoidedWalls; // 0x5c(0x04)
	float NavmeshCheckInterval; // 0x60(0x04)
	float PathOptimizationInterval; // 0x64(0x04)
	float SeparationDirClamp; // 0x68(0x04)
	float PathOffsetRadiusMultiplier; // 0x6c(0x04)
	char pad_70_0 : 4; // 0x70(0x01)
	char bResolveCollisions : 1; // 0x70(0x01)
	char pad_70_5 : 3; // 0x70(0x01)
	char pad_71[0x7f]; // 0x71(0x7f)
};

// Class AIModule.GridPathFollowingComponent
// Size: 0x300 (Inherited: 0x2d0)
struct UGridPathFollowingComponent : UPathFollowingComponent {
	struct UNavLocalGridManager* GridManager; // 0x2d0(0x08)
	char pad_2D8[0x28]; // 0x2d8(0x28)
};

// Class AIModule.NavFilter_AIControllerDefault
// Size: 0x48 (Inherited: 0x48)
struct UNavFilter_AIControllerDefault : UNavigationQueryFilter {
};

// Class AIModule.NavLinkProxy
// Size: 0x2e0 (Inherited: 0x290)
struct ANavLinkProxy : AActor {
	char pad_290[0x10]; // 0x290(0x10)
	struct TArray<struct FNavigationLink> PointLinks; // 0x2a0(0x10)
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x2b0(0x10)
	struct UNavLinkCustomComponent* SmartLinkComp; // 0x2c0(0x08)
	bool bSmartLinkIsRelevant; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct FMulticastInlineDelegate OnSmartLinkReached; // 0x2d0(0x10)

	void SetSmartLinkEnabled(bool bEnabled); // Function AIModule.NavLinkProxy.SetSmartLinkEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ebe588
	void ResumePathFollowing(struct AActor* Agent); // Function AIModule.NavLinkProxy.ResumePathFollowing // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ebe300
	void ReceiveSmartLinkReached(struct AActor* Agent, struct FVector& Destination); // Function AIModule.NavLinkProxy.ReceiveSmartLinkReached // (RequiredAPI|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x211c0a0
	bool IsSmartLinkEnabled(); // Function AIModule.NavLinkProxy.IsSmartLinkEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebdd94
	bool HasMovingAgents(); // Function AIModule.NavLinkProxy.HasMovingAgents // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebdc88
};

// Class AIModule.NavLocalGridManager
// Size: 0x58 (Inherited: 0x28)
struct UNavLocalGridManager : UObject {
	char pad_28[0x30]; // 0x28(0x30)

	bool SetLocalNavigationGridDensity(struct UObject* WorldContextObject, float CellSize); // Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6ebe3d8
	void RemoveLocalNavigationGrid(struct UObject* WorldContextObject, int32_t GridId, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6ebe1dc
	bool FindLocalNavigationGridPath(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, struct TArray<struct FVector>& PathPoints); // Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6ebd2a4
	int32_t AddLocalNavigationGridForPoints(struct UObject* WorldContextObject, struct TArray<struct FVector>& Locations, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6ebcf10
	int32_t AddLocalNavigationGridForPoint(struct UObject* WorldContextObject, struct FVector& Location, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6ebcc7c
	int32_t AddLocalNavigationGridForCapsule(struct UObject* WorldContextObject, struct FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6ebc8dc
	int32_t AddLocalNavigationGridForBox(struct UObject* WorldContextObject, struct FVector& Location, struct FVector Extent, struct FRotator Rotation, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6ebc354
};

// Class AIModule.PathFollowingManager
// Size: 0x28 (Inherited: 0x28)
struct UPathFollowingManager : UObject {
};

// Class AIModule.AIPerceptionComponent
// Size: 0x188 (Inherited: 0xa0)
struct UAIPerceptionComponent : UActorComponent {
	struct TArray<struct UAISenseConfig*> SensesConfig; // 0xa0(0x10)
	struct UAISense* DominantSense; // 0xb0(0x08)
	char pad_B8[0x8]; // 0xb8(0x08)
	struct AAIController* AIOwner; // 0xc0(0x08)
	char pad_C8[0x80]; // 0xc8(0x80)
	struct FMulticastInlineDelegate OnPerceptionUpdated; // 0x148(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionForgotten; // 0x158(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionUpdated; // 0x168(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionInfoUpdated; // 0x178(0x10)

	void SetSenseEnabled(struct UAISense* SenseClass, bool bEnable); // Function AIModule.AIPerceptionComponent.SetSenseEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ebe49c
	void RequestStimuliListenerUpdate(); // Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ebe2ec
	void OnOwnerEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function AIModule.AIPerceptionComponent.OnOwnerEndPlay // (Final|RequiredAPI|Native|Public) // @ game+0x6ebe118
	bool IsSenseEnabled(struct UAISense* SenseClass); // Function AIModule.AIPerceptionComponent.IsSenseEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebdcf0
	void GetPerceivedHostileActorsBySense(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebdb40
	void GetPerceivedHostileActors(struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebda60
	void GetKnownPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebd874
	void GetCurrentlyPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ebd738
	bool GetActorsPerception(struct AActor* Actor, struct FActorPerceptionBlueprintInfo& Info); // Function AIModule.AIPerceptionComponent.GetActorsPerception // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6ebd4cc
	void ForgetAll(); // Function AIModule.AIPerceptionComponent.ForgetAll // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ebd4b8
};

// Class AIModule.AIPerceptionListenerInterface
// Size: 0x28 (Inherited: 0x28)
struct UAIPerceptionListenerInterface : UInterface {
};

// Class AIModule.AIPerceptionStimuliSourceComponent
// Size: 0xb8 (Inherited: 0xa0)
struct UAIPerceptionStimuliSourceComponent : UActorComponent {
	char bAutoRegisterAsSource : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct TArray<struct UAISense*> RegisterAsSourceForSenses; // 0xa8(0x10)

	void UnregisterFromSense(struct UAISense* SenseClass); // Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6eccf54
	void UnregisterFromPerceptionSystem(); // Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6eccf40
	void RegisterWithPerceptionSystem(); // Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ecbdf8
	void RegisterForSense(struct UAISense* SenseClass); // Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ecbb2c
};

// Class AIModule.AIPerceptionSystem
// Size: 0x130 (Inherited: 0x38)
struct UAIPerceptionSystem : UAISubsystem {
	char pad_38[0x50]; // 0x38(0x50)
	struct TArray<struct UAISense*> Senses; // 0x88(0x10)
	float PerceptionAgingRate; // 0x98(0x04)
	char pad_9C[0x94]; // 0x9c(0x94)

	void ReportPerceptionEvent(struct UObject* WorldContextObject, struct UAISenseEvent* PerceptionEvent); // Function AIModule.AIPerceptionSystem.ReportPerceptionEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6ecc780
	void ReportEvent(struct UAISenseEvent* PerceptionEvent); // Function AIModule.AIPerceptionSystem.ReportEvent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6ecc1f0
	bool RegisterPerceptionStimuliSource(struct UObject* WorldContextObject, struct UAISense* Sense, struct AActor* Target); // Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6ecbc7c
	void OnPerceptionStimuliSourceEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay // (Final|RequiredAPI|Native|Protected) // @ game+0x20f61fc
	struct UAISense* GetSenseClassForStimulus(struct UObject* WorldContextObject, struct FAIStimulus& Stimulus); // Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6ecb9b8
};

// Class AIModule.AISense
// Size: 0x78 (Inherited: 0x28)
struct UAISense : UObject {
	enum class EAISenseNotifyType NotifyType; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	char bWantsNewPawnNotification : 1; // 0x2c(0x01)
	char bAutoRegisterAllPawnsAsSources : 1; // 0x2c(0x01)
	char pad_2C_2 : 6; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	struct UAIPerceptionSystem* PerceptionSystemInstance; // 0x30(0x08)
	char pad_38[0x40]; // 0x38(0x40)
};

// Class AIModule.AISenseConfig_Damage
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Damage : UAISenseConfig {
	struct UAISense_Damage* Implementation; // 0x48(0x08)
};

// Class AIModule.AISense_Blueprint
// Size: 0xa0 (Inherited: 0x78)
struct UAISense_Blueprint : UAISense {
	struct UUserDefinedStruct* ListenerDataType; // 0x78(0x08)
	struct TArray<struct UAIPerceptionComponent*> ListenerContainer; // 0x80(0x10)
	struct TArray<struct UAISenseEvent*> UnprocessedEvents; // 0x90(0x10)

	float OnUpdate(struct TArray<struct UAISenseEvent*>& EventsToProcess); // Function AIModule.AISense_Blueprint.OnUpdate // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnListenerUpdated(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent); // Function AIModule.AISense_Blueprint.OnListenerUpdated // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnListenerUnregistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent); // Function AIModule.AISense_Blueprint.OnListenerUnregistered // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnListenerRegistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent); // Function AIModule.AISense_Blueprint.OnListenerRegistered // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void K2_OnNewPawn(struct APawn* NewPawn); // Function AIModule.AISense_Blueprint.K2_OnNewPawn // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void GetAllListenerComponents(struct TArray<struct UAIPerceptionComponent*>& ListenerComponents); // Function AIModule.AISense_Blueprint.GetAllListenerComponents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecb28c
	void GetAllListenerActors(struct TArray<struct AActor*>& ListenerActors); // Function AIModule.AISense_Blueprint.GetAllListenerActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecb1b0
};

// Class AIModule.AISense_Damage
// Size: 0x88 (Inherited: 0x78)
struct UAISense_Damage : UAISense {
	struct TArray<struct FAIDamageEvent> RegisteredEvents; // 0x78(0x10)

	void ReportDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation, struct FName tag); // Function AIModule.AISense_Damage.ReportDamageEvent // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6ecbe0c
};

// Class AIModule.AISense_Hearing
// Size: 0xe0 (Inherited: 0x78)
struct UAISense_Hearing : UAISense {
	struct TArray<struct FAINoiseEvent> NoiseEvents; // 0x78(0x10)
	float SpeedOfSoundSq; // 0x88(0x04)
	char pad_8C[0x54]; // 0x8c(0x54)

	void ReportNoiseEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, struct AActor* Instigator, float MaxRange, struct FName tag); // Function AIModule.AISense_Hearing.ReportNoiseEvent // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6ecc2b0
};

// Class AIModule.AISense_Prediction
// Size: 0x88 (Inherited: 0x78)
struct UAISense_Prediction : UAISense {
	struct TArray<struct FAIPredictionEvent> RegisteredEvents; // 0x78(0x10)

	void RequestPawnPredictionEvent(struct APawn* Requestor, struct AActor* PredictedActor, float PredictionTime); // Function AIModule.AISense_Prediction.RequestPawnPredictionEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6eccba8
	void RequestControllerPredictionEvent(struct AAIController* Requestor, struct AActor* PredictedActor, float PredictionTime); // Function AIModule.AISense_Prediction.RequestControllerPredictionEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6eccab0
};

// Class AIModule.AISense_Sight
// Size: 0x1a8 (Inherited: 0x78)
struct UAISense_Sight : UAISense {
	char pad_78[0xd8]; // 0x78(0xd8)
	int32_t MaxTracesPerTick; // 0x150(0x04)
	int32_t MaxAsyncTracesPerTick; // 0x154(0x04)
	int32_t MinQueriesPerTimeSliceCheck; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
	double MaxTimeSlicePerTick; // 0x160(0x08)
	float HighImportanceQueryDistanceThreshold; // 0x168(0x04)
	char pad_16C[0x4]; // 0x16c(0x04)
	float MaxQueryImportance; // 0x170(0x04)
	float SightLimitQueryImportance; // 0x174(0x04)
	float PendingQueriesBudgetReductionRatio; // 0x178(0x04)
	bool bUseAsynchronousTraceForDefaultSightQueries; // 0x17c(0x01)
	char pad_17D[0x2b]; // 0x17d(0x2b)
};

// Class AIModule.AISense_Team
// Size: 0x88 (Inherited: 0x78)
struct UAISense_Team : UAISense {
	struct TArray<struct FAITeamStimulusEvent> RegisteredEvents; // 0x78(0x10)
};

// Class AIModule.AISense_Touch
// Size: 0xd8 (Inherited: 0x78)
struct UAISense_Touch : UAISense {
	struct TArray<struct FAITouchEvent> RegisteredEvents; // 0x78(0x10)
	char pad_88[0x50]; // 0x88(0x50)

	void ReportTouchEvent(struct UObject* WorldContextObject, struct AActor* TouchReceiver, struct AActor* OtherActor, struct FVector Location); // Function AIModule.AISense_Touch.ReportTouchEvent // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6ecc8d0
};

// Class AIModule.AISightTargetInterface
// Size: 0x28 (Inherited: 0x28)
struct UAISightTargetInterface : UInterface {
};

// Class AIModule.PawnSensingComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UPawnSensingComponent : UActorComponent {
	float HearingThreshold; // 0xa0(0x04)
	float LOSHearingThreshold; // 0xa4(0x04)
	float SightRadius; // 0xa8(0x04)
	float SensingInterval; // 0xac(0x04)
	float HearingMaxSoundAge; // 0xb0(0x04)
	char bEnableSensingUpdates : 1; // 0xb4(0x01)
	char bOnlySensePlayers : 1; // 0xb4(0x01)
	char bSeePawns : 1; // 0xb4(0x01)
	char bHearNoises : 1; // 0xb4(0x01)
	char pad_B4_4 : 4; // 0xb4(0x01)
	char pad_B5[0xb]; // 0xb5(0x0b)
	struct FMulticastInlineDelegate OnSeePawn; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnHearNoise; // 0xd0(0x10)
	float PeripheralVisionAngle; // 0xe0(0x04)
	float PeripheralVisionCosine; // 0xe4(0x04)

	void SetSensingUpdatesEnabled(bool bEnabled); // Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled // (RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6eccebc
	void SetSensingInterval(float NewSensingInterval); // Function AIModule.PawnSensingComponent.SetSensingInterval // (RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6ecce38
	void SetPeripheralVisionAngle(float NewPeripheralVisionAngle); // Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle // (RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x6eccdb4
	void SeePawnDelegate__DelegateSignature(struct APawn* Pawn); // DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x211c0a0
	void HearNoiseDelegate__DelegateSignature(struct APawn* Instigator, struct FVector& Location, float Volume); // DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults) // @ game+0x211c0a0
	float GetPeripheralVisionCosine(); // Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecb9a0
	float GetPeripheralVisionAngle(); // Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6ecb988
};

// Class AIModule.AITask
// Size: 0x68 (Inherited: 0x60)
struct UAITask : UGameplayTask {
	struct AAIController* OwnerController; // 0x60(0x08)
};

// Class AIModule.AITask_LockLogic
// Size: 0x68 (Inherited: 0x68)
struct UAITask_LockLogic : UAITask {
};

// Class AIModule.AITask_MoveTo
// Size: 0x118 (Inherited: 0x68)
struct UAITask_MoveTo : UAITask {
	struct FMulticastInlineDelegate OnRequestFailed; // 0x68(0x10)
	struct FMulticastInlineDelegate OnMoveFinished; // 0x78(0x10)
	struct FAIMoveRequest MoveRequest; // 0x88(0x50)
	char pad_D8[0x40]; // 0xd8(0x40)

	struct UAITask_MoveTo* AIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, struct AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuousGoalTracking, enum class EAIOptionFlag ProjectGoalOnNavigation); // Function AIModule.AITask_MoveTo.AIMoveTo // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6eca94c
};

// Class AIModule.AITask_RunEQS
// Size: 0xe0 (Inherited: 0x68)
struct UAITask_RunEQS : UAITask {
	char pad_68[0x78]; // 0x68(0x78)

	struct UAITask_RunEQS* RunEQS(struct AAIController* Controller, struct UEnvQuery* QueryTemplate); // Function AIModule.AITask_RunEQS.RunEQS // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x6eccca0
};

// Class AIModule.VisualLoggerExtension
// Size: 0x28 (Inherited: 0x28)
struct UVisualLoggerExtension : UObject {
};

