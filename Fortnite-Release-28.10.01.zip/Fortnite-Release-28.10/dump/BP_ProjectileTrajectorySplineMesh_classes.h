// BlueprintGeneratedClass BP_ProjectileTrajectorySplineMesh.BP_ProjectileTrajectorySplineMesh_C
// Size: 0x770 (Inherited: 0x770)
struct UBP_ProjectileTrajectorySplineMesh_C : USplineMeshComponent {
};

