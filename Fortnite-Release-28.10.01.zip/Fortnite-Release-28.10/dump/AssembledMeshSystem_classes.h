// Class AssembledMeshSystem.AssembledMeshSchema
// Size: 0x1c0 (Inherited: 0x30)
struct UAssembledMeshSchema : UPrimaryDataAsset {
	struct FGameplayTag MeshSchemaTag; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TSoftObjectPtr<UCustomizableObjectInstance> CustomizableObjectInstance; // 0x38(0x20)
	struct TSoftObjectPtr<UCustomizableObject> CustomizableObject; // 0x58(0x20)
	int32_t ComponentIndex; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TMap<struct FString, struct FString> SelectedIntParams; // 0x80(0x50)
	struct TMap<struct FString, float> SelectedFloatParams; // 0xd0(0x50)
	struct FAssembledMeshAttachmentRules AttachmentRules; // 0x120(0x50)
	struct TSoftClassPtr<UObject> AnimClass; // 0x170(0x20)
	struct FGameplayTagContainer SoundLibraryTags; // 0x190(0x20)
	struct TArray<struct FInstancedStruct> AdditionalData; // 0x1b0(0x10)
};

// Class AssembledMeshSystem.HeadAccDataAssetLink
// Size: 0x108 (Inherited: 0x108)
struct UHeadAccDataAssetLink : UDataAssetLink {
};

// Class AssembledMeshSystem.NeckAccDataAssetLink
// Size: 0x108 (Inherited: 0x108)
struct UNeckAccDataAssetLink : UDataAssetLink {
};

// Class AssembledMeshSystem.HipAccDataAssetLink
// Size: 0x108 (Inherited: 0x108)
struct UHipAccDataAssetLink : UDataAssetLink {
};

// Class AssembledMeshSystem.AssembledMeshUserComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UAssembledMeshUserComponent : UActorComponent {
	char pad_A0[0x10]; // 0xa0(0x10)
	struct TArray<struct UAssembledMeshSchema*> MeshParts; // 0xb0(0x10)
	struct TArray<struct FAssembledComponentReferences> MeshPartComponents; // 0xc0(0x10)
	bool bAssignMeshPartsOnBeginPlay; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)

	void SetMeshPart(struct UAssembledMeshSchema* InMeshPart); // Function AssembledMeshSystem.AssembledMeshUserComponent.SetMeshPart // (Final|Native|Private|BlueprintCallable) // @ game+0x7059fb4
	void OnRep_MeshParts(); // Function AssembledMeshSystem.AssembledMeshUserComponent.OnRep_MeshParts // (Native|Protected) // @ game+0x351e7b8
	struct UAssembledMeshSchema* GetMeshPart(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GetMeshPart // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x66a91a4
	struct USkeletalMeshComponent* GetAttachToComponent(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GetAttachToComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x38a57d8
	void GatherAndAssignAssembledMeshParts(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GatherAndAssignAssembledMeshParts // (Native|Public) // @ game+0x219df9c
	void CustomizationCompleted(int32_t PartIndex); // Function AssembledMeshSystem.AssembledMeshUserComponent.CustomizationCompleted // (Native|Protected) // @ game+0x7059f30
};

