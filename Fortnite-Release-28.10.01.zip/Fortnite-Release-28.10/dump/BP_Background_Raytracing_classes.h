// BlueprintGeneratedClass BP_Background_Raytracing.BP_Background_Raytracing_C
// Size: 0x2d0 (Inherited: 0x290)
struct ABP_Background_Raytracing_C : AActor {
	struct UStaticMeshComponent* SM_InvertedSphere_BackPlate_Half; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	bool FullSphere; // 0x2a0(0x01)
	bool UseCubemap; // 0x2a1(0x01)
	char pad_2A2[0x6]; // 0x2a2(0x06)
	double Brightness; // 0x2a8(0x08)
	struct UTexture* 2dTexture; // 0x2b0(0x08)
	struct UTexture* Cubemap; // 0x2b8(0x08)
	struct FLinearColor FadeColor; // 0x2c0(0x10)

	void UserConstructionScript(); // Function BP_Background_Raytracing.BP_Background_Raytracing_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

