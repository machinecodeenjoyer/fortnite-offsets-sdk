// BlueprintGeneratedClass BP_SpeedLines_Looping_Camera_Lens_Riding.BP_SpeedLines_Looping_Camera_Lens_Riding_C
// Size: 0x380 (Inherited: 0x380)
struct ABP_SpeedLines_Looping_Camera_Lens_Riding_C : AEmitterCameraLensEffectBase {
};

