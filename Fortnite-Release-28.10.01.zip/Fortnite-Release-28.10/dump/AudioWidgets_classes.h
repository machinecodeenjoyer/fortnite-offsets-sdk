// Class AudioWidgets.AudioMeter
// Size: 0x6b0 (Inherited: 0x178)
struct UAudioMeter : UWidget {
	struct TArray<struct FMeterChannelInfo> MeterChannelInfo; // 0x178(0x10)
	struct FDelegate MeterChannelInfoDelegate; // 0x188(0x0c)
	char pad_194[0xc]; // 0x194(0x0c)
	struct FAudioMeterStyle WidgetStyle; // 0x1a0(0x480)
	enum class EOrientation orientation; // 0x620(0x01)
	char pad_621[0x3]; // 0x621(0x03)
	struct FLinearColor BackgroundColor; // 0x624(0x10)
	struct FLinearColor MeterBackgroundColor; // 0x634(0x10)
	struct FLinearColor MeterValueColor; // 0x644(0x10)
	struct FLinearColor MeterPeakColor; // 0x654(0x10)
	struct FLinearColor MeterClippingColor; // 0x664(0x10)
	struct FLinearColor MeterScaleColor; // 0x674(0x10)
	struct FLinearColor MeterScaleLabelColor; // 0x684(0x10)
	char pad_694[0x1c]; // 0x694(0x1c)

	void SetMeterValueColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterValueColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d194
	void SetMeterScaleLabelColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d05c
	void SetMeterScaleColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83cf24
	void SetMeterPeakColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterPeakColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83cdec
	void SetMeterClippingColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterClippingColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83ccb4
	void SetMeterChannelInfo(struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo); // Function AudioWidgets.AudioMeter.SetMeterChannelInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa83c5e8
	void SetMeterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83c4b0
	void SetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83c104
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature // (Public|Delegate) // @ game+0x211c0a0
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo(); // Function AudioWidgets.AudioMeter.GetMeterChannelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa83b89c
};

// Class AudioWidgets.AudioOscilloscope
// Size: 0x660 (Inherited: 0x178)
struct UAudioOscilloscope : UWidget {
	char pad_178[0x8]; // 0x178(0x08)
	struct FAudioOscilloscopePanelStyle OscilloscopeStyle; // 0x180(0x470)
	struct UAudioBus* AudioBus; // 0x5f0(0x08)
	float TimeWindowMs; // 0x5f8(0x04)
	float AnalysisPeriodMs; // 0x5fc(0x04)
	bool bShowTimeGrid; // 0x600(0x01)
	enum class EXAxisLabelsUnit TimeGridLabelsUnit; // 0x601(0x01)
	bool bShowAmplitudeGrid; // 0x602(0x01)
	bool bShowAmplitudeLabels; // 0x603(0x01)
	enum class EYAxisLabelsUnit AmplitudeGridLabelsUnit; // 0x604(0x01)
	bool bShowTriggerThresholdLine; // 0x605(0x01)
	char pad_606[0x2]; // 0x606(0x02)
	float TriggerThreshold; // 0x608(0x04)
	enum class EAudioPanelLayoutType PanelLayoutType; // 0x60c(0x01)
	char pad_60D[0x53]; // 0x60d(0x53)

	void StopProcessing(); // Function AudioWidgets.AudioOscilloscope.StopProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e4f0
	void StartProcessing(); // Function AudioWidgets.AudioOscilloscope.StartProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e4a0
	struct TArray<float> GetOscilloscopeAudioSamples__DelegateSignature(); // DelegateFunction AudioWidgets.AudioOscilloscope.GetOscilloscopeAudioSamples__DelegateSignature // (Public|Delegate) // @ game+0x211c0a0
};

// Class AudioWidgets.AudioRadialSlider
// Size: 0x380 (Inherited: 0x178)
struct UAudioRadialSlider : UWidget {
	float Value; // 0x178(0x04)
	struct FDelegate ValueDelegate; // 0x17c(0x0c)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x188(0x01)
	char pad_189[0x3]; // 0x189(0x03)
	struct FLinearColor CenterBackgroundColor; // 0x18c(0x10)
	struct FLinearColor SliderProgressColor; // 0x19c(0x10)
	struct FLinearColor SliderBarColor; // 0x1ac(0x10)
	char pad_1BC[0x4]; // 0x1bc(0x04)
	struct FVector2D HandStartEndRatio; // 0x1c0(0x10)
	struct FText UnitsText; // 0x1d0(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x1e8(0x10)
	bool ShowLabelOnlyOnHover; // 0x1f8(0x01)
	bool ShowUnitsText; // 0x1f9(0x01)
	bool IsUnitsTextReadOnly; // 0x1fa(0x01)
	bool IsValueTextReadOnly; // 0x1fb(0x01)
	float SliderThickness; // 0x1fc(0x04)
	struct FVector2D OutputRange; // 0x200(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x210(0x10)
	char pad_220[0x160]; // 0x220(0x160)

	void SetWidgetLayout(enum class EAudioRadialSliderLayout InLayout); // Function AudioWidgets.AudioRadialSlider.SetWidgetLayout // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e41c
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e1c4
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e0ac
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioRadialSlider.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa83df74
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0xa83dcdc
	void SetSliderThickness(float InThickness); // Function AudioWidgets.AudioRadialSlider.SetSliderThickness // (Final|Native|Public|BlueprintCallable) // @ game+0xa83db1c
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d9e4
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d774
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioRadialSlider.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa83d524
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0xa83d404
	void SetOutputRange(struct FVector2D InOutputRange); // Function AudioWidgets.AudioRadialSlider.SetOutputRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d2cc
	void SetHandStartEndRatio(struct FVector2D InHandStartEndRatio); // Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83c374
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83c23c
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioRadialSlider.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa83c06c
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioRadialSlider.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa83bf3c
};

// Class AudioWidgets.AudioVolumeRadialSlider
// Size: 0x380 (Inherited: 0x380)
struct UAudioVolumeRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioFrequencyRadialSlider
// Size: 0x380 (Inherited: 0x380)
struct UAudioFrequencyRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioSliderBase
// Size: 0x930 (Inherited: 0x178)
struct UAudioSliderBase : UWidget {
	float Value; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct FText UnitsText; // 0x180(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x198(0x10)
	struct FDelegate TextLabelBackgroundColorDelegate; // 0x1a8(0x0c)
	bool ShowLabelOnlyOnHover; // 0x1b4(0x01)
	bool ShowUnitsText; // 0x1b5(0x01)
	bool IsUnitsTextReadOnly; // 0x1b6(0x01)
	bool IsValueTextReadOnly; // 0x1b7(0x01)
	struct FDelegate ValueDelegate; // 0x1b8(0x0c)
	struct FLinearColor SliderBackgroundColor; // 0x1c4(0x10)
	struct FDelegate SliderBackgroundColorDelegate; // 0x1d4(0x0c)
	struct FLinearColor SliderBarColor; // 0x1e0(0x10)
	struct FDelegate SliderBarColorDelegate; // 0x1f0(0x0c)
	struct FLinearColor SliderThumbColor; // 0x1fc(0x10)
	struct FDelegate SliderThumbColorDelegate; // 0x20c(0x0c)
	struct FLinearColor WidgetBackgroundColor; // 0x218(0x10)
	struct FDelegate WidgetBackgroundColorDelegate; // 0x228(0x0c)
	enum class EOrientation orientation; // 0x234(0x01)
	char pad_235[0x3]; // 0x235(0x03)
	struct FMulticastInlineDelegate OnValueChanged; // 0x238(0x10)
	char pad_248[0x6e8]; // 0x248(0x6e8)

	void SetWidgetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83e2e4
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e254
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e138
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioSliderBase.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e010
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0xa83de28
	void SetSliderThumbColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderThumbColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83dba4
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d8ac
	void SetSliderBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa83d63c
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioSliderBase.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa83d5b0
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0xa83d494
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa83b80c
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioSliderBase.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa83bfd4
	float GetLinValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetLinValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa83b80c
};

// Class AudioWidgets.AudioSlider
// Size: 0x940 (Inherited: 0x930)
struct UAudioSlider : UAudioSliderBase {
	struct TWeakObjectPtr<struct UCurveFloat> LinToOutputCurve; // 0x930(0x08)
	struct TWeakObjectPtr<struct UCurveFloat> OutputToLinCurve; // 0x938(0x08)
};

// Class AudioWidgets.AudioVolumeSlider
// Size: 0x940 (Inherited: 0x940)
struct UAudioVolumeSlider : UAudioSlider {
};

// Class AudioWidgets.AudioFrequencySlider
// Size: 0x940 (Inherited: 0x930)
struct UAudioFrequencySlider : UAudioSliderBase {
	struct FVector2D OutputRange; // 0x930(0x10)
};

// Class AudioWidgets.AudioVectorscope
// Size: 0x390 (Inherited: 0x178)
struct UAudioVectorscope : UWidget {
	char pad_178[0x8]; // 0x178(0x08)
	struct FAudioVectorscopePanelStyle VectorscopeStyle; // 0x180(0x1a0)
	struct UAudioBus* AudioBus; // 0x320(0x08)
	bool bShowGrid; // 0x328(0x01)
	char pad_329[0x3]; // 0x329(0x03)
	int32_t GridDivisions; // 0x32c(0x04)
	float DisplayPersistenceMs; // 0x330(0x04)
	float Scale; // 0x334(0x04)
	enum class EAudioPanelLayoutType PanelLayoutType; // 0x338(0x01)
	char pad_339[0x57]; // 0x339(0x57)

	void StopProcessing(); // Function AudioWidgets.AudioVectorscope.StopProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e518
	void StartProcessing(); // Function AudioWidgets.AudioVectorscope.StartProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0xa83e4c8
	struct TArray<float> GetVectorscopeAudioSamples__DelegateSignature(); // DelegateFunction AudioWidgets.AudioVectorscope.GetVectorscopeAudioSamples__DelegateSignature // (Public|Delegate) // @ game+0x211c0a0
};

