// BlueprintGeneratedClass AI_skill_phoebe_bot_healing.AI_skill_phoebe_bot_healing_C
// Size: 0xb8 (Inherited: 0xb8)
struct UAI_skill_phoebe_bot_healing_C : UFortAthenaAIBotHealingSkillSet {
};

