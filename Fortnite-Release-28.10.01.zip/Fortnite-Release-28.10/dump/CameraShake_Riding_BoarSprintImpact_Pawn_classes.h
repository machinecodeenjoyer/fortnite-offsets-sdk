// BlueprintGeneratedClass CameraShake_Riding_BoarSprintImpact_Pawn.CameraShake_Riding_BoarSprintImpact_Pawn_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Riding_BoarSprintImpact_Pawn_C : ULegacyCameraShake {
};

