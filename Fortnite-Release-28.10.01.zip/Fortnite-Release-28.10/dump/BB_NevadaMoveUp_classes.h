// BlueprintGeneratedClass BB_NevadaMoveUp.BB_NevadaMoveUp_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_NevadaMoveUp_C : UFortMobileActionButtonBehavior {
};

