// BlueprintGeneratedClass Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C
// Size: 0xcd8 (Inherited: 0xbc8)
struct AAthena_Prop_ParentBuildingContainerBlueprint_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbc8(0x08)
	bool DebugWind; // 0xbd0(0x01)
	char pad_BD1[0x7]; // 0xbd1(0x07)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xbd8(0x10)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xbe8(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xbf0(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xc00(0x08)
	double DebugWindYaw; // 0xc08(0x08)
	double Debug Wind Intensity; // 0xc10(0x08)
	bool Set Max Actor Scale; // 0xc18(0x01)
	char pad_C19[0x7]; // 0xc19(0x07)
	double Max Scale; // 0xc20(0x08)
	bool Disable TOD Lights and Material Emissive Values; // 0xc28(0x01)
	bool Disable Static Mesh Shadow Casting When Lights Are Active; // 0xc29(0x01)
	bool Use An Alternate Shadow Mesh When The Light is On ; // 0xc2a(0x01)
	char pad_C2B[0x5]; // 0xc2b(0x05)
	struct UStaticMesh* AlternateShadowStaticMesh; // 0xc30(0x08)
	bool Animate Emissive and Lights Over Time; // 0xc38(0x01)
	char pad_C39[0x7]; // 0xc39(0x07)
	struct TArray<struct FLinearColor> CodeControlled_EmissiveColor; // 0xc40(0x10)
	struct TArray<double> CodeControlled_LightConeOpacity; // 0xc50(0x10)
	struct FDayPhaseFloats Light Intensity Over Time of Day ; // 0xc60(0x10)
	double Day Phase Transition Length; // 0xc70(0x08)
	struct FDayPhaseFloats Emissive Intensity Over Time of Day; // 0xc78(0x10)
	double Volumetric Light Scattering Intensity; // 0xc88(0x08)
	bool Cast Volumetric Shadows; // 0xc90(0x01)
	bool Animate Lights With A Curve - Disables time of day light controls; // 0xc91(0x01)
	bool Animate Mesh MID Emissive Value with a Curve - Disables time of day light controls; // 0xc92(0x01)
	char pad_C93[0x5]; // 0xc93(0x05)
	struct UCurveFloat* LightAnimationCurve; // 0xc98(0x08)
	double CodeControlled_Animation Curve Animation Length; // 0xca0(0x08)
	int32_t CodeControlled_NumberOfMaterials; // 0xca8(0x04)
	char pad_CAC[0x4]; // 0xcac(0x04)
	struct TArray<double> ; // 0xcb0(0x10)
	double Random Time Scale Percent; // 0xcc0(0x08)
	double CodeControlled_CurrentPlayLength; // 0xcc8(0x08)
	double Snow Coverage Amount; // 0xcd0(0x08)

	void GetTimeOfDayBlueprintDefaultVariables(struct FTimeOfDayBlueprintDefaultVariables& OutVariables); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.GetTimeOfDayBlueprintDefaultVariables // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UserConstructionScript(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void Loop Animation Curve(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.Loop Animation Curve // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnBounceAnimationUpdate(struct FFortBounceData& Data); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnSetSearched(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnSetSearched // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint(int32_t EntryPoint); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

