// BlueprintGeneratedClass BBE_Crouch.BBE_Crouch_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_Crouch_C : UFortMobileActionButtonBehaviorExtension {
};

