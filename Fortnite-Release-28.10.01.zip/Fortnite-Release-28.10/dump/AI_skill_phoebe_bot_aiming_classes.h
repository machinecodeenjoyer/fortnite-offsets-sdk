// BlueprintGeneratedClass AI_skill_phoebe_bot_aiming.AI_skill_phoebe_bot_aiming_C
// Size: 0x1598 (Inherited: 0x1598)
struct UAI_skill_phoebe_bot_aiming_C : UFortAthenaAIBotAimingSkillSet {
};

