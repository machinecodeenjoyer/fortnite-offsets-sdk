// Class BattlePassS28UI.BattlePassBulkBuyPageS28
// Size: 0x5a0 (Inherited: 0x5a0)
struct UBattlePassBulkBuyPageS28 : UFortBattlePassBulkBuyPageBase {
};

// Class BattlePassS28UI.BattlePassLandingPageS28
// Size: 0x5b8 (Inherited: 0x550)
struct UBattlePassLandingPageS28 : UBattlePassLandingPageBase {
	struct UBattlePassLandingPageButton* Button_Rewards; // 0x550(0x08)
	struct UBattlePassLandingPageButton* Button_CharacterCustomizer; // 0x558(0x08)
	struct UBattlePassLandingPageButton* Button_BonusRewards; // 0x560(0x08)
	struct UBattlePassLandingPageButton* Button_Quests; // 0x568(0x08)
	struct UBattlePassLandingPageButton* Button_JoinSubscription; // 0x570(0x08)
	struct UBattlePassLandingPageButton* Button_WeeklyRewards; // 0x578(0x08)
	struct UCommonTextBlock* Text_SeasonNumber; // 0x580(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x588(0x08)
	char pad_590[0x28]; // 0x590(0x28)

	void OnBattlePassSubscriptionAllowed(bool bSubscriptionAllowed); // Function BattlePassS28UI.BattlePassLandingPageS28.OnBattlePassSubscriptionAllowed // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
};

// Class BattlePassS28UI.BattlePassRewardPageS28
// Size: 0x5b8 (Inherited: 0x518)
struct UBattlePassRewardPageS28 : UBattlePassRewardPageBase {
	struct UFortBattlePassRewardTrack* RewardsTrackClass; // 0x518(0x08)
	struct UFortBattlePassTile* FocusedReward; // 0x520(0x08)
	struct TArray<struct UFortBattlePassRewardTrack*> TrackPages; // 0x528(0x10)
	char pad_538[0x4]; // 0x538(0x04)
	enum class ERewardPageType RewardPageType; // 0x53c(0x01)
	char pad_53D[0x3]; // 0x53d(0x03)
	int32_t HoldTileTooltip_ClaimedRewardsToHide; // 0x540(0x04)
	int32_t HoldTileTooltip_ClaimedBattlePassToHide; // 0x544(0x04)
	int32_t HoldTileTooltip_RequiredBattleStarsToShow; // 0x548(0x04)
	int32_t LevelRequirementUnlockTooltip_RequiredLevel; // 0x54c(0x04)
	int32_t ClaimAllRewardsTooltip_RequiredLevelToShow; // 0x550(0x04)
	char pad_554[0x4]; // 0x554(0x04)
	struct UCommonAnimatedSwitcher* Switcher_RewardTracks; // 0x558(0x08)
	struct UFortBattlePassTutorialTooltipS28* TutorialTooltip_LevelRequirementUnlock; // 0x560(0x08)
	struct UFortBattlePassTutorialTooltipS28* TutorialTooltip_ClaimAllRewards; // 0x568(0x08)
	struct UFortBattlePassTutorialTooltipS28* TutorialTooltip_HoldTile; // 0x570(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x578(0x08)
	struct UBattlePassBulkBuyInputData* BulkBuyInputData; // 0x580(0x08)
	struct UCommonButtonBase* Button_NextPage; // 0x588(0x08)
	struct UCommonButtonBase* Button_PreviousPage; // 0x590(0x08)
	char pad_598[0x20]; // 0x598(0x20)

	void OnPageChanged(int32_t PageNumber, int32_t RewardPageTotal); // Function BattlePassS28UI.BattlePassRewardPageS28.OnPageChanged // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnLoadingScreenSelectedChanged(bool bIsSelected); // Function BattlePassS28UI.BattlePassRewardPageS28.OnLoadingScreenSelectedChanged // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnInputMethodChanged(enum class ECommonInputType InputType); // Function BattlePassS28UI.BattlePassRewardPageS28.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnInitForPageType(enum class ERewardPageType InRewardPageType); // Function BattlePassS28UI.BattlePassRewardPageS28.OnInitForPageType // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	struct UWidget* HandleRewardTracksBoundaryNavigation(enum class EUINavigation InNavigation); // Function BattlePassS28UI.BattlePassRewardPageS28.HandleRewardTracksBoundaryNavigation // (Final|Native|Private) // @ game+0xa8e58e4
	struct FVaultWorldBackgroundData GetRewardPageBackgroundData(); // Function BattlePassS28UI.BattlePassRewardPageS28.GetRewardPageBackgroundData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa8e5604
};

// Class BattlePassS28UI.BattlePassScreenS28
// Size: 0xe28 (Inherited: 0x940)
struct UBattlePassScreenS28 : UBattlePassScreenBase {
	struct UFortBattlePassPurchaseResourcesWidget* ResourcePurchaseScreenClass; // 0x940(0x08)
	char pad_948[0x8]; // 0x948(0x08)
	struct UCommonButtonBase* Button_Close; // 0x950(0x08)
	struct UCommonButtonLegacy* Button_TouchClose; // 0x958(0x08)
	struct UCommonButtonBase* Button_ToggleViewDetails; // 0x960(0x08)
	struct UCommonButtonBase* Button_ReplayTrailer; // 0x968(0x08)
	struct UCommonButtonBase* Button_ReplayTrailer_Mobile; // 0x970(0x08)
	struct UCommonButtonBase* Button_ShowAbout; // 0x978(0x08)
	struct UCommonButtonBase* Button_ShowAbout_Mobile; // 0x980(0x08)
	struct UCommonButtonBase* Button_ShowAboutCustomization; // 0x988(0x08)
	struct UCommonButtonBase* Button_ShowAboutCustomization_Mobile; // 0x990(0x08)
	struct UCommonButtonBase* Button_BulkBuyRewards; // 0x998(0x08)
	struct UCommonButtonBase* Button_PageComplete; // 0x9a0(0x08)
	struct UCommonButtonBase* Button_GiftBattlePass; // 0x9a8(0x08)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_PlatformBasedButtons; // 0x9b0(0x08)
	struct UFortBattlePassResourcesWidgetBase* BattlePassCurrencyPanel; // 0x9b8(0x08)
	struct UAthenaExclusiveRewardBanner* AthenaExclusiveRewardBanner; // 0x9c0(0x08)
	struct UCommonTextBlock* Text_Description; // 0x9c8(0x08)
	struct UCommonTextBlock* Text_ItemName; // 0x9d0(0x08)
	struct UAthenaRewardItemTypeRarityTag* ItemRewardTag; // 0x9d8(0x08)
	struct UCommonTextBlock* Text_SetDetails; // 0x9e0(0x08)
	struct UWidgetSwitcher* Switcher_PrerequisiteInfo; // 0x9e8(0x08)
	struct UCommonTextBlock* Text_Prerequisite; // 0x9f0(0x08)
	struct UWidget* Widget_PrerequisiteProgress; // 0x9f8(0x08)
	struct UWidget* Widget_LevelUpMessageFree; // 0xa00(0x08)
	struct UWidget* Widget_LevelUpMessagePremium; // 0xa08(0x08)
	struct UWidget* Widget_CustomResourceMessage; // 0xa10(0x08)
	struct UWidgetSwitcher* Switcher_PrimaryAction; // 0xa18(0x08)
	struct UFortCTAButton* Button_BuyLevels; // 0xa20(0x08)
	struct UFortCTAButton* Button_BuyBattlePass; // 0xa28(0x08)
	struct UFortCTAButton* Button_ClaimReward; // 0xa30(0x08)
	struct UCommonButtonBase* Button_ViewQuests; // 0xa38(0x08)
	struct UCommonButtonBase* Button_PreviewLoadingScreen; // 0xa40(0x08)
	struct UFortDynamicEntryBox* ItemVMCards; // 0xa48(0x08)
	struct UBorder* Tag_RequiresBP; // 0xa50(0x08)
	struct UBorder* Tag_PageLocked; // 0xa58(0x08)
	struct UBorder* Tag_BaseItem; // 0xa60(0x08)
	struct UBorder* Tag_Prerequisite; // 0xa68(0x08)
	struct UBorder* Tag_CompletePage; // 0xa70(0x08)
	struct UBorder* Tag_NotEnough_Currency; // 0xa78(0x08)
	struct UBorder* Tag_Cost; // 0xa80(0x08)
	struct UBorder* Tag_Owned; // 0xa88(0x08)
	struct UBorder* Tag_Delayed; // 0xa90(0x08)
	struct FGameplayTag QuestCategoryParentTag; // 0xa98(0x04)
	char pad_A9C[0x4]; // 0xa9c(0x04)
	struct UAthenaLoadingScreenPreviewPanel* PreviewLoadingScreenWidgetClass; // 0xaa0(0x08)
	struct FGameplayTag JunoTag; // 0xaa8(0x04)
	char pad_AAC[0x5c]; // 0xaac(0x5c)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0xb08(0x08)
	struct UAthenaSeasonItemEntryBase* CurrentSelectedEntry; // 0xb10(0x08)
	struct TArray<enum class EBattlePassView> SwitcherSubPageTypes; // 0xb18(0x10)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_SubPage; // 0xb28(0x08)
	char pad_B30[0x100]; // 0xb30(0x100)
	struct UFortItemDefinition* SeasonalBaseCustomizationItem; // 0xc30(0x08)
	bool bHasSubscription; // 0xc38(0x01)
	char pad_C39[0x7]; // 0xc39(0x07)
	struct UFortBattlePassTutorialTooltipS28* TutorialTooltip_BattleStars; // 0xc40(0x08)
	struct UFortBattlePassTutorialTooltipS28* TutorialTooltip_StylePoints; // 0xc48(0x08)
	struct UFortSwipePanel* SwipePanel_Navigation; // 0xc50(0x08)
	char pad_C58[0x1d0]; // 0xc58(0x1d0)

	void OverviewShowAnimationFinished(); // Function BattlePassS28UI.BattlePassScreenS28.OverviewShowAnimationFinished // (Final|Native|Public|BlueprintCallable) // @ game+0x32e4b44
	void OnUpdateStatusBar(struct FText& StatusText, enum class EBattlePassStatusBarTypeS28& BarType); // Function BattlePassS28UI.BattlePassScreenS28.OnUpdateStatusBar // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnUpdateOwnedOrEquippedTag(struct FText& StatusText); // Function BattlePassS28UI.BattlePassScreenS28.OnUpdateOwnedOrEquippedTag // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnUpdateBattlePassRequiredBar(bool bPassRequiredVisible); // Function BattlePassS28UI.BattlePassScreenS28.OnUpdateBattlePassRequiredBar // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnTransitionItemDetails(bool bTransitionForward); // Function BattlePassS28UI.BattlePassScreenS28.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnSetWeeklyRewardsInfo(struct FTimespan& DelayTimespan, int32_t AvailableRewards, int32_t OwnedRewards, int32_t TotalRewards, int32_t AvailablePages, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS28UI.BattlePassScreenS28.OnSetWeeklyRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x211c0a0
	void OnSetWarningToolTip(enum class ERewardWarningTooltipType28& WarningTooltipType, struct FText& Description); // Function BattlePassS28UI.BattlePassScreenS28.OnSetWarningToolTip // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnSetResourcePrice(int32_t Cost, struct UFortPersistentResourceItemDefinition* PersistentResource); // Function BattlePassS28UI.BattlePassScreenS28.OnSetResourcePrice // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnSetQuestRewardsInfo(struct FTimespan& DelayTimespan, int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS28UI.BattlePassScreenS28.OnSetQuestRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x211c0a0
	void OnSetPrerequisiteInfo(struct FText& Description, int32_t CurrentAmount, int32_t NeededAmount, enum class EBattlePassRewardPrerequisiteType PrerequisiteType, bool bShowPrerequisiteLock); // Function BattlePassS28UI.BattlePassScreenS28.OnSetPrerequisiteInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnSetItemPrice(int32_t Cost, enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassS28UI.BattlePassScreenS28.OnSetItemPrice // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnSetEquipButtonEnable(bool bIsEnable); // Function BattlePassS28UI.BattlePassScreenS28.OnSetEquipButtonEnable // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnSetCrewInfo(bool bIsNextMonthRewards, struct FText& MonthText, struct FTimespan& NextMonthlyRewardTimespan, struct FText& CharacterDisplayName, struct FText& CharacterDescription); // Function BattlePassS28UI.BattlePassScreenS28.OnSetCrewInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x211c0a0
	void OnSetCoverPageData(struct FText& Title, struct FText& Description, bool bPageComplete); // Function BattlePassS28UI.BattlePassScreenS28.OnSetCoverPageData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnSetBonusRewardsInfo(bool bIsUnlocked, int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages, int32_t ClaimedOutfits, int32_t TotalOutfits); // Function BattlePassS28UI.BattlePassScreenS28.OnSetBonusRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnSetBonusInfo(enum class ECosmeticCompatibleMode& BonusInfoType, bool Claimed, struct FText& Description, struct UTexture2D* PreviewTexture); // Function BattlePassS28UI.BattlePassScreenS28.OnSetBonusInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnSetBaseRewardsInfo(int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS28UI.BattlePassScreenS28.OnSetBaseRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnItemVmCardUpdate(struct FExpandedItemVM ItemVMs, struct UAthenaSeasonItemEntryBase* EntrySelected); // Function BattlePassS28UI.BattlePassScreenS28.OnItemVmCardUpdate // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnItemDelayed(struct FTimespan Delay); // Function BattlePassS28UI.BattlePassScreenS28.OnItemDelayed // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x211c0a0
	void OnInsufficientResource(struct UFortPersistentResourceItemDefinition* PersistentResource); // Function BattlePassS28UI.BattlePassScreenS28.OnInsufficientResource // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnInsufficientFunds(enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassS28UI.BattlePassScreenS28.OnInsufficientFunds // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnGameModeCompatibilityTagUpdate(struct UFortItemDefinition* ItemDefinition); // Function BattlePassS28UI.BattlePassScreenS28.OnGameModeCompatibilityTagUpdate // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnBattlePassOwned(); // Function BattlePassS28UI.BattlePassScreenS28.OnBattlePassOwned // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnBattlePassGiftingAllowed(bool bGiftingAllowed); // Function BattlePassS28UI.BattlePassScreenS28.OnBattlePassGiftingAllowed // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	bool IsSeasonalCustomizationItemOwned(); // Function BattlePassS28UI.BattlePassScreenS28.IsSeasonalCustomizationItemOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa8e599c
	void HandleSwitcherVisibilityShown(); // Function BattlePassS28UI.BattlePassScreenS28.HandleSwitcherVisibilityShown // (Final|Native|Public|BlueprintCallable) // @ game+0xa8e5974
	void HandleItemVMCardClicked(struct UFortItemVM* ItemVM, struct UAthenaSeasonItemEntryBase* EntrySelected); // Function BattlePassS28UI.BattlePassScreenS28.HandleItemVMCardClicked // (Final|Native|Public|BlueprintCallable) // @ game+0xa8e5820
	void HandleFullScreenMapToggled(bool bMapVisible); // Function BattlePassS28UI.BattlePassScreenS28.HandleFullScreenMapToggled // (Final|Native|Private) // @ game+0xa8e57a0
	void HandleClaimRewardComplete(bool bSuccess, struct TArray<struct FString>& OfferTemplateIdList); // Function BattlePassS28UI.BattlePassScreenS28.HandleClaimRewardComplete // (Final|Native|Private|HasOutParms) // @ game+0xa8e56b4
	void GoBackOneScreen(); // Function BattlePassS28UI.BattlePassScreenS28.GoBackOneScreen // (Final|Native|Public|BlueprintCallable) // @ game+0xa8e56a0
	struct FTimespan GetQuestPageDelay(); // Function BattlePassS28UI.BattlePassScreenS28.GetQuestPageDelay // (Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa8e55d8
	bool GetEquipButtonEnable(); // Function BattlePassS28UI.BattlePassScreenS28.GetEquipButtonEnable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa8e55bc
};

// Class BattlePassS28UI.FortBattlePassCustomSkinPageS28
// Size: 0x5e0 (Inherited: 0x5c8)
struct UFortBattlePassCustomSkinPageS28 : UFortBattlePassCustomSkinPageBase {
	struct FString ClaimBaseItemTooltip_ClaimCheckTemplateId; // 0x5c8(0x10)
	struct UFortBattlePassTutorialTooltip* TutorialTooltip_ClaimBaseItem; // 0x5d8(0x08)
};

// Class BattlePassS28UI.FortBattlePassResourcesWidgetS28
// Size: 0x318 (Inherited: 0x2f8)
struct UFortBattlePassResourcesWidgetS28 : UFortBattlePassResourcesWidgetBase {
	struct UCommonTextBlock* Text_BattleStarsAmount; // 0x2f8(0x08)
	struct UCommonTextBlock* Text_StylePointsAmount; // 0x300(0x08)
	struct UBorder* Border_StylePointsRewardsTag; // 0x308(0x08)
	struct UBorder* Border_BattleStarsRewardsTag; // 0x310(0x08)

	void OnStylePointsRewardsSet(int32_t Rewards); // Function BattlePassS28UI.FortBattlePassResourcesWidgetS28.OnStylePointsRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnBattleStarRewardsSet(int32_t Rewards); // Function BattlePassS28UI.FortBattlePassResourcesWidgetS28.OnBattleStarRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
};

// Class BattlePassS28UI.FortBattlePassTutorialTooltipS28
// Size: 0x2f8 (Inherited: 0x2e8)
struct UFortBattlePassTutorialTooltipS28 : UCommonUserWidget {
	struct UCommonRichTextBlock* Text_Tooltip; // 0x2e8(0x08)
	char pad_2F0[0x8]; // 0x2f0(0x08)

	void ShowTooltip(); // Function BattlePassS28UI.FortBattlePassTutorialTooltipS28.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void SetText(struct FText Text); // Function BattlePassS28UI.FortBattlePassTutorialTooltipS28.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0xa8c3da8
	void HideTooltip(); // Function BattlePassS28UI.FortBattlePassTutorialTooltipS28.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
};

