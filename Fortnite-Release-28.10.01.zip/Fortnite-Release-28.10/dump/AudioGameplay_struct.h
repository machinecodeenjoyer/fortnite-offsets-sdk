// ScriptStruct AudioGameplay.AudioGameplayRequirements
// Size: 0x50 (Inherited: 0x00)
struct FAudioGameplayRequirements {
	struct UAudioRequirementPreset* Preset; // 0x00(0x08)
	struct FGameplayTagQuery Custom; // 0x08(0x48)
};

