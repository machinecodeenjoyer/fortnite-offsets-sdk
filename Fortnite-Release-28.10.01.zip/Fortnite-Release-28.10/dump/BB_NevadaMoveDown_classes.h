// BlueprintGeneratedClass BB_NevadaMoveDown.BB_NevadaMoveDown_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_NevadaMoveDown_C : UFortMobileActionButtonBehavior {
};

