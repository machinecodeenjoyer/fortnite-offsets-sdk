// BlueprintGeneratedClass Athena_Grenade_Base_WhipTracker.Athena_Grenade_Base_WhipTracker_C
// Size: 0xf8 (Inherited: 0xf8)
struct UAthena_Grenade_Base_WhipTracker_C : UBulletWhipTrackerComponent_Default_C {
};

