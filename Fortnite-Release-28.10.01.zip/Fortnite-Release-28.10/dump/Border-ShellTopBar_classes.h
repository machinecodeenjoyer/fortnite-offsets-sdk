// BlueprintGeneratedClass Border-ShellTopBar.Border-ShellTopBar_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-ShellTopBar_C : UCommonBorderStyle {
};

