// WidgetBlueprintGeneratedClass AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C
// Size: 0x4f8 (Inherited: 0x4d0)
struct UAthenaItemTextureVariantPicker_C : UFortVariantItemTexturePicker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d0(0x08)
	struct UCommonRichTextBlock* TextBlock_AllItemsArchived; // 0x4d8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_AvailableItems; // 0x4e0(0x08)
	struct FMulticastInlineDelegate OnConflictStatusUpdated; // 0x4e8(0x10)

	void Construct(); // Function AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnToggleAllItemsArchivedMessage(bool bDisplay); // Function AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C.OnToggleAllItemsArchivedMessage // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void HandleEntryInitialized(struct UObject* Item, struct UUserWidget* Widget); // Function AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C.HandleEntryInitialized // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HandleConflictStatusUpdated(bool IsConflicting, struct FText ConflictReason); // Function AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C.HandleConflictStatusUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_AthenaItemTextureVariantPicker(int32_t EntryPoint); // Function AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C.ExecuteUbergraph_AthenaItemTextureVariantPicker // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
	void OnConflictStatusUpdated__DelegateSignature(bool IsConflicting, struct FText ConflictReason); // Function AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C.OnConflictStatusUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

