// BlueprintGeneratedClass BBE_ValetEmoteSquadComms.BBE_ValetEmoteSquadComms_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_ValetEmoteSquadComms_C : UFortMobileActionButtonBehaviorExtension {
};

