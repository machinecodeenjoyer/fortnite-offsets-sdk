// BlueprintGeneratedClass AnimNotifyState_NiagaraNotify_SetParameters.AnimNotifyState_NiagaraNotify_SetParameters_C
// Size: 0x88 (Inherited: 0x78)
struct UAnimNotifyState_NiagaraNotify_SetParameters_C : UAnimNotifyState_TimedNiagaraEffect {
	struct TArray<struct FStruc_NiagaraParameters> Parameter Setup; // 0x78(0x10)

	bool Received_NotifyTick(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float FrameDeltaTime, struct FAnimNotifyEventReference& EventReference); // Function AnimNotifyState_NiagaraNotify_SetParameters.AnimNotifyState_NiagaraNotify_SetParameters_C.Received_NotifyTick // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
};

