// BlueprintGeneratedClass B_CosmeticStatObject_TotalVictoryCrowns.B_CosmeticStatObject_TotalVictoryCrowns_C
// Size: 0x90 (Inherited: 0x90)
struct UB_CosmeticStatObject_TotalVictoryCrowns_C : UFortCosmeticStatObject_TotalVictoryCrowns {
};

