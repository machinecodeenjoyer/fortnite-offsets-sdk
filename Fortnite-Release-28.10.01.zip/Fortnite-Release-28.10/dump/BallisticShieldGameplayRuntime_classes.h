// Class BallisticShieldGameplayRuntime.BallisticShieldItemLayerAnimInstance
// Size: 0x7d0 (Inherited: 0x6f0)
struct UBallisticShieldItemLayerAnimInstance : UFortItemLayerAnimInstance {
	bool bIsRush; // 0x6f0(0x01)
	bool bIsEquipping; // 0x6f1(0x01)
	bool bIsReloading; // 0x6f2(0x01)
	bool bEnterLanding; // 0x6f3(0x01)
	bool bExitLanding; // 0x6f4(0x01)
	bool bIsShieldBlocking; // 0x6f5(0x01)
	bool bIsStaggerBuildup; // 0x6f6(0x01)
	char pad_6F7[0x1]; // 0x6f7(0x01)
	float Yaw; // 0x6f8(0x04)
	float ChargeAOAlpha; // 0x6fc(0x04)
	int32_t GenderAndSize; // 0x700(0x04)
	float ReloadUBAlpha; // 0x704(0x04)
	float MaskLeftArmAlpha; // 0x708(0x04)
	float StaggerAmount; // 0x70c(0x04)
	char pad_710[0xc0]; // 0x710(0xc0)
};

// Class BallisticShieldGameplayRuntime.BallisticShieldWeaponInterface
// Size: 0x28 (Inherited: 0x28)
struct UBallisticShieldWeaponInterface : UInterface {

	void GetBallisticShieldData(enum class EBallisticShieldPlayerActionState& BallisticShieldPlayerState, float& StaggerBuildupPercent); // Function BallisticShieldGameplayRuntime.BallisticShieldWeaponInterface.GetBallisticShieldData // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xa88a3a8
};

// Class BallisticShieldGameplayRuntime.FortMovementMode_ELBShieldSprint
// Size: 0x3f8 (Inherited: 0x3c0)
struct UFortMovementMode_ELBShieldSprint : UFortMovementMode_ELTacSprint {
	struct FScalableFloat ChargeRotationRate; // 0x3c0(0x28)
	struct UGameplayAbility* GrantedAbility; // 0x3e8(0x08)
	char pad_3F0[0x8]; // 0x3f0(0x08)
};

// Class BallisticShieldGameplayRuntime.TargetingFilterTask_BShieldCharge
// Size: 0xb0 (Inherited: 0x28)
struct UTargetingFilterTask_BShieldCharge : UTargetingFilterTask_BasicFilterTemplate {
	struct TArray<ClassPtrProperty> WalkableActorClasses; // 0x28(0x10)
	struct FScalableFloat BashableActorAngle; // 0x38(0x28)
	struct FScalableFloat MainTraceDistance; // 0x60(0x28)
	struct FScalableFloat FloorHitZTolerance; // 0x88(0x28)
};

