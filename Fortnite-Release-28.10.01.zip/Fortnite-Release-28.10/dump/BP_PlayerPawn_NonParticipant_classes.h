// BlueprintGeneratedClass BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C
// Size: 0x6ad8 (Inherited: 0x68b4)
struct ABP_PlayerPawn_NonParticipant_C : ABP_PlayerPawn_Athena_Phoebe_C {
	char pad_68B4[0x4]; // 0x68b4(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x68b8(0x08)
	struct UFortAthenaAlertStateComponent* FortAthenaAlertState; // 0x68c0(0x08)
	struct UAudioComponent* VOAudioComponent; // 0x68c8(0x08)
	bool UseAlertness; // 0x68d0(0x01)
	bool UseVO; // 0x68d1(0x01)
	bool UseIdleVO; // 0x68d2(0x01)
	bool UseDropExtraLootOnDeath; // 0x68d3(0x01)
	bool UseFullBodyHitReact; // 0x68d4(0x01)
	bool UseChangedTargetReplication; // 0x68d5(0x01)
	bool UseAlertSound; // 0x68d6(0x01)
	enum class EAlertLevel AlertLevel; // 0x68d7(0x01)
	enum class EAlertLevel OldAlertLevel; // 0x68d8(0x01)
	char pad_68D9[0x3]; // 0x68d9(0x03)
	struct FGameplayTag GameplayCueAlertState; // 0x68dc(0x04)
	struct UGameplayEffect* GE_NPC_Status_Stressed_Infinite; // 0x68e0(0x08)
	struct UGameplayEffect* GE_NPC_Status_Stressed_Cooldown; // 0x68e8(0x08)
	double MinDistanceToTargetToPlayCombatAlertAnimation; // 0x68f0(0x08)
	struct FScalableFloat MinIdleVODelay; // 0x68f8(0x28)
	struct FScalableFloat MaxIdleVODelay; // 0x6920(0x28)
	struct FName LootTierNameToSpawnWhenDead; // 0x6948(0x04)
	struct FName LootTier_Medium; // 0x694c(0x04)
	struct FName LootTier_Shell; // 0x6950(0x04)
	struct FName LootTier_Heavy; // 0x6954(0x04)
	struct FName LootTier_Light; // 0x6958(0x04)
	struct FName LootTier_Rockets; // 0x695c(0x04)
	struct UFortGameplayDataTrackerComponentManager* DataTrackerComponentManager; // 0x6960(0x08)
	struct FGameplayTag AlertLevelUnawareTag; // 0x6968(0x04)
	struct FGameplayTag AlertLevelAlertedTag; // 0x696c(0x04)
	struct FGameplayTag AlertLevelAggressiveTag; // 0x6970(0x04)
	struct FGameplayTag TC_DisguiseTag; // 0x6974(0x04)
	struct UGameplayEffect* GE_RemoveDisguise; // 0x6978(0x08)
	struct UFortAbilitySet* HitReactAbilitySet; // 0x6980(0x08)
	struct UAnimMontage* DefaultFullbodyHitReactionMontage; // 0x6988(0x08)
	struct UFortPatrolAnimAsset* CurrentPatrolAnimAsset; // 0x6990(0x08)
	struct UAnimInstance* PatrolLayerAnimBP; // 0x6998(0x08)
	struct TArray<struct FFortPatrolAnimSetWeaponPair> PatrolAnimSetPairs; // 0x69a0(0x10)
	bool bShouldDoFullAnimationUpdate; // 0x69b0(0x01)
	char pad_69B1[0x3]; // 0x69b1(0x03)
	struct FActiveGameplayEffectHandle GEDuelHandle; // 0x69b4(0x08)
	char pad_69BC[0x4]; // 0x69bc(0x04)
	struct UGameplayEffect* GE_DuelTag; // 0x69c0(0x08)
	struct AFortPlayerPawn* Challenger; // 0x69c8(0x08)
	struct UAnimInstance* OverrideLayerAnimBP; // 0x69d0(0x08)
	struct UFortPatrolAnimAsset* FallbackPatrolAnimAsset; // 0x69d8(0x08)
	bool bIsInVehicleThatSupportsNoAlertState; // 0x69e0(0x01)
	char pad_69E1[0x3]; // 0x69e1(0x03)
	struct FActiveGameplayEffectHandle GE_Quest_Converted_Handle; // 0x69e4(0x08)
	char pad_69EC[0x4]; // 0x69ec(0x04)
	struct UGameplayEffect* GE_Quest_Converted_HireNPC; // 0x69f0(0x08)
	struct USoundBase* DeathFX Sound; // 0x69f8(0x08)
	struct AFortPawn* PawnConverter; // 0x6a00(0x08)
	struct FGameplayTagContainer TagsToApplyOnConvertedPawn; // 0x6a08(0x20)
	struct FGameplayTagContainer TagsToApplyOnConvertingPawn; // 0x6a28(0x20)
	struct USoundLibrary* PawnSoundLibrary; // 0x6a48(0x08)
	struct UFortAbilitySet* GASToApplyOnConvertedPawn; // 0x6a50(0x08)
	bool RemoveGASOnUnconverted; // 0x6a58(0x01)
	char pad_6A59[0x7]; // 0x6a59(0x07)
	struct FFortAbilitySetHandle HNDL_EquippedAbilitySet; // 0x6a60(0x38)
	struct AActor* NewTargetActor; // 0x6a98(0x08)
	struct FMulticastInlineDelegate OnTargetChanged; // 0x6aa0(0x10)
	struct FMulticastInlineDelegate OnAlertLevelChanged; // 0x6ab0(0x10)
	struct FMulticastInlineDelegate OnDeath; // 0x6ac0(0x10)
	struct FTimerHandle IdleVOTimerHandle; // 0x6ad0(0x08)

	void SetNPCAnimSpeedScalar(double SpeedScalar); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.SetNPCAnimSpeedScalar // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SoundLibrarySetup(bool IsAdding); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.SoundLibrarySetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HandlePawnUnconverted(struct AFortPawn* UnconvertedPawn); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.HandlePawnUnconverted // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HandlePawnConverted(struct AFortPawn* InstigatorPawn, struct AFortPawn* ConvertedPawn); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.HandlePawnConverted // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayAlertLevelVO(enum class EAlertLevel OldAlertLevel, enum class EAlertLevel NewAlertLevel); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.PlayAlertLevelVO // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HandleAlertStateUpdates(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.HandleAlertStateUpdates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_bIsInVehicleThatSupportsNoAlertState(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnRep_bIsInVehicleThatSupportsNoAlertState // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UpdateAlertStateVehicleCheck(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.UpdateAlertStateVehicleCheck // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ClientOnTargetChanged(struct AActor* NewTarget); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ClientOnTargetChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetIconPlacement(struct AActor* SelfActor, struct AActor* ViewingActor, struct FVector& OutLocation, struct FVector& OutExtents); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.GetIconPlacement // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void ClientOnAlertLevelChanged(enum class EAlertLevel OldAlertLevel, enum class EAlertLevel NewAlertLevel); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ClientOnAlertLevelChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void InitializeAnimInstanceSettings(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.InitializeAnimInstanceSettings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UpdatePatrolAnimSet(struct AFortWeapon* NewWeapon); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.UpdatePatrolAnimSet // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetCurrentFullbodyHitReactionMontage(struct UAnimMontage*& CurrentMontage); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.GetCurrentFullbodyHitReactionMontage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetDataTrackerActorStateFromAlertLevel(enum class EAlertLevel AlertLevel); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.SetDataTrackerActorStateFromAlertLevel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void DataTrackerSetup(bool Is Registering); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.DataTrackerSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetupLootTierNameWithWeapon(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.SetupLootTierNameWithWeapon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AlertLevelChanged(enum class EAlertLevel OldAlertLevel, enum class EAlertLevel InputPin); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.AlertLevelChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayVoiceComponentSoundByTag(struct FGameplayTag SoundBankTag, struct UAudioComponent*& AudioComponent); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.PlayVoiceComponentSoundByTag // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetAlertedStateGameplayCue(bool Alerted, bool Combat); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.SetAlertedStateGameplayCue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_NewTargetActor(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnRep_NewTargetActor // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_AlertLevel(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnRep_AlertLevel // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UserConstructionScript(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnDBNOStateChanged_Event(struct AFortPawn* FortPawn, bool bInIsDBNO); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnDBNOStateChanged_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void AttemptPlayVocalReinforcementSound(struct FGameplayTagContainer MetadataTagContainer); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.AttemptPlayVocalReinforcementSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ActivateAlertDBNOCleanUp(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ActivateAlertDBNOCleanUp // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnAlertLEvelCHangedEvent(struct AFortAthenaAIBotController* BotController, enum class EAlertLevel OldAlertLevel, enum class EAlertLevel NewAlertLevel); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnAlertLEvelCHangedEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void TriggerIdleVO(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.TriggerIdleVO // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponEquipped(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnWeaponEquipped // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnCharacterCustomizationCompleted(struct AFortPlayerPawn* Pawn); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnCharacterCustomizationCompleted // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GameplayCue.Player.Interrogation.Voice.PickedUp(enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.GameplayCue.Player.Interrogation.Voice.PickedUp // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void (struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C. // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ChallengerDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ChallengerDied // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetChallenger(struct AFortPlayerPawn* Challenger); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.SetChallenger // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void LinkPatrolAnimLayer(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.LinkPatrolAnimLayer // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void LinkOverrideAnimLayer(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.LinkOverrideAnimLayer // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnAnimInputEvent(struct UFortAnimInputEvent* AnimInputEvent); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnAnimInputEvent // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ReLinkAnimLayer(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ReLinkAnimLayer // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayVoiceSoundByTag(struct FGameplayTag SoundBankTag); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.PlayVoiceSoundByTag // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnEnteredVehicleEvent(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnEnteredVehicleEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnExitedVehicleEvent(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnExitedVehicleEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void BndEvt__BP_PlayerPawn_NonParticipant_ConvertComponent_K2Node_ComponentBoundEvent_1_ConvertedEvent__DelegateSignature(struct AFortPawn* InstigatorPawn, struct AFortPawn* ConvertedPawn); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.BndEvt__BP_PlayerPawn_NonParticipant_ConvertComponent_K2Node_ComponentBoundEvent_1_ConvertedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x211c0a0
	void BndEvt__ConvertComponent_K2Node_ComponentBoundEvent_1_UnconvertedEvent__DelegateSignature(struct AFortPawn* UnconvertedPawn, enum class EUnconvertReason UnconvertReason); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.BndEvt__ConvertComponent_K2Node_ComponentBoundEvent_1_UnconvertedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x211c0a0
	void OnExitedVehicle(); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnExitedVehicle // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnDied_Event(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnDied_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AiTargetChanged(struct AActor* OldTarget, struct AActor* NewTarget); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.AiTargetChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BP_PlayerPawn_NonParticipant(int32_t EntryPoint); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.ExecuteUbergraph_BP_PlayerPawn_NonParticipant // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
	void OnDeath__DelegateSignature(enum class EDeathCause Cause); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnDeath__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnAlertLevelChanged__DelegateSignature(enum class EAlertLevel OldAlertLevel, enum class EAlertLevel NewAlertLevel); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnAlertLevelChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnTargetChanged__DelegateSignature(struct AActor* NewTarget); // Function BP_PlayerPawn_NonParticipant.BP_PlayerPawn_NonParticipant_C.OnTargetChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

