// BlueprintGeneratedClass BBE_Rock_RadioNext.BBE_Rock_RadioNext_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_Rock_RadioNext_C : UFortMobileActionButtonBehaviorExtension {
};

