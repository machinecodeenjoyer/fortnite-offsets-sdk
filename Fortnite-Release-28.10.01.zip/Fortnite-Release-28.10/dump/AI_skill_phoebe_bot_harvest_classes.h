// BlueprintGeneratedClass AI_skill_phoebe_bot_harvest.AI_skill_phoebe_bot_harvest_C
// Size: 0xd0 (Inherited: 0xd0)
struct UAI_skill_phoebe_bot_harvest_C : UFortAthenaAIBotHarvestSkillSet {
};

