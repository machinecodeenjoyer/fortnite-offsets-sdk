// BlueprintGeneratedClass AI_skill_phoebe_bot_movement.AI_skill_phoebe_bot_movement_C
// Size: 0x14c0 (Inherited: 0x14c0)
struct UAI_skill_phoebe_bot_movement_C : UFortAthenaAIBotMovementSkillSet {
};

