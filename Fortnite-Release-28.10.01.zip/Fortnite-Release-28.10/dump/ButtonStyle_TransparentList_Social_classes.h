// BlueprintGeneratedClass ButtonStyle_TransparentList_Social.ButtonStyle_TransparentList_Social_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_TransparentList_Social_C : UCommonButtonStyle {
};

