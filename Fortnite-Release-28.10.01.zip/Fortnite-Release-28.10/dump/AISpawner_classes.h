// Class AISpawner.AISpawnerPreviewerComponent
// Size: 0x2f0 (Inherited: 0x2e0)
struct UAISpawnerPreviewerComponent : UChildActorComponent {
	struct AFortPlayerMannequin* PlayerMannequinClass; // 0x2e0(0x08)
	char pad_2E8[0x8]; // 0x2e8(0x08)

	void SetCIDForPreview(struct UAthenaCharacterItemDefinition* InCID); // Function AISpawner.AISpawnerPreviewerComponent.SetCIDForPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4aca44
	void SetActorForPreview(struct AActor* InActorClass); // Function AISpawner.AISpawnerPreviewerComponent.SetActorForPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4ac930
	void ClearCIDPreview(); // Function AISpawner.AISpawnerPreviewerComponent.ClearCIDPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4ac91c
	void ClearActorPreview(); // Function AISpawner.AISpawnerPreviewerComponent.ClearActorPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4ac91c
};

