// BlueprintGeneratedClass Athena_PlayerCameraModeBase.Athena_PlayerCameraModeBase_C
// Size: 0x1ba0 (Inherited: 0x1ba0)
struct UAthena_PlayerCameraModeBase_C : UFortCameraMode_ThirdPerson {
};

