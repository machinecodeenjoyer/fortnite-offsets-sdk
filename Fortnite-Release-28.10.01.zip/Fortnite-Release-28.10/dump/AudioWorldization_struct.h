// Enum AudioWorldization.ETraceDirection
enum class ETraceDirection : uint8 {
	N = 0,
	E = 1,
	S = 2,
	W = 3,
	Up = 4,
	None = 5,
	ETraceDirection_MAX = 6
};

// ScriptStruct AudioWorldization.AudioWorldizationSend
// Size: 0x68 (Inherited: 0x00)
struct FAudioWorldizationSend {
	struct USoundSubmix* Submix; // 0x00(0x08)
	struct TSet<struct USoundModulatorBase*> VolumeModulators; // 0x08(0x50)
	struct TArray<struct USoundEffectSubmixPreset*> EffectChain; // 0x58(0x10)
};

// ScriptStruct AudioWorldization.AudioWorldizationSettings
// Size: 0x78 (Inherited: 0x00)
struct FAudioWorldizationSettings {
	struct FName Identifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FAudioWorldizationSend> Sends; // 0x08(0x10)
	float EnclosureSmoothSpeed; // 0x18(0x04)
	float WallDistanceSmoothSpeed; // 0x1c(0x04)
	float TraceRadius; // 0x20(0x04)
	float CrossfadeTime; // 0x24(0x04)
	int32_t TracePoints; // 0x28(0x04)
	int32_t TracesPerFrame; // 0x2c(0x04)
	float SideQuadrantDegrees; // 0x30(0x04)
	float UpQuadrantDegrees; // 0x34(0x04)
	struct FVector TraceOrigin; // 0x38(0x18)
	enum class ECollisionChannel TraceChannel; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct TArray<enum class ECollisionChannel> ResponseChannels; // 0x58(0x10)
	struct UAudioWorldizationTracePolicyBase* TracePolicy; // 0x68(0x08)
	struct UAudioWorldizationTraceDirectionPolicyBase* TraceDirectionPolicy; // 0x70(0x08)
};

// ScriptStruct AudioWorldization.AudioWorldizationQuadrantSettings
// Size: 0x10 (Inherited: 0x00)
struct FAudioWorldizationQuadrantSettings {
	struct USoundControlBus* WallDistanceBus; // 0x00(0x08)
	struct USoundControlBus* EnclosureBus; // 0x08(0x08)
};

// ScriptStruct AudioWorldization.AudioWorldizationGlobalSettings
// Size: 0x30 (Inherited: 0x00)
struct FAudioWorldizationGlobalSettings {
	float EffectCrossfadeTime; // 0x00(0x04)
	struct FName IgnoreTraceActorTag; // 0x04(0x04)
	struct USoundControlBus* EnclosureBus; // 0x08(0x08)
	struct USoundControlBus* WallDistanceBus; // 0x10(0x08)
	struct USoundControlBus* ListenerAzimuthBus; // 0x18(0x08)
	struct TArray<struct FAudioWorldizationQuadrantSettings> Quadrants; // 0x20(0x10)
};

// ScriptStruct AudioWorldization.AudioSphereTraceResult
// Size: 0x0c (Inherited: 0x00)
struct FAudioSphereTraceResult {
	bool bBlocking; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Distance; // 0x04(0x04)
	char pad_8[0x4]; // 0x08(0x04)
};

