// WidgetBlueprintGeneratedClass AccountNotFound.AccountNotFound_C
// Size: 0x560 (Inherited: 0x560)
struct UAccountNotFound_C : UFortAccountNotFound {
};

