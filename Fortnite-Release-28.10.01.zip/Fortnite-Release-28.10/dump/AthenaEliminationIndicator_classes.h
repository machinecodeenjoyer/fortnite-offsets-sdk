// WidgetBlueprintGeneratedClass AthenaEliminationIndicator.AthenaEliminationIndicator_C
// Size: 0x690 (Inherited: 0x668)
struct UAthenaEliminationIndicator_C : UAthenaEliminationIndicator {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x668(0x08)
	struct UWidgetAnimation* Outro; // 0x670(0x08)
	struct UWidgetAnimation* Intro; // 0x678(0x08)
	struct UImage* Arrow; // 0x680(0x08)
	struct UImage* Image_Diamondpulse; // 0x688(0x08)

	void Construct(); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_AthenaEliminationIndicator(int32_t EntryPoint); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.ExecuteUbergraph_AthenaEliminationIndicator // (Final|UbergraphFunction) // @ game+0x211c0a0
};

