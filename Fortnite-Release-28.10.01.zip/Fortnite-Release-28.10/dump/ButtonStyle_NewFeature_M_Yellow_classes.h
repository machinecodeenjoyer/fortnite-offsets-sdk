// BlueprintGeneratedClass ButtonStyle_NewFeature_M_Yellow.ButtonStyle_NewFeature_M_Yellow_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_NewFeature_M_Yellow_C : UCommonButtonStyle {
};

