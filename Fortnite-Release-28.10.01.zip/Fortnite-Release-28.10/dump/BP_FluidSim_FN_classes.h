// BlueprintGeneratedClass BP_FluidSim_FN.BP_FluidSim_FN_C
// Size: 0x790 (Inherited: 0x5d0)
struct ABP_FluidSim_FN_C : ABP_FluidSim_01_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5d0(0x08)
	struct FFluidForceDynamic BoatForceSettings; // 0x5d8(0x70)
	struct FFluidForceDynamic PlayerForceSettings; // 0x648(0x70)
	struct FFluidForceDynamic MechForceSettings; // 0x6b8(0x70)
	struct TArray<struct AFortPawn*> RelevantFortPawns; // 0x728(0x10)
	bool Use FN Pawn Forces; // 0x738(0x01)
	char pad_739[0x7]; // 0x739(0x07)
	struct TMap<struct FGameplayTag, struct FFluidForceDynamic> VehicleTypeMap; // 0x740(0x50)

	void GetFortnitePawnForces(); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetFortnitePawnForces // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetLocalPawn(struct APawn*& Pawn); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetLocalPawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void GetPlayerPawnForces(); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetPlayerPawnForces // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_BP_FluidSim_FN(int32_t EntryPoint); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.ExecuteUbergraph_BP_FluidSim_FN // (Final|UbergraphFunction) // @ game+0x211c0a0
};

