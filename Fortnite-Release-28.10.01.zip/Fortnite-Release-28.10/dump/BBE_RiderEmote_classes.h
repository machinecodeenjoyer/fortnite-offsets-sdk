// BlueprintGeneratedClass BBE_RiderEmote.BBE_RiderEmote_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_RiderEmote_C : UFortMobileActionButtonBehaviorExtension {
};

