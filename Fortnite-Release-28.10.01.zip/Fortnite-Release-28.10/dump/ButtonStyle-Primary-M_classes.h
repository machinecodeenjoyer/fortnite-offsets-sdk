// BlueprintGeneratedClass ButtonStyle-Primary-M.ButtonStyle-Primary-M_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Primary-M_C : UCommonButtonStyle {
};

