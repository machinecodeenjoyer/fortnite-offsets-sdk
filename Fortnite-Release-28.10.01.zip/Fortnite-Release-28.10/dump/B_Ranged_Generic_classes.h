// BlueprintGeneratedClass B_Ranged_Generic.B_Ranged_Generic_C
// Size: 0x20a0 (Inherited: 0x1c68)
struct AB_Ranged_Generic_C : AFortWeaponRanged {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1c68(0x08)
	struct UParticleSystemComponent* Muzzle(Empty); // 0x1c70(0x08)
	float AnimateScopePostProcess_DownSightPostProcessAmount_393D8BA5486879173797EF8C9B8D4642; // 0x1c78(0x04)
	enum class ETimelineDirection AnimateScopePostProcess__Direction_393D8BA5486879173797EF8C9B8D4642; // 0x1c7c(0x01)
	char pad_1C7D[0x3]; // 0x1c7d(0x03)
	struct UTimelineComponent* AnimateScopePostProcess; // 0x1c80(0x08)
	struct UNiagaraSystem* OpticGlint; // 0x1c88(0x08)
	struct UParticleSystem* MuzzleParticleSystem; // 0x1c90(0x08)
	bool UseDestroyEffect; // 0x1c98(0x01)
	char pad_1C99[0x7]; // 0x1c99(0x07)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0x1ca0(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0x1ca8(0x08)
	bool Use Reload Particles; // 0x1cb0(0x01)
	char pad_1CB1[0x7]; // 0x1cb1(0x07)
	double LastPlayFXTime; // 0x1cb8(0x08)
	double MinPlayFXTime; // 0x1cc0(0x08)
	bool UseShellsOnFire?; // 0x1cc8(0x01)
	bool UseShellsOnReload?; // 0x1cc9(0x01)
	bool UseShellsOnPump?; // 0x1cca(0x01)
	char pad_1CCB[0x5]; // 0x1ccb(0x05)
	struct UNiagaraSystem* Shell Burst FX; // 0x1cd0(0x08)
	struct UNiagaraSystem* Shell Looping FX; // 0x1cd8(0x08)
	struct UNiagaraSystem* Reload_System; // 0x1ce0(0x08)
	struct UMaterialInterface* Reload Smoke Material; // 0x1ce8(0x08)
	struct FName ReloadSocketName; // 0x1cf0(0x04)
	struct FGameplayTag TagToApplyOpticGlint; // 0x1cf4(0x04)
	struct TArray<struct AFortAIPawn*> Array Of Active Enemy AI; // 0x1cf8(0x10)
	bool Scope - Render Enemies To Custom Depth Buffer; // 0x1d08(0x01)
	char pad_1D09[0x3]; // 0x1d09(0x03)
	struct FName Shells Socket Name; // 0x1d0c(0x04)
	enum class En_ShellTypes_01 ShellTypeSelect; // 0x1d10(0x01)
	char pad_1D11[0x7]; // 0x1d11(0x07)
	double Shells Spawn Rate Scale; // 0x1d18(0x08)
	struct FVector ShellsRotationRate; // 0x1d20(0x18)
	struct FVector Shells Velocity; // 0x1d38(0x18)
	struct FVector Shells Gravity; // 0x1d50(0x18)
	struct FVector Shells Size; // 0x1d68(0x18)
	double Target Scope Vignette Blur Screen Percentage; // 0x1d80(0x08)
	double ScopeCameraOffsetX; // 0x1d88(0x08)
	double ScopeCameraOffsetY; // 0x1d90(0x08)
	double Scope Camera Offset Amount; // 0x1d98(0x08)
	double Inherit Parent Velocity; // 0x1da0(0x08)
	double Cylindrical Radius; // 0x1da8(0x08)
	double Cylindrical Height; // 0x1db0(0x08)
	struct FLinearColor Shell Color; // 0x1db8(0x10)
	struct UNiagaraComponent* Spawned_Shells; // 0x1dc8(0x08)
	bool DebugShellsSocket?; // 0x1dd0(0x01)
	char pad_1DD1[0x7]; // 0x1dd1(0x07)
	struct USoundBase* Sound_ScopeZoomIn; // 0x1dd8(0x08)
	struct USoundBase* Sound_ScopeZoomOut; // 0x1de0(0x08)
	struct UNiagaraComponent* Alteration Ambient PS; // 0x1de8(0x08)
	struct FGameplayTagContainer ReticleHUDElementTags; // 0x1df0(0x20)
	bool Is Wind Enabled; // 0x1e10(0x01)
	char pad_1E11[0x7]; // 0x1e11(0x07)
	struct UParticleSystem* MuzzleWindParticleSystem; // 0x1e18(0x08)
	struct UParticleSystem* MuzzleParticleSystem1P; // 0x1e20(0x08)
	bool ShouldHideReticleAfterDelay; // 0x1e28(0x01)
	char pad_1E29[0x7]; // 0x1e29(0x07)
	struct UParticleSystemComponent* MuzzleWindParticleSpawned; // 0x1e30(0x08)
	int32_t StencilBufferValue; // 0x1e38(0x04)
	char pad_1E3C[0x4]; // 0x1e3c(0x04)
	struct UCurveFloat* Curve_PitchOffset; // 0x1e40(0x08)
	struct USoundBase* Sound_ScopedInLoop; // 0x1e48(0x08)
	struct UAudioComponent* ScopeZoomInComp; // 0x1e50(0x08)
	struct UAudioComponent* ScopedInLoopComp; // 0x1e58(0x08)
	struct UAudioComponent* ScopeZoomOutComp; // 0x1e60(0x08)
	double Alteration Ambient PS Max Draw Distance; // 0x1e68(0x08)
	double Muzzle PS Max Draw Distance; // 0x1e70(0x08)
	double Beam PS Max Draw Distance; // 0x1e78(0x08)
	double Reload PS Max Draw Distance; // 0x1e80(0x08)
	double Shells PS Max Draw Distance; // 0x1e88(0x08)
	struct FMulticastInlineDelegate onAimDownSightsChanged; // 0x1e90(0x10)
	bool IsMuzzleNiagara; // 0x1ea0(0x01)
	char pad_1EA1[0x7]; // 0x1ea1(0x07)
	struct UNiagaraSystem* MuzzleNiagaraSystemInstance; // 0x1ea8(0x08)
	struct TSoftObjectPtr<UNiagaraSystem> MuzzleNiagaraSystemAsset; // 0x1eb0(0x20)
	struct UNiagaraComponent* MuzzleNiagaraComponentInstance; // 0x1ed0(0x08)
	struct TArray<struct UParticleSystemComponent*> MuzzleParticleSystemComponents; // 0x1ed8(0x10)
	double Muzzle_ChanceOfLargeFlash; // 0x1ee8(0x08)
	double Muzzle_FlashLarge_MinScale; // 0x1ef0(0x08)
	double Muzzle_FlashLarge_MaxScale; // 0x1ef8(0x08)
	double Muzzle_FlashSmall_MinScale; // 0x1f00(0x08)
	double Muzzle_FlashSmall_MaxScale; // 0x1f08(0x08)
	struct FTimerHandle ScopeEffectDelay1Handle; // 0x1f10(0x08)
	struct FTimerHandle ScopeEffectDelay2Handle; // 0x1f18(0x08)
	struct FScalableFloat UseNativeFX; // 0x1f20(0x28)
	struct FScalableFloat UseUpdatedFeedback; // 0x1f48(0x28)
	struct FMulticastInlineDelegate OnStartFiring; // 0x1f70(0x10)
	struct FMulticastInlineDelegate OnPersistentFireStopped; // 0x1f80(0x10)
	struct UStaticMesh* ScopeMesh; // 0x1f90(0x08)
	struct UStaticMeshComponent* ScopeMesh1P_Spawned; // 0x1f98(0x08)
	struct TArray<struct UMaterialInterface*> ScopeMaterialOverrides; // 0x1fa0(0x10)
	float Reload Smoke Lifetime; // 0x1fb0(0x04)
	float Reload Smoke Width Scale; // 0x1fb4(0x04)
	struct FLinearColor BaseColorAlpha; // 0x1fb8(0x10)
	bool Use Emissive in Reload; // 0x1fc8(0x01)
	char pad_1FC9[0x3]; // 0x1fc9(0x03)
	struct FLinearColor Reload Emissive Color; // 0x1fcc(0x10)
	bool Is Rocket Launcher; // 0x1fdc(0x01)
	char pad_1FDD[0x3]; // 0x1fdd(0x03)
	struct FLinearColor Rocket Launcher Spark Color; // 0x1fe0(0x10)
	bool Reload Ejects Shells; // 0x1ff0(0x01)
	bool IsPaprika? (MuzzleFX); // 0x1ff1(0x01)
	char pad_1FF2[0x6]; // 0x1ff2(0x06)
	struct UNiagaraComponent* OpticGlintComp; // 0x1ff8(0x08)
	struct UFXSystemAsset* Muzzle System; // 0x2000(0x08)
	float Muzzle Hue Control; // 0x2008(0x04)
	float Muzzle Core Cap Scale; // 0x200c(0x04)
	struct FVector Muzzle Core Scale; // 0x2010(0x18)
	float Spark Amount Scale; // 0x2028(0x04)
	float Smoke Size Scale; // 0x202c(0x04)
	struct FLinearColor MuzzleSmokeInitialColor; // 0x2030(0x10)
	float Smoke Initial Color Scale Variance; // 0x2040(0x04)
	float Smoke Emissive Scale; // 0x2044(0x04)
	bool Use Heated Elements; // 0x2048(0x01)
	char pad_2049[0x3]; // 0x2049(0x03)
	float Decal Size; // 0x204c(0x04)
	struct FVector Decal Offset; // 0x2050(0x18)
	float Decal Alpha; // 0x2068(0x04)
	char pad_206C[0x4]; // 0x206c(0x04)
	struct UFXSystemComponent* Spawned Muzzle System; // 0x2070(0x08)
	int32_t Burst Loops; // 0x2078(0x04)
	bool Muzzle_BakedSupressor (Always Suppressed); // 0x207c(0x01)
	bool bIsLocal; // 0x207d(0x01)
	char pad_207E[0x2]; // 0x207e(0x02)
	struct UNiagaraSystem* Magazine Eject System; // 0x2080(0x08)
	struct FName Magazine Eject Socket Name; // 0x2088(0x04)
	bool Use Magazine Eject; // 0x208c(0x01)
	char pad_208D[0x3]; // 0x208d(0x03)
	struct UMaterialInterface* Magazine Eject Material; // 0x2090(0x08)
	struct UStaticMesh* Magazine Eject Model; // 0x2098(0x08)

	void Activate Magazine Eject FX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.Activate Magazine Eject FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void MuzzleModCheck(bool& isMuzzleBrake, bool& isMuzzleSupressor, bool& isMuzzleBreacher); // Function B_Ranged_Generic.B_Ranged_Generic_C.MuzzleModCheck // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void MuzzleADSCheck(bool& Return ADS Bool); // Function B_Ranged_Generic.B_Ranged_Generic_C.MuzzleADSCheck // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ShowOpticGlint(bool AimDownsights); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowOpticGlint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AddRandomScale_Paprika(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AddRandomScale_Paprika // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StopLocalForceFeedback(struct UForceFeedbackEffect* ForceFeedbackEffect, struct FName tag); // Function B_Ranged_Generic.B_Ranged_Generic_C.StopLocalForceFeedback // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayLocalForceFeedback(struct UForceFeedbackEffect* ForceFeedbackEffect, struct FName tag, bool bLooping); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayLocalForceFeedback // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void getScopeComp(struct UStaticMeshComponent*& ScopeComponent); // Function B_Ranged_Generic.B_Ranged_Generic_C.getScopeComp // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void initScope(); // Function B_Ranged_Generic.B_Ranged_Generic_C.initScope // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void IsNewFeedbackEnabled(bool& Enabled); // Function B_Ranged_Generic.B_Ranged_Generic_C.IsNewFeedbackEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void LocalReloadStarted(float ReloadTime, enum class EFortWeaponReloadType ReloadType); // Function B_Ranged_Generic.B_Ranged_Generic_C.LocalReloadStarted // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetCorrectMuzzleNiagaraSystem(struct TSoftObjectPtr<UNiagaraSystem>& OutNiagaraSystem); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetCorrectMuzzleNiagaraSystem // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void PlayScopeOutAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayScopeOutAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetScopeParameters(struct UStaticMeshComponent*& ScopeComponent, struct FVector2D& DepthOfFieldVignetteRange, struct FVector& WeaponSightsOffset); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetScopeParameters // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void GetActiveMuzzleComponents(struct TArray<struct UFXSystemComponent*>& NewParam); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetActiveMuzzleComponents // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void SetActiveMuzzleComponent(bool NiagaraEnabled); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetActiveMuzzleComponent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StopScopedAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.StopScopedAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StartScopedAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.StartScopedAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetPostProcessParams(double InputPin); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetPostProcessParams // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetActiveAlterationIdleParticles(bool Active); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetActiveAlterationIdleParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ShowReticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HideReticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ActivateOrDeactivateWindParticle(bool bNewActive); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateOrDeactivateWindParticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void DeactivateMuzzleFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateMuzzleFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ActivateReloadSmokeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateReloadSmokeFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ActivateShellsFX(bool bool); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void DeactivateShellsFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetupShellFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetupShellFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UpdateShellEmittersFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UpdateShellEmittersFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Muzzle Play Reload FX(enum class EFortReloadFXState Selection); // Function B_Ranged_Generic.B_Ranged_Generic_C.Muzzle Play Reload FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Muzzle Flash FX(bool Persistent Fire); // Function B_Ranged_Generic.B_Ranged_Generic_C.Muzzle Flash FX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetWpnRarity(); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AddRandomScale(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AddRandomScale // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UserConstructionScript(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AnimateScopePostProcess__FinishedFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void AnimateScopePostProcess__UpdateFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void AnimateScopePostProcess__Toggle Scope__EventFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__Toggle Scope__EventFunc // (BlueprintEvent) // @ game+0x211c0a0
	void OnLoaded_4D1409A247BFDB4C074B628406FC7A72(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_4D1409A247BFDB4C074B628406FC7A72 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnLoaded_3A9BBE884A5C5966375089938B7DC0CA(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_3A9BBE884A5C5966375089938B7DC0CA // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnLoaded_83457BA843174AC6288682A342EBEAD9(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_83457BA843174AC6288682A342EBEAD9 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnLoaded_5B08633343C4DA6FF40449A8A36357E4(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_5B08633343C4DA6FF40449A8A36357E4 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnStopWeaponFireFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStopWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnPlayReloadFX(enum class EFortReloadFXState ReloadStage); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayReloadFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnSetTargeting(bool bNewIsTargeting); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnSetTargeting // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void K2_OnUnEquip(); // Function B_Ranged_Generic.B_Ranged_Generic_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void InitializeScopeVariables(); // Function B_Ranged_Generic.B_Ranged_Generic_C.InitializeScopeVariables // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Update Enemy Custom Depths(bool Enable Or Disable, int32_t StencilBufferValue); // Function B_Ranged_Generic.B_Ranged_Generic_C.Update Enemy Custom Depths // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponAttached(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnInitAlteration(struct UFortAlterationItemDefinition* NewAlteration); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnInitAlteration // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ShellsON_(onPump)(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellsON_(onPump) // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnEquippedWeaponDestory(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void SetWeaponPierceThrough(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWeaponPierceThrough // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void SetWeaponPierceThrough_ClientRep(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWeaponPierceThrough_ClientRep // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void HideWeaponMesh(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ShowWeaponMesh(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HideWeapon(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ShowWeapon(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReverseScopePP(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReverseScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ResetDoonceScopeSound(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ResetDoonceScopeSound // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UnhideThirdPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideThirdPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PlayScopePP(); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HideFirstPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideFirstPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AbortScopeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AbortScopeFX // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void HideThirdPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideThirdPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UnhideFirstPersonStuffPart2(int32_t Which Call); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideFirstPersonStuffPart2 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void UnhideFirstPersonStuffPart1(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideFirstPersonStuffPart1 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ForceScopeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ForceScopeFX // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void BindFireRateChange(); // Function B_Ranged_Generic.B_Ranged_Generic_C.BindFireRateChange // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void PitchUpOnRateOfFireChange(float NewRateOfFire); // Function B_Ranged_Generic.B_Ranged_Generic_C.PitchUpOnRateOfFireChange // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ShellEjectionFixOn(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellEjectionFixOn // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Bind on Effects Quality(); // Function B_Ranged_Generic.B_Ranged_Generic_C.Bind on Effects Quality // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ShellEjectionOff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellEjectionOff // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ForceScopeBackImmediatly(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ForceScopeBackImmediatly // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnPlayImpactFX(struct FHitResult& HitResult, enum class EPhysicalSurface ImpactPhysicalSurface, struct UFXSystemComponent* SpawnedPSC); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayImpactFX // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void OnStartOverheated(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStartOverheated // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void LoadNiagaraMuzzleSoftObject(); // Function B_Ranged_Generic.B_Ranged_Generic_C.LoadNiagaraMuzzleSoftObject // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnApplyFireModeData(struct UFortWeaponFireModeData* FireModeData); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnApplyFireModeData // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ScopeEffectDelay2(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ScopeEffectDelay2 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ScopeEffectDelay1(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ScopeEffectDelay1 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ModAddedtoWeapon(struct UFortWeaponModItemDefinition* Mod, struct AFortWeapon* Weapon); // Function B_Ranged_Generic.B_Ranged_Generic_C.ModAddedtoWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void CancelScopeTargeting(); // Function B_Ranged_Generic.B_Ranged_Generic_C.CancelScopeTargeting // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void UpdateModMagazine(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UpdateModMagazine // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveParticleData(struct TArray<struct FBasicParticleData>& Data, struct UNiagaraSystem* NiagaraSystem, struct FVector& SimulationPositionOffset); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReceiveParticleData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnWeaponDetached(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponDetached // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_B_Ranged_Generic(int32_t EntryPoint); // Function B_Ranged_Generic.B_Ranged_Generic_C.ExecuteUbergraph_B_Ranged_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
	void OnPersistentFireStopped__DelegateSignature(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPersistentFireStopped__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnStartFiring__DelegateSignature(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStartFiring__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void onAimDownSightsChanged__DelegateSignature(bool AimDownsights); // Function B_Ranged_Generic.B_Ranged_Generic_C.onAimDownSightsChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
};

