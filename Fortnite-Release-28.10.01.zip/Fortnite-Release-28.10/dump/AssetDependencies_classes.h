// Class AssetDependencies.AssetDependencySettings
// Size: 0x150 (Inherited: 0x30)
struct UAssetDependencySettings : UDeveloperSettings {
	struct TArray<struct FName> ExcludedPaths; // 0x30(0x10)
	char pad_40[0x50]; // 0x40(0x50)
	struct TArray<struct FName> ExcludedPackages; // 0x90(0x10)
	char pad_A0[0x50]; // 0xa0(0x50)
	struct TArray<struct UObject*> ClassIgnoreList; // 0xf0(0x10)
	struct TSet<struct UObject*> ClassIgnoreListSet; // 0x100(0x50)
};

