// BlueprintGeneratedClass B_CameraLens_SpookyMist_End.B_CameraLens_SpookyMist_End_C
// Size: 0x388 (Inherited: 0x380)
struct AB_CameraLens_SpookyMist_End_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_SpookyMist_End.B_CameraLens_SpookyMist_End_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_B_CameraLens_SpookyMist_End(int32_t EntryPoint); // Function B_CameraLens_SpookyMist_End.B_CameraLens_SpookyMist_End_C.ExecuteUbergraph_B_CameraLens_SpookyMist_End // (Final|UbergraphFunction) // @ game+0x211c0a0
};

