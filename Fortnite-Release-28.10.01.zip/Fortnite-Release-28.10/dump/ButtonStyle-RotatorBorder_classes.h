// BlueprintGeneratedClass ButtonStyle-RotatorBorder.ButtonStyle-RotatorBorder_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-RotatorBorder_C : UCommonButtonStyle {
};

