// BlueprintGeneratedClass ButtonStyle-Tab-Manage.ButtonStyle-Tab-Manage_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Tab-Manage_C : UCommonButtonStyle {
};

