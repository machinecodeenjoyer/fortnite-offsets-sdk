// BlueprintGeneratedClass ButtonStyle-Icon_Transparent.ButtonStyle-Icon_Transparent_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Icon_Transparent_C : UCommonButtonStyle {
};

