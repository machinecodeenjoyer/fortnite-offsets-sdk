// BlueprintGeneratedClass BP_CameraLens_HidingProp_Teleporting_Looping_WilliePete.BP_CameraLens_HidingProp_Teleporting_Looping_WilliePete_C
// Size: 0x380 (Inherited: 0x380)
struct ABP_CameraLens_HidingProp_Teleporting_Looping_WilliePete_C : AEmitterCameraLensEffectBase {
};

