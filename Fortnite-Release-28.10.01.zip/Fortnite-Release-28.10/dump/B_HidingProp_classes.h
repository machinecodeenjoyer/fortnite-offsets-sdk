// BlueprintGeneratedClass B_HidingProp.B_HidingProp_C
// Size: 0x11a9 (Inherited: 0xc20)
struct AB_HidingProp_C : AFortHidingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc20(0x08)
	struct USceneComponent* ProjectileLocation_ForwardVector; // 0xc28(0x08)
	struct UStaticMeshComponent* LandedOnCollisionMesh; // 0xc30(0x08)
	struct USphereComponent* Sphere; // 0xc38(0x08)
	struct USceneComponent* HideLocation_ForwardVector; // 0xc40(0x08)
	float Loot_MovementTimeline_Forward_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xc48(0x04)
	float Loot_MovementTimeline_Z_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xc4c(0x04)
	enum class ETimelineDirection Loot_MovementTimeline__Direction_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xc50(0x01)
	char pad_C51[0x7]; // 0xc51(0x07)
	struct UTimelineComponent* Loot_MovementTimeline; // 0xc58(0x08)
	struct FScalableFloat Enabled; // 0xc60(0x28)
	struct FScalableFloat HidingEnabled; // 0xc88(0x28)
	struct FScalableFloat PlayerLimit; // 0xcb0(0x28)
	struct FScalableFloat TeleportEnabled; // 0xcd8(0x28)
	struct FScalableFloat CanTeleport; // 0xd00(0x28)
	struct TArray<struct AFortPawn*> HidingPlayers; // 0xd28(0x10)
	struct FGameplayTag EnterGameplayCue; // 0xd38(0x04)
	struct FGameplayTag ExitGameplayCue; // 0xd3c(0x04)
	struct FGameplayTag LandedOnGameplayCue; // 0xd40(0x04)
	char pad_D44[0x4]; // 0xd44(0x04)
	struct UMaterialInstanceDynamic* Mid; // 0xd48(0x08)
	struct FGameplayTag RustleGameplayCue; // 0xd50(0x04)
	struct FGameplayTag ExitGameplayCue_Player; // 0xd54(0x04)
	struct FGameplayTag WhileEnteringGameplayCue; // 0xd58(0x04)
	char pad_D5C[0x4]; // 0xd5c(0x04)
	double ObstructionTraceLength; // 0xd60(0x08)
	struct TArray<enum class EObjectTypeQuery> DestroyObjectTypes; // 0xd68(0x10)
	struct TArray<struct AFortPawn*> Array; // 0xd78(0x10)
	int32_t Int; // 0xd88(0x04)
	char pad_D8C[0x4]; // 0xd8c(0x04)
	struct FVector DeimosPropSpawnerOffset; // 0xd90(0x18)
	bool FixedEntranceDirection; // 0xda8(0x01)
	char pad_DA9[0x7]; // 0xda9(0x07)
	double MaxInteractAngle; // 0xdb0(0x08)
	struct FVector WobbleLocationOffset; // 0xdb8(0x18)
	double InteractBelowPropDistance; // 0xdd0(0x08)
	struct TMap<struct AFortPawn*, double> HiddenPlayersAndEnterTimes; // 0xdd8(0x50)
	struct AFortPawn* LastPawnToInteract; // 0xe28(0x08)
	struct AB_HidingProp_C* TargetTeleporter; // 0xe30(0x08)
	struct FGameplayTag TeleporterEnterGameplayCue; // 0xe38(0x04)
	struct FGameplayTag TeleporterExitGameplayCue; // 0xe3c(0x04)
	struct FGameplayTag LoopingTeleportingCue; // 0xe40(0x04)
	struct FGameplayTag GC_Wobble; // 0xe44(0x04)
	struct FTimerHandle WobbleTimerHandle; // 0xe48(0x08)
	struct TArray<struct FGameplayTag> BlockEntranceTags; // 0xe50(0x10)
	struct TArray<struct FGameplayTag> BlockExitTags; // 0xe60(0x10)
	struct UAnimMontage* EnterAnimMontage; // 0xe70(0x08)
	struct UAnimMontage* ExitAnimMontage; // 0xe78(0x08)
	struct AFortPawn* LastPawnToHide; // 0xe80(0x08)
	struct FGameplayTag TeleportingStateGC; // 0xe88(0x04)
	bool RandomWobbleNormal; // 0xe8c(0x01)
	bool SingleOccupant; // 0xe8d(0x01)
	bool Teleporting; // 0xe8e(0x01)
	bool JumpOut; // 0xe8f(0x01)
	struct UGameplayEffect* GE_OnExitingPropNoJump_BlockActions; // 0xe90(0x08)
	bool DestroyInNonSpyLTM; // 0xe98(0x01)
	bool ActiveInSpyLTM; // 0xe99(0x01)
	char pad_E9A[0x6]; // 0xe9a(0x06)
	struct TArray<struct FGameplayTag> ForceAllowInteractTags; // 0xea0(0x10)
	struct FGameplayTag IsTeleporter; // 0xeb0(0x04)
	struct FGameplayTag ContainsPlayerRepNof; // 0xeb4(0x04)
	struct FVector ObstructionTraceExtents; // 0xeb8(0x18)
	struct FVector ObstructionTraceStartOffSet; // 0xed0(0x18)
	double ExitLaunchVelocity; // 0xee8(0x08)
	struct FVector AdditionalLaunchVelocity; // 0xef0(0x18)
	struct FVector Obstruction Trace End; // 0xf08(0x18)
	struct FVector FixedEntraceObstructionTraceEndOffset; // 0xf20(0x18)
	bool isActiveTeleportExit; // 0xf38(0x01)
	char pad_F39[0x7]; // 0xf39(0x07)
	struct UGameplayEffect* GE_TeleportAbilityGranted; // 0xf40(0x08)
	bool DisableWhenSubmergedInWater; // 0xf48(0x01)
	char pad_F49[0x7]; // 0xf49(0x07)
	struct FGameplayTagContainer DisableWhenSubmergedExceptionTags; // 0xf50(0x20)
	struct TArray<struct AFortPawn*> NonCosmeticPawns; // 0xf70(0x10)
	struct UCameraModifier* CameraModifier; // 0xf80(0x08)
	struct FVector ; // 0xf88(0x18)
	struct AActor* Pawn; // 0xfa0(0x08)
	struct FVector Loot_CachedActorForward; // 0xfa8(0x18)
	struct TArray<struct FVector> Loot_VectorOffsets; // 0xfc0(0x10)
	bool SpawnedLoot; // 0xfd0(0x01)
	char pad_FD1[0x7]; // 0xfd1(0x07)
	double Loot_MoveForwardDistance; // 0xfd8(0x08)
	double Loot_MoveUpDistance; // 0xfe0(0x08)
	double Loot_SpawnRadius; // 0xfe8(0x08)
	struct FVector Loot_SpawnOffset; // 0xff0(0x18)
	bool ShouldSpawnLoot; // 0x1008(0x01)
	char pad_1009[0x7]; // 0x1009(0x07)
	struct FString Loot Tier Group; // 0x1010(0x10)
	bool SetEntranceRotation; // 0x1020(0x01)
	char pad_1021[0x7]; // 0x1021(0x07)
	struct UGameplayEffect* PropSpecificEffectToApplyToHiders; // 0x1028(0x08)
	struct FScalableFloat RustlesPerWobble; // 0x1030(0x28)
	struct FScalableFloat RustleWobbleRadius; // 0x1058(0x28)
	struct FScalableFloat EnterWobbleRadius; // 0x1080(0x28)
	double NonJumpExitDistance; // 0x10a8(0x08)
	struct UFortCameraMode* Camera Mode; // 0x10b0(0x08)
	bool MoveToActorOnEnter; // 0x10b8(0x01)
	bool IgnorePhysicsBodyCollisionOnEnter; // 0x10b9(0x01)
	bool bCanRustleAndWobble; // 0x10ba(0x01)
	bool SkipRestoreCameraViewTargetOnStopHiding; // 0x10bb(0x01)
	bool SkipRootMotionMovementOnStopHiding; // 0x10bc(0x01)
	char pad_10BD[0x3]; // 0x10bd(0x03)
	struct FRotator AddedSetEntranceRotation; // 0x10c0(0x18)
	double MoveToActorDelayOnEnter; // 0x10d8(0x08)
	double MoveToActorDurationOverride; // 0x10e0(0x08)
	struct FMarkedActorDisplayInfo MarkerDisplay; // 0x10e8(0xa8)
	struct FVector MarkerPositionOffset; // 0x1190(0x18)
	bool ObstructionTraceByObject; // 0x11a8(0x01)

	void Get Obstruction Objects(bool TraceByChannel, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator orientation, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct FHitResult>& OutHits); // Function B_HidingProp.B_HidingProp_C.Get Obstruction Objects // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	struct FVector GetMarkerPositionOffset(); // Function B_HidingProp.B_HidingProp_C.GetMarkerPositionOffset // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	struct FMarkedActorDisplayInfo GetMarkerDisplayData(); // Function B_HidingProp.B_HidingProp_C.GetMarkerDisplayData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void GetTurnClientCameraCollisionOnDelayTime(double& Delay); // Function B_HidingProp.B_HidingProp_C.GetTurnClientCameraCollisionOnDelayTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void Can Hide by Falling(struct AActor* OtherActor, bool& CanHide, struct AFortPlayerPawn*& aFortPlayerPawn); // Function B_HidingProp.B_HidingProp_C.Can Hide by Falling // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Player Getting in Prop(struct AFortPawn* FortPawn, bool& Is Getting In); // Function B_HidingProp.B_HidingProp_C.Player Getting in Prop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void Player Hidden in Prop(struct AFortPawn* Fort Pawn, bool& IsHidden); // Function B_HidingProp.B_HidingProp_C.Player Hidden in Prop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void LocalOnFailedInteract(struct AFortPlayerPawn* InteractingPawn); // Function B_HidingProp.B_HidingProp_C.LocalOnFailedInteract // (Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	float GetMinDistanceFromInteraction(); // Function B_HidingProp.B_HidingProp_C.GetMinDistanceFromInteraction // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	void GetPlayerLimit(int32_t& PlayerLimit); // Function B_HidingProp.B_HidingProp_C.GetPlayerLimit // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void Allow Cosmetics For Pawn(struct AFortPawn*& Pawn, bool& Allow); // Function B_HidingProp.B_HidingProp_C.Allow Cosmetics For Pawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_ContainsPlayer(); // Function B_HidingProp.B_HidingProp_C.OnRep_ContainsPlayer // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_IsTeleporter(); // Function B_HidingProp.B_HidingProp_C.OnRep_IsTeleporter // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	bool CheckCanUsePassage(struct UObject* Object); // Function B_HidingProp.B_HidingProp_C.CheckCanUsePassage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	bool IsInInfiltrationLTM(); // Function B_HidingProp.B_HidingProp_C.IsInInfiltrationLTM // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x211c0a0
	void OnRep_Teleporting(); // Function B_HidingProp.B_HidingProp_C.OnRep_Teleporting // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	struct FText BlueprintGetFailedInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetFailedInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	void RemoveHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.RemoveHiddenPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AddHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.AddHiddenPlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnRep_HidingPlayers(); // Function B_HidingProp.B_HidingProp_C.OnRep_HidingPlayers // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float& OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_HidingProp.B_HidingProp_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x211c0a0
	void Loot_MovementTimeline__FinishedFunc(); // Function B_HidingProp.B_HidingProp_C.Loot_MovementTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x211c0a0
	void Loot_MovementTimeline__UpdateFunc(); // Function B_HidingProp.B_HidingProp_C.Loot_MovementTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x211c0a0
	void OnReady_64CBF02E419FF250B433D5B2A6E5D744(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function B_HidingProp.B_HidingProp_C.OnReady_64CBF02E419FF250B433D5B2A6E5D744 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141(); // Function B_HidingProp.B_HidingProp_C.OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141 // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_HidingProp.B_HidingProp_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function B_HidingProp.B_HidingProp_C.BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x211c0a0
	void LandedOnHayStack(struct AFortPlayerPawn* PlayerPawn, double Z Velocity Mag); // Function B_HidingProp.B_HidingProp_C.LandedOnHayStack // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void LaunchPlayersOffTop(struct AFortPlayerPawn* PlayerPawn); // Function B_HidingProp.B_HidingProp_C.LaunchPlayersOffTop // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function B_HidingProp.B_HidingProp_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void StopHidingLoop(); // Function B_HidingProp.B_HidingProp_C.StopHidingLoop // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void HidingPlayerCountChanged(); // Function B_HidingProp.B_HidingProp_C.HidingPlayerCountChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void InteractEnter(); // Function B_HidingProp.B_HidingProp_C.InteractEnter // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void EndHidingAnalyticSession(struct AFortPawn* FortPawn, enum class EEnvironmentalItemEndReason EndReason); // Function B_HidingProp.B_HidingProp_C.EndHidingAnalyticSession // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void WatchForPlayerDeath(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.WatchForPlayerDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void Pawn Died(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_HidingProp.B_HidingProp_C.Pawn Died // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StopHiding(struct AFortPawn* Pawn); // Function B_HidingProp.B_HidingProp_C.StopHiding // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ReceiveBeginPlay(); // Function B_HidingProp.B_HidingProp_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void Teleport(struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Teleport // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void IgnorePawnCollision(struct AFortPawn* Target, double InIgnoreDuration); // Function B_HidingProp.B_HidingProp_C.IgnorePawnCollision // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ToggleCameraCollisionForClients(); // Function B_HidingProp.B_HidingProp_C.ToggleCameraCollisionForClients // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void StartHiding(struct AFortPawn* InteractingPawn); // Function B_HidingProp.B_HidingProp_C.StartHiding // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void TurnClientCameraCollisionOn(); // Function B_HidingProp.B_HidingProp_C.TurnClientCameraCollisionOn // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.AddGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void RemoveGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.RemoveGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.ExecuteGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void OnMatchStarted(); // Function B_HidingProp.B_HidingProp_C.OnMatchStarted // (Event|Public|BlueprintEvent) // @ game+0x211c0a0
	void Launch Pickups(struct TArray<struct AFortPickup*>& Array, struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Launch Pickups // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void EntranceBlockedByUndamageable(struct AFortPlayerPawn* PlayerPawn); // Function B_HidingProp.B_HidingProp_C.EntranceBlockedByUndamageable // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void IgnorePhysicsCollisionDamage(struct AFortPawn* Target, double Ignore Duration); // Function B_HidingProp.B_HidingProp_C.IgnorePhysicsCollisionDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void BP_HandleExitPressed(struct AFortPlayerPawn* TargetPlayerPawn); // Function B_HidingProp.B_HidingProp_C.BP_HandleExitPressed // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_B_HidingProp(int32_t EntryPoint); // Function B_HidingProp.B_HidingProp_C.ExecuteUbergraph_B_HidingProp // (Final|UbergraphFunction|HasDefaults) // @ game+0x211c0a0
};

