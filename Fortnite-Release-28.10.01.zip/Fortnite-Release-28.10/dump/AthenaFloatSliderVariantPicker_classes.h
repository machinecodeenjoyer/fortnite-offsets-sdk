// WidgetBlueprintGeneratedClass AthenaFloatSliderVariantPicker.AthenaFloatSliderVariantPicker_C
// Size: 0x408 (Inherited: 0x3f0)
struct UAthenaFloatSliderVariantPicker_C : UFortFloatSliderVariantPicker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f0(0x08)
	struct UOverlay* Panel_Value; // 0x3f8(0x08)
	struct USimpleMaterialProgressBar_C* Progress; // 0x400(0x08)

	void OnUpdateValue(float NormalizedValue, bool bIsLocked); // Function AthenaFloatSliderVariantPicker.AthenaFloatSliderVariantPicker_C.OnUpdateValue // (Event|Protected|BlueprintEvent) // @ game+0x211c0a0
	void ExecuteUbergraph_AthenaFloatSliderVariantPicker(int32_t EntryPoint); // Function AthenaFloatSliderVariantPicker.AthenaFloatSliderVariantPicker_C.ExecuteUbergraph_AthenaFloatSliderVariantPicker // (Final|UbergraphFunction) // @ game+0x211c0a0
};

