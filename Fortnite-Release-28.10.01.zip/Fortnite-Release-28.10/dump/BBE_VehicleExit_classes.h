// BlueprintGeneratedClass BBE_VehicleExit.BBE_VehicleExit_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_VehicleExit_C : UFortMobileActionButtonBehaviorExtension {
};

