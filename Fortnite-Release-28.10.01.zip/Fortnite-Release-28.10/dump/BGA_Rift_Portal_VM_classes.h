// BlueprintGeneratedClass BGA_Rift_Portal_VM.BGA_Rift_Portal_VM_C
// Size: 0xc88 (Inherited: 0xc88)
struct ABGA_Rift_Portal_VM_C : ABGA_RiftPortal_Item_Athena_C {
};

