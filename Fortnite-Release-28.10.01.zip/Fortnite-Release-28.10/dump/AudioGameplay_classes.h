// Class AudioGameplay.AudioComponentGroupExtension
// Size: 0x28 (Inherited: 0x28)
struct UAudioComponentGroupExtension : UInterface {
};

// Class AudioGameplay.AudioGameplayCondition
// Size: 0x28 (Inherited: 0x28)
struct UAudioGameplayCondition : UInterface {

	bool ConditionMet_Position(struct FVector& Position); // Function AudioGameplay.AudioGameplayCondition.ConditionMet_Position // (RequiredAPI|Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x15ca170
	bool ConditionMet(); // Function AudioGameplay.AudioGameplayCondition.ConditionMet // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x24f4ae8
};

// Class AudioGameplay.AudioGameplayVolumeInteraction
// Size: 0x28 (Inherited: 0x28)
struct UAudioGameplayVolumeInteraction : UInterface {

	void OnListenerExit(); // Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3346b94
	void OnListenerEnter(); // Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x30e10d4
};

// Class AudioGameplay.SoundHandleSubsystem
// Size: 0xe0 (Inherited: 0x30)
struct USoundHandleSubsystem : UAudioEngineSubsystem {
	char pad_30[0xb0]; // 0x30(0xb0)
};

// Class AudioGameplay.AudioComponentGroup
// Size: 0x440 (Inherited: 0x290)
struct UAudioComponentGroup : USceneComponent {
	char pad_290[0x8]; // 0x290(0x08)
	struct FMulticastInlineDelegate OnStopped; // 0x298(0x10)
	struct FMulticastInlineDelegate OnKilled; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnVirtualized; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnUnvirtualized; // 0x2c8(0x10)
	struct TArray<struct UAudioComponent*> Components; // 0x2d8(0x10)
	struct TArray<struct FAudioParameter> ParamsToSet; // 0x2e8(0x10)
	struct TArray<struct FAudioParameter> PersistentParams; // 0x2f8(0x10)
	struct TArray<struct TScriptInterface<IAudioComponentGroupExtension>> Extensions; // 0x308(0x10)
	char pad_318[0x128]; // 0x318(0x128)

	void UnsubscribeObject(struct UObject* Object); // Function AudioGameplay.AudioComponentGroup.UnsubscribeObject // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f669b0
	void SubscribeToStringParam(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToStringParam // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f668d8
	void SubscribeToEvent(struct FName EventName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66800
	void SubscribeToBool(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToBool // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66728
	void StopSound(struct USoundBase* sound, float FadeTime); // Function AudioGameplay.AudioComponentGroup.StopSound // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66664
	struct UAudioComponentGroup* StaticGetOrCreateComponentGroup(struct AActor* Actor); // Function AudioGameplay.AudioComponentGroup.StaticGetOrCreateComponentGroup // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0x6f665e4
	void SetVolumeMultiplier(float InVolume); // Function AudioGameplay.AudioComponentGroup.SetVolumeMultiplier // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66564
	void SetPitchMultiplier(float InPitch); // Function AudioGameplay.AudioComponentGroup.SetPitchMultiplier // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f664e4
	void SetLowPassFilter(float InFrequency); // Function AudioGameplay.AudioComponentGroup.SetLowPassFilter // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66464
	void RemoveExternalComponent(struct UAudioComponent* ComponentToRemove); // Function AudioGameplay.AudioComponentGroup.RemoveExternalComponent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66354
	void RemoveExtension(struct TScriptInterface<IAudioComponentGroupExtension> NewExtension); // Function AudioGameplay.AudioComponentGroup.RemoveExtension // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f66204
	bool IsVirtualized(); // Function AudioGameplay.AudioComponentGroup.IsVirtualized // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f661ec
	bool IsPlayingAny(); // Function AudioGameplay.AudioComponentGroup.IsPlayingAny // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f661d0
	struct FString GetStringParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetStringParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f6612c
	float GetFloatParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetFloatParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f6609c
	bool GetBoolParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetBoolParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f66010
	void EnableVirtualization(); // Function AudioGameplay.AudioComponentGroup.EnableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65ffc
	void DisableVirtualization(); // Function AudioGameplay.AudioComponentGroup.DisableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65fe8
	void BroadcastStopAll(); // Function AudioGameplay.AudioComponentGroup.BroadcastStopAll // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65fcc
	void BroadcastKill(); // Function AudioGameplay.AudioComponentGroup.BroadcastKill // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65fb0
	void BroadcastEvent(struct FName EventName); // Function AudioGameplay.AudioComponentGroup.BroadcastEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65f30
	void AddExternalComponent(struct UAudioComponent* ComponentToAdd); // Function AudioGameplay.AudioComponentGroup.AddExternalComponent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65ad8
	void AddExtension(struct TScriptInterface<IAudioComponentGroupExtension> NewExtension); // Function AudioGameplay.AudioComponentGroup.AddExtension // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6f65994
};

// Class AudioGameplay.AudioGameplayComponent
// Size: 0xa8 (Inherited: 0xa0)
struct UAudioGameplayComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
};

// Class AudioGameplay.AudioRequirementPreset
// Size: 0x78 (Inherited: 0x30)
struct UAudioRequirementPreset : UDataAsset {
	struct FGameplayTagQuery Query; // 0x30(0x48)
};

// Class AudioGameplay.AudioParameterComponent
// Size: 0xd8 (Inherited: 0xa8)
struct UAudioParameterComponent : UAudioGameplayComponent {
	char pad_A8[0x10]; // 0xa8(0x10)
	struct TArray<struct TWeakObjectPtr<struct UAudioComponent>> ActiveComponents; // 0xb8(0x10)
	struct TArray<struct FAudioParameter> Parameters; // 0xc8(0x10)

	struct TArray<struct FAudioParameter> GetParameters(); // Function AudioGameplay.AudioParameterComponent.GetParameters // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ffa108
};

