// BlueprintGeneratedClass Border-SolidBG-ShellBlue.Border-SolidBG-ShellBlue_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-SolidBG-ShellBlue_C : UBorder-ShellTopBar_C {
};

