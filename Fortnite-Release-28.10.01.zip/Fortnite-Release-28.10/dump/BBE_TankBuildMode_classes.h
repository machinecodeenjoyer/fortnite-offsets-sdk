// BlueprintGeneratedClass BBE_TankBuildMode.BBE_TankBuildMode_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_TankBuildMode_C : UFortMobileActionButtonBehaviorExtension {
};

