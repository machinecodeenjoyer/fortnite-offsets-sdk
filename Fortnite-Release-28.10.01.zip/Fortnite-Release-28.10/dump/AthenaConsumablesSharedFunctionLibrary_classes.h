// BlueprintGeneratedClass AthenaConsumablesSharedFunctionLibrary.AthenaConsumablesSharedFunctionLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UAthenaConsumablesSharedFunctionLibrary_C : UBlueprintFunctionLibrary {

	void Get Actor Forward Cardinal Direction(struct AActor* Actor, struct UObject* __WorldContext, enum class ECardinalDirection& OutCardinalDirection, double& OutYaw); // Function AthenaConsumablesSharedFunctionLibrary.AthenaConsumablesSharedFunctionLibrary_C.Get Actor Forward Cardinal Direction // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x211c0a0
	void IsOverlappingDeployableBlockVolume(struct UObject* WorldContextObject, float BlockingAreaCheckRadius, struct FVector Location, struct UObject* __WorldContext, bool& bOverlapping); // Function AthenaConsumablesSharedFunctionLibrary.AthenaConsumablesSharedFunctionLibrary_C.IsOverlappingDeployableBlockVolume // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x211c0a0
};

