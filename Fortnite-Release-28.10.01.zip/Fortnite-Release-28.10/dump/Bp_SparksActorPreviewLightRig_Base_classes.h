// BlueprintGeneratedClass Bp_SparksActorPreviewLightRig_Base.Bp_SparksActorPreviewLightRig_Base_C
// Size: 0x488 (Inherited: 0x488)
struct ABp_SparksActorPreviewLightRig_Base_C : ASparksItemPreviewOffPawnActor {
};

