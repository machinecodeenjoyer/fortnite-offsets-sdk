// BlueprintGeneratedClass BBE_AugmentRotate.BBE_AugmentRotate_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_AugmentRotate_C : UFortMobileActionButtonBehaviorExtension {
};

