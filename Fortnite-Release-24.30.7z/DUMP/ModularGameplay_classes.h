// Class ModularGameplay.GameFrameworkComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UGameFrameworkComponent : UActorComponent {
};

// Class ModularGameplay.ControllerComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UControllerComponent : UGameFrameworkComponent {
};

// Class ModularGameplay.GameFrameworkComponentManager
// Size: 0x238 (Inherited: 0x30)
struct UGameFrameworkComponentManager : UGameInstanceSubsystem {
	char pad_30[0x208]; // 0x30(0x208)

	void UnregisterClassInitStateDelegate(); // Function ModularGameplay.GameFrameworkComponentManager.UnregisterClassInitStateDelegate // (Final|Native|Public|BlueprintCallable) // @ game+0x7d69798
	void UnregisterActorInitStateDelegate(); // Function ModularGameplay.GameFrameworkComponentManager.UnregisterActorInitStateDelegate // (Final|Native|Public|BlueprintCallable) // @ game+0x7d693ec
	void SendExtensionEvent(); // Function ModularGameplay.GameFrameworkComponentManager.SendExtensionEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x7d68ff8
	void RemoveReceiver(); // Function ModularGameplay.GameFrameworkComponentManager.RemoveReceiver // (Final|Native|Public|BlueprintCallable) // @ game+0x7d68e80
	void RegisterAndCallForClassInitState(); // Function ModularGameplay.GameFrameworkComponentManager.RegisterAndCallForClassInitState // (Final|Native|Public|BlueprintCallable) // @ game+0x7d68058
	void RegisterAndCallForActorInitState(); // Function ModularGameplay.GameFrameworkComponentManager.RegisterAndCallForActorInitState // (Final|Native|Public|BlueprintCallable) // @ game+0x7d67890
	void AddReceiver(); // Function ModularGameplay.GameFrameworkComponentManager.AddReceiver // (Final|Native|Public|BlueprintCallable) // @ game+0x7d673f4
};

// Class ModularGameplay.GameFrameworkInitStateInterface
// Size: 0x28 (Inherited: 0x28)
struct UGameFrameworkInitStateInterface : UInterface {

	void UnregisterInitStateDelegate(); // Function ModularGameplay.GameFrameworkInitStateInterface.UnregisterInitStateDelegate // (Native|Public|BlueprintCallable) // @ game+0x7d69d60
	void RegisterAndCallForInitStateChange(); // Function ModularGameplay.GameFrameworkInitStateInterface.RegisterAndCallForInitStateChange // (Native|Public|BlueprintCallable) // @ game+0x7d68aac
	void HasReachedInitState(); // Function ModularGameplay.GameFrameworkInitStateInterface.HasReachedInitState // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d67710
	void GetInitState(); // Function ModularGameplay.GameFrameworkInitStateInterface.GetInitState // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d676e4
	void GetFeatureName(); // Function ModularGameplay.GameFrameworkInitStateInterface.GetFeatureName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d676b8
};

// Class ModularGameplay.GameStateComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UGameStateComponent : UGameFrameworkComponent {
};

// Class ModularGameplay.PawnComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UPawnComponent : UGameFrameworkComponent {
};

// Class ModularGameplay.PlayerStateComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerStateComponent : UGameFrameworkComponent {
};

