// Class MLDeformerFramework.MLDeformerAsset
// Size: 0x30 (Inherited: 0x28)
struct UMLDeformerAsset : UObject {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x00(0x38002000)
	 ; // 0x00(0x00)
};

// Class MLDeformerFramework.MLDeformerVizSettings
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerVizSettings : UObject {
};

// Class MLDeformerFramework.MLDeformerGeomCacheVizSettings
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerGeomCacheVizSettings : UMLDeformerVizSettings {
};

// Class MLDeformerFramework.MLDeformerMorphModelVizSettings
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerMorphModelVizSettings : UMLDeformerGeomCacheVizSettings {
};

// Class MLDeformerFramework.MLDeformerComponent
// Size: 0xe0 (Inherited: 0xa0)
struct UMLDeformerComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x201]; // 0x2c3(0x583c2810)
	 ; // 0x00(0x00)

	void UpdateSkeletalMeshComponent(); // Function MLDeformerFramework.MLDeformerComponent.UpdateSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xba49520
	void SetWeight(); // Function MLDeformerFramework.MLDeformerComponent.SetWeight // (Final|Native|Public|BlueprintCallable) // @ game+0x7fc2d84
	void SetDeformerAsset(); // Function MLDeformerFramework.MLDeformerComponent.SetDeformerAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x7a7faa8
	void GetWeight(); // Function MLDeformerFramework.MLDeformerComponent.GetWeight // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x86af1e0
	void GetSkeletalMeshComponent(); // Function MLDeformerFramework.MLDeformerComponent.GetSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x74b6d04
	void GetDeformerAsset(); // Function MLDeformerFramework.MLDeformerComponent.GetDeformerAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a8da8c
	void FindSkeletalMeshComponent(); // Function MLDeformerFramework.MLDeformerComponent.FindSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba48f60
};

// Class MLDeformerFramework.MLDeformerComponentSource
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerComponentSource : UOptimusComponentSource {
};

// Class MLDeformerFramework.MLDeformerModel
// Size: 0xe0 (Inherited: 0x28)
struct UMLDeformerModel : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	int32_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000200]; // 0x2c3(0x90002000)
	 ; // 0x00(0x00)
};

// Class MLDeformerFramework.MLDeformerGeomCacheModel
// Size: 0xe0 (Inherited: 0xe0)
struct UMLDeformerGeomCacheModel : UMLDeformerModel {
};

// Class MLDeformerFramework.MLDeformerGraphDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerGraphDataInterface : UOptimusComputeDataInterface {
};

// Class MLDeformerFramework.MLDeformerGraphDataProvider
// Size: 0x30 (Inherited: 0x28)
struct UMLDeformerGraphDataProvider : UComputeDataProvider {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8020d]; // 0x00(0x39ec20d0)
	 ; // 0x00(0x00)
};

// Class MLDeformerFramework.MLDeformerGraphDebugDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerGraphDebugDataInterface : UOptimusComputeDataInterface {
};

// Class MLDeformerFramework.MLDeformerGraphDebugDataProvider
// Size: 0x38 (Inherited: 0x28)
struct UMLDeformerGraphDebugDataProvider : UComputeDataProvider {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8020d]; // 0x2c3(0x39ec20d0)
	 ; // 0x00(0x00)
};

// Class MLDeformerFramework.MLDeformerInputInfo
// Size: 0x68 (Inherited: 0x28)
struct UMLDeformerInputInfo : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x50100000)
	 ; // 0x00(0x00)
};

// Class MLDeformerFramework.MLDeformerModelInstance
// Size: 0x90 (Inherited: 0x28)
struct UMLDeformerModelInstance : UObject {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2200]; // 0x00(0xd9122000)
	 ; // 0x00(0x00)
};

// Class MLDeformerFramework.MLDeformerMorphModel
// Size: 0x110 (Inherited: 0xe0)
struct UMLDeformerMorphModel : UMLDeformerGeomCacheModel {
	char pad_E0[0x1e3]; // 0xe0(0x1e3)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x90482010)
	 ; // 0x00(0x00)

	void SetMorphTargetDeltas(); // Function MLDeformerFramework.MLDeformerMorphModel.SetMorphTargetDeltas // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba493cc
	void SetMorphTargetDeltaFloats(); // Function MLDeformerFramework.MLDeformerMorphModel.SetMorphTargetDeltaFloats // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba49278
};

// Class MLDeformerFramework.MLDeformerMorphModelInstance
// Size: 0x98 (Inherited: 0x90)
struct UMLDeformerMorphModelInstance : UMLDeformerModelInstance {
	char pad_90[0x8]; // 0x90(0x08)
};

// Class MLDeformerFramework.MLDeformerTestModel
// Size: 0xe0 (Inherited: 0xe0)
struct UMLDeformerTestModel : UMLDeformerModel {
};

// Class MLDeformerFramework.TestModelInstance
// Size: 0x90 (Inherited: 0x90)
struct UTestModelInstance : UMLDeformerModelInstance {
};

