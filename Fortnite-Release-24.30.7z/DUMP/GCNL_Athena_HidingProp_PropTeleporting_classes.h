// BlueprintGeneratedClass GCNL_Athena_HidingProp_PropTeleporting.GCNL_Athena_HidingProp_PropTeleporting_C
// Size: 0x968 (Inherited: 0x960)
struct AGCNL_Athena_HidingProp_PropTeleporting_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x8]; // 0x960(0x08)

	void ReceiveBeginPlay(); // Function GCNL_Athena_HidingProp_PropTeleporting.GCNL_Athena_HidingProp_PropTeleporting_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_Athena_HidingProp_PropTeleporting(); // Function GCNL_Athena_HidingProp_PropTeleporting.GCNL_Athena_HidingProp_PropTeleporting_C.ExecuteUbergraph_GCNL_Athena_HidingProp_PropTeleporting // (Final|UbergraphFunction) // @ game+0x179ea74
};

