// BlueprintGeneratedClass UIManager_Startup.UIManager_Startup_C
// Size: 0x220 (Inherited: 0x220)
struct UUIManager_Startup_C : UFortUIManager_Startup {
};

