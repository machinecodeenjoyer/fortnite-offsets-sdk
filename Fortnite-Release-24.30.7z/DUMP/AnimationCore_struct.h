// Enum AnimationCore.EConstraintType
enum class EConstraintType : uint8 {
	Transform = 0,
	Aim = 1,
	MAX = 2
};

// Enum AnimationCore.ETransformConstraintType
enum class ETransformConstraintType : uint8 {
	Translation = 0,
	Rotation = 1,
	Scale = 2,
	Parent = 3,
	LookAt = 4,
	ETransformConstraintType_MAX = 5
};

// Enum AnimationCore.EEulerRotationOrder
enum class EEulerRotationOrder : uint8 {
	XYZ = 0,
	XZY = 1,
	YXZ = 2,
	YZX = 3,
	ZXY = 4,
	ZYX = 5,
	EEulerRotationOrder_MAX = 6
};

// ScriptStruct AnimationCore.Axis
// Size: 0x20 (Inherited: 0x00)
struct FAxis {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x30182010)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.NodeChain
// Size: 0x10 (Inherited: 0x00)
struct FNodeChain {
	struct TArray<struct FName>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x00(0x20000000)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.NodeObject
// Size: 0x08 (Inherited: 0x00)
struct FNodeObject {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000200]; // 0x2c3(0x30002000)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.NodeHierarchyData
// Size: 0x70 (Inherited: 0x00)
struct FNodeHierarchyData {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x20000000)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.NodeHierarchyWithUserData
// Size: 0x78 (Inherited: 0x00)
struct FNodeHierarchyWithUserData {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct AnimationCore.CCDIKChainLink
// Size: 0xe0 (Inherited: 0x00)
struct FCCDIKChainLink {
	char pad_0[0xe0]; // 0x00(0xe0)
};

// ScriptStruct AnimationCore.FilterOptionPerAxis
// Size: 0x03 (Inherited: 0x00)
struct FFilterOptionPerAxis {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.TransformFilter
// Size: 0x09 (Inherited: 0x00)
struct FTransformFilter {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500050)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.ConstraintDescription
// Size: 0x0d (Inherited: 0x00)
struct FConstraintDescription {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.ConstraintOffset
// Size: 0xc0 (Inherited: 0x00)
struct FConstraintOffset {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000200]; // 0x2c3(0x30002000)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.TransformConstraint
// Size: 0x20 (Inherited: 0x00)
struct FTransformConstraint {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500050)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.ConstraintDescriptionEx
// Size: 0x10 (Inherited: 0x00)
struct FConstraintDescriptionEx {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x00(0x100010)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.TransformConstraintDescription
// Size: 0x18 (Inherited: 0x10)
struct FTransformConstraintDescription : FConstraintDescriptionEx {
	char pad_10[0x2b3]; // 0x10(0x2b3)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x30182010)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.AimConstraintDescription
// Size: 0x70 (Inherited: 0x10)
struct FAimConstraintDescription : FConstraintDescriptionEx {
	char pad_10[0x2b3]; // 0x10(0x2b3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x100010)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.ConstraintDescriptor
// Size: 0x10 (Inherited: 0x00)
struct FConstraintDescriptor {
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000200]; // 0x00(0x30002000)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.ConstraintData
// Size: 0xe0 (Inherited: 0x00)
struct FConstraintData {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0xe0]; // 0x00(0xe0)
};

// ScriptStruct AnimationCore.EulerTransform
// Size: 0x48 (Inherited: 0x00)
struct FEulerTransform {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

// ScriptStruct AnimationCore.FABRIKChainLink
// Size: 0x50 (Inherited: 0x00)
struct FFABRIKChainLink {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct AnimationCore.TransformNoScale
// Size: 0x40 (Inherited: 0x00)
struct FTransformNoScale {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

