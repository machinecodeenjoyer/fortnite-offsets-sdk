// Class DeveloperSettings.DeveloperSettings
// Size: 0x30 (Inherited: 0x28)
struct UDeveloperSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class DeveloperSettings.DeveloperSettingsBackedByCVars
// Size: 0x30 (Inherited: 0x30)
struct UDeveloperSettingsBackedByCVars : UDeveloperSettings {
};

// Class DeveloperSettings.PlatformSettings
// Size: 0x40 (Inherited: 0x28)
struct UPlatformSettings : UObject {
	char pad_28[0x18]; // 0x28(0x18)
};

// Class DeveloperSettings.PlatformSettingsManager
// Size: 0x80 (Inherited: 0x28)
struct UPlatformSettingsManager : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x58]; // 0x28(0x58)
};

