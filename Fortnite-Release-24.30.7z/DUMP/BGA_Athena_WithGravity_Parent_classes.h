// BlueprintGeneratedClass BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C
// Size: 0xcc9 (Inherited: 0xa10)
struct ABGA_Athena_WithGravity_Parent_C : ABuildingGameplayActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A10[0x2b9]; // 0xa10(0x2b9)

	void BounceBGAAwayFromLocation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BounceBGAAwayFromLocation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_StopSimServerLocation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnRep_StopSimServerLocation // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_StopLocation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnRep_StopLocation // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Init(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.Init // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnAttach(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnAttach // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void RestartSimulation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.RestartSimulation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttachToBindedActor(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.AttachToBindedActor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BounceBGA(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BounceBGA // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CheckForSameClassToBounce(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.CheckForSameClassToBounce // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_RepCollision(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnRep_RepCollision // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ForceBounceBGA(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ForceBounceBGA // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_bResumeSimulation(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnRep_bResumeSimulation // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BaseDestroyed(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BaseDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BaseDied(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.BaseDied // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void HandleBinding(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.HandleBinding // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveHit(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void StopSim(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.StopSim // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveBeginPlay(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void Impulse(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.Impulse // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PlayHitFX(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.PlayHitFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SpawnFXSounds(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.SpawnFXSounds // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttachedWasDestroyed(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.AttachedWasDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SlidingDoorOpened(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.SlidingDoorOpened // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnUnderneathPhysicsObjectAwakeChanged(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.OnUnderneathPhysicsObjectAwakeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_BGA_Athena_WithGravity_Parent(); // Function BGA_Athena_WithGravity_Parent.BGA_Athena_WithGravity_Parent_C.ExecuteUbergraph_BGA_Athena_WithGravity_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

