// Enum CommonConversationRuntime.EConversationTaskResultType
enum class EConversationTaskResultType : uint8 {
	Invalid = 0,
	AbortConversation = 1,
	AdvanceConversation = 2,
	AdvanceConversationWithChoice = 3,
	PauseConversationAndSendClientChoices = 4,
	ReturnToLastClientChoice = 5,
	ReturnToCurrentClientChoice = 6,
	ReturnToConversationStart = 7,
	EConversationTaskResultType_MAX = 8
};

// Enum CommonConversationRuntime.EConversationRequirementResult
enum class EConversationRequirementResult : uint8 {
	Passed = 0,
	FailedButVisible = 1,
	FailedAndHidden = 2,
	EConversationRequirementResult_MAX = 3
};

// Enum CommonConversationRuntime.EConversationChoiceType
enum class EConversationChoiceType : uint8 {
	ServerOnly = 0,
	UserChoiceAvailable = 1,
	UserChoiceUnavailable = 2,
	EConversationChoiceType_MAX = 3
};

// ScriptStruct CommonConversationRuntime.ClientConversationMessagePayload
// Size: 0x78 (Inherited: 0x00)
struct FClientConversationMessagePayload {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4]; // 0x2c3(0x400000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ClientConversationOptionEntry
// Size: 0x70 (Inherited: 0x00)
struct FClientConversationOptionEntry {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FText  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4]; // 0x2c3(0x400000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationNodeParameterPair
// Size: 0x20 (Inherited: 0x00)
struct FConversationNodeParameterPair {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FString  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x205]; // 0x2c3(0x30780000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationChoiceReference
// Size: 0x20 (Inherited: 0x00)
struct FConversationChoiceReference {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4]; // 0x2c3(0x400040)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationNodeHandle
// Size: 0x10 (Inherited: 0x00)
struct FConversationNodeHandle {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x00(0x30182010)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationParticipants
// Size: 0x10 (Inherited: 0x00)
struct FConversationParticipants {
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x204]; // 0x00(0x20400000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationParticipantEntry
// Size: 0x10 (Inherited: 0x00)
struct FConversationParticipantEntry {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x204]; // 0x2c3(0x38702040)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ClientConversationMessage
// Size: 0x48 (Inherited: 0x00)
struct FClientConversationMessage {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4]; // 0x2c3(0x600040)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationTaskResult
// Size: 0x80 (Inherited: 0x00)
struct FConversationTaskResult {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000200]; // 0x2c3(0x90002000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.AdvanceConversationRequest
// Size: 0x30 (Inherited: 0x00)
struct FAdvanceConversationRequest {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4]; // 0x2c3(0x400000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationContext
// Size: 0x38 (Inherited: 0x00)
struct FConversationContext {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x98002000)
	 ; // 0x00(0x00)
};

// ScriptStruct CommonConversationRuntime.ConversationEntryList
// Size: 0x18 (Inherited: 0x00)
struct FConversationEntryList {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct CommonConversationRuntime.CommonDialogueBankParticipant
// Size: 0x30 (Inherited: 0x00)
struct FCommonDialogueBankParticipant {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct CommonConversationRuntime.NetSerializeScriptStructCache_ConvVersion
// Size: 0x60 (Inherited: 0x00)
struct FNetSerializeScriptStructCache_ConvVersion {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0x60]; // 0x00(0x60)
};

// ScriptStruct CommonConversationRuntime.ConversationChoiceData
// Size: 0x08 (Inherited: 0x00)
struct FConversationChoiceData {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct CommonConversationRuntime.ConversationChoiceDataHandle
// Size: 0x20 (Inherited: 0x00)
struct FConversationChoiceDataHandle {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct CommonConversationRuntime.ConversationBranchPoint
// Size: 0x80 (Inherited: 0x00)
struct FConversationBranchPoint {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x20000000)
	 ; // 0x00(0x00)
};

