// WidgetBlueprintGeneratedClass RedeemFriendCodeWindow.RedeemFriendCodeWindow_C
// Size: 0x5b8 (Inherited: 0x550)
struct URedeemFriendCodeWindow_C : UFortRedeemCodeBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_550[0x68]; // 0x550(0x68)

	void HandleRedeemCodeComplete(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.HandleRedeemCodeComplete // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Close(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.Close // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__CancelButton_K2Node_ComponentBoundEvent_57_CommonButtonClicked__DelegateSignature(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.BndEvt__CancelButton_K2Node_ComponentBoundEvent_57_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BndEvt__SendButton_K2Node_ComponentBoundEvent_75_CommonButtonClicked__DelegateSignature(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.BndEvt__SendButton_K2Node_ComponentBoundEvent_75_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void OnRedeemFriendCodeComplete(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.OnRedeemFriendCodeComplete // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__FriendCodeEntry_K2Node_ComponentBoundEvent_0_OnEditableTextChangedEvent__DelegateSignature(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.BndEvt__FriendCodeEntry_K2Node_ComponentBoundEvent_0_OnEditableTextChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__Button_Cancel_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.BndEvt__Button_Cancel_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_RedeemFriendCodeWindow(); // Function RedeemFriendCodeWindow.RedeemFriendCodeWindow_C.ExecuteUbergraph_RedeemFriendCodeWindow // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

