// BlueprintGeneratedClass ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C
// Size: 0x408 (Inherited: 0x298)
struct AThreatPostProcessManagerAndParticleBlueprint_C : AFortThreatParticleActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x170]; // 0x298(0x170)

	void SetForceOff(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.SetForceOff // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CalculatePlayerPositionNearBox(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.CalculatePlayerPositionNearBox // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Ramp Up down values on death__FinishedFunc(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.Ramp Up down values on death__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void Ramp Up down values on death__UpdateFunc(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.Ramp Up down values on death__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void ReceiveTick(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnThreatCloudsChanged(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.OnThreatCloudsChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnWorldReady(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.OnWorldReady // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void VFX_RainTracePeriodic(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.VFX_RainTracePeriodic // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void StartTraceTimer(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.StartTraceTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ForceUpdateLensEffect(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.ForceUpdateLensEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnThreatOverrideChanged(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.OnThreatOverrideChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_ThreatPostProcessManagerAndParticleBlueprint(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.ExecuteUbergraph_ThreatPostProcessManagerAndParticleBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
	void NewEventDispatcher0__DelegateSignature(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.NewEventDispatcher0__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NewEventDispatcher__DelegateSignature(); // Function ThreatPostProcessManagerAndParticleBlueprint.ThreatPostProcessManagerAndParticleBlueprint_C.NewEventDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

