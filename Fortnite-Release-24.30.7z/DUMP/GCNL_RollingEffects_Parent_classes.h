// BlueprintGeneratedClass GCNL_RollingEffects_Parent.GCNL_RollingEffects_Parent_C
// Size: 0xae8 (Inherited: 0xac0)
struct AGCNL_RollingEffects_Parent_C : AFortGameplayCueNotifyLoop_PhysicsObjectRolling {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_AC0[0x28]; // 0xac0(0x28)

	void GetObjectSizeParam(); // Function GCNL_RollingEffects_Parent.GCNL_RollingEffects_Parent_C.GetObjectSizeParam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void GetSoundAsset(); // Function GCNL_RollingEffects_Parent.GCNL_RollingEffects_Parent_C.GetSoundAsset // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void OnApplicationGeneric(); // Function GCNL_RollingEffects_Parent.GCNL_RollingEffects_Parent_C.OnApplicationGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCNL_RollingEffects_Parent.GCNL_RollingEffects_Parent_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_RollingEffects_Parent(); // Function GCNL_RollingEffects_Parent.GCNL_RollingEffects_Parent_C.ExecuteUbergraph_GCNL_RollingEffects_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

