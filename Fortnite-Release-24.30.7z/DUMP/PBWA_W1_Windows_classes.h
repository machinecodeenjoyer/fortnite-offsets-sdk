// BlueprintGeneratedClass PBWA_W1_Windows.PBWA_W1_Windows_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_W1_Windows_C : ABuildingWall {
};

