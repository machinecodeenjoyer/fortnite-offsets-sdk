// Class MusicBlocks.MusicSequencerHitComponent
// Size: 0x1e0 (Inherited: 0xa0)
struct UMusicSequencerHitComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2020]; // 0x2c3(0x5111000)
	 ; // 0x00(0x00)

	void ReplicateMusicSequencerHit(); // Function MusicBlocks.MusicSequencerHitComponent.ReplicateMusicSequencerHit // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0xb2bf0c4
	void RegisterMusicSequencerActor(); // Function MusicBlocks.MusicSequencerHitComponent.RegisterMusicSequencerActor // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0xb2bee24
	void ProcessSequenceHitEvent(); // Function MusicBlocks.MusicSequencerHitComponent.ProcessSequenceHitEvent // (Final|Native|Protected|HasOutParms) // @ game+0xb2bed38
	void OnSequenceHitEventExpired(); // Function MusicBlocks.MusicSequencerHitComponent.OnSequenceHitEventExpired // (Final|Native|Protected) // @ game+0xb2bebc8
	void AddSequenceHitEvent(); // Function MusicBlocks.MusicSequencerHitComponent.AddSequenceHitEvent // (Final|Native|Protected) // @ game+0xb2be920
	void AddMusicSequencerActor(); // Function MusicBlocks.MusicSequencerHitComponent.AddMusicSequencerActor // (Final|Native|Protected) // @ game+0xb2be790
};

// Class MusicBlocks.MusicSequencerHitActor
// Size: 0x290 (Inherited: 0x288)
struct AMusicSequencerHitActor : AActor {
	char pad_288[0x3b]; // 0x288(0x3b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0xb0209]; // 0x2c3(0xaa286890)
	 ; // 0x00(0x00)

	void GetMusicSequencerHitComponent(); // Function MusicBlocks.MusicSequencerHitActor.GetMusicSequencerHitComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x71dfa9c
};

// Class MusicBlocks.MusicSequencerHitAdderComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UMusicSequencerHitAdderComponent : UPlayspaceComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x604c2810)
	 ; // 0x00(0x00)

	void GetMusicSequencerHitActor(); // Function MusicBlocks.MusicSequencerHitAdderComponent.GetMusicSequencerHitActor // (Final|Native|Public|Const) // @ game+0x25586d8
};

