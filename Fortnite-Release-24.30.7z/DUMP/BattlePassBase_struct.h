// Enum BattlePassBase.EBattlePassLandingPageSpecialEntryType
enum class EBattlePassLandingPageSpecialEntryType : uint8 {
	None = 0,
	Subscription = 1,
	CharacterCustomizer = 2,
	SpecialCharacter = 3,
	Weekly = 4,
	COUNT = 5,
	EBattlePassLandingPageSpecialEntryType_MAX = 6
};

// Enum BattlePassBase.FBattlePassLandingPageButtonDisplayBehavior
enum class FBattlePassLandingPageButtonDisplayBehavior : uint8 {
	None = 0,
	MainRewards = 1,
	BonusRewards = 2,
	WeeklyRewards = 3,
	QuestRewards = 4,
	Subscription = 5,
	Customization = 6,
	FBattlePassLandingPageButtonDisplayBehavior_MAX = 7
};

// Enum BattlePassBase.BattlePassTileAvailabilityStates
enum class BattlePassTileAvailabilityStates : uint8 {
	Invalid = 0,
	Available = 1,
	Owned = 2,
	Locked = 3,
	BattlePassTileAvailabilityStates_MAX = 4
};

// ScriptStruct BattlePassBase.BattlePassEntrySelectedParams
// Size: 0x58 (Inherited: 0x00)
struct FBattlePassEntrySelectedParams {
	char pad_0[0x58]; // 0x00(0x58)
};

// ScriptStruct BattlePassBase.BattlePassCoverPageParams
// Size: 0x48 (Inherited: 0x00)
struct FBattlePassCoverPageParams {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct BattlePassBase.BattlePassLandingPageButtonTexts
// Size: 0x48 (Inherited: 0x00)
struct FBattlePassLandingPageButtonTexts {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FText  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x2c3(0x1500000)
	 ; // 0x00(0x00)
};

// ScriptStruct BattlePassBase.BattlePassLandingPageButtonDisplayBehaviorData
// Size: 0x18 (Inherited: 0x00)
struct FBattlePassLandingPageButtonDisplayBehaviorData {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x2c3(0x31f82150)
	 ; // 0x00(0x00)
};

// ScriptStruct BattlePassBase.BattlePassLandingPageButtonDisplayDetails
// Size: 0x70 (Inherited: 0x00)
struct FBattlePassLandingPageButtonDisplayDetails {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x2c3(0x1500000)
	 ; // 0x00(0x00)
};

// ScriptStruct BattlePassBase.BattlePassLandingPageEntryPreviewInfo
// Size: 0x90 (Inherited: 0x00)
struct FBattlePassLandingPageEntryPreviewInfo {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x2c3(0x31f82150)
	 ; // 0x00(0x00)
};

// ScriptStruct BattlePassBase.SeasonalResourceList
// Size: 0x10 (Inherited: 0x00)
struct FSeasonalResourceList {
	struct TArray<struct FNone*>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x00(0x28000000)
	 ; // 0x00(0x00)
};

