// Enum HmxUtl.EPointerValidity
enum class EPointerValidity : uint8 {
	Valid = 0,
	Null = 1,
	EPointerValidity_MAX = 2
};

// Enum HmxUtl.EResult
enum class EResult : uint8 {
	Success = 0,
	Failure = 1,
	EResult_MAX = 2
};

