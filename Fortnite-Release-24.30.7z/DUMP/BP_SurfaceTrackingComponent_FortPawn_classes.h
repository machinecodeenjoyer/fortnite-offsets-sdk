// BlueprintGeneratedClass BP_SurfaceTrackingComponent_FortPawn.BP_SurfaceTrackingComponent_FortPawn_C
// Size: 0x180 (Inherited: 0x180)
struct UBP_SurfaceTrackingComponent_FortPawn_C : UFortSurfaceTrackingComponent {
};

