// BlueprintGeneratedClass Athena_PlayerCameraHoisted.Athena_PlayerCameraHoisted_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct UAthena_PlayerCameraHoisted_C : UAthena_PlayerCameraModeBase_C {
};

