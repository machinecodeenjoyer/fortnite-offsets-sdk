// BlueprintGeneratedClass GA_Riding_Creature_Burt_SprintCharge.GA_Riding_Creature_Burt_SprintCharge_C
// Size: 0xb30 (Inherited: 0xb28)
struct UGA_Riding_Creature_Burt_SprintCharge_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x8]; // 0xb28(0x08)

	void K2_ActivateAbility(); // Function GA_Riding_Creature_Burt_SprintCharge.GA_Riding_Creature_Burt_SprintCharge_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Riding_Creature_Burt_SprintCharge.GA_Riding_Creature_Burt_SprintCharge_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void FailedToActivatePassiveAbility(); // Function GA_Riding_Creature_Burt_SprintCharge.GA_Riding_Creature_Burt_SprintCharge_C.FailedToActivatePassiveAbility // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Riding_Creature_Burt_SprintCharge(); // Function GA_Riding_Creature_Burt_SprintCharge.GA_Riding_Creature_Burt_SprintCharge_C.ExecuteUbergraph_GA_Riding_Creature_Burt_SprintCharge // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

