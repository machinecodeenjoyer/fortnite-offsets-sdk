// BlueprintGeneratedClass GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C
// Size: 0xfa8 (Inherited: 0xb28)
struct UGA_Athena_Consumable_Throw_Parent_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x480]; // 0xb28(0x480)

	void ShouldOnlyShowTrajectoryOnUse(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.ShouldOnlyShowTrajectoryOnUse // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void SpawnTrajectoryIndicator(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.SpawnTrajectoryIndicator // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetProjectileTrajectoryActor(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetProjectileTrajectoryActor // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void GetProjectileTrajectoryPoints(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetProjectileTrajectoryPoints // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void CalculateProjectileTrajectory(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.CalculateProjectileTrajectory // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void K2_CanActivateAbility(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void IsTrajectoryLocationValid(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.IsTrajectoryLocationValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void OnUpdateTrajectory(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnUpdateTrajectory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AddValidCamera(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.AddValidCamera // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetOwningPlayer(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetOwningPlayer // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void ExecuteThrowGC(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.ExecuteThrowGC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_OverrideFailedReason(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.K2_OverrideFailedReason // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void RemoveCookGC(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.RemoveCookGC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AddCookGC(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.AddCookGC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetProjectileAdditionalThrowAngleToUse(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetProjectileAdditionalThrowAngleToUse // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void GetProjectileInitialGravityScaleToUse(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetProjectileInitialGravityScaleToUse // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void GetProjectileInitialSpeedToUse(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetProjectileInitialSpeedToUse // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void CleanupTrajectory(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.CleanupTrajectory // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PostThrowCleanup(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.PostThrowCleanup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateTrajectorySpline(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.UpdateTrajectorySpline // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetupDummyProjectile(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.SetupDummyProjectile // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnProjectileSpawned(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnProjectileSpawned // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SpawnThrownProjectile(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.SpawnThrownProjectile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnProjectileSetup(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnProjectileSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetSpawnLocationAndRotation(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.GetSpawnLocationAndRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void PrethrowSetup(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.PrethrowSetup // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnFinish_96367E244486362FDDE5ED87D909C17B(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnFinish_96367E244486362FDDE5ED87D909C17B // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Completed_01C5B37D48E3DC6F82DDC58640CE2A27(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.Completed_01C5B37D48E3DC6F82DDC58640CE2A27 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Cancelled_01C5B37D48E3DC6F82DDC58640CE2A27(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.Cancelled_01C5B37D48E3DC6F82DDC58640CE2A27 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Triggered_01C5B37D48E3DC6F82DDC58640CE2A27(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.Triggered_01C5B37D48E3DC6F82DDC58640CE2A27 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRelease_76BCD7D74FEC0FB6EFBBDFB57A0107B0(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnRelease_76BCD7D74FEC0FB6EFBBDFB57A0107B0 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCancelled_D89CCB8E47DB19D6DCF41F96F207CC3D(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnCancelled_D89CCB8E47DB19D6DCF41F96F207CC3D // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnInterrupted_D89CCB8E47DB19D6DCF41F96F207CC3D(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnInterrupted_D89CCB8E47DB19D6DCF41F96F207CC3D // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBlendOut_D89CCB8E47DB19D6DCF41F96F207CC3D(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnBlendOut_D89CCB8E47DB19D6DCF41F96F207CC3D // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCompleted_D89CCB8E47DB19D6DCF41F96F207CC3D(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnCompleted_D89CCB8E47DB19D6DCF41F96F207CC3D // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void EventReceived_E3F1B58D4D7A664CB557709F9DAE3C9F(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.EventReceived_E3F1B58D4D7A664CB557709F9DAE3C9F // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnSync_9C8FDC8044B1444580A9809C231F294D(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnSync_9C8FDC8044B1444580A9809C231F294D // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void EventReceived_05B8BFFC4ECA26FE5390E9BC303AACA6(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.EventReceived_05B8BFFC4ECA26FE5390E9BC303AACA6 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttemptSpawnThrownProjectile(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.AttemptSpawnThrownProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void InitTrajectoryVariables(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.InitTrajectoryVariables // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ThrowProjectile(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.ThrowProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ThrowMontageStarted(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.ThrowMontageStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnAbilityInputReleased(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnAbilityInputReleased // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void UpdateTrajectory(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.UpdateTrajectory // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CleanupTrajectoryIndicatorOnUnequip(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.CleanupTrajectoryIndicatorOnUnequip // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Athena_Consumable_Throw_Parent(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.ExecuteUbergraph_GA_Athena_Consumable_Throw_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
	void OnProjectileSpawn__DelegateSignature(); // Function GA_Athena_Consumable_Throw_Parent.GA_Athena_Consumable_Throw_Parent_C.OnProjectileSpawn__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

