// Class SrirachaRanchUI.FortMobileActionButtonBehavior_ToggleRadio
// Size: 0x120 (Inherited: 0x110)
struct UFortMobileActionButtonBehavior_ToggleRadio : UFortMobileActionButtonBehavior {
	char pad_110[0x1b3]; // 0x110(0x1b3)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x985c2010)
	 ; // 0x00(0x00)

	void HandleRadioStopped(); // Function SrirachaRanchUI.FortMobileActionButtonBehavior_ToggleRadio.HandleRadioStopped // (Final|Native|Private) // @ game+0xb11fb94
	void HandleRadioPlaying(); // Function SrirachaRanchUI.FortMobileActionButtonBehavior_ToggleRadio.HandleRadioPlaying // (Final|Native|Private) // @ game+0xb11f8c8
};

// Class SrirachaRanchUI.RadioPlayerWidgetBase
// Size: 0x350 (Inherited: 0x300)
struct URadioPlayerWidgetBase : UFortHUDElementWidget {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x200810)
	 ; // 0x00(0x00)

	void SetControllable(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.SetControllable // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSourcePlaying(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnSourcePlaying // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSourceFinished(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnSourceFinished // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnShouldShowDueToEntrance(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnShouldShowDueToEntrance // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnRadioStopped(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnRadioStopped // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnLoadingNewSource(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnLoadingNewSource // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnFailedToOpenSource(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnFailedToOpenSource // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnDisconnectFromComp(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnDisconnectFromComp // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnControllerGainedNewFortPawn(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.OnControllerGainedNewFortPawn // (Final|Native|Protected) // @ game+0xb11fe80
	void NativeExitedVehicle(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.NativeExitedVehicle // (Final|Native|Protected) // @ game+0xb11fe6c
	void NativeEnteredVehicle(); // Function SrirachaRanchUI.RadioPlayerWidgetBase.NativeEnteredVehicle // (Final|Native|Protected) // @ game+0xb11fe58
};

