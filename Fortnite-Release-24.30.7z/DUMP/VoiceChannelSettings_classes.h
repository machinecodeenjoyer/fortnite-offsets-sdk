// WidgetBlueprintGeneratedClass VoiceChannelSettings.VoiceChannelSettings_C
// Size: 0x3e0 (Inherited: 0x360)
struct UVoiceChannelSettings_C : UFortVoiceSettingsDisplay {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_360[0x80]; // 0x360(0x80)

	void BndEvt__Button_GearIcon_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(); // Function VoiceChannelSettings.VoiceChannelSettings_C.BndEvt__Button_GearIcon_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BndEvt__Button_OpenSettings_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature(); // Function VoiceChannelSettings.VoiceChannelSettings_C.BndEvt__Button_OpenSettings_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BndEvt__Button_GearIcon_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(); // Function VoiceChannelSettings.VoiceChannelSettings_C.BndEvt__Button_GearIcon_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_VoiceChannelSettings(); // Function VoiceChannelSettings.VoiceChannelSettings_C.ExecuteUbergraph_VoiceChannelSettings // (Final|UbergraphFunction) // @ game+0x179ea74
};

