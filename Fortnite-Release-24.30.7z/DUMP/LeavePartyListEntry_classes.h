// WidgetBlueprintGeneratedClass LeavePartyListEntry.LeavePartyListEntry_C
// Size: 0x14d8 (Inherited: 0x1490)
struct ULeavePartyListEntry_C : UFortLeavePartyListEntry {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1490[0x48]; // 0x1490(0x48)

	void BP_OnUnhovered(); // Function LeavePartyListEntry.LeavePartyListEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(); // Function LeavePartyListEntry.LeavePartyListEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function LeavePartyListEntry.LeavePartyListEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_LeavePartyListEntry(); // Function LeavePartyListEntry.LeavePartyListEntry_C.ExecuteUbergraph_LeavePartyListEntry // (Final|UbergraphFunction) // @ game+0x179ea74
};

