// BlueprintGeneratedClass BP_VendAISpawner_Base.BP_VendAISpawner_Base_C
// Size: 0x2b0 (Inherited: 0x288)
struct ABP_VendAISpawner_Base_C : AActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_288[0x28]; // 0x288(0x28)

	void ReceiveBeginPlay(); // Function BP_VendAISpawner_Base.BP_VendAISpawner_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_BP_VendAISpawner_Base(); // Function BP_VendAISpawner_Base.BP_VendAISpawner_Base_C.ExecuteUbergraph_BP_VendAISpawner_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

