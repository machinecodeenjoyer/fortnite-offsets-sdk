// BlueprintGeneratedClass GE_Riding_Creatue_IsBeingRidden_Passive.GE_Riding_Creatue_IsBeingRidden_Passive_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Riding_Creatue_IsBeingRidden_Passive_C : UGameplayEffect {
};

