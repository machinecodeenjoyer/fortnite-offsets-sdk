// BlueprintGeneratedClass GCN_Athena_Bush.GCN_Athena_Bush_C
// Size: 0x9f0 (Inherited: 0x960)
struct AGCN_Athena_Bush_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x90]; // 0x960(0x90)

	void OpacityFade__FinishedFunc(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.OpacityFade__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void OpacityFade__UpdateFunc(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.OpacityFade__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void On Player Step(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.On Player Step // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStart(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.OnLoopingStart // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemoval(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.OnRemoval // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ReceiveTick(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_Athena_Bush(); // Function GCN_Athena_Bush.GCN_Athena_Bush_C.ExecuteUbergraph_GCN_Athena_Bush // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

