// BlueprintGeneratedClass PlayerCameraMode1P.PlayerCameraMode1P_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct UPlayerCameraMode1P_C : UFortCameraMode_ThirdPerson {
};

