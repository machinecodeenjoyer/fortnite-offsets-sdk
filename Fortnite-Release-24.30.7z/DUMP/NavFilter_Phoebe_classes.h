// BlueprintGeneratedClass NavFilter_Phoebe.NavFilter_Phoebe_C
// Size: 0x48 (Inherited: 0x48)
struct UNavFilter_Phoebe_C : UNavigationQueryFilter {
};

