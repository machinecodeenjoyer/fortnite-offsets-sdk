// BlueprintGeneratedClass GCN_Athena_Consumable_Throw_Generic.GCN_Athena_Consumable_Throw_Generic_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Athena_Consumable_Throw_Generic_C : UFortGameplayCueNotify_Burst {
};

