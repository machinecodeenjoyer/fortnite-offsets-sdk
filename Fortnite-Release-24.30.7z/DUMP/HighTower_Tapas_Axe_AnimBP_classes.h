// AnimBlueprintGeneratedClass HighTower_Tapas_Axe_AnimBP.HighTower_Tapas_Axe_AnimBP_C
// Size: 0x1c40 (Inherited: 0x700)
struct UHighTower_Tapas_Axe_AnimBP_C : UCustomCharacterPartAnimInstance_HightowerTapasAxe {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_700[0x1540]; // 0x700(0x1540)

	void AnimGraph(); // Function HighTower_Tapas_Axe_AnimBP.HighTower_Tapas_Axe_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_HighTower_Tapas_Axe_AnimBP(); // Function HighTower_Tapas_Axe_AnimBP.HighTower_Tapas_Axe_AnimBP_C.ExecuteUbergraph_HighTower_Tapas_Axe_AnimBP // (Final|UbergraphFunction) // @ game+0x179ea74
};

