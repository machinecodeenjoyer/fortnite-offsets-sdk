// BlueprintGeneratedClass GCN_CollisionEffects_Metal.GCN_CollisionEffects_Metal_C
// Size: 0x368 (Inherited: 0x368)
struct UGCN_CollisionEffects_Metal_C : UGCN_CollisionEffects_Parent_C {
};

