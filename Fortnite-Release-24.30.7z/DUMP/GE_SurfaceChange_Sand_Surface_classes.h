// BlueprintGeneratedClass GE_SurfaceChange_Sand_Surface.GE_SurfaceChange_Sand_Surface_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_SurfaceChange_Sand_Surface_C : UGameplayEffect {
};

