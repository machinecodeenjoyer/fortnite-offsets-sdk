// BlueprintGeneratedClass v2_PlayerCameraModeRanged.v2_PlayerCameraModeRanged_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct Uv2_PlayerCameraModeRanged_C : Uv2_PlayerCameraModeBase_C {
};

