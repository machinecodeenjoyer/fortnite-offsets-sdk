// BlueprintGeneratedClass BP_DetailLevelMesh.BP_DetailLevelMesh_C
// Size: 0x2a2 (Inherited: 0x288)
struct ABP_DetailLevelMesh_C : AActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_288[0x1a]; // 0x288(0x1a)

	void ExecuteUbergraph_BP_DetailLevelMesh(); // Function BP_DetailLevelMesh.BP_DetailLevelMesh_C.ExecuteUbergraph_BP_DetailLevelMesh // (Final|UbergraphFunction) // @ game+0x179ea74
};

