// WidgetBlueprintGeneratedClass UserActionMenuInputButton.UserActionMenuInputButton_C
// Size: 0x1460 (Inherited: 0x1460)
struct UUserActionMenuInputButton_C : UCommonButtonLegacy {
};

