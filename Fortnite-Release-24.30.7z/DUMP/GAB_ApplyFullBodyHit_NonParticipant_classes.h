// BlueprintGeneratedClass GAB_ApplyFullBodyHit_NonParticipant.GAB_ApplyFullBodyHit_NonParticipant_C
// Size: 0xb98 (Inherited: 0xb98)
struct UGAB_ApplyFullBodyHit_NonParticipant_C : UGAB_GenericApplyFullBodyHit_C {

	void PickFullBodyHitMontageSection(); // Function GAB_ApplyFullBodyHit_NonParticipant.GAB_ApplyFullBodyHit_NonParticipant_C.PickFullBodyHitMontageSection // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

