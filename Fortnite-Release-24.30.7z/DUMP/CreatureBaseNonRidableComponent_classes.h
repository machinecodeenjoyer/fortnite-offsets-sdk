// BlueprintGeneratedClass CreatureBaseNonRidableComponent.CreatureBaseNonRidableComponent_C
// Size: 0xba (Inherited: 0xa0)
struct UCreatureBaseNonRidableComponent_C : UActorComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A0[0x1a]; // 0xa0(0x1a)

	void GetRidingInfoFromTarget(); // Function CreatureBaseNonRidableComponent.CreatureBaseNonRidableComponent_C.GetRidingInfoFromTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ToggleRidingAlternative(); // Function CreatureBaseNonRidableComponent.CreatureBaseNonRidableComponent_C.ToggleRidingAlternative // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AlternateRidingEvent(); // Function CreatureBaseNonRidableComponent.CreatureBaseNonRidableComponent_C.AlternateRidingEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_CreatureBaseNonRidableComponent(); // Function CreatureBaseNonRidableComponent.CreatureBaseNonRidableComponent_C.ExecuteUbergraph_CreatureBaseNonRidableComponent // (Final|UbergraphFunction) // @ game+0x179ea74
};

