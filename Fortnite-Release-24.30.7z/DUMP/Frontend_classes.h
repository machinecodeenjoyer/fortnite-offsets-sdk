// BlueprintGeneratedClass Frontend.Frontend_C
// Size: 0x2b8 (Inherited: 0x2a0)
struct AFrontend_C : AFortLevelScriptActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2A0[0x18]; // 0x2a0(0x18)

	void PlaySpeech(); // Function Frontend.Frontend_C.PlaySpeech // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMatchStarted(); // Function Frontend.Frontend_C.OnMatchStarted // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void EnableTutorial(); // Function Frontend.Frontend_C.EnableTutorial // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_Frontend(); // Function Frontend.Frontend_C.ExecuteUbergraph_Frontend // (Final|UbergraphFunction) // @ game+0x179ea74
};

