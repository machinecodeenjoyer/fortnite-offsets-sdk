// BlueprintGeneratedClass WindManager.WindManager_C
// Size: 0x644 (Inherited: 0x518)
struct AWindManager_C : AFortWindManager {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_518[0x12c]; // 0x518(0x12c)

	void Find Matching Wind Mesh Index And Write Bool(); // Function WindManager.WindManager_C.Find Matching Wind Mesh Index And Write Bool // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetWindMatVariables(); // Function WindManager.WindManager_C.SetWindMatVariables // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateWindDeltaCyl(); // Function WindManager.WindManager_C.UpdateWindDeltaCyl // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void RemoveWindCylinder(); // Function WindManager.WindManager_C.RemoveWindCylinder // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateStormWindCylinder(); // Function WindManager.WindManager_C.UpdateStormWindCylinder // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Calculate Camera Position(); // Function WindManager.WindManager_C.Calculate Camera Position // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UserConstructionScript(); // Function WindManager.WindManager_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnWindImpulseCylinderDeath(); // Function WindManager.WindManager_C.OnWindImpulseCylinderDeath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnWindImpulseCylinderDeltaComplete(); // Function WindManager.WindManager_C.OnWindImpulseCylinderDeltaComplete // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnWindImpulseCylinderCreation(); // Function WindManager.WindManager_C.OnWindImpulseCylinderCreation // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void SpawnTestWind(); // Function WindManager.WindManager_C.SpawnTestWind // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Play Water Splash Particle System At Location(); // Function WindManager.WindManager_C.Play Water Splash Particle System At Location // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AddWindParticleSystemComponent(); // Function WindManager.WindManager_C.AddWindParticleSystemComponent // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Register player for render to texture purposes(); // Function WindManager.WindManager_C.Register player for render to texture purposes // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Add Wind Component(); // Function WindManager.WindManager_C.Add Wind Component // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveBeginPlay(); // Function WindManager.WindManager_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void Update Test(); // Function WindManager.WindManager_C.Update Test // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Add Render To Texture Particle(); // Function WindManager.WindManager_C.Add Render To Texture Particle // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WindManager(); // Function WindManager.WindManager_C.ExecuteUbergraph_WindManager // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

