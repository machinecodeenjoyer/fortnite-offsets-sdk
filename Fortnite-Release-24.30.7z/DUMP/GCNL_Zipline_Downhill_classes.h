// BlueprintGeneratedClass GCNL_Zipline_Downhill.GCNL_Zipline_Downhill_C
// Size: 0x9a0 (Inherited: 0x960)
struct AGCNL_Zipline_Downhill_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x40]; // 0x960(0x40)

	void OnRemovalGeneric(); // Function GCNL_Zipline_Downhill.GCNL_Zipline_Downhill_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStartGeneric(); // Function GCNL_Zipline_Downhill.GCNL_Zipline_Downhill_C.OnLoopingStartGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void cameraShakeTimer(); // Function GCNL_Zipline_Downhill.GCNL_Zipline_Downhill_C.cameraShakeTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_Zipline_Downhill(); // Function GCNL_Zipline_Downhill.GCNL_Zipline_Downhill_C.ExecuteUbergraph_GCNL_Zipline_Downhill // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

