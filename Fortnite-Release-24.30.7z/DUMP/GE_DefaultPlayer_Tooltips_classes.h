// BlueprintGeneratedClass GE_DefaultPlayer_Tooltips.GE_DefaultPlayer_Tooltips_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_DefaultPlayer_Tooltips_C : UGameplayEffect {
};

