// BlueprintGeneratedClass Athena_GameState.Athena_GameState_C
// Size: 0x3268 (Inherited: 0x3250)
struct AAthena_GameState_C : AFortGameStateBR {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_3250[0x18]; // 0x3250(0x18)

	void OnWinnerAnnounced(); // Function Athena_GameState.Athena_GameState_C.OnWinnerAnnounced // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_Athena_GameState(); // Function Athena_GameState.Athena_GameState_C.ExecuteUbergraph_Athena_GameState // (Final|UbergraphFunction) // @ game+0x179ea74
};

