// BlueprintGeneratedClass FrontendCamera_Inspect.FrontendCamera_Inspect_C
// Size: 0xa00 (Inherited: 0x9f0)
struct AFrontendCamera_Inspect_C : AFortCameraBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_9F0[0x10]; // 0x9f0(0x10)

	void BP_OnActivated(); // Function FrontendCamera_Inspect.FrontendCamera_Inspect_C.BP_OnActivated // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void BP_OnDeactivated(); // Function FrontendCamera_Inspect.FrontendCamera_Inspect_C.BP_OnDeactivated // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_FrontendCamera_Inspect(); // Function FrontendCamera_Inspect.FrontendCamera_Inspect_C.ExecuteUbergraph_FrontendCamera_Inspect // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

