// BlueprintGeneratedClass GE_Athena_DBNO_Bleed.GE_Athena_DBNO_Bleed_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Athena_DBNO_Bleed_C : UGET_PeriodicEnergyDamage_C {
};

