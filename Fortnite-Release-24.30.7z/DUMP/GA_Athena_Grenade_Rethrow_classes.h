// BlueprintGeneratedClass GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C
// Size: 0xfd0 (Inherited: 0xfa8)
struct UGA_Athena_Grenade_Rethrow_C : UGA_Athena_Consumable_Throw_Parent_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_FA8[0x28]; // 0xfa8(0x28)

	void DetachProjectile(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.DetachProjectile // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttachProjectile(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.AttachProjectile // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Completed_3B7299CC49B6C5C075996A9C8DDF315F(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.Completed_3B7299CC49B6C5C075996A9C8DDF315F // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Cancelled_3B7299CC49B6C5C075996A9C8DDF315F(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.Cancelled_3B7299CC49B6C5C075996A9C8DDF315F // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Triggered_3B7299CC49B6C5C075996A9C8DDF315F(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.Triggered_3B7299CC49B6C5C075996A9C8DDF315F // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnFinish_B295E6694DBD8B2B2478A38EA60F5624(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.OnFinish_B295E6694DBD8B2B2478A38EA60F5624 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ThrowProjectile(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.ThrowProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void RethrowProjectile(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.RethrowProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttemptSpawnThrownProjectile(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.AttemptSpawnThrownProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Athena_Grenade_Rethrow(); // Function GA_Athena_Grenade_Rethrow.GA_Athena_Grenade_Rethrow_C.ExecuteUbergraph_GA_Athena_Grenade_Rethrow // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

