// BlueprintGeneratedClass GET_AfflictedParent.GET_AfflictedParent_C
// Size: 0x858 (Inherited: 0x858)
struct UGET_AfflictedParent_C : UGET_DamageParent_C {
};

