// Class BlueprintContext.BlueprintContextBase
// Size: 0x30 (Inherited: 0x30)
struct UBlueprintContextBase : USubsystem {
};

// Class BlueprintContext.BlueprintContextLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintContextLibrary : UBlueprintFunctionLibrary {

	void GetContext(); // Function BlueprintContext.BlueprintContextLibrary.GetContext // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x20ca1b8
};

