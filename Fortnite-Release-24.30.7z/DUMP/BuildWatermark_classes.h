// WidgetBlueprintGeneratedClass BuildWatermark.BuildWatermark_C
// Size: 0x320 (Inherited: 0x318)
struct UBuildWatermark_C : UFortBuildWatermark {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_318[0x8]; // 0x318(0x08)

	void Construct(); // Function BuildWatermark.BuildWatermark_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void HandlePartyJoined(); // Function BuildWatermark.BuildWatermark_C.HandlePartyJoined // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Destruct(); // Function BuildWatermark.BuildWatermark_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void HandlePlayerStateChanged(); // Function BuildWatermark.BuildWatermark_C.HandlePlayerStateChanged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_BuildWatermark(); // Function BuildWatermark.BuildWatermark_C.ExecuteUbergraph_BuildWatermark // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

