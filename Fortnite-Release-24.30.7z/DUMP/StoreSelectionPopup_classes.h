// WidgetBlueprintGeneratedClass StoreSelectionPopup.StoreSelectionPopup_C
// Size: 0x568 (Inherited: 0x548)
struct UStoreSelectionPopup_C : UFortMtxStoreSelectionPopup {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_548[0x20]; // 0x548(0x20)

	void BP_OnActivated(); // Function StoreSelectionPopup.StoreSelectionPopup_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_StoreSelectionPopup(); // Function StoreSelectionPopup.StoreSelectionPopup_C.ExecuteUbergraph_StoreSelectionPopup // (Final|UbergraphFunction) // @ game+0x179ea74
};

