// Class HmxAudioGraphics.AudioAnalysisTexture
// Size: 0x198 (Inherited: 0x180)
struct UAudioAnalysisTexture : UHysteresisTextureBase {
	char pad_180[0x143]; // 0x180(0x143)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8020d]; // 0x2c3(0x929888d0)
	 ; // 0x00(0x00)
};

// Class HmxAudioGraphics.OldMusicTempometerComponent
// Size: 0x1a8 (Inherited: 0xa0)
struct UOldMusicTempometerComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x30182010)
	 ; // 0x00(0x00)

	void SetSongPosInterfaceFromActor(); // Function HmxAudioGraphics.OldMusicTempometerComponent.SetSongPosInterfaceFromActor // (Final|Native|Public|BlueprintCallable) // @ game+0xb40f7c4
	void SetSongPosInterface(); // Function HmxAudioGraphics.OldMusicTempometerComponent.SetSongPosInterface // (Final|Native|Public|BlueprintCallable) // @ game+0xb40f62c
	void SetMaterialParameterCollection(); // Function HmxAudioGraphics.OldMusicTempometerComponent.SetMaterialParameterCollection // (Final|Native|Public|BlueprintCallable) // @ game+0xb40f498
	void GetTimeSignatureNumerator(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetTimeSignatureNumerator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f460
	void GetTimeSignatureDenominator(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetTimeSignatureDenominator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f428
	void GetTickLifetime(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetTickLifetime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f3f0
	void GetTempo(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetTempo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f3b8
	void GetSongPosInterfaceNoMutex(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetSongPosInterfaceNoMutex // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f390
	void GetSongPosInterface(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetSongPosInterface // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f338
	void GetSongPos(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetSongPos // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f2c8
	void GetMusicTick(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMusicTick // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f290
	void GetMusicSeconds(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMusicSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f258
	void GetMusicMeasure(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMusicMeasure // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f220
	void GetMusicBeat(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMusicBeat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f1e8
	void GetMeasureTick(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMeasureTick // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f1b0
	void GetMeasureLifetime(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMeasureLifetime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f178
	void GetMeasureBeat(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMeasureBeat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f140
	void GetMaterialParameterCollection(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetMaterialParameterCollection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f0f0
	void GetBeatTick(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetBeatTick // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f0b8
	void GetBeatLifetime(); // Function HmxAudioGraphics.OldMusicTempometerComponent.GetBeatLifetime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb40f080
};

// Class HmxAudioGraphics.StutterTexture
// Size: 0x160 (Inherited: 0x150)
struct UStutterTexture : UHmxTextureBase {
	char pad_150[0x173]; // 0x150(0x173)
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x90482010)
	 ; // 0x00(0x00)

	void RefreshTexture(); // Function HmxAudioGraphics.StutterTexture.RefreshTexture // (Final|Native|Private|BlueprintCallable) // @ game+0x7431d60
};

