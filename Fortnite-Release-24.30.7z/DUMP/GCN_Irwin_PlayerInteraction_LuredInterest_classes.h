// BlueprintGeneratedClass GCN_Irwin_PlayerInteraction_LuredInterest.GCN_Irwin_PlayerInteraction_LuredInterest_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Irwin_PlayerInteraction_LuredInterest_C : UFortGameplayCueNotify_Burst {
};

