// WidgetBlueprintGeneratedClass SocialInteraction.SocialInteraction_C
// Size: 0x1568 (Inherited: 0x1510)
struct USocialInteraction_C : USocialInteractionButton {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1510[0x58]; // 0x1510(0x58)

	void BP_OnUnhovered(); // Function SocialInteraction.SocialInteraction_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInteractionSet(); // Function SocialInteraction.SocialInteraction_C.OnInteractionSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function SocialInteraction.SocialInteraction_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function SocialInteraction.SocialInteraction_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_SocialInteraction(); // Function SocialInteraction.SocialInteraction_C.ExecuteUbergraph_SocialInteraction // (Final|UbergraphFunction) // @ game+0x179ea74
};

