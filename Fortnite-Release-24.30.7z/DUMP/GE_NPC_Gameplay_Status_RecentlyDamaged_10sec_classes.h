// BlueprintGeneratedClass GE_NPC_Gameplay_Status_RecentlyDamaged_10sec.GE_NPC_Gameplay_Status_RecentlyDamaged_10sec_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_NPC_Gameplay_Status_RecentlyDamaged_10sec_C : UGameplayEffect {
};

