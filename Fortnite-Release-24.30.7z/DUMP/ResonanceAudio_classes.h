// Class ResonanceAudio.ResonanceAudioSoundfieldSettings
// Size: 0x30 (Inherited: 0x28)
struct UResonanceAudioSoundfieldSettings : USoundfieldEncodingSettingsBase {
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x00(0x31f82150)
	 ; // 0x00(0x00)
};

// Class ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UResonanceAudioBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	void SetGlobalReverbPreset(); // Function ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary.SetGlobalReverbPreset // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbf1d660
	void GetGlobalReverbPreset(); // Function ResonanceAudio.ResonanceAudioBlueprintFunctionLibrary.GetGlobalReverbPreset // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbf1d4c4
};

// Class ResonanceAudio.ResonanceAudioDirectivityVisualizer
// Size: 0x308 (Inherited: 0x288)
struct AResonanceAudioDirectivityVisualizer : AActor {
	char pad_288[0x3b]; // 0x288(0x3b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x98002000)
	 ; // 0x00(0x00)
};

// Class ResonanceAudio.ResonanceAudioReverbPluginPreset
// Size: 0x170 (Inherited: 0x68)
struct UResonanceAudioReverbPluginPreset : USoundEffectSubmixPreset {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x00(0x100010)
	 ; // 0x00(0x00)

	void SetRoomRotation(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomRotation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbf1e074
	void SetRoomPosition(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomPosition // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbf1dfec
	void SetRoomMaterials(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomMaterials // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xbf1de64
	void SetRoomDimensions(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetRoomDimensions // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbf1dddc
	void SetReverbTimeModifier(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbTimeModifier // (Final|Native|Public|BlueprintCallable) // @ game+0xbf1dc58
	void SetReverbGain(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbGain // (Final|Native|Public|BlueprintCallable) // @ game+0xbf1dad4
	void SetReverbBrightness(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReverbBrightness // (Final|Native|Public|BlueprintCallable) // @ game+0xbf1d950
	void SetReflectionScalar(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetReflectionScalar // (Final|Native|Public|BlueprintCallable) // @ game+0xbf1d7cc
	void SetEnableRoomEffects(); // Function ResonanceAudio.ResonanceAudioReverbPluginPreset.SetEnableRoomEffects // (Final|Native|Public|BlueprintCallable) // @ game+0xbf1d4e8
};

// Class ResonanceAudio.ResonanceAudioSettings
// Size: 0x78 (Inherited: 0x28)
struct UResonanceAudioSettings : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x44201]; // 0x2c3(0x30180000)
	 ; // 0x00(0x00)
};

// Class ResonanceAudio.ResonanceAudioSpatializationSourceSettings
// Size: 0x50 (Inherited: 0x28)
struct UResonanceAudioSpatializationSourceSettings : USpatializationPluginSourceSettingsBase {
	char pad_28[0x29b]; // 0x28(0x29b)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40044201]; // 0x2c3(0x305c2010)
	 ; // 0x00(0x00)

	void SetSoundSourceSpread(); // Function ResonanceAudio.ResonanceAudioSpatializationSourceSettings.SetSoundSourceSpread // (Final|Native|Public|BlueprintCallable) // @ game+0x75c08b0
	void SetSoundSourceDirectivity(); // Function ResonanceAudio.ResonanceAudioSpatializationSourceSettings.SetSoundSourceDirectivity // (Final|Native|Public|BlueprintCallable) // @ game+0xbf1e0fc
};

