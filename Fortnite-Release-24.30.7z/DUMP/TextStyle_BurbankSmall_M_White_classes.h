// BlueprintGeneratedClass TextStyle_BurbankSmall_M_White.TextStyle_BurbankSmall_M_White_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle_BurbankSmall_M_White_C : UTextStyle-BaseParent_C {
};

