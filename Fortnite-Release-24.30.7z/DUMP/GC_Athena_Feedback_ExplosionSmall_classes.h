// BlueprintGeneratedClass GC_Athena_Feedback_ExplosionSmall.GC_Athena_Feedback_ExplosionSmall_C
// Size: 0x210 (Inherited: 0x210)
struct UGC_Athena_Feedback_ExplosionSmall_C : UFortGameplayCueNotify_Burst {

	void OnBurst(); // Function GC_Athena_Feedback_ExplosionSmall.GC_Athena_Feedback_ExplosionSmall_C.OnBurst // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
};

