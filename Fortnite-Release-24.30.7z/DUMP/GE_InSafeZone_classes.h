// BlueprintGeneratedClass GE_InSafeZone.GE_InSafeZone_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_InSafeZone_C : UGameplayEffect {
};

