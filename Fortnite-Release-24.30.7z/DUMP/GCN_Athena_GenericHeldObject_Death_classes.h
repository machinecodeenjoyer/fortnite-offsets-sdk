// BlueprintGeneratedClass GCN_Athena_GenericHeldObject_Death.GCN_Athena_GenericHeldObject_Death_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Athena_GenericHeldObject_Death_C : UFortGameplayCueNotify_Burst {
};

