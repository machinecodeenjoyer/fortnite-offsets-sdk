// BlueprintGeneratedClass NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C
// Size: 0x3d01 (Inherited: 0x3ba0)
struct ANPC_Pawn_Wildlife_Parent_C : ANPC_Pawn_Parent_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_3BA0[0x161]; // 0x3ba0(0x161)

	void TryShowHealthBar(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.TryShowHealthBar // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BlueprintCanInteract(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void PlayStateChangeAudio(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.PlayStateChangeAudio // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PlayAdditiveHitReacts(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.PlayAdditiveHitReacts // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BlueprintModifyIncomingDamage(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.BlueprintModifyIncomingDamage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPCStatusWidget_UpdateKeepVisible(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.NPCStatusWidget_UpdateKeepVisible // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CanBeInteractedWithWhenTamed(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.CanBeInteractedWithWhenTamed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void NPC PickupGrabbed_Destroyed(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.NPC PickupGrabbed_Destroyed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetTamingEnabled(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.SetTamingEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC CanBeInteractedWith(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.NPC CanBeInteractedWith // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttachAndApplyVocalFX(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.AttachAndApplyVocalFX // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Play Water Splash at Water Surface(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.Play Water Splash at Water Surface // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void IsValidAutoFireTarget(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.IsValidAutoFireTarget // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void Play Sound Lib(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.Play Sound Lib // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateTamingIndicator(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.UpdateTamingIndicator // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_LeaderTeam(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnRep_LeaderTeam // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoaded_9DC5FDA543FAF13BB29E95AA78B28A06(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnLoaded_9DC5FDA543FAF13BB29E95AA78B28A06 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveBeginPlay(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void LinkAnimationLayers(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.LinkAnimationLayers // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AsyncLinkAnimationLayer(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.AsyncLinkAnimationLayer // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCustomizationsLoaded_BP(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnCustomizationsLoaded_BP // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void On NPC PawnInteractedWith(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.On NPC PawnInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__ConvertComponent_K2Node_ComponentBoundEvent_0_ConvertedEvent__DelegateSignature(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.BndEvt__ConvertComponent_K2Node_ComponentBoundEvent_0_ConvertedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BndEvt__ConvertComponent_K2Node_ComponentBoundEvent_1_UnconvertedEvent__DelegateSignature(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.BndEvt__ConvertComponent_K2Node_ComponentBoundEvent_1_UnconvertedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void NPC AlertLevelChangedServer(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.NPC AlertLevelChangedServer // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnDeathServer(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void NPC LeaderSet(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.NPC LeaderSet // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__SoundLibrary_Component_K2Node_ComponentBoundEvent_2_OnSoundLibraryPlayEvent__DelegateSignature(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.BndEvt__SoundLibrary_Component_K2Node_ComponentBoundEvent_2_OnSoundLibraryPlayEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnBeingControlledChanged(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnBeingControlledChanged // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnApplyEffectOptimization(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnApplyEffectOptimization // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnDamagePlayEffects(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void NPC UpdateHealthBarComponentVisibility(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.NPC UpdateHealthBarComponentVisibility // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void (); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C. // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void On Pawn Focused(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.On Pawn Focused // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void HideStatus(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.HideStatus // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnSlidingStateChanged(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnSlidingStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnDeathPlayEffects(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnLanded(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnLanded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnLandedMulticast(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnLandedMulticast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnTamedMulticast(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnTamedMulticast // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnOutOfConvertResistanceServer(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnOutOfConvertResistanceServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void RestoreConvertResistance(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.RestoreConvertResistance // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_NPC_Pawn_Wildlife_Parent(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.ExecuteUbergraph_NPC_Pawn_Wildlife_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
	void OnModifiedDamageReceived__DelegateSignature(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnModifiedDamageReceived__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ConvertedDispatcher__DelegateSignature(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.ConvertedDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPickupGrabbed_Destroyed__DelegateSignature(); // Function NPC_Pawn_Wildlife_Parent.NPC_Pawn_Wildlife_Parent_C.OnPickupGrabbed_Destroyed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

