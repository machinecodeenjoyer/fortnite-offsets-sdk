// WidgetBlueprintGeneratedClass SubgameSelectScreen.SubgameSelectScreen_C
// Size: 0x494 (Inherited: 0x460)
struct USubgameSelectScreen_C : UFortSubgameSelectScreen {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_460[0x34]; // 0x460(0x34)

	void IsMinorShutdownWarningEnabled(); // Function SubgameSelectScreen.SubgameSelectScreen_C.IsMinorShutdownWarningEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void IsBusyMatchmaking(); // Function SubgameSelectScreen.SubgameSelectScreen_C.IsBusyMatchmaking // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void AdvanceTextureCycle(); // Function SubgameSelectScreen.SubgameSelectScreen_C.AdvanceTextureCycle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void InitializeTextureCycle(); // Function SubgameSelectScreen.SubgameSelectScreen_C.InitializeTextureCycle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnEventEnded_57187EC14A536D0960088EB25BDF39E5(); // Function SubgameSelectScreen.SubgameSelectScreen_C.OnEventEnded_57187EC14A536D0960088EB25BDF39E5 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnEventUpdated_57187EC14A536D0960088EB25BDF39E5(); // Function SubgameSelectScreen.SubgameSelectScreen_C.OnEventUpdated_57187EC14A536D0960088EB25BDF39E5 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnEventActive_57187EC14A536D0960088EB25BDF39E5(); // Function SubgameSelectScreen.SubgameSelectScreen_C.OnEventActive_57187EC14A536D0960088EB25BDF39E5 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BP_OnActivated(); // Function SubgameSelectScreen.SubgameSelectScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_SubgameSelectScreen(); // Function SubgameSelectScreen.SubgameSelectScreen_C.ExecuteUbergraph_SubgameSelectScreen // (Final|UbergraphFunction) // @ game+0x179ea74
};

