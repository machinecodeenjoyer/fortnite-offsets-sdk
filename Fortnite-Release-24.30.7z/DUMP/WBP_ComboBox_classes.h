// WidgetBlueprintGeneratedClass WBP_ComboBox.WBP_ComboBox_C
// Size: 0x33d (Inherited: 0x2c8)
struct UWBP_ComboBox_C : UFortComboBox {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2C8[0x75]; // 0x2c8(0x75)

	void SetActionVisibility(); // Function WBP_ComboBox.WBP_ComboBox_C.SetActionVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetText(); // Function WBP_ComboBox.WBP_ComboBox_C.SetText // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetContentSize(); // Function WBP_ComboBox.WBP_ComboBox_C.SetContentSize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Set Focus Visual(); // Function WBP_ComboBox.WBP_ComboBox_C.Set Focus Visual // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetContentAlignment(); // Function WBP_ComboBox.WBP_ComboBox_C.SetContentAlignment // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnAddedToFocusPath(); // Function WBP_ComboBox.WBP_ComboBox_C.OnAddedToFocusPath // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnRemovedFromFocusPath(); // Function WBP_ComboBox.WBP_ComboBox_C.OnRemovedFromFocusPath // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnMouseEnter(); // Function WBP_ComboBox.WBP_ComboBox_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnMouseLeave(); // Function WBP_ComboBox.WBP_ComboBox_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__WBP_ComboBox_ComboBox_K2Node_ComponentBoundEvent_0_OnSelectionChangedEvent__DelegateSignature(); // Function WBP_ComboBox.WBP_ComboBox_C.BndEvt__WBP_ComboBox_ComboBox_K2Node_ComponentBoundEvent_0_OnSelectionChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function WBP_ComboBox.WBP_ComboBox_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__WBP_ComboBox_ComboBox_K2Node_ComponentBoundEvent_1_OnOpeningEvent__DelegateSignature(); // Function WBP_ComboBox.WBP_ComboBox_C.BndEvt__WBP_ComboBox_ComboBox_K2Node_ComponentBoundEvent_1_OnOpeningEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void RefreshHoverAnim(); // Function WBP_ComboBox.WBP_ComboBox_C.RefreshHoverAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PreConstruct(); // Function WBP_ComboBox.WBP_ComboBox_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void Destruct(); // Function WBP_ComboBox.WBP_ComboBox_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnInputDeviceChanged(); // Function WBP_ComboBox.WBP_ComboBox_C.OnInputDeviceChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WBP_ComboBox(); // Function WBP_ComboBox.WBP_ComboBox_C.ExecuteUbergraph_WBP_ComboBox // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

