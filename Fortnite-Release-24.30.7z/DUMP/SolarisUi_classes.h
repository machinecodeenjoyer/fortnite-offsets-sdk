// Class SolarisUi.SolUserWidget
// Size: 0x2b8 (Inherited: 0x298)
struct USolUserWidget : UUserWidget {
	char pad_298[0x20]; // 0x298(0x20)
};

