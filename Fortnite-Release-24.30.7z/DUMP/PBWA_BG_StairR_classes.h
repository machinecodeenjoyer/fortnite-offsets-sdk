// BlueprintGeneratedClass PBWA_BG_StairR.PBWA_BG_StairR_C
// Size: 0xd78 (Inherited: 0xd78)
struct APBWA_BG_StairR_C : ABuildingStairs {
};

