// BlueprintGeneratedClass GCN_BurtCharging_Player_Latent.GCN_BurtCharging_Player_Latent_C
// Size: 0x558 (Inherited: 0x528)
struct AGCN_BurtCharging_Player_Latent_C : AFortGameplayCueNotify_BurstLatent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_528[0x30]; // 0x528(0x30)

	void OnExecute(); // Function GCN_BurtCharging_Player_Latent.GCN_BurtCharging_Player_Latent_C.OnExecute // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteBoostLogic(); // Function GCN_BurtCharging_Player_Latent.GCN_BurtCharging_Player_Latent_C.ExecuteBoostLogic // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BoostEndEvent(); // Function GCN_BurtCharging_Player_Latent.GCN_BurtCharging_Player_Latent_C.BoostEndEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_BurtCharging_Player_Latent(); // Function GCN_BurtCharging_Player_Latent.GCN_BurtCharging_Player_Latent_C.ExecuteUbergraph_GCN_BurtCharging_Player_Latent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

