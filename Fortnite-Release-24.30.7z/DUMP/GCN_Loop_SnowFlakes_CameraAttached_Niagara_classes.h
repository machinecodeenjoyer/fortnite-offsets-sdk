// BlueprintGeneratedClass GCN_Loop_SnowFlakes_CameraAttached_Niagara.GCN_Loop_SnowFlakes_CameraAttached_Niagara_C
// Size: 0x974 (Inherited: 0x960)
struct AGCN_Loop_SnowFlakes_CameraAttached_Niagara_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x14]; // 0x960(0x14)

	void OnLoopingStartGeneric(); // Function GCN_Loop_SnowFlakes_CameraAttached_Niagara.GCN_Loop_SnowFlakes_CameraAttached_Niagara_C.OnLoopingStartGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_Loop_SnowFlakes_CameraAttached_Niagara(); // Function GCN_Loop_SnowFlakes_CameraAttached_Niagara.GCN_Loop_SnowFlakes_CameraAttached_Niagara_C.ExecuteUbergraph_GCN_Loop_SnowFlakes_CameraAttached_Niagara // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

