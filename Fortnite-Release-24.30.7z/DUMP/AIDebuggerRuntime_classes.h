// Class AIDebuggerRuntime.AIDebuggerCheatManager
// Size: 0x28 (Inherited: 0x28)
struct UAIDebuggerCheatManager : UChildCheatManager {

	void StartAIDebugger(); // Function AIDebuggerRuntime.AIDebuggerCheatManager.StartAIDebugger // (Final|Exec|Native|Public) // @ game+0x8396144
	void NextNavMesh(); // Function AIDebuggerRuntime.AIDebuggerCheatManager.NextNavMesh // (Final|Exec|Native|Public) // @ game+0x29cdec8
	void EnableNavMeshVisualizer(); // Function AIDebuggerRuntime.AIDebuggerCheatManager.EnableNavMeshVisualizer // (Final|Exec|Native|Public) // @ game+0x70883c8
};

// Class AIDebuggerRuntime.AIDebuggerRendererComponent
// Size: 0x610 (Inherited: 0x570)
struct UAIDebuggerRendererComponent : UPrimitiveComponent {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x201]; // 0x2c3(0x583c2810)
	 ; // 0x00(0x00)
};

// Class AIDebuggerRuntime.FortControllerComponent_AIDebugger
// Size: 0xe0 (Inherited: 0xa8)
struct UFortControllerComponent_AIDebugger : UFortControllerComponent {
	char pad_A8[0x21b]; // 0xa8(0x21b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x22215]; // 0x2c3(0x647ac950)
	 ; // 0x00(0x00)

	void VisualizeNextNavMesh(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNextNavMesh // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x9167444
	void VisualizeNavMeshID(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNavMeshID // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x938d310
	void SetVisualizationEnable(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.SetVisualizationEnable // (RequiredAPI|Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0xb070d90
	void OnRep_EnabledVisualizers(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnRep_EnabledVisualizers // (Final|Native|Public) // @ game+0xb070d54
	void OnPlayerExitedIsland(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnPlayerExitedIsland // (Final|Native|Public|HasOutParms) // @ game+0xb070b8c
	void IsVisualizationEnabled(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.IsVisualizationEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb070a0c
	void GetOrCreateRenderer(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.GetOrCreateRenderer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb0709e8
};

