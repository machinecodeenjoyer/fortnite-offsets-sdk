// BlueprintGeneratedClass TextStyle-Base-M-B_Black.TextStyle-Base-M-B_Black_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-Base-M-B_Black_C : UTextStyle-Base-M-B_C {
};

