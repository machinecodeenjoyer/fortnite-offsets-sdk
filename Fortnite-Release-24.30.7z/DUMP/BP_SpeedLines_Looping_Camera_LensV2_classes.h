// BlueprintGeneratedClass BP_SpeedLines_Looping_Camera_LensV2.BP_SpeedLines_Looping_Camera_LensV2_C
// Size: 0x370 (Inherited: 0x370)
struct ABP_SpeedLines_Looping_Camera_LensV2_C : AEmitterCameraLensEffectBase {
};

