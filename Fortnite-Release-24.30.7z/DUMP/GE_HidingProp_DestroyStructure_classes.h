// BlueprintGeneratedClass GE_HidingProp_DestroyStructure.GE_HidingProp_DestroyStructure_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_HidingProp_DestroyStructure_C : UGameplayEffect {
};

