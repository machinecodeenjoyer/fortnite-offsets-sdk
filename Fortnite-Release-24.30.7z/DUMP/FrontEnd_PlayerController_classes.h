// BlueprintGeneratedClass FrontEnd_PlayerController.FrontEnd_PlayerController_C
// Size: 0x2cb0 (Inherited: 0x2cb0)
struct AFrontEnd_PlayerController_C : AFortPlayerControllerFrontEnd {
};

