// BlueprintGeneratedClass TextStyle-Base-XS-70pc.TextStyle-Base-XS-70pc_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-Base-XS-70pc_C : UTextStyle-Base-XS_C {
};

