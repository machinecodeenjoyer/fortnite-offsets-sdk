// BlueprintGeneratedClass LoginCamera_Blueprint.LoginCamera_Blueprint_C
// Size: 0xa08 (Inherited: 0x9f0)
struct ALoginCamera_Blueprint_C : AFortCameraBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_9F0[0x18]; // 0x9f0(0x18)

	void BP_OnActivated(); // Function LoginCamera_Blueprint.LoginCamera_Blueprint_C.BP_OnActivated // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_LoginCamera_Blueprint(); // Function LoginCamera_Blueprint.LoginCamera_Blueprint_C.ExecuteUbergraph_LoginCamera_Blueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

