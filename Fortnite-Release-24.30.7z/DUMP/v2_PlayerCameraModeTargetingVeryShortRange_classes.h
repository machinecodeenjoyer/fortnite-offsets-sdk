// BlueprintGeneratedClass v2_PlayerCameraModeTargetingVeryShortRange.v2_PlayerCameraModeTargetingVeryShortRange_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct Uv2_PlayerCameraModeTargetingVeryShortRange_C : Uv2_PlayerCameraModeRanged_C {
};

