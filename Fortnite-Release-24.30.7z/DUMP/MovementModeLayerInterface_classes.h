// AnimBlueprintGeneratedClass MovementModeLayerInterface.MovementModeLayerInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UMovementModeLayerInterface_C : UAnimLayerInterface {

	void MovementMode_AimOffset(); // Function MovementModeLayerInterface.MovementModeLayerInterface_C.MovementMode_AimOffset // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MovementMode_FinalPoseOverride(); // Function MovementModeLayerInterface.MovementModeLayerInterface_C.MovementMode_FinalPoseOverride // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MovementMode_FullBodyOverride(); // Function MovementModeLayerInterface.MovementModeLayerInterface_C.MovementMode_FullBodyOverride // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MovementMode_SourcePose(); // Function MovementModeLayerInterface.MovementModeLayerInterface_C.MovementMode_SourcePose // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MovementMode_LocomotionAdditives(); // Function MovementModeLayerInterface.MovementModeLayerInterface_C.MovementMode_LocomotionAdditives // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MovementMode_LowerBodyOverride(); // Function MovementModeLayerInterface.MovementModeLayerInterface_C.MovementMode_LowerBodyOverride // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

