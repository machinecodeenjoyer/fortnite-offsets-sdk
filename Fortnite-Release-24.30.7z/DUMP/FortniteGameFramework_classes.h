// Class FortniteGameFramework.FGF_Character
// Size: 0x680 (Inherited: 0x620)
struct AFGF_Character : ACharacter {
	char pad_620[0x60]; // 0x620(0x60)
};

// Class FortniteGameFramework.FGF_GameMode
// Size: 0x3c8 (Inherited: 0x370)
struct AFGF_GameMode : AGameMode {
	char pad_370[0x58]; // 0x370(0x58)
};

// Class FortniteGameFramework.FGF_GameState
// Size: 0x358 (Inherited: 0x2f8)
struct AFGF_GameState : AGameState {
	char pad_2F8[0x60]; // 0x2f8(0x60)
};

// Class FortniteGameFramework.FGF_PlayerController
// Size: 0x8a0 (Inherited: 0x848)
struct AFGF_PlayerController : APlayerController {
	char pad_848[0x58]; // 0x848(0x58)
};

// Class FortniteGameFramework.FGF_PlayerState
// Size: 0x398 (Inherited: 0x340)
struct AFGF_PlayerState : APlayerState {
	char pad_340[0x58]; // 0x340(0x58)
};

// Class FortniteGameFramework.ObjectBasedStateTreeSchema
// Size: 0x28 (Inherited: 0x28)
struct UObjectBasedStateTreeSchema : UStateTreeSchema {
};

// Class FortniteGameFramework.StateTreeManagerComponent
// Size: 0x1e0 (Inherited: 0xa0)
struct UStateTreeManagerComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2200]; // 0x2c3(0x41100000)
	 ; // 0x00(0x00)
};

// Class FortniteGameFramework.StateTreeTaskObject
// Size: 0x50 (Inherited: 0x48)
struct UStateTreeTaskObject : UStateTreeTaskBlueprintBase {
	char pad_48[0x27b]; // 0x48(0x27b)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x58482810)
	 ; // 0x00(0x00)
};

