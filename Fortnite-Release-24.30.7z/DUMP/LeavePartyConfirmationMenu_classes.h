// WidgetBlueprintGeneratedClass LeavePartyConfirmationMenu.LeavePartyConfirmationMenu_C
// Size: 0x438 (Inherited: 0x428)
struct ULeavePartyConfirmationMenu_C : UFortLeavePartyMenu {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_428[0x10]; // 0x428(0x10)

	void OnOpened(); // Function LeavePartyConfirmationMenu.LeavePartyConfirmationMenu_C.OnOpened // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_LeavePartyConfirmationMenu(); // Function LeavePartyConfirmationMenu.LeavePartyConfirmationMenu_C.ExecuteUbergraph_LeavePartyConfirmationMenu // (Final|UbergraphFunction) // @ game+0x179ea74
};

