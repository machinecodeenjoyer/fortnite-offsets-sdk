// BlueprintGeneratedClass InterfacePlayerPawn.InterfacePlayerPawn_C
// Size: 0x28 (Inherited: 0x28)
struct UInterfacePlayerPawn_C : UInterface {

	void MeleeSwingLeft_End(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.MeleeSwingLeft_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingRight_End(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.MeleeSwingRight_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FootStepRight(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.FootStepRight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FootStepLeft(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.FootStepLeft // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Melee_Effect_Color(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.Melee_Effect_Color // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingLeft(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.MeleeSwingLeft // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingRight(); // Function InterfacePlayerPawn.InterfacePlayerPawn_C.MeleeSwingRight // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

