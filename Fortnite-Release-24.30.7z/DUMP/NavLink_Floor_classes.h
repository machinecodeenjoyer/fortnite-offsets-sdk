// BlueprintGeneratedClass NavLink_Floor.NavLink_Floor_C
// Size: 0x80 (Inherited: 0x80)
struct UNavLink_Floor_C : UFortNavLinkDefinition {
};

