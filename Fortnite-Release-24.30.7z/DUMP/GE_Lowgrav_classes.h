// BlueprintGeneratedClass GE_Lowgrav.GE_Lowgrav_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Lowgrav_C : UGameplayEffect {
};

