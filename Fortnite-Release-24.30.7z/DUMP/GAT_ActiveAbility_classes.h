// BlueprintGeneratedClass GAT_ActiveAbility.GAT_ActiveAbility_C
// Size: 0xb50 (Inherited: 0xb28)
struct UGAT_ActiveAbility_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x28]; // 0xb28(0x28)

	void EndAbilityWithReason(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.EndAbilityWithReason // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SendHeroAbilityActivationEvent(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.SendHeroAbilityActivationEvent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetHolsterWeaponWithName(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.SetHolsterWeaponWithName // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ShouldAbilityRespondToEvent(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.K2_ShouldAbilityRespondToEvent // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void ActiveAbilitySetup(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.ActiveAbilitySetup // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetKnockbackImmunity(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.SetKnockbackImmunity // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetPawnCollision(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.SetPawnCollision // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GAT_ActiveAbility(); // Function GAT_ActiveAbility.GAT_ActiveAbility_C.ExecuteUbergraph_GAT_ActiveAbility // (Final|UbergraphFunction) // @ game+0x179ea74
};

