// BlueprintGeneratedClass v1_PlayerCameraModeTargetingVeryShortRange.v1_PlayerCameraModeTargetingVeryShortRange_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct Uv1_PlayerCameraModeTargetingVeryShortRange_C : Uv1_PlayerCameraModeBase_C {
};

