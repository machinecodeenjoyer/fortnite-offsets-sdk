// BlueprintGeneratedClass WorldLightingMenu.WorldLightingMenu_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct AWorldLightingMenu_C : AFortLevelScriptActor {
};

