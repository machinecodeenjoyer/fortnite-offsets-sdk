// BlueprintGeneratedClass FrontendCamera_Main.FrontendCamera_Main_C
// Size: 0xa00 (Inherited: 0x9f0)
struct AFrontendCamera_Main_C : AFortCameraBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_9F0[0x10]; // 0x9f0(0x10)

	void BP_OnActivated(); // Function FrontendCamera_Main.FrontendCamera_Main_C.BP_OnActivated // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_FrontendCamera_Main(); // Function FrontendCamera_Main.FrontendCamera_Main_C.ExecuteUbergraph_FrontendCamera_Main // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

