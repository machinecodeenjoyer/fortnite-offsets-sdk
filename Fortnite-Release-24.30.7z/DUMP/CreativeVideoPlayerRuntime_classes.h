// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility
// Size: 0xb90 (Inherited: 0xb28)
struct UCreativeVideoPlayerFullscreenGameplayAbility : UFortGameplayAbility {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x382c2010)
	 ; // 0x00(0x00)

	void ServerLeaveFullscreenMode(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerLeaveFullscreenMode // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x8fe9844
	void ServerEnterFullscreenMode(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerEnterFullscreenMode // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x8013f14
	void OnFullscreenUIEnds(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.OnFullscreenUIEnds // (Final|Native|Private) // @ game+0xb2b17d0
	void HandleEnterFullscreenActionReleased(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionReleased // (Final|Native|Private) // @ game+0xb2b1788
	void HandleEnterFullscreenActionPressed(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionPressed // (Final|Native|Private) // @ game+0x29cdec8
	void ExitFullscreenState(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ExitFullscreenState // (Final|Native|Public|BlueprintCallable) // @ game+0xb2b175c
	void EnterFullscreenStateWithOptions(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenStateWithOptions // (Final|Native|Public|BlueprintCallable) // @ game+0xb2b15ec
	void EnterFullscreenState(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenState // (Final|Native|Public|BlueprintCallable) // @ game+0xb2b15c0
	void ClientTransitionToFullscreenVideo(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientTransitionToFullscreenVideo // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x8fe985c
	void ClientLeaveFullscreenVideo(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientLeaveFullscreenVideo // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x8fe95a4
};

// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCreativeVideoPlayerFunctionLibrary : UBlueprintFunctionLibrary {

	void ShutdownFullscreenVideoMode(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary.ShutdownFullscreenVideoMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb2b17e4
};

// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerWorldSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UCreativeVideoPlayerWorldSubsystem : UWorldSubsystem {
	struct FMulticastInlineDelegate  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10080200]; // 0x00(0x20000000)
	 ; // 0x00(0x00)
};

