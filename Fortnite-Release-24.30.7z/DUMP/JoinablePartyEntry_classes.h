// WidgetBlueprintGeneratedClass JoinablePartyEntry.JoinablePartyEntry_C
// Size: 0x1598 (Inherited: 0x1520)
struct UJoinablePartyEntry_C : UFortJoinablePartyListEntry {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1520[0x78]; // 0x1520(0x78)

	void BP_OnUnhovered(); // Function JoinablePartyEntry.JoinablePartyEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(); // Function JoinablePartyEntry.JoinablePartyEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function JoinablePartyEntry.JoinablePartyEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInviteStatusUpdated(); // Function JoinablePartyEntry.JoinablePartyEntry_C.OnInviteStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_JoinablePartyEntry(); // Function JoinablePartyEntry.JoinablePartyEntry_C.ExecuteUbergraph_JoinablePartyEntry // (Final|UbergraphFunction) // @ game+0x179ea74
};

