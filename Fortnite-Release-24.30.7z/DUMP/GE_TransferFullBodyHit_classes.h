// BlueprintGeneratedClass GE_TransferFullBodyHit.GE_TransferFullBodyHit_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_TransferFullBodyHit_C : UGameplayEffect {
};

