// BlueprintGeneratedClass GE_Riding_Player_IsRiding.GE_Riding_Player_IsRiding_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Riding_Player_IsRiding_C : UGameplayEffect {
};

