// WidgetBlueprintGeneratedClass XpBarToolTip.XpBarToolTip_C
// Size: 0x388 (Inherited: 0x2c0)
struct UXpBarToolTip_C : UCommonUserWidget {
	char pad_2C0[0x3]; // 0x2c0(0x03)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x14d02080)
	 ; // 0x00(0x00)

	void GetBodyText(); // Function XpBarToolTip.XpBarToolTip_C.GetBodyText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void GetRestedXPText(); // Function XpBarToolTip.XpBarToolTip_C.GetRestedXPText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void GetBoostXPText(); // Function XpBarToolTip.XpBarToolTip_C.GetBoostXPText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void GetCommanderXPText(); // Function XpBarToolTip.XpBarToolTip_C.GetCommanderXPText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void GetHeaderText(); // Function XpBarToolTip.XpBarToolTip_C.GetHeaderText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
};

