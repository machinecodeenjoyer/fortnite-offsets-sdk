// BlueprintGeneratedClass GE_Athena_Tethered.GE_Athena_Tethered_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Athena_Tethered_C : UGameplayEffect {
};

