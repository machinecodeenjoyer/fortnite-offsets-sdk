// BlueprintGeneratedClass TextStyle-MediumButton-Disabled.TextStyle-MediumButton-Disabled_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-MediumButton-Disabled_C : UTextStyle-MediumButton_C {
};

