// VerseClass Verse.$SolarisSignatureFunctionOuter
// Size: 0x28 (Inherited: 0x28)
struct U$SolarisSignatureFunctionOuter : UObject {
};

// VerseClass Verse.Colors
// Size: 0x28 (Inherited: 0x28)
struct UColors : UObject {

	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2f_U_L_Ncolor_M_Nint_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2f_U_L_Ncolor_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bab8
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2f_U_L_Ncolor_M_Nfloat_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2f_U_L_Ncolor_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bab0
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2d_U_L_Ncolor_M_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2d_U_L_Ncolor_M_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807baa8
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2b_U_L_Ncolor_M_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2b_U_L_Ncolor_M_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807baa0
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Ncolor_M_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Ncolor_M_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba78
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Ncolor_M_Nfloat_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Ncolor_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba80
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Nfloat_M_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Nfloat_M_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba90
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Ncolor_M_Nint_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Ncolor_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba88
	void _L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Nint_M_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_Roperator_U_2a_U_L_Nint_M_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba98
	void _L_2fVerse_2eorg_2fColors_N_RMakeSRGBFromColor_L_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeSRGBFromColor_L_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba70
	void _L_2fVerse_2eorg_2fColors_N_RMakeHSVFromColor_L_Ncolor_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeHSVFromColor_L_Ncolor_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba68
	void _L_2fVerse_2eorg_2fColors_N_RMakeColorFromTemperature_L_Nfloat_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeColorFromTemperature_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba60
	void _L_2fVerse_2eorg_2fColors_N_RMakeColorFromSRGBValues_L_Nint_M_Nint_M_Nint_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeColorFromSRGBValues_L_Nint_M_Nint_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba50
	void _L_2fVerse_2eorg_2fColors_N_RMakeColorFromSRGB_L_Nfloat_M_Nfloat_M_Nfloat_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeColorFromSRGB_L_Nfloat_M_Nfloat_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba58
	void _L_2fVerse_2eorg_2fColors_N_RMakeColorFromHex_L_N_Kchar_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeColorFromHex_L_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba48
	void _L_2fVerse_2eorg_2fColors_N_RMakeColorFromHSV_L_Nfloat_M_Nfloat_M_Nfloat_R(); // Function Verse.Colors._L_2fVerse_2eorg_2fColors_N_RMakeColorFromHSV_L_Nfloat_M_Nfloat_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807ba40
	void Colors_color$Factory(); // Function Verse.Colors.Colors_color$Factory // (Static|HasOutParms) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Colors.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Colors_NamedColors
// Size: 0xdf0 (Inherited: 0x28)
struct UColors_NamedColors : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x2c3(0x802000)
	 ; // 0x00(0x00)

	void $InitCDO(); // Function Verse.Colors_NamedColors.$InitCDO // (HasDefaults) // @ game+0x179ea74
};

// VerseClass Verse.Random
// Size: 0x28 (Inherited: 0x28)
struct URandom : UObject {

	void _L_2fVerse_2eorg_2fRandom_N_RShuffle_L_N_Kt_20where_20t_R(); // Function Verse.Random._L_2fVerse_2eorg_2fRandom_N_RShuffle_L_N_Kt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fRandom_N_RGetRandomInt_L_Nint_M_Nint_R(); // Function Verse.Random._L_2fVerse_2eorg_2fRandom_N_RGetRandomInt_L_Nint_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bac8
	void _L_2fVerse_2eorg_2fRandom_N_RGetRandomFloat_L_Nfloat_M_Nfloat_R(); // Function Verse.Random._L_2fVerse_2eorg_2fRandom_N_RGetRandomFloat_L_Nfloat_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bac0
	void $InitCDO(); // Function Verse.Random.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.task_Verse_event$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Verse_event$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function Verse.task_Verse_event$Await.Update // (Native|Public|HasOutParms) // @ game+0x807ba38
};

// VerseClass Verse.Verse
// Size: 0x30 (Inherited: 0x28)
struct UVerse : UObject {
	double  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x00(0x10802000)
	 ; // 0x00(0x00)

	void _L_2fVerse_2eorg_2fVerse_N_Rsubscribable_L_Ntype_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Rsubscribable_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Rsubscribable(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Rsubscribable // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Rsignalable_L_Ntype_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Rsignalable_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eSlice_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_Nint_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eSlice_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_Nint_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eSlice_U_L_N_Kt_M_Ntuple_L_R_M_Nint_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eSlice_U_L_N_Kt_M_Ntuple_L_R_M_Nint_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceFirstElement_U_L_N_Kt_M_Ntuple_L_R_M_Nt_M_Nt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceFirstElement_U_L_N_Kt_M_Ntuple_L_R_M_Nt_M_Nt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceElement_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_Nt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceElement_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_Nt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceAllElements_U_L_N_Kt_M_Ntuple_L_R_M_Nt_M_Nt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceAllElements_U_L_N_Kt_M_Ntuple_L_R_M_Nt_M_Nt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceAll_U_L_N_Kt_M_Ntuple_L_R_M_N_Kt_M_N_Kt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eReplaceAll_U_L_N_Kt_M_Ntuple_L_R_M_N_Kt_M_N_Kt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemoveFirstElement_U_L_N_Kt_M_Ntuple_L_R_M_Nt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemoveFirstElement_U_L_N_Kt_M_Ntuple_L_R_M_Nt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemoveElement_U_L_N_Kt_M_Ntuple_L_R_M_Nint_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemoveElement_U_L_N_Kt_M_Ntuple_L_R_M_Nint_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemoveAllElements_U_L_N_Kt_M_Ntuple_L_R_M_Nt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemoveAllElements_U_L_N_Kt_M_Ntuple_L_R_M_Nt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemove_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_Nint_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eRemove_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_Nint_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eIsFinite_U_L_Nfloat_M_Ntuple_L_R_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eIsFinite_U_L_Nfloat_M_Ntuple_L_R_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eIsAlmostZero_U_L_Nfloat_M_Ntuple_L_R_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eIsAlmostZero_U_L_Nfloat_M_Ntuple_L_R_M_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eInsert_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_N_Kt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eInsert_U_L_N_Kt_M_Ntuple_L_R_M_Nint_M_N_Kt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eFind_U_L_N_Kt_M_Ntuple_L_R_M_Nt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Roperator_U_2eFind_U_L_N_Kt_M_Ntuple_L_R_M_Nt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Rlistenable(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Rlistenable // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Rlistenable_L_Ntype_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Rlistenable_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Revent(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Revent // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_Revent_L_Ntype_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_Revent_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RToString_L_Nchar_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RToString_L_Nchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbd8
	void _L_2fVerse_2eorg_2fVerse_N_RToString_L_N_Kchar_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RToString_L_N_Kchar_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RToString_L_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RToString_L_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbe8
	void _L_2fVerse_2eorg_2fVerse_N_RToString_L_Nchar32_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RToString_L_Nchar32_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbd0
	void _L_2fVerse_2eorg_2fVerse_N_RToString_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RToString_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbe0
	void _L_2fVerse_2eorg_2fVerse_N_RTanh_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RTanh_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbc8
	void _L_2fVerse_2eorg_2fVerse_N_RTan_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RTan_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbc0
	void _L_2fVerse_2eorg_2fVerse_N_RSqrt_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RSqrt_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbb8
	void _L_2fVerse_2eorg_2fVerse_N_RSinh_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RSinh_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bbb0
	void _L_2fVerse_2eorg_2fVerse_N_RSin_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RSin_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bba8
	void _L_2fVerse_2eorg_2fVerse_N_RSgn_L_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RSgn_L_Nint_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RSgn_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RSgn_L_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RRound_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RRound_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bba0
	void _L_2fVerse_2eorg_2fVerse_N_RQuotient_L_Nint_M_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RQuotient_L_Nint_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb98
	void _L_2fVerse_2eorg_2fVerse_N_RPrint_L_N_Kchar_M_Nfloat_M_Ncolor_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RPrint_L_N_Kchar_M_Nfloat_M_Ncolor_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x807bb90
	void _L_2fVerse_2eorg_2fVerse_N_RPow_L_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RPow_L_Nfloat_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb88
	void _L_2fVerse_2eorg_2fVerse_N_RMod_L_Nint_M_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMod_L_Nint_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb80
	void _L_2fVerse_2eorg_2fVerse_N_RMin_L_Nint_M_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMin_L_Nint_M_Nint_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RMin_L_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMin_L_Nfloat_M_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RMax_L_Nint_M_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMax_L_Nint_M_Nint_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RMax_L_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMax_L_Nfloat_M_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RMakeMessageInternal_L_N_Kchar_M_N_Kchar_M_N_5b_Kchar_5dlocalizable__value_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMakeMessageInternal_L_N_Kchar_M_N_Kchar_M_N_5b_Kchar_5dlocalizable__value_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb78
	void _L_2fVerse_2eorg_2fVerse_N_RMakeLocalizableValue_L_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMakeLocalizableValue_L_Nint_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RMakeLocalizableValue_L_N_Kchar_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMakeLocalizableValue_L_N_Kchar_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RMakeLocalizableValue_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RMakeLocalizableValue_L_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RLog_L_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLog_L_Nfloat_M_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RLocalizeInternal_L_N_Kchar_M_N_Kchar_M_N_Ktuple_L_Kchar_M_Kchar_R_M_Nlocale_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLocalizeInternal_L_N_Kchar_M_N_Kchar_M_N_Ktuple_L_Kchar_M_Kchar_R_M_Nlocale_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb70
	void _L_2fVerse_2eorg_2fVerse_N_RLocalize_L_Nfloat_M_Nlocale_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLocalize_L_Nfloat_M_Nlocale_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RLocalize_L_Nint_M_Nlocale_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLocalize_L_Nint_M_Nlocale_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RLocalize_L_N_Kchar_M_Nlocale_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLocalize_L_N_Kchar_M_Nlocale_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RLocalize_L_Nmessage_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLocalize_L_Nmessage_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RLn_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLn_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb68
	void _L_2fVerse_2eorg_2fVerse_N_RLerp_L_Nfloat_M_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RLerp_L_Nfloat_M_Nfloat_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb60
	void _L_2fVerse_2eorg_2fVerse_N_RJoin_L_N_K_Kchar_M_N_Kchar_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RJoin_L_N_K_Kchar_M_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb58
	void _L_2fVerse_2eorg_2fVerse_N_RIsAlmostEqual_L_Nfloat_M_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RIsAlmostEqual_L_Nfloat_M_Nfloat_M_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RInt_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RInt_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb50
	void _L_2fVerse_2eorg_2fVerse_N_RFloor_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RFloor_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb48
	void _L_2fVerse_2eorg_2fVerse_N_RExp_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RExp_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb40
	void _L_2fVerse_2eorg_2fVerse_N_RErr_L_N_Kchar_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RErr_L_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb38
	void _L_2fVerse_2eorg_2fVerse_N_RCosh_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RCosh_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb30
	void _L_2fVerse_2eorg_2fVerse_N_RCos_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RCos_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb28
	void _L_2fVerse_2eorg_2fVerse_N_RConcatenate_L_N_K_Kt_20where_20t_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RConcatenate_L_N_K_Kt_20where_20t_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RClamp_L_Nfloat_M_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RClamp_L_Nfloat_M_Nfloat_M_Nfloat_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_N_RClamp_L_Nint_M_Nint_M_Nint_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RClamp_L_Nint_M_Nint_M_Nint_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb20
	void _L_2fVerse_2eorg_2fVerse_N_RCeil_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RCeil_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb18
	void _L_2fVerse_2eorg_2fVerse_N_RArcTan_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArcTan_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb10
	void _L_2fVerse_2eorg_2fVerse_N_RArcTan_L_Nfloat_M_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArcTan_L_Nfloat_M_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb08
	void _L_2fVerse_2eorg_2fVerse_N_RArcSin_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArcSin_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bb00
	void _L_2fVerse_2eorg_2fVerse_N_RArcCos_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArcCos_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807baf8
	void _L_2fVerse_2eorg_2fVerse_N_RArTanh_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArTanh_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807baf0
	void _L_2fVerse_2eorg_2fVerse_N_RArSinh_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArSinh_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bae8
	void _L_2fVerse_2eorg_2fVerse_N_RArCosh_L_Nfloat_R(); // Function Verse.Verse._L_2fVerse_2eorg_2fVerse_N_RArCosh_L_Nfloat_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x807bae0
	void Verse_locale$Factory(); // Function Verse.Verse.Verse_locale$Factory // (Static|HasOutParms) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Verse.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Verse_cancelable
// Size: 0x28 (Inherited: 0x28)
struct UVerse_cancelable : UObject {

	void _L_2fVerse_2eorg_2fVerse_2fcancelable_N_RCancel(); // Function Verse.Verse_cancelable._L_2fVerse_2eorg_2fVerse_2fcancelable_N_RCancel // (Public|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass Verse.Verse_disposable
// Size: 0x28 (Inherited: 0x28)
struct UVerse_disposable : UObject {

	void _L_2fVerse_2eorg_2fVerse_2fdisposable_N_RDispose(); // Function Verse.Verse_disposable._L_2fVerse_2eorg_2fVerse_2fdisposable_N_RDispose // (Public|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass Verse.Verse_event
// Size: 0x80 (Inherited: 0x28)
struct UVerse_event : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x58]; // 0x28(0x58)

	void _L_2fVerse_2eorg_2fVerse_2fsignalable_2fsignalable_Lpayload_R_N_RSignal_L_Npayload_R(); // Function Verse.Verse_event._L_2fVerse_2eorg_2fVerse_2fsignalable_2fsignalable_Lpayload_R_N_RSignal_L_Npayload_R // (Native|Public|BlueprintCallable) // @ game+0x807bad8
	void _L_2fVerse_2eorg_2fVerse_2fevent_2fevent_Lt_R_N_RGetAwaitCount(); // Function Verse.Verse_event._L_2fVerse_2eorg_2fVerse_2fevent_2fevent_Lt_R_N_RGetAwaitCount // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x807bad0
	void Await(); // Function Verse.Verse_event.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function Verse.Verse_event.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function Verse.Verse_event.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Verse_event.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Verse_invalidatable
// Size: 0x28 (Inherited: 0x28)
struct UVerse_invalidatable : UObject {

	void _L_2fVerse_2eorg_2fVerse_2finvalidatable_N_RIsValid(); // Function Verse.Verse_invalidatable._L_2fVerse_2eorg_2fVerse_2finvalidatable_N_RIsValid // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass Verse.Verse_listenable
// Size: 0x28 (Inherited: 0x28)
struct UVerse_listenable : UObject {
};

// VerseClass Verse.Verse_localizable_float
// Size: 0x40 (Inherited: 0x28)
struct UVerse_localizable_float : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	double  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x2c3(0x10802000)
	 ; // 0x00(0x00)

	void _L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R(); // Function Verse.Verse_localizable_float._L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function Verse.Verse_localizable_float.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function Verse.Verse_localizable_float.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Verse_localizable_float.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Verse_localizable_int
// Size: 0x40 (Inherited: 0x28)
struct UVerse_localizable_int : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	int64_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x2c3(0x10802000)
	 ; // 0x00(0x00)

	void _L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R(); // Function Verse.Verse_localizable_int._L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function Verse.Verse_localizable_int.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function Verse.Verse_localizable_int.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Verse_localizable_int.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Verse_localizable_string
// Size: 0x48 (Inherited: 0x28)
struct UVerse_localizable_string : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x20]; // 0x28(0x20)

	void _L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R(); // Function Verse.Verse_localizable_string._L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function Verse.Verse_localizable_string.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function Verse.Verse_localizable_string.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Verse_localizable_string.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Verse_localizable_value
// Size: 0x28 (Inherited: 0x28)
struct UVerse_localizable_value : UObject {

	void _L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R(); // Function Verse.Verse_localizable_value._L_2fVerse_2eorg_2fVerse_2flocalizable__value_N_RLocalizeValue_L_Nlocale_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass Verse.Verse_message
// Size: 0x98 (Inherited: 0x28)
struct UVerse_message : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x70]; // 0x28(0x70)

	void $InitInstance(); // Function Verse.Verse_message.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function Verse.Verse_message.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function Verse.Verse_message.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass Verse.Verse_signalable
// Size: 0x28 (Inherited: 0x28)
struct UVerse_signalable : UObject {

	void _L_2fVerse_2eorg_2fVerse_2fsignalable_2fsignalable_Lpayload_R_N_RSignal_L_Npayload_R(); // Function Verse.Verse_signalable._L_2fVerse_2eorg_2fVerse_2fsignalable_2fsignalable_Lpayload_R_N_RSignal_L_Npayload_R // (Public|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass Verse.Verse_subscribable
// Size: 0x28 (Inherited: 0x28)
struct UVerse_subscribable : UObject {

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function Verse.Verse_subscribable._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

