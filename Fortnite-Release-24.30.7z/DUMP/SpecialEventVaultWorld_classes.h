// BlueprintGeneratedClass SpecialEventVaultWorld.SpecialEventVaultWorld_C
// Size: 0x3c8 (Inherited: 0x341)
struct ASpecialEventVaultWorld_C : AVaultWorld_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_341[0x87]; // 0x341(0x87)

	void TransitionBackgroundBackward(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.TransitionBackgroundBackward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionBackgroundForward(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.TransitionBackgroundForward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetupBackgroundMaterial(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.SetupBackgroundMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UserConstructionScript(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionForward__FinishedFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.TransitionForward__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void TransitionForward__UpdateFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.TransitionForward__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void TransitionBackward__FinishedFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.TransitionBackward__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void TransitionBackward__UpdateFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.TransitionBackward__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void Background-Effects__FinishedFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.Background-Effects__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void Background-Effects__UpdateFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.Background-Effects__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void Floor-Visibility__FinishedFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.Floor-Visibility__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void Floor-Visibility__UpdateFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.Floor-Visibility__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void ItemDetails__FinishedFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.ItemDetails__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void ItemDetails__UpdateFunc(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.ItemDetails__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void ReceiveBeginPlay(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnTransitionBackground(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.OnTransitionBackground // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSetupBackground(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.OnSetupBackground // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnUpdateDisplay(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.OnUpdateDisplay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInitialBackgroundTransition(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.OnInitialBackgroundTransition // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnTransitionItemDetails(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnUpdateMaterialIndex(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.OnUpdateMaterialIndex // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_SpecialEventVaultWorld(); // Function SpecialEventVaultWorld.SpecialEventVaultWorld_C.ExecuteUbergraph_SpecialEventVaultWorld // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

