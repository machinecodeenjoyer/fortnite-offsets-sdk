// Class ModelViewViewModel.MVVMViewModelContextResolver
// Size: 0x28 (Inherited: 0x28)
struct UMVVMViewModelContextResolver : UObject {

	void K2_CreateInstance(); // Function ModelViewViewModel.MVVMViewModelContextResolver.K2_CreateInstance // (Event|Public|BlueprintEvent|Const) // @ game+0x179ea74
};

// Class ModelViewViewModel.MVVMGameSubsystem
// Size: 0x38 (Inherited: 0x30)
struct UMVVMGameSubsystem : UGameInstanceSubsystem {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2200]; // 0x00(0x18022000)
	 ; // 0x00(0x00)

	void GetViewModelCollection(); // Function ModelViewViewModel.MVVMGameSubsystem.GetViewModelCollection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x706ceb8
};

// Class ModelViewViewModel.MVVMSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UMVVMSubsystem : UEngineSubsystem {

	void K2_GetViewFromUserWidget(); // Function ModelViewViewModel.MVVMSubsystem.K2_GetViewFromUserWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x863ce60
	void K2_GetAvailableBindings(); // Function ModelViewViewModel.MVVMSubsystem.K2_GetAvailableBindings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x863ca84
	void K2_GetAvailableBinding(); // Function ModelViewViewModel.MVVMSubsystem.K2_GetAvailableBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x863c590
	void GetGlobalViewModelCollection(); // Function ModelViewViewModel.MVVMSubsystem.GetGlobalViewModelCollection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7783d10
	void DoesWidgetTreeContainedWidget(); // Function ModelViewViewModel.MVVMSubsystem.DoesWidgetTreeContainedWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x863b950
};

// Class ModelViewViewModel.MVVMViewModelBase
// Size: 0x68 (Inherited: 0x28)
struct UMVVMViewModelBase : UObject {
	char pad_28[0x40]; // 0x28(0x40)

	void K2_SetPropertyValue(); // Function ModelViewViewModel.MVVMViewModelBase.K2_SetPropertyValue // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x863d2a4
	void K2_RemoveFieldValueChangedDelegate(); // Function ModelViewViewModel.MVVMViewModelBase.K2_RemoveFieldValueChangedDelegate // (Final|Native|Public|BlueprintCallable) // @ game+0x863cfd8
	void K2_BroadcastFieldValueChanged(); // Function ModelViewViewModel.MVVMViewModelBase.K2_BroadcastFieldValueChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0x863c3fc
	void K2_AddFieldValueChangedDelegate(); // Function ModelViewViewModel.MVVMViewModelBase.K2_AddFieldValueChangedDelegate // (Final|Native|Public|BlueprintCallable) // @ game+0x863c130
};

// Class ModelViewViewModel.MVVMViewModelCollectionObject
// Size: 0x50 (Inherited: 0x28)
struct UMVVMViewModelCollectionObject : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x28]; // 0x28(0x28)

	void RemoveViewModel(); // Function ModelViewViewModel.MVVMViewModelCollectionObject.RemoveViewModel // (Final|Native|Public|BlueprintCallable) // @ game+0x863d804
	void RemoveAllViewModelInstance(); // Function ModelViewViewModel.MVVMViewModelCollectionObject.RemoveAllViewModelInstance // (Final|Native|Public|BlueprintCallable) // @ game+0x863d674
	void FindViewModelInstance(); // Function ModelViewViewModel.MVVMViewModelCollectionObject.FindViewModelInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x863bdb0
	void FindFirstViewModelInstanceOfType(); // Function ModelViewViewModel.MVVMViewModelCollectionObject.FindFirstViewModelInstanceOfType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x863bce0
	void AddViewModelInstance(); // Function ModelViewViewModel.MVVMViewModelCollectionObject.AddViewModelInstance // (Final|Native|Public|BlueprintCallable) // @ game+0x863b6a8
};

// Class ModelViewViewModel.MVVMViewModelBlueprintGeneratedClass
// Size: 0x370 (Inherited: 0x350)
struct UMVVMViewModelBlueprintGeneratedClass : UBlueprintGeneratedClass {
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x80000000)
	 ; // 0x00(0x00)
};

// Class ModelViewViewModel.MVVMBindingSubsystem
// Size: 0x90 (Inherited: 0x30)
struct UMVVMBindingSubsystem : UEngineSubsystem {
	char pad_30[0x60]; // 0x30(0x60)
};

// Class ModelViewViewModel.MVVMView
// Size: 0x68 (Inherited: 0x28)
struct UMVVMView : UUserWidgetExtension {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x82208]; // 0x2c3(0x1ae22080)
	 ; // 0x00(0x00)

	void SetViewModelByClass(); // Function ModelViewViewModel.MVVMView.SetViewModelByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x863dc3c
	void SetViewModel(); // Function ModelViewViewModel.MVVMView.SetViewModel // (Final|Native|Public|BlueprintCallable) // @ game+0x863d994
	void GetViewModel(); // Function ModelViewViewModel.MVVMView.GetViewModel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x863bf78
};

// Class ModelViewViewModel.MVVMViewClass
// Size: 0xb0 (Inherited: 0x28)
struct UMVVMViewClass : UWidgetBlueprintGeneratedClassExtension {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x80010000)
	 ; // 0x00(0x00)
};

