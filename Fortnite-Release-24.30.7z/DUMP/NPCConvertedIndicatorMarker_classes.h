// WidgetBlueprintGeneratedClass NPCConvertedIndicatorMarker.NPCConvertedIndicatorMarker_C
// Size: 0x660 (Inherited: 0x638)
struct UNPCConvertedIndicatorMarker_C : UAthenaMarkedActorIndicator {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_638[0x28]; // 0x638(0x28)

	void OnSetMarkerData(); // Function NPCConvertedIndicatorMarker.NPCConvertedIndicatorMarker_C.OnSetMarkerData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnPingCommandEvent(); // Function NPCConvertedIndicatorMarker.NPCConvertedIndicatorMarker_C.OnPingCommandEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_NPCConvertedIndicatorMarker(); // Function NPCConvertedIndicatorMarker.NPCConvertedIndicatorMarker_C.ExecuteUbergraph_NPCConvertedIndicatorMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

