// WidgetBlueprintGeneratedClass MissedInvitesEntry.MissedInvitesEntry_C
// Size: 0x14e0 (Inherited: 0x1490)
struct UMissedInvitesEntry_C : UFortMissedInvitesListEntry {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1490[0x50]; // 0x1490(0x50)

	void BP_OnUnhovered(); // Function MissedInvitesEntry.MissedInvitesEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(); // Function MissedInvitesEntry.MissedInvitesEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function MissedInvitesEntry.MissedInvitesEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_MissedInvitesEntry(); // Function MissedInvitesEntry.MissedInvitesEntry_C.ExecuteUbergraph_MissedInvitesEntry // (Final|UbergraphFunction) // @ game+0x179ea74
};

