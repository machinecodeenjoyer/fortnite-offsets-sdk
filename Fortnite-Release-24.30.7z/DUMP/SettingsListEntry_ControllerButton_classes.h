// WidgetBlueprintGeneratedClass SettingsListEntry_ControllerButton.SettingsListEntry_ControllerButton_C
// Size: 0x330 (Inherited: 0x320)
struct USettingsListEntry_ControllerButton_C : UFortSettingsListEntrySetting_ControllerButton {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_320[0x10]; // 0x320(0x10)

	void OnSettingAssigned(); // Function SettingsListEntry_ControllerButton.SettingsListEntry_ControllerButton_C.OnSettingAssigned // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__Button_ControllerAction_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(); // Function SettingsListEntry_ControllerButton.SettingsListEntry_ControllerButton_C.BndEvt__Button_ControllerAction_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_SettingsListEntry_ControllerButton(); // Function SettingsListEntry_ControllerButton.SettingsListEntry_ControllerButton_C.ExecuteUbergraph_SettingsListEntry_ControllerButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

