// BlueprintGeneratedClass GE_RiftPortal_Teleported.GE_RiftPortal_Teleported_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_RiftPortal_Teleported_C : UGameplayEffect {
};

