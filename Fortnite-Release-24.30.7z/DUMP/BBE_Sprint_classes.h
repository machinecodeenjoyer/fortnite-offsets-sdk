// BlueprintGeneratedClass BBE_Sprint.BBE_Sprint_C
// Size: 0x70 (Inherited: 0x70)
struct UBBE_Sprint_C : UFortMobileActionButtonBehaviorExtension {
};

