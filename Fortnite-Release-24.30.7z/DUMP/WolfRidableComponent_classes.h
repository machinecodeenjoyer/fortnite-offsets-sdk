// BlueprintGeneratedClass WolfRidableComponent.WolfRidableComponent_C
// Size: 0xbd0 (Inherited: 0xbd0)
struct UWolfRidableComponent_C : UCreatureBaseRidableComponent_C {
};

