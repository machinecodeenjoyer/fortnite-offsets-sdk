// BlueprintGeneratedClass GE_Damage_Explosive_LineOfSight.GE_Damage_Explosive_LineOfSight_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Damage_Explosive_LineOfSight_C : UGE_Ranged_GenericDamage_Explosive_C {
};

