// WidgetBlueprintGeneratedClass PressAnyKey.PressAnyKey_C
// Size: 0x590 (Inherited: 0x590)
struct UPressAnyKey_C : UFortSettingsPressAnyKey {
};

