// BlueprintGeneratedClass GCN_Loop_CreativeInvulnerable.GCN_Loop_CreativeInvulnerable_C
// Size: 0x9d0 (Inherited: 0x9d0)
struct AGCN_Loop_CreativeInvulnerable_C : AGCN_Loop_GhostMode_C {
};

