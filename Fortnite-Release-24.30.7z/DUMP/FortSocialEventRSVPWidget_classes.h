// WidgetBlueprintGeneratedClass FortSocialEventRSVPWidget.FortSocialEventRSVPWidget_C
// Size: 0x2c1 (Inherited: 0x298)
struct UFortSocialEventRSVPWidget_C : UFortSocialEventRSVPWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x29]; // 0x298(0x29)

	void Construct(); // Function FortSocialEventRSVPWidget.FortSocialEventRSVPWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnRefreshDisplay(); // Function FortSocialEventRSVPWidget.FortSocialEventRSVPWidget_C.OnRefreshDisplay // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_FortSocialEventRSVPWidget(); // Function FortSocialEventRSVPWidget.FortSocialEventRSVPWidget_C.ExecuteUbergraph_FortSocialEventRSVPWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

