// Class AIPatrolPath.AIPatrolPathComponent
// Size: 0x348 (Inherited: 0xa0)
struct UAIPatrolPathComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct TSoftClassPtr<UObject>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10001]; // 0x2c3(0x82c0800)
	 ; // 0x00(0x00)

	void SyncSharedUserOptions(); // Function AIPatrolPath.AIPatrolPathComponent.SyncSharedUserOptions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb416064
	void ShouldRenderPath(); // Function AIPatrolPath.AIPatrolPathComponent.ShouldRenderPath // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetRenderPath(); // Function AIPatrolPath.AIPatrolPathComponent.SetRenderPath // (Final|Native|Public|BlueprintCallable) // @ game+0xb415ef4
	void SetPatrolPathGroup(); // Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathGroup // (Final|Native|Public|BlueprintCallable) // @ game+0xb415bec
	void SetPatrolPathEnabled(); // Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0xb415a6c
	void SetPatrollingMode(); // Function AIPatrolPath.AIPatrolPathComponent.SetPatrollingMode // (Final|Native|Public|BlueprintCallable) // @ game+0xb415d68
	void RequestRenderPath(); // Function AIPatrolPath.AIPatrolPathComponent.RequestRenderPath // (Final|Native|Public|BlueprintCallable) // @ game+0xb4159f8
	void RenderToNextPoint(); // Function AIPatrolPath.AIPatrolPathComponent.RenderToNextPoint // (Final|Native|Public|BlueprintCallable) // @ game+0xb4159e4
	void RenderToNextAndPreviousPoint(); // Function AIPatrolPath.AIPatrolPathComponent.RenderToNextAndPreviousPoint // (Final|Native|Public|BlueprintCallable) // @ game+0xb415960
	void RemovePoint(); // Function AIPatrolPath.AIPatrolPathComponent.RemovePoint // (Final|Native|Public|BlueprintCallable) // @ game+0xb41593c
	void PropagatePatrolPathPointIndexToDevice(); // Function AIPatrolPath.AIPatrolPathComponent.PropagatePatrolPathPointIndexToDevice // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void PropagatePatrolPathIndexToDevice(); // Function AIPatrolPath.AIPatrolPathComponent.PropagatePatrolPathIndexToDevice // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ProcessDevicePropertyUpdate(); // Function AIPatrolPath.AIPatrolPathComponent.ProcessDevicePropertyUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0xb415464
	void PatrolPointReached(); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPointReached // (Final|Native|Private) // @ game+0xb4151e0
	void PatrolPointFailedToReach(); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPointFailedToReach // (Final|Native|Private) // @ game+0xb414f5c
	void PatrolPathStopped(); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStopped // (Final|Native|Private) // @ game+0xb414dec
	void PatrolPathStarted(); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStarted // (Final|Native|Private) // @ game+0xb414c7c
	void OnPatrolPathGroupsMerged(); // Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathGroupsMerged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPatrolPathActorAssigned(); // Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathActorAssigned // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPathExtremitiesChanged(); // Function AIPatrolPath.AIPatrolPathComponent.OnPathExtremitiesChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void HasValidPatrolPath(); // Function AIPatrolPath.AIPatrolPathComponent.HasValidPatrolPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb414bf8
	void GetPatrolPathPointIndexFromDevice(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndexFromDevice // (Event|Public|BlueprintEvent|Const) // @ game+0x179ea74
	void GetPatrolPathPointIndex(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb414b98
	void GetPatrolPathPoint(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb414904
	void GetPatrolPathIndexFromDevice(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndexFromDevice // (Event|Public|BlueprintEvent|Const) // @ game+0x179ea74
	void GetPatrolPathIndex(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4148e0
	void GetPatrolFilterOptions(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolFilterOptions // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void GetNextAvailablePatrolPathIndex(); // Function AIPatrolPath.AIPatrolPathComponent.GetNextAvailablePatrolPathIndex // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb414848
	void GetLinkedPatrolPoints(); // Function AIPatrolPath.AIPatrolPathComponent.GetLinkedPatrolPoints // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4146d0
	void GeneratePathPoints(); // Function AIPatrolPath.AIPatrolPathComponent.GeneratePathPoints // (Final|Native|Public|BlueprintCallable) // @ game+0xb414560
	void CanNextPointBeReached(); // Function AIPatrolPath.AIPatrolPathComponent.CanNextPointBeReached // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb414540
};

