// Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAutomationUtilsBlueprintLibrary : UBlueprintFunctionLibrary {

	void TakeGameplayAutomationScreenshot(); // Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ee7848
};

