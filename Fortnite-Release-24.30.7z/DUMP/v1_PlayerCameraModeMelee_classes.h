// BlueprintGeneratedClass v1_PlayerCameraModeMelee.v1_PlayerCameraModeMelee_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct Uv1_PlayerCameraModeMelee_C : Uv1_PlayerCameraModeBase_C {
};

