// BlueprintGeneratedClass WrapPreview.WrapPreview_C
// Size: 0x5d4 (Inherited: 0x520)
struct AWrapPreview_C : AAthenaWrapPreviewActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_520[0xb4]; // 0x520(0xb4)

	void UpdateFloorVisibility(); // Function WrapPreview.WrapPreview_C.UpdateFloorVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwitchErebusLighting(); // Function WrapPreview.WrapPreview_C.SwitchErebusLighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateLightingScale(); // Function WrapPreview.WrapPreview_C.UpdateLightingScale // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetFloorEnabled(); // Function WrapPreview.WrapPreview_C.SetFloorEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void LightControl(); // Function WrapPreview.WrapPreview_C.LightControl // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwitchPCLighting(); // Function WrapPreview.WrapPreview_C.SwitchPCLighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwitchMobileLighting(); // Function WrapPreview.WrapPreview_C.SwitchMobileLighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void HandleLightingScale(); // Function WrapPreview.WrapPreview_C.HandleLightingScale // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateSettings(); // Function WrapPreview.WrapPreview_C.UpdateSettings // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnSetFloorMaterial(); // Function WrapPreview.WrapPreview_C.OnSetFloorMaterial // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPreviewVisualsSpawned(); // Function WrapPreview.WrapPreview_C.OnPreviewVisualsSpawned // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnUpdateFloorMaterial(); // Function WrapPreview.WrapPreview_C.OnUpdateFloorMaterial // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WrapPreview(); // Function WrapPreview.WrapPreview_C.ExecuteUbergraph_WrapPreview // (Final|UbergraphFunction) // @ game+0x179ea74
};

