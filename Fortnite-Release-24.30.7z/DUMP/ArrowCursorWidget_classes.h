// WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C
// Size: 0x298 (Inherited: 0x298)
struct UArrowCursorWidget_C : UUserWidget {

	void (); // Function ArrowCursorWidget.ArrowCursorWidget_C. // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
};

