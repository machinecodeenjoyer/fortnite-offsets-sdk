// BlueprintGeneratedClass TextStyle-Base-S-B-Blue.TextStyle-Base-S-B-Blue_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-Base-S-B-Blue_C : UTextStyle-Base-S-B_C {
};

