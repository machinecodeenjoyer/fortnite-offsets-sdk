// WidgetBlueprintGeneratedClass JoinRequestUserListEntry.JoinRequestUserListEntry_C
// Size: 0x1580 (Inherited: 0x1520)
struct UJoinRequestUserListEntry_C : UFortSocialUserListEntry {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1520[0x60]; // 0x1520(0x60)

	void BP_OnUnhovered(); // Function JoinRequestUserListEntry.JoinRequestUserListEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(); // Function JoinRequestUserListEntry.JoinRequestUserListEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function JoinRequestUserListEntry.JoinRequestUserListEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnFocusLost(); // Function JoinRequestUserListEntry.JoinRequestUserListEntry_C.OnFocusLost // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_JoinRequestUserListEntry(); // Function JoinRequestUserListEntry.JoinRequestUserListEntry_C.ExecuteUbergraph_JoinRequestUserListEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

