// BlueprintGeneratedClass GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C
// Size: 0xa68 (Inherited: 0x972)
struct AGCNL_Athena_SnowSurface_C : AGCNL_Athena_Surface_Parent_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_972[0xf6]; // 0x972(0xf6)

	void OnPlayerFootstep(); // Function GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C.OnPlayerFootstep // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStartNiagara(); // Function GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C.OnLoopingStartNiagara // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStart(); // Function GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C.OnLoopingStart // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemoval(); // Function GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C.OnRemoval // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void K2_HandleGameplayCue(); // Function GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_Athena_SnowSurface(); // Function GCNL_Athena_SnowSurface.GCNL_Athena_SnowSurface_C.ExecuteUbergraph_GCNL_Athena_SnowSurface // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

