// BlueprintGeneratedClass PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C
// Size: 0x5560 (Inherited: 0x5470)
struct APlayerPawn_Athena_Generic_Parent_C : AFortPlayerPawnAthena {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_5470[0xf0]; // 0x5470(0xf0)

	void ReceiveBeginPlay(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnEnteredVehicle(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.OnEnteredVehicle // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnExitedVehicle(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.OnExitedVehicle // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnJumped(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.OnJumped // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void K2_OnStartCrouch(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.K2_OnStartCrouch // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndCrouch(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.K2_OnEndCrouch // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PlayerPawn_Athena_Generic_Parent(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.ExecuteUbergraph_PlayerPawn_Athena_Generic_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
	void OnExitedVehicleDispatcher__DelegateSignature(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.OnExitedVehicleDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnEnteredVehicleDispatcher__DelegateSignature(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.OnEnteredVehicleDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPlayHit__DelegateSignature(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.OnPlayHit__DelegateSignature // (Public|Delegate|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ShootingTargetReactToJump__DelegateSignature(); // Function PlayerPawn_Athena_Generic_Parent.PlayerPawn_Athena_Generic_Parent_C.ShootingTargetReactToJump__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

