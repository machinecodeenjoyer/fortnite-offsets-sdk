// BlueprintGeneratedClass PBWA_M1_Windows.PBWA_M1_Windows_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_M1_Windows_C : ABuildingWall {
};

