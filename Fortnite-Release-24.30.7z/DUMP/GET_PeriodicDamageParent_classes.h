// BlueprintGeneratedClass GET_PeriodicDamageParent.GET_PeriodicDamageParent_C
// Size: 0x858 (Inherited: 0x858)
struct UGET_PeriodicDamageParent_C : UGET_AfflictedParent_C {
};

