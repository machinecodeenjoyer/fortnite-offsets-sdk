// WidgetBlueprintGeneratedClass WBP_UIKit_Button_Regular.WBP_UIKit_Button_Regular_C
// Size: 0x1a21 (Inherited: 0x1a18)
struct UWBP_UIKit_Button_Regular_C : UWBP_UIKit_ButtonCTA_Base_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1A18[0x9]; // 0x1a18(0x09)

	void OverrideFontMaterials(); // Function WBP_UIKit_Button_Regular.WBP_UIKit_Button_Regular_C.OverrideFontMaterials // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PreConstruct(); // Function WBP_UIKit_Button_Regular.WBP_UIKit_Button_Regular_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WBP_UIKit_Button_Regular(); // Function WBP_UIKit_Button_Regular.WBP_UIKit_Button_Regular_C.ExecuteUbergraph_WBP_UIKit_Button_Regular // (Final|UbergraphFunction) // @ game+0x179ea74
};

