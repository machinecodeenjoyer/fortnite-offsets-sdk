// BlueprintGeneratedClass PlayerTakeDamage_CameraShake.PlayerTakeDamage_CameraShake_C
// Size: 0x210 (Inherited: 0x210)
struct UPlayerTakeDamage_CameraShake_C : ULegacyCameraShake {
};

