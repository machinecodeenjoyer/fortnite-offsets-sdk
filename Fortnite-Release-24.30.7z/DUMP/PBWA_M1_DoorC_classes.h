// BlueprintGeneratedClass PBWA_M1_DoorC.PBWA_M1_DoorC_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_M1_DoorC_C : ABuildingWall {
};

