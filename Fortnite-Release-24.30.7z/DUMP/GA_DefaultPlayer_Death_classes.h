// BlueprintGeneratedClass GA_DefaultPlayer_Death.GA_DefaultPlayer_Death_C
// Size: 0xd10 (Inherited: 0xcfc)
struct UGA_DefaultPlayer_Death_C : UGAB_GenericDeath_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_CFC[0x14]; // 0xcfc(0x14)

	void PickDeathMontageSection(); // Function GA_DefaultPlayer_Death.GA_DefaultPlayer_Death_C.PickDeathMontageSection // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_DefaultPlayer_Death(); // Function GA_DefaultPlayer_Death.GA_DefaultPlayer_Death_C.ExecuteUbergraph_GA_DefaultPlayer_Death // (Final|UbergraphFunction) // @ game+0x179ea74
};

