// Enum SidecarSys.EInventoryPersistenceMode
enum class EInventoryPersistenceMode : uint8 {
	Normal = 0,
	Deferred = 1,
	Disabled = 2,
	ReadOnly = 3,
	EInventoryPersistenceMode_MAX = 4
};

// ScriptStruct SidecarSys.SidecarFileInfo
// Size: 0x68 (Inherited: 0x00)
struct FSidecarFileInfo {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0x68]; // 0x00(0x68)
};

