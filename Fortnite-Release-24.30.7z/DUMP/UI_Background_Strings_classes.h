// WidgetBlueprintGeneratedClass UI_Background_Strings.UI_Background_Strings_C
// Size: 0x2c0 (Inherited: 0x298)
struct UUI_Background_Strings_C : UUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x28]; // 0x298(0x28)

	void PreConstruct(); // Function UI_Background_Strings.UI_Background_Strings_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function UI_Background_Strings.UI_Background_Strings_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_UI_Background_Strings(); // Function UI_Background_Strings.UI_Background_Strings_C.ExecuteUbergraph_UI_Background_Strings // (Final|UbergraphFunction) // @ game+0x179ea74
};

