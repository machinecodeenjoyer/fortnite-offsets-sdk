// BlueprintGeneratedClass GA_GrindRail_KeybindDisplay.GA_GrindRail_KeybindDisplay_C
// Size: 0xb50 (Inherited: 0xb48)
struct UGA_GrindRail_KeybindDisplay_C : UFortGameplayAbility_KeybindDisplay {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B48[0x8]; // 0xb48(0x08)

	void K2_ActivateAbility(); // Function GA_GrindRail_KeybindDisplay.GA_GrindRail_KeybindDisplay_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_GrindRail_KeybindDisplay(); // Function GA_GrindRail_KeybindDisplay.GA_GrindRail_KeybindDisplay_C.ExecuteUbergraph_GA_GrindRail_KeybindDisplay // (Final|UbergraphFunction) // @ game+0x179ea74
};

