// Class DeploymentConsole.DeploymentConsoleComponent
// Size: 0x238 (Inherited: 0xa0)
struct UDeploymentConsoleComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x204]; // 0x2c3(0x40902000)
	 ; // 0x00(0x00)

	void SpawnAircrafts(); // Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircrafts // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xb29ecf8
	void SpawnAircraft(); // Function DeploymentConsole.DeploymentConsoleComponent.SpawnAircraft // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7a2b828
	void SetupTeamSpawnPoints(); // Function DeploymentConsole.DeploymentConsoleComponent.SetupTeamSpawnPoints // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x70883c8
	void SetPlayerIsWaiting(); // Function DeploymentConsole.DeploymentConsoleComponent.SetPlayerIsWaiting // (Final|Native|Public|BlueprintCallable) // @ game+0xb29ea4c
	void SetAircraftLock(); // Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftLock // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x70883c8
	void SetAircraftDropZone(); // Function DeploymentConsole.DeploymentConsoleComponent.SetAircraftDropZone // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb29e9e8
	void RetrievePlayerSpawnLocation(); // Function DeploymentConsole.DeploymentConsoleComponent.RetrievePlayerSpawnLocation // (Final|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb29e668
	void MoveBoxTo(); // Function DeploymentConsole.DeploymentConsoleComponent.MoveBoxTo // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xb29e524
	void InitializeFlightPath(); // Function DeploymentConsole.DeploymentConsoleComponent.InitializeFlightPath // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb29e368
	void GetTeamSpawnData(); // Function DeploymentConsole.DeploymentConsoleComponent.GetTeamSpawnData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29e2ec
	void GetSpawnPoints(); // Function DeploymentConsole.DeploymentConsoleComponent.GetSpawnPoints // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29e2d0
	void GetMinigameTeamsWithPlayers(); // Function DeploymentConsole.DeploymentConsoleComponent.GetMinigameTeamsWithPlayers // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb29e064
	void GetMapInfo(); // Function DeploymentConsole.DeploymentConsoleComponent.GetMapInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29e040
	void GetDefaultFlightPathConstructionInfo(); // Function DeploymentConsole.DeploymentConsoleComponent.GetDefaultFlightPathConstructionInfo // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29dc48
	void GetCachedAircraftSpawnZone(); // Function DeploymentConsole.DeploymentConsoleComponent.GetCachedAircraftSpawnZone // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29dbbc
	void ForcePlayerEnterAircraft(); // Function DeploymentConsole.DeploymentConsoleComponent.ForcePlayerEnterAircraft // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0xb29d910
	void ConstructInventoryOnController(); // Function DeploymentConsole.DeploymentConsoleComponent.ConstructInventoryOnController // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x7194604
	void ClearFlightInfos(); // Function DeploymentConsole.DeploymentConsoleComponent.ClearFlightInfos // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|Const) // @ game+0xb29d8fc
	void CalculateSpawnRotationFromLocation(); // Function DeploymentConsole.DeploymentConsoleComponent.CalculateSpawnRotationFromLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29d854
	void AdjustLocationToValidHeight(); // Function DeploymentConsole.DeploymentConsoleComponent.AdjustLocationToValidHeight // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb29d7ac
};

// Class DeploymentConsole.FortAthenaMutator_CR_Respawn
// Size: 0x330 (Inherited: 0x330)
struct AFortAthenaMutator_CR_Respawn : AFortAthenaMutator {
};

