// BlueprintGeneratedClass GCL_BoostJumpPack_Hovering_Papaya.GCL_BoostJumpPack_Hovering_Papaya_C
// Size: 0xae0 (Inherited: 0xae0)
struct AGCL_BoostJumpPack_Hovering_Papaya_C : AGCL_BoostJumpPack_Hovering_Infinite_C {
};

