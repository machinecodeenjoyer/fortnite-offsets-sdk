// BlueprintGeneratedClass PBWA_BG_StairW.PBWA_BG_StairW_C
// Size: 0xd78 (Inherited: 0xd78)
struct APBWA_BG_StairW_C : ABuildingStairs {
};

