// WidgetBlueprintGeneratedClass LoginScreen.LoginScreen_C
// Size: 0x548 (Inherited: 0x4f8)
struct ULoginScreen_C : UFortUIStateWidget_Login {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_4F8[0x50]; // 0x4f8(0x50)

	void BndEvt__LoginScreen_Splash_Screen_K2Node_ComponentBoundEvent_0_OnWidgetActivationChanged__DelegateSignature(); // Function LoginScreen.LoginScreen_C.BndEvt__LoginScreen_Splash_Screen_K2Node_ComponentBoundEvent_0_OnWidgetActivationChanged__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function LoginScreen.LoginScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void SetKeyArtVisibility(); // Function LoginScreen.LoginScreen_C.SetKeyArtVisibility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnActivated(); // Function LoginScreen.LoginScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_LoginScreen(); // Function LoginScreen.LoginScreen_C.ExecuteUbergraph_LoginScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

