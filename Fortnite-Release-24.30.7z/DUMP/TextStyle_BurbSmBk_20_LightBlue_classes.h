// BlueprintGeneratedClass TextStyle_BurbSmBk_20_LightBlue.TextStyle_BurbSmBk_20_LightBlue_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle_BurbSmBk_20_LightBlue_C : UTextStyle-BaseParent_C {
};

