// BlueprintGeneratedClass StoreCardReveal_Parent.StoreCardReveal_Parent_C
// Size: 0x298 (Inherited: 0x288)
struct AStoreCardReveal_Parent_C : AActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_288[0x10]; // 0x288(0x10)

	void InitiatePinata(); // Function StoreCardReveal_Parent.StoreCardReveal_Parent_C.InitiatePinata // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_StoreCardReveal_Parent(); // Function StoreCardReveal_Parent.StoreCardReveal_Parent_C.ExecuteUbergraph_StoreCardReveal_Parent // (Final|UbergraphFunction) // @ game+0x179ea74
};

