// VerseClass VerseNative.$SolarisSignatureFunctionOuter
// Size: 0x28 (Inherited: 0x28)
struct U$SolarisSignatureFunctionOuter : UObject {
};

// VerseClass VerseNative.Concurrency
// Size: 0x28 (Inherited: 0x28)
struct UConcurrency : UObject {

	void _L_2fVerse_2eorg_2fConcurrency_N_Rtask_L_Ntype_R(); // Function VerseNative.Concurrency._L_2fVerse_2eorg_2fConcurrency_N_Rtask_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fConcurrency_N_Rawaitable_L_Ntype_R(); // Function VerseNative.Concurrency._L_2fVerse_2eorg_2fConcurrency_N_Rawaitable_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fConcurrency_N_Rawaitable(); // Function VerseNative.Concurrency._L_2fVerse_2eorg_2fConcurrency_N_Rawaitable // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitCDO(); // Function VerseNative.Concurrency.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseNative.Concurrency_awaitable
// Size: 0x28 (Inherited: 0x28)
struct UConcurrency_awaitable : UObject {

	void Await(); // Function VerseNative.Concurrency_awaitable.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VerseNative.Concurrency_mind
// Size: 0x58 (Inherited: 0x28)
struct UConcurrency_mind : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x30]; // 0x28(0x30)

	void _L_2fVerse_2eorg_2fConcurrency_2fmind_N_RGetNumActive(); // Function VerseNative.Concurrency_mind._L_2fVerse_2eorg_2fConcurrency_2fmind_N_RGetNumActive // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x80308f0
	void _L_2fVerse_2eorg_2fConcurrency_2fmind_N_RCancelAll(); // Function VerseNative.Concurrency_mind._L_2fVerse_2eorg_2fConcurrency_2fmind_N_RCancelAll // (Native|Public|BlueprintCallable) // @ game+0x80308e8
	void $InitInstance(); // Function VerseNative.Concurrency_mind.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseNative.Concurrency_mind.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseNative.Concurrency_mind.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseNative.Concurrency_task
// Size: 0x150 (Inherited: 0x28)
struct UConcurrency_task : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x128]; // 0x28(0x128)

	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RUnsettled(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RUnsettled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030938
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RUninterrupted(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RUninterrupted // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030930
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RSettled(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RSettled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030928
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RInterrupted(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RInterrupted // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030920
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCompleted(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCompleted // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030918
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCanceling(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCanceling // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030910
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCanceled(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCanceled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8030908
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCancel(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RCancel // (Native|Public|BlueprintCallable) // @ game+0x8030900
	void Await(); // Function VerseNative.Concurrency_task.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RActive(); // Function VerseNative.Concurrency_task._L_2fVerse_2eorg_2fConcurrency_2ftask_2ftask_Lt_R_N_RActive // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x80308f8
	void $InitInstance(); // Function VerseNative.Concurrency_task.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseNative.Concurrency_task.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseNative.Concurrency_task.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseNative.Native
// Size: 0x28 (Inherited: 0x28)
struct UNative : UObject {

	void $InitCDO(); // Function VerseNative.Native.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseNative.task_Concurrency_awaitable$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Concurrency_awaitable$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseNative.task_Concurrency_awaitable$Await.Update // (Public|HasOutParms) // @ game+0x179ea74
};

// VerseClass VerseNative.task_Concurrency_task$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Concurrency_task$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseNative.task_Concurrency_task$Await.Update // (Native|Public|HasOutParms) // @ game+0x80308e0
};

