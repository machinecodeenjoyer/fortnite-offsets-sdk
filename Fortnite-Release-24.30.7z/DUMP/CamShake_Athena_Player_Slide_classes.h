// BlueprintGeneratedClass CamShake_Athena_Player_Slide.CamShake_Athena_Player_Slide_C
// Size: 0x210 (Inherited: 0x210)
struct UCamShake_Athena_Player_Slide_C : ULegacyCameraShake {
};

