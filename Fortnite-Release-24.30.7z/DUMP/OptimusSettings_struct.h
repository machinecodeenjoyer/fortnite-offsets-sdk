// Enum OptimusSettings.EOptimusDefaultDeformerMode
enum class EOptimusDefaultDeformerMode : uint8 {
	Never = 0,
	SkinCacheOnly = 1,
	Always = 2,
	EOptimusDefaultDeformerMode_MAX = 3
};

