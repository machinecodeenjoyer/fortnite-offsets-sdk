// BlueprintGeneratedClass EnemyPawn_Interface.EnemyPawn_Interface_C
// Size: 0x28 (Inherited: 0x28)
struct UEnemyPawn_Interface_C : UInterface {

	void TriggerDeathFX(); // Function EnemyPawn_Interface.EnemyPawn_Interface_C.TriggerDeathFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Orphaned(); // Function EnemyPawn_Interface.EnemyPawn_Interface_C.Orphaned // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

