// BlueprintGeneratedClass TextStyle-BurbankSmall-XS-Gray.TextStyle-BurbankSmall-XS-Gray_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-BurbankSmall-XS-Gray_C : UTextStyle-BaseParent_C {
};

