// BlueprintGeneratedClass PBWA_BG_Archway.PBWA_BG_Archway_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_BG_Archway_C : ABuildingWall {
};

