// BlueprintGeneratedClass TeamID_PvP_05.TeamID_PvP_05_C
// Size: 0x38 (Inherited: 0x38)
struct UTeamID_PvP_05_C : UFortTeamIdentification {
};

