// BlueprintGeneratedClass GA_NPC_Parent.GA_NPC_Parent_C
// Size: 0xe60 (Inherited: 0xb28)
struct UGA_NPC_Parent_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x338]; // 0xb28(0x338)

	void NPC ResetRotationRate(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ResetRotationRate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC OverrideRotationRate(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC OverrideRotationRate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC GetGoalActor(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC GetGoalActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void NPC AbilityTargetIsBuildingWeAreDestroyingToNavigate(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC AbilityTargetIsBuildingWeAreDestroyingToNavigate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void NPC ApplyGameplayEffectWithMMRScaling(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ApplyGameplayEffectWithMMRScaling // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC ApplyGameplayAbilityCooldownWithMMRScaling(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ApplyGameplayAbilityCooldownWithMMRScaling // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC ScalableFloatIsValid(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ScalableFloatIsValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void NPC GetScalableFloatHotfixValue(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC GetScalableFloatHotfixValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void NPC SetAlertLevelByAIAbilityTargetType(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC SetAlertLevelByAIAbilityTargetType // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC SetAlertLevel(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC SetAlertLevel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC DoIntentionalFailedAttack(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC DoIntentionalFailedAttack // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC AttemptBuildFrustrationDueToMovement(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC AttemptBuildFrustrationDueToMovement // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC AttemptBuildFrustrationDueToGoal(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC AttemptBuildFrustrationDueToGoal // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC ClearFrustrationTagsForMovement(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ClearFrustrationTagsForMovement // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC ClearFrustrationTagsForGoals(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ClearFrustrationTagsForGoals // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void DestroyBuilding(); // Function GA_NPC_Parent.GA_NPC_Parent_C.DestroyBuilding // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC GenerateLaunchVelocityWithMinimumAngle(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC GenerateLaunchVelocityWithMinimumAngle // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_CanActivateAbility(); // Function GA_NPC_Parent.GA_NPC_Parent_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void NPC TryResetMovementUrgency(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC TryResetMovementUrgency // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC TrySetMovementUrgency(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC TrySetMovementUrgency // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC EQS Results(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC EQS Results // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC DebugFreezeFrame(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC DebugFreezeFrame // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC ApplyGameplayEffectContainerAndLaunchTargets(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC ApplyGameplayEffectContainerAndLaunchTargets // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC AbilityTargetIsWithinAngleThreshold(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC AbilityTargetIsWithinAngleThreshold // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC IsMontageInfoValid(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC IsMontageInfoValid // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void NPC AbilityDebugMessage(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC AbilityDebugMessage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void NPC SetupAbility(); // Function GA_NPC_Parent.GA_NPC_Parent_C.NPC SetupAbility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Cancelled_4BB5000E4F2C1DAB20E4FFAAA97E1368(); // Function GA_NPC_Parent.GA_NPC_Parent_C.Cancelled_4BB5000E4F2C1DAB20E4FFAAA97E1368 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Targeted_4BB5000E4F2C1DAB20E4FFAAA97E1368(); // Function GA_NPC_Parent.GA_NPC_Parent_C.Targeted_4BB5000E4F2C1DAB20E4FFAAA97E1368 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Cancelled_13B12ED64A3570FC1E117FAC4E3F7961(); // Function GA_NPC_Parent.GA_NPC_Parent_C.Cancelled_13B12ED64A3570FC1E117FAC4E3F7961 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Targeted_13B12ED64A3570FC1E117FAC4E3F7961(); // Function GA_NPC_Parent.GA_NPC_Parent_C.Targeted_13B12ED64A3570FC1E117FAC4E3F7961 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BeginDestroyBuildings(); // Function GA_NPC_Parent.GA_NPC_Parent_C.BeginDestroyBuildings // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_NPC_Parent(); // Function GA_NPC_Parent.GA_NPC_Parent_C.ExecuteUbergraph_GA_NPC_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

