// BlueprintGeneratedClass GE_ColdBreath_V2.GE_ColdBreath_V2_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_ColdBreath_V2_C : UGameplayEffect {
};

