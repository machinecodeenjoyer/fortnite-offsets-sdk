// BlueprintGeneratedClass CinematicCamera_MatineeTransition.CinematicCamera_MatineeTransition_C
// Size: 0x68 (Inherited: 0x68)
struct UCinematicCamera_MatineeTransition_C : UFortCinematicCamera {
};

