// BlueprintGeneratedClass GE_Blade_LeapSlam_BuildingDestroy.GE_Blade_LeapSlam_BuildingDestroy_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Blade_LeapSlam_BuildingDestroy_C : UGET_DirectPhysicalDamage_C {
};

