// BlueprintGeneratedClass FriendNotification.FriendNotification_C
// Size: 0x158 (Inherited: 0x150)
struct UFriendNotification_C : UFortUIFriendNotification {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_150[0x8]; // 0x150(0x08)

	void JoinPartyInvite(); // Function FriendNotification.FriendNotification_C.JoinPartyInvite // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ShowFriendInvites(); // Function FriendNotification.FriendNotification_C.ShowFriendInvites // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_FriendNotification(); // Function FriendNotification.FriendNotification_C.ExecuteUbergraph_FriendNotification // (Final|UbergraphFunction) // @ game+0x179ea74
};

