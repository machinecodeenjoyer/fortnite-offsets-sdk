// BlueprintGeneratedClass GE_Curie_FireInteract_Vehicle.GE_Curie_FireInteract_Vehicle_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Curie_FireInteract_Vehicle_C : UGameplayEffect {
};

