// AnimBlueprintGeneratedClass NitroFlow_Axe_AnimBP.NitroFlow_Axe_AnimBP_C
// Size: 0x830 (Inherited: 0x6f0)
struct UNitroFlow_Axe_AnimBP_C : UCustomCharacterPartAnimInstance {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_6F0[0x140]; // 0x6f0(0x140)

	void AnimGraph(); // Function NitroFlow_Axe_AnimBP.NitroFlow_Axe_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_NitroFlow_Axe_AnimBP(); // Function NitroFlow_Axe_AnimBP.NitroFlow_Axe_AnimBP_C.ExecuteUbergraph_NitroFlow_Axe_AnimBP // (Final|UbergraphFunction) // @ game+0x179ea74
};

