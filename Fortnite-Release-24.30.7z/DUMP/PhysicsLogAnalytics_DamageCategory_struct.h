// UserDefinedEnum PhysicsLogAnalytics_DamageCategory.PhysicsLogAnalytics_DamageCategory
enum class PhysicsLogAnalytics_DamageCategory : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	PhysicsLogAnalytics_MAX = 4
};

