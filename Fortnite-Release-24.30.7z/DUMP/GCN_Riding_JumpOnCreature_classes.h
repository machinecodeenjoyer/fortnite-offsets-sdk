// BlueprintGeneratedClass GCN_Riding_JumpOnCreature.GCN_Riding_JumpOnCreature_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Riding_JumpOnCreature_C : UFortGameplayCueNotify_Burst {
};

