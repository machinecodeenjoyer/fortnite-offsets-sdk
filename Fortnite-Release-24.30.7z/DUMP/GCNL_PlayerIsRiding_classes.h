// BlueprintGeneratedClass GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C
// Size: 0xa30 (Inherited: 0x960)
struct AGCNL_PlayerIsRiding_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0xd0]; // 0x960(0xd0)

	void CalculateVelocityParam(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.CalculateVelocityParam // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void WhileActive(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.WhileActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveBeginPlay(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ReceiveTick(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStartGeneric(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.OnLoopingStartGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void PlayerRidingGCNLStarted(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.PlayerRidingGCNLStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PlayerRidingDCNLEnded(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.PlayerRidingDCNLEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnJumpApex(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.OnJumpApex // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetUpRidableAudioEvents(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.SetUpRidableAudioEvents // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void StartLoopingAudio(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.StartLoopingAudio // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_PlayerIsRiding(); // Function GCNL_PlayerIsRiding.GCNL_PlayerIsRiding_C.ExecuteUbergraph_GCNL_PlayerIsRiding // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

