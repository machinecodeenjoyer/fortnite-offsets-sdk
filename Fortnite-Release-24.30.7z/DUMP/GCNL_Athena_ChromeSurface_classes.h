// BlueprintGeneratedClass GCNL_Athena_ChromeSurface.GCNL_Athena_ChromeSurface_C
// Size: 0x988 (Inherited: 0x972)
struct AGCNL_Athena_ChromeSurface_C : AGCNL_Athena_Surface_Parent_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_972[0x16]; // 0x972(0x16)

	void OnApplicationGeneric(); // Function GCNL_Athena_ChromeSurface.GCNL_Athena_ChromeSurface_C.OnApplicationGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCNL_Athena_ChromeSurface.GCNL_Athena_ChromeSurface_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_Athena_ChromeSurface(); // Function GCNL_Athena_ChromeSurface.GCNL_Athena_ChromeSurface_C.ExecuteUbergraph_GCNL_Athena_ChromeSurface // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

