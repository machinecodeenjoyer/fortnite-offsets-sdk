// BlueprintGeneratedClass GE_NPC_BehaviorPhaseIntroBehaviorCooldown_60s.GE_NPC_BehaviorPhaseIntroBehaviorCooldown_60s_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_NPC_BehaviorPhaseIntroBehaviorCooldown_60s_C : UGameplayEffect {
};

