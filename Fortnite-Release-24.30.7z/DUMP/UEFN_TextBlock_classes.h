// BlueprintGeneratedClass UEFN_TextBlock.UEFN_TextBlock_C
// Size: 0x350 (Inherited: 0x350)
struct UUEFN_TextBlock_C : UUEFNTextBlockBase {
};

