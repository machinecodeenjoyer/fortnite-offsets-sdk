// BlueprintGeneratedClass GCNL_RollingEffects_Wood.GCNL_RollingEffects_Wood_C
// Size: 0xae8 (Inherited: 0xae8)
struct AGCNL_RollingEffects_Wood_C : AGCNL_RollingEffects_Parent_C {
};

