// BlueprintGeneratedClass BBE_NevadaHonk.BBE_NevadaHonk_C
// Size: 0x70 (Inherited: 0x70)
struct UBBE_NevadaHonk_C : UFortMobileActionButtonBehaviorExtension {
};

