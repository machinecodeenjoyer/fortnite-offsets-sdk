// BlueprintGeneratedClass SR_Rock.SR_Rock_C
// Size: 0x450 (Inherited: 0x450)
struct USR_Rock_C : UStreamingRadioPlayerComponent_Rock {
};

