// BlueprintGeneratedClass BBE_TankBuildMode.BBE_TankBuildMode_C
// Size: 0x70 (Inherited: 0x70)
struct UBBE_TankBuildMode_C : UFortMobileActionButtonBehaviorExtension {
};

