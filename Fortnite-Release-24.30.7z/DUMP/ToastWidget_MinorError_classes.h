// WidgetBlueprintGeneratedClass ToastWidget_MinorError.ToastWidget_MinorError_C
// Size: 0x379 (Inherited: 0x2e8)
struct UToastWidget_MinorError_C : UFortToastWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2E8[0x91]; // 0x2e8(0x91)

	void SetupAnimBindings(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.SetupAnimBindings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ApplyAdditionalStyling(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.ApplyAdditionalStyling // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetOpenButtonVisibility(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.GetOpenButtonVisibility // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void StartIntro(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.StartIntro // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateToast(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.UpdateToast // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PlayOutro(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.PlayOutro // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMouseEnter(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnMouseLeave(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__OpenButton_K2Node_ComponentBoundEvent_5_CommonButtonClicked__DelegateSignature(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.BndEvt__OpenButton_K2Node_ComponentBoundEvent_5_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void HandleOutroFinished(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.HandleOutroFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void HandleIntroFinished(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.HandleIntroFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void Destruct(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPlayOpenAnimation(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.OnPlayOpenAnimation // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnNotificationSet(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.OnNotificationSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnNotificationUpdated(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.OnNotificationUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_ToastWidget_MinorError(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.ExecuteUbergraph_ToastWidget_MinorError // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
	void OnFinishedToast__DelegateSignature(); // Function ToastWidget_MinorError.ToastWidget_MinorError_C.OnFinishedToast__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

