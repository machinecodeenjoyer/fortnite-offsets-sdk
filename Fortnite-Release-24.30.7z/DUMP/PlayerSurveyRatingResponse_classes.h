// WidgetBlueprintGeneratedClass PlayerSurveyRatingResponse.PlayerSurveyRatingResponse_C
// Size: 0x430 (Inherited: 0x420)
struct UPlayerSurveyRatingResponse_C : UFortPlayerSurveyRatingResponseBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_420[0x10]; // 0x420(0x10)

	void OnAddedToFocusPath(); // Function PlayerSurveyRatingResponse.PlayerSurveyRatingResponse_C.OnAddedToFocusPath // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnResponsesSet_BP(); // Function PlayerSurveyRatingResponse.PlayerSurveyRatingResponse_C.OnResponsesSet_BP // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PlayerSurveyRatingResponse(); // Function PlayerSurveyRatingResponse.PlayerSurveyRatingResponse_C.ExecuteUbergraph_PlayerSurveyRatingResponse // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

