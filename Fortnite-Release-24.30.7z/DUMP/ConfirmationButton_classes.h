// WidgetBlueprintGeneratedClass ConfirmationButton.ConfirmationButton_C
// Size: 0x1620 (Inherited: 0x1620)
struct UConfirmationButton_C : UIconTextButton_C {
};

