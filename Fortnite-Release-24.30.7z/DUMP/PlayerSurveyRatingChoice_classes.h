// WidgetBlueprintGeneratedClass PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C
// Size: 0x1430 (Inherited: 0x1420)
struct UPlayerSurveyRatingChoice_C : UFortPlayerSurveyRatingChoiceBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1420[0x10]; // 0x1420(0x10)

	void GetCurrentButtonBrush(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.GetCurrentButtonBrush // (Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void UpdateInputActionRenderOpacity(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.UpdateInputActionRenderOpacity // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateTextStyle(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.UpdateTextStyle // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnUnhovered(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSurveyResetChoice(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.OnSurveyResetChoice // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInitialized(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void BP_OnSelected(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnDeselected(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PlayerSurveyRatingChoice(); // Function PlayerSurveyRatingChoice.PlayerSurveyRatingChoice_C.ExecuteUbergraph_PlayerSurveyRatingChoice // (Final|UbergraphFunction) // @ game+0x179ea74
};

