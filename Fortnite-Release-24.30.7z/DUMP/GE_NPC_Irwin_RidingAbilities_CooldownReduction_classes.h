// BlueprintGeneratedClass GE_NPC_Irwin_RidingAbilities_CooldownReduction.GE_NPC_Irwin_RidingAbilities_CooldownReduction_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_NPC_Irwin_RidingAbilities_CooldownReduction_C : UGameplayEffect {
};

