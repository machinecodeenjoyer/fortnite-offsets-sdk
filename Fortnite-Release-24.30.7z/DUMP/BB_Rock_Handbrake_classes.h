// BlueprintGeneratedClass BB_Rock_Handbrake.BB_Rock_Handbrake_C
// Size: 0x110 (Inherited: 0x110)
struct UBB_Rock_Handbrake_C : UFortMobileActionButtonBehavior {
};

