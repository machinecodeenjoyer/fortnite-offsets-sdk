// WidgetBlueprintGeneratedClass PinModal.PinModal_C
// Size: 0x6d8 (Inherited: 0x5e0)
struct UPinModal_C : UFortPinModal {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_5E0[0xf8]; // 0x5e0(0xf8)

	void Set Visual States(); // Function PinModal.PinModal_C.Set Visual States // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetPreviewData(); // Function PinModal.PinModal_C.SetPreviewData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CollectPinButtons(); // Function PinModal.PinModal_C.CollectPinButtons // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PreConstruct(); // Function PinModal.PinModal_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnSetPinState(); // Function PinModal.PinModal_C.OnSetPinState // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PinModal(); // Function PinModal.PinModal_C.ExecuteUbergraph_PinModal // (Final|UbergraphFunction) // @ game+0x179ea74
};

