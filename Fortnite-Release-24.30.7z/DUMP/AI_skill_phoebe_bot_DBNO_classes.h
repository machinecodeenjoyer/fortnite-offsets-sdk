// BlueprintGeneratedClass AI_skill_phoebe_bot_DBNO.AI_skill_phoebe_bot_DBNO_C
// Size: 0x170 (Inherited: 0x170)
struct UAI_skill_phoebe_bot_DBNO_C : UFortAthenaAIBotDBNOSkillSet {
};

