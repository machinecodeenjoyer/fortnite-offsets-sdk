// BlueprintGeneratedClass TVPostProcessBPAthena.TVPostProcessBPAthena_C
// Size: 0x2d0 (Inherited: 0x2a1)
struct ATVPostProcessBPAthena_C : ATVPostProcessBP_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2A1[0x2f]; // 0x2a1(0x2f)

	void IsEnabledForCurrentSubgame(); // Function TVPostProcessBPAthena.TVPostProcessBPAthena_C.IsEnabledForCurrentSubgame // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void FrontEndCameraSwitchFadeAthena__FinishedFunc(); // Function TVPostProcessBPAthena.TVPostProcessBPAthena_C.FrontEndCameraSwitchFadeAthena__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void FrontEndCameraSwitchFadeAthena__UpdateFunc(); // Function TVPostProcessBPAthena.TVPostProcessBPAthena_C.FrontEndCameraSwitchFadeAthena__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void ExecuteCameraSwitch(); // Function TVPostProcessBPAthena.TVPostProcessBPAthena_C.ExecuteCameraSwitch // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Camera_DisableEffects(); // Function TVPostProcessBPAthena.TVPostProcessBPAthena_C.Camera_DisableEffects // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_TVPostProcessBPAthena(); // Function TVPostProcessBPAthena.TVPostProcessBPAthena_C.ExecuteUbergraph_TVPostProcessBPAthena // (Final|UbergraphFunction) // @ game+0x179ea74
};

