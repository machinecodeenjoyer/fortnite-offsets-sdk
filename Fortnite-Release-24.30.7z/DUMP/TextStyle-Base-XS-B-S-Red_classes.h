// BlueprintGeneratedClass TextStyle-Base-XS-B-S-Red.TextStyle-Base-XS-B-S-Red_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-Base-XS-B-S-Red_C : UTextStyle-BaseParent_C {
};

