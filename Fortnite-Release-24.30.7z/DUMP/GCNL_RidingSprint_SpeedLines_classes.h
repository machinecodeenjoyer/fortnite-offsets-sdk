// BlueprintGeneratedClass GCNL_RidingSprint_SpeedLines.GCNL_RidingSprint_SpeedLines_C
// Size: 0x978 (Inherited: 0x960)
struct AGCNL_RidingSprint_SpeedLines_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x18]; // 0x960(0x18)

	void OnApplicationGeneric(); // Function GCNL_RidingSprint_SpeedLines.GCNL_RidingSprint_SpeedLines_C.OnApplicationGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCNL_RidingSprint_SpeedLines.GCNL_RidingSprint_SpeedLines_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_RidingSprint_SpeedLines(); // Function GCNL_RidingSprint_SpeedLines.GCNL_RidingSprint_SpeedLines_C.ExecuteUbergraph_GCNL_RidingSprint_SpeedLines // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

