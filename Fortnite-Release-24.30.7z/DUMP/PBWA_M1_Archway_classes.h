// BlueprintGeneratedClass PBWA_M1_Archway.PBWA_M1_Archway_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_M1_Archway_C : ABuildingWall {
};

