// BlueprintGeneratedClass BBE_RiderEmote.BBE_RiderEmote_C
// Size: 0x70 (Inherited: 0x70)
struct UBBE_RiderEmote_C : UFortMobileActionButtonBehaviorExtension {
};

