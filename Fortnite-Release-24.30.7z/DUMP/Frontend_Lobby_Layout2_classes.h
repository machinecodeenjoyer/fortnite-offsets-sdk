// BlueprintGeneratedClass Frontend_Lobby_Layout2.Frontend_Lobby_Layout2_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct AFrontend_Lobby_Layout2_C : AFortLevelScriptActor {
};

