// VerseClass VerseDevices.$SolarisSignatureFunctionOuter
// Size: 0x28 (Inherited: 0x28)
struct U$SolarisSignatureFunctionOuter : UObject {
};

// VerseClass VerseDevices.Devices
// Size: 0x30 (Inherited: 0x28)
struct UDevices : UObject {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x81208]; // 0x00(0xb4d12080)
	 ; // 0x00(0x00)

	void _L_2fFortnite_2ecom_2fDevices_N_Roperator_U_2eGetTags_U_L_Ncreative__object__interface_M_Ntuple_L_R_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_Roperator_U_2eGetTags_U_L_Ncreative__object__interface_M_Ntuple_L_R_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb050ecc
	void _L_2fFortnite_2ecom_2fDevices_N_Roperator_U_2eGetPlayspace_U_L_Ncreative__object__interface_M_Ntuple_L_R_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_Roperator_U_2eGetPlayspace_U_L_Ncreative__object__interface_M_Ntuple_L_R_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb050ec4
	void _L_2fFortnite_2ecom_2fDevices_N_Rdevice__event_L_Ntype_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_Rdevice__event_L_Ntype_R // (Final|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_N_Rdevice__event(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_Rdevice__event // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_N_RToString_L_Nmove__to__internal__result_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_RToString_L_Nmove__to__internal__result_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_N_RSpawnProp_L_Ncreative__prop__asset_M_Ntransform_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_RSpawnProp_L_Ncreative__prop__asset_M_Ntransform_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb050eb4
	void _L_2fFortnite_2ecom_2fDevices_N_RSpawnProp_L_Ncreative__prop__asset_M_Nvector3_M_Nrotation_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_RSpawnProp_L_Ncreative__prop__asset_M_Nvector3_M_Nrotation_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb050ebc
	void _L_2fFortnite_2ecom_2fDevices_N_RGetCreativeObjectsWithTags_L_Ntag__search__criteria_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_RGetCreativeObjectsWithTags_L_Ntag__search__criteria_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xafc2dc4
	void _L_2fFortnite_2ecom_2fDevices_N_RGetCreativeObjectsWithTag_L_Ntag_R(); // Function VerseDevices.Devices._L_2fFortnite_2ecom_2fDevices_N_RGetCreativeObjectsWithTag_L_Ntag_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb050eac
	void Devices_device_ai_interaction_result$Factory(); // Function VerseDevices.Devices.Devices_device_ai_interaction_result$Factory // (Static|HasOutParms) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices.$InitCDO // (HasDefaults) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_device
// Size: 0x78 (Inherited: 0x38)
struct UDevices_creative_device : UVerseCreativeDevice {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x40]; // 0x38(0x40)

	void _L_2fFortnite_2ecom_2fDevices_2fcreative__device_N_ROnEnd(); // Function VerseDevices.Devices_creative_device._L_2fFortnite_2ecom_2fDevices_2fcreative__device_N_ROnEnd // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__device_N_ROnBegin__Internal(); // Function VerseDevices.Devices_creative_device._L_2fFortnite_2ecom_2fDevices_2fcreative__device_N_ROnBegin__Internal // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void OnBegin(); // Function VerseDevices.Devices_creative_device.OnBegin // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fGame_2fpositional_N_RGetTransform(); // Function VerseDevices.Devices_creative_device._L_2fFortnite_2ecom_2fGame_2fpositional_N_RGetTransform // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050ed4
	void $InitInstance(); // Function VerseDevices.Devices_creative_device.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_device.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_device.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_device_asset
// Size: 0xd8 (Inherited: 0xd8)
struct UDevices_creative_device_asset : UAssets_asset {

	void $InitInstance(); // Function VerseDevices.Devices_creative_device_asset.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_device_asset.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_device_asset.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_object
// Size: 0xc0 (Inherited: 0x40)
struct UDevices_creative_object : UVerseCreativeObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_40[0x80]; // 0x40(0x80)

	void _L_2fFortnite_2ecom_2fGame_2fpositional_N_RGetTransform(); // Function VerseDevices.Devices_creative_object._L_2fFortnite_2ecom_2fGame_2fpositional_N_RGetTransform // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050edc
	void $InitInstance(); // Function VerseDevices.Devices_creative_object.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_object.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_object.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_device_base
// Size: 0xc0 (Inherited: 0xc0)
struct UDevices_creative_device_base : UDevices_creative_object {

	void $InitInstance(); // Function VerseDevices.Devices_creative_device_base.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_device_base.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_device_base.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_object_interface
// Size: 0x28 (Inherited: 0x28)
struct UDevices_creative_object_interface : UObject {
};

// VerseClass VerseDevices.Devices_creative_prop
// Size: 0x190 (Inherited: 0xc0)
struct UDevices_creative_prop : UDevices_creative_object {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_C0[0xd0]; // 0xc0(0xd0)

	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RTeleportToInternal_L_Ntransform_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RTeleportToInternal_L_Ntransform_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e04
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RTeleportTo_L_Ntransform_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RTeleportTo_L_Ntransform_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RTeleportTo_L_Nvector3_M_Nrotation_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RTeleportTo_L_Nvector3_M_Nrotation_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RSetStaticMesh_L_Nstatic__mesh_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RSetStaticMesh_L_Nstatic__mesh_R // (Native|Public|BlueprintCallable) // @ game+0xb050dfc
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RSetMaterialAtIndex_L_Nmaterial_M_Nint_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RSetMaterialAtIndex_L_Nmaterial_M_Nint_R // (Native|Public|BlueprintCallable) // @ game+0xb050dec
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RSetMaterial_L_Nmaterial_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RSetMaterial_L_Nmaterial_R // (Native|Public|BlueprintCallable) // @ game+0xb050df4
	void MoveToInternal_L_Ntransform_M_Nfloat_R(); // Function VerseDevices.Devices_creative_prop.MoveToInternal_L_Ntransform_M_Nfloat_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void MoveTo_L_Ntransform_M_Nfloat_R(); // Function VerseDevices.Devices_creative_prop.MoveTo_L_Ntransform_M_Nfloat_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void MoveTo_L_Nvector3_M_Nrotation_M_Nfloat_R(); // Function VerseDevices.Devices_creative_prop.MoveTo_L_Nvector3_M_Nrotation_M_Nfloat_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_2finvalidatable_N_RIsValid(); // Function VerseDevices.Devices_creative_prop._L_2fVerse_2eorg_2fVerse_2finvalidatable_N_RIsValid // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050ef4
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RHandleTeleportToResult_L_Nteleport__to__result_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RHandleTeleportToResult_L_Nteleport__to__result_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RHandleMoveToInternalResult_L_Nmove__to__internal__result_R(); // Function VerseDevices.Devices_creative_prop._L_2fFortnite_2ecom_2fDevices_2fcreative__prop_N_RHandleMoveToInternalResult_L_Nmove__to__internal__result_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fVerse_2eorg_2fVerse_2fdisposable_N_RDispose(); // Function VerseDevices.Devices_creative_prop._L_2fVerse_2eorg_2fVerse_2fdisposable_N_RDispose // (Native|Public|BlueprintCallable) // @ game+0xb050eec
	void $InitInstance(); // Function VerseDevices.Devices_creative_prop.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_prop.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_prop.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_prop_asset
// Size: 0xd8 (Inherited: 0xd8)
struct UDevices_creative_prop_asset : UAssets_asset {

	void $InitInstance(); // Function VerseDevices.Devices_creative_prop_asset.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_prop_asset.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_prop_asset.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_creative_prop_debug_log
// Size: 0x28 (Inherited: 0x28)
struct UDevices_creative_prop_debug_log : UDiagnostics_log_channel {

	void $InitInstance(); // Function VerseDevices.Devices_creative_prop_debug_log.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_creative_prop_debug_log.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_creative_prop_debug_log.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_CreativeAnimation
// Size: 0x28 (Inherited: 0x28)
struct UDevices_CreativeAnimation : UObject {

	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_N_Roperator_U_2eGetAnimationController_U_L_Ncreative__prop_M_Ntuple_L_R_R(); // Function VerseDevices.Devices_CreativeAnimation._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_N_Roperator_U_2eGetAnimationController_U_L_Ncreative__prop_M_Ntuple_L_R_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_N_RGetAnimationController_L_Ncreative__prop_R(); // Function VerseDevices.Devices_CreativeAnimation._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_N_RGetAnimationController_L_Ncreative__prop_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb050de4
	void Devices_CreativeAnimation_keyframe_delta$Factory(); // Function VerseDevices.Devices_CreativeAnimation.Devices_CreativeAnimation_keyframe_delta$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void Devices_CreativeAnimation_cubic_bezier_parameters$Factory(); // Function VerseDevices.Devices_CreativeAnimation.Devices_CreativeAnimation_cubic_bezier_parameters$Factory // (Static|HasOutParms) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_CreativeAnimation.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_CreativeAnimation_animation_controller
// Size: 0x168 (Inherited: 0x28)
struct UDevices_CreativeAnimation_animation_controller : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct F$Block*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x81208]; // 0x2c3(0xb4d12080)
	 ; // 0x00(0x00)

	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RToString_L_Nset__animation__result_R(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RToString_L_Nset__animation__result_R // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RStopInternal(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RStopInternal // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050ddc
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RStop(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RStop // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RSetAnimationInternal_L_N_Kkeyframe__delta_M_Nanimation__mode_R(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RSetAnimationInternal_L_N_Kkeyframe__delta_M_Nanimation__mode_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050dd4
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RSetAnimation_L_N_Kkeyframe__delta_M_Nanimation__mode_R(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RSetAnimation_L_N_Kkeyframe__delta_M_Nanimation__mode_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPlayInternal(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPlayInternal // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050dcc
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPlay(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPlay // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPauseInternal(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPauseInternal // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050dc4
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPause(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RPause // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RLogPlayStopPauseResultIfError_L_N_Kchar_M_Nplaystoppause__result_R(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RLogPlayStopPauseResultIfError_L_N_Kchar_M_Nplaystoppause__result_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RIsValid(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RIsValid // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050dbc
	void _L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RGetState(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller._L_2fFortnite_2ecom_2fDevices_2fCreativeAnimation_2fanimation__controller_N_RGetState // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050db4
	void AwaitNextKeyframe(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller.AwaitNextKeyframe // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller.$InitCDO // (HasDefaults) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_CreativeAnimation_animation_controller_debug_log
// Size: 0x28 (Inherited: 0x28)
struct UDevices_CreativeAnimation_animation_controller_debug_log : UDiagnostics_log_channel {

	void $InitInstance(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller_debug_log.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller_debug_log.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_CreativeAnimation_animation_controller_debug_log.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_CreativeAnimation_InterpolationTypes
// Size: 0xc8 (Inherited: 0x28)
struct UDevices_CreativeAnimation_InterpolationTypes : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x2c3(0x802000)
	 ; // 0x00(0x00)

	void $InitCDO(); // Function VerseDevices.Devices_CreativeAnimation_InterpolationTypes.$InitCDO // (HasDefaults) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event
// Size: 0xa8 (Inherited: 0x28)
struct UDevices_device_event : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x80]; // 0x28(0x80)

	void $InitInstance(); // Function VerseDevices.Devices_device_event.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event_agent
// Size: 0xa8 (Inherited: 0xa8)
struct UDevices_device_event_agent : UDevices_device_event {

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function VerseDevices.Devices_device_event_agent._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050efc
	void Await(); // Function VerseDevices.Devices_device_event_agent.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_device_event_agent.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event_agent.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event_agent.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event_agent_int
// Size: 0xa8 (Inherited: 0xa8)
struct UDevices_device_event_agent_int : UDevices_device_event {

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function VerseDevices.Devices_device_event_agent_int._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050f04
	void Await(); // Function VerseDevices.Devices_device_event_agent_int.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_device_event_agent_int.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event_agent_int.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event_agent_int.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event_ai_interaction
// Size: 0xc8 (Inherited: 0xa8)
struct UDevices_device_event_ai_interaction : UDevices_device_event {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A8[0x20]; // 0xa8(0x20)

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function VerseDevices.Devices_device_event_ai_interaction._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050f0c
	void Await(); // Function VerseDevices.Devices_device_event_ai_interaction.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_device_event_ai_interaction.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event_ai_interaction.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event_ai_interaction.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event_optional_agent
// Size: 0xa8 (Inherited: 0xa8)
struct UDevices_device_event_optional_agent : UDevices_device_event {

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function VerseDevices.Devices_device_event_optional_agent._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050f14
	void Await(); // Function VerseDevices.Devices_device_event_optional_agent.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_device_event_optional_agent.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event_optional_agent.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event_optional_agent.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event_optional_agent_int
// Size: 0xa8 (Inherited: 0xa8)
struct UDevices_device_event_optional_agent_int : UDevices_device_event {

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function VerseDevices.Devices_device_event_optional_agent_int._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050f1c
	void Await(); // Function VerseDevices.Devices_device_event_optional_agent_int.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_device_event_optional_agent_int.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event_optional_agent_int.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event_optional_agent_int.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_event_void
// Size: 0xa8 (Inherited: 0xa8)
struct UDevices_device_event_void : UDevices_device_event {

	void _L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R(); // Function VerseDevices.Devices_device_event_void._L_2fVerse_2eorg_2fVerse_2fsubscribable_2fsubscribable_Lt_R_N_RSubscribe_L_Nt_Tvoid_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050f24
	void Await(); // Function VerseDevices.Devices_device_event_void.Await // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VerseDevices.Devices_device_event_void.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_event_void.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_event_void.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function
// Size: 0x58 (Inherited: 0x28)
struct UDevices_device_function : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x30]; // 0x28(0x30)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function_N_RInvoke(); // Function VerseDevices.Devices_device_function._L_2fFortnite_2ecom_2fDevices_2fdevice__function_N_RInvoke // (Native|Public|BlueprintCallable) // @ game+0xb050e14
	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function_N_RInvoke_L_Nagent_R(); // Function VerseDevices.Devices_device_function._L_2fFortnite_2ecom_2fDevices_2fdevice__function_N_RInvoke_L_Nagent_R // (Native|Public|BlueprintCallable) // @ game+0xb050e0c
	void $InitInstance(); // Function VerseDevices.Devices_device_function.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_base
// Size: 0x38 (Inherited: 0x28)
struct UDevices_device_function_get_base : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x10]; // 0x28(0x10)

	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_base.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_base.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_base.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_agent
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_agent : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__agent_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_agent._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__agent_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e1c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_agent.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_agent.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_agent.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_color
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_color : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__color_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_color._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__color_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e24
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_color.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_color.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_color.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_float
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_float : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__float_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_float._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__float_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e2c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_float.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_float.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_float.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_int
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_int : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__int_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_int._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__int_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e34
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_int.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_int.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_int.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_logic
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_logic : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__logic_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_logic._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__logic_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e3c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_logic.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_logic.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_logic.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_string
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_string : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__string_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_string._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__string_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e44
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_string.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_string.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_string.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_get_vector3
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_get_vector3 : UDevices_device_function_get_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__vector3_N_RInvoke(); // Function VerseDevices.Devices_device_function_get_vector3._L_2fFortnite_2ecom_2fDevices_2fdevice__function__get__vector3_N_RInvoke // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e4c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_get_vector3.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_get_vector3.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_get_vector3.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_base
// Size: 0x38 (Inherited: 0x28)
struct UDevices_device_function_set_base : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x10]; // 0x28(0x10)

	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_base.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_base.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_base.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_agent
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_agent : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__agent_N_RInvoke_L_N_Qagent_R(); // Function VerseDevices.Devices_device_function_set_agent._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__agent_N_RInvoke_L_N_Qagent_R // (Native|Public|BlueprintCallable) // @ game+0xb050e54
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_agent.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_agent.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_agent.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_color
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_color : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__color_N_RInvoke_L_Ncolor_R(); // Function VerseDevices.Devices_device_function_set_color._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__color_N_RInvoke_L_Ncolor_R // (Native|Public|BlueprintCallable) // @ game+0xb050e5c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_color.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_color.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_color.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_float
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_float : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__float_N_RInvoke_L_Nfloat_R(); // Function VerseDevices.Devices_device_function_set_float._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__float_N_RInvoke_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xb050e64
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_float.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_float.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_float.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_int
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_int : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__int_N_RInvoke_L_Nint_R(); // Function VerseDevices.Devices_device_function_set_int._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__int_N_RInvoke_L_Nint_R // (Native|Public|BlueprintCallable) // @ game+0xb050e6c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_int.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_int.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_int.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_logic
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_logic : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__logic_N_RInvoke_L_Nlogic_R(); // Function VerseDevices.Devices_device_function_set_logic._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__logic_N_RInvoke_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xb050e74
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_logic.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_logic.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_logic.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_multi_parameter_base
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_multi_parameter_base : UDevices_device_function_set_base {
	char pad_38[0x28b]; // 0x38(0x28b)
	OptionProperty  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80200]; // 0x2c3(0x14812000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_multi_parameter_base.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_multi_parameter_base.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_multi_parameter_base.$InitCDO // (HasDefaults) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_params_by_name
// Size: 0xa8 (Inherited: 0x48)
struct UDevices_device_function_set_params_by_name : UDevices_device_function_set_multi_parameter_base {
	char pad_48[0x27b]; // 0x48(0x27b)
	struct TMap<struct FNone*, None>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80000]; // 0x2c3(0x4000000)
	 ; // 0x00(0x00)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__name_N_RInvoke_L_N_5b_Kchar_5dfunction__parameter__base_R(); // Function VerseDevices.Devices_device_function_set_params_by_name._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__name_N_RInvoke_L_N_5b_Kchar_5dfunction__parameter__base_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e7c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_params_by_name.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_params_by_name.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_params_by_name.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_params_by_name_const
// Size: 0xb8 (Inherited: 0xa8)
struct UDevices_device_function_set_params_by_name_const : UDevices_device_function_set_params_by_name {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A8[0x10]; // 0xa8(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__name__const_N_RInvokeConst_L_N_5b_Kchar_5dfunction__parameter__base_R(); // Function VerseDevices.Devices_device_function_set_params_by_name_const._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__name__const_N_RInvokeConst_L_N_5b_Kchar_5dfunction__parameter__base_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e84
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_params_by_name_const.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_params_by_name_const.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_params_by_name_const.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_params_by_type
// Size: 0x68 (Inherited: 0x48)
struct UDevices_device_function_set_params_by_type : UDevices_device_function_set_multi_parameter_base {
	char pad_48[0x27b]; // 0x48(0x27b)
	struct TArray<struct FNone*>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80000]; // 0x2c3(0x4000000)
	 ; // 0x00(0x00)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__type_N_RInvoke_L_N_Kfunction__parameter__base_R(); // Function VerseDevices.Devices_device_function_set_params_by_type._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__type_N_RInvoke_L_N_Kfunction__parameter__base_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e8c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_params_by_type.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_params_by_type.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_params_by_type.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_params_by_type_const
// Size: 0x78 (Inherited: 0x68)
struct UDevices_device_function_set_params_by_type_const : UDevices_device_function_set_params_by_type {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_68[0x10]; // 0x68(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__type__const_N_RInvokeConst_L_N_Kfunction__parameter__base_R(); // Function VerseDevices.Devices_device_function_set_params_by_type_const._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__params__by__type__const_N_RInvokeConst_L_N_Kfunction__parameter__base_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb050e94
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_params_by_type_const.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_params_by_type_const.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_params_by_type_const.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_string
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_string : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__string_N_RInvoke_L_N_Kchar_R(); // Function VerseDevices.Devices_device_function_set_string._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__string_N_RInvoke_L_N_Kchar_R // (Native|Public|BlueprintCallable) // @ game+0xb050e9c
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_string.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_string.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_string.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_function_set_vector3
// Size: 0x48 (Inherited: 0x38)
struct UDevices_device_function_set_vector3 : UDevices_device_function_set_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_38[0x10]; // 0x38(0x10)

	void _L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__vector3_N_RInvoke_L_Nvector3_R(); // Function VerseDevices.Devices_device_function_set_vector3._L_2fFortnite_2ecom_2fDevices_2fdevice__function__set__vector3_N_RInvoke_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xb050ea4
	void $InitInstance(); // Function VerseDevices.Devices_device_function_set_vector3.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_function_set_vector3.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_function_set_vector3.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_device_subscription
// Size: 0x68 (Inherited: 0x28)
struct UDevices_device_subscription : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x40]; // 0x28(0x40)

	void _L_2fVerse_2eorg_2fVerse_2fcancelable_N_RCancel(); // Function VerseDevices.Devices_device_subscription._L_2fVerse_2eorg_2fVerse_2fcancelable_N_RCancel // (Native|Public|BlueprintCallable) // @ game+0xb050ee4
	void $InitInstance(); // Function VerseDevices.Devices_device_subscription.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_device_subscription.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_device_subscription.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_base
// Size: 0x28 (Inherited: 0x28)
struct UDevices_function_parameter_base : UObject {

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_base.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_base.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_base.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_agent
// Size: 0x30 (Inherited: 0x28)
struct UDevices_function_parameter_agent : UDevices_function_parameter_base {
	OptionProperty  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80200]; // 0x00(0x14812000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_agent.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_agent.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_agent.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_color
// Size: 0x40 (Inherited: 0x28)
struct UDevices_function_parameter_color : UDevices_function_parameter_base {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x00(0x802000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_color.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_color.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_color.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_float
// Size: 0x30 (Inherited: 0x28)
struct UDevices_function_parameter_float : UDevices_function_parameter_base {
	double  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x00(0x10802000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_float.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_float.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_float.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_int
// Size: 0x30 (Inherited: 0x28)
struct UDevices_function_parameter_int : UDevices_function_parameter_base {
	int64_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x00(0x10802000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_int.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_int.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_int.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_logic
// Size: 0x30 (Inherited: 0x28)
struct UDevices_function_parameter_logic : UDevices_function_parameter_base {
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x00(0x800000)
	 ; // 0x00(0x00)
	char pad_28[0x8]; // 0x28(0x08)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_logic.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_logic.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_logic.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_string
// Size: 0x38 (Inherited: 0x28)
struct UDevices_function_parameter_string : UDevices_function_parameter_base {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x10]; // 0x28(0x10)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_string.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_string.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_string.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.Devices_function_parameter_vector3
// Size: 0x40 (Inherited: 0x28)
struct UDevices_function_parameter_vector3 : UDevices_function_parameter_base {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x00(0x802000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VerseDevices.Devices_function_parameter_vector3.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseDevices.Devices_function_parameter_vector3.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseDevices.Devices_function_parameter_vector3.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseDevices.task_Devices_creative_device$OnBegin
// Size: 0x159 (Inherited: 0x150)
struct Utask_Devices_creative_device$OnBegin : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_creative_device$OnBegin.Update // (Public|HasOutParms) // @ game+0x179ea74
};

// VerseClass VerseDevices.task_Devices_creative_prop$MoveTo_L_Ntransform_M_Nfloat_R
// Size: 0x278 (Inherited: 0x150)
struct Utask_Devices_creative_prop$MoveTo_L_Ntransform_M_Nfloat_R : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_creative_prop$MoveTo_L_Ntransform_M_Nfloat_R.Update // (Public|HasOutParms) // @ game+0x179ea74
};

// VerseClass VerseDevices.task_Devices_creative_prop$MoveTo_L_Nvector3_M_Nrotation_M_Nfloat_R
// Size: 0x2d8 (Inherited: 0x150)
struct Utask_Devices_creative_prop$MoveTo_L_Nvector3_M_Nrotation_M_Nfloat_R : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_creative_prop$MoveTo_L_Nvector3_M_Nrotation_M_Nfloat_R.Update // (Public|HasOutParms) // @ game+0x179ea74
};

// VerseClass VerseDevices.task_Devices_creative_prop$MoveToInternal_L_Ntransform_M_Nfloat_R
// Size: 0x6f8 (Inherited: 0x150)
struct Utask_Devices_creative_prop$MoveToInternal_L_Ntransform_M_Nfloat_R : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_creative_prop$MoveToInternal_L_Ntransform_M_Nfloat_R.Update // (Public|HasOutParms) // @ game+0x179ea74
};

// VerseClass VerseDevices.task_Devices_CreativeAnimation_animation_controller$AwaitNextKeyframe
// Size: 0x15a (Inherited: 0x150)
struct Utask_Devices_CreativeAnimation_animation_controller$AwaitNextKeyframe : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_CreativeAnimation_animation_controller$AwaitNextKeyframe.Update // (Native|Public|HasOutParms) // @ game+0xb050d7c
};

// VerseClass VerseDevices.task_Devices_device_event_agent$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Devices_device_event_agent$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_device_event_agent$Await.Update // (Native|Public|HasOutParms) // @ game+0xb050d84
};

// VerseClass VerseDevices.task_Devices_device_event_agent_int$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Devices_device_event_agent_int$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_device_event_agent_int$Await.Update // (Native|Public|HasOutParms) // @ game+0xb050d8c
};

// VerseClass VerseDevices.task_Devices_device_event_ai_interaction$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Devices_device_event_ai_interaction$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_device_event_ai_interaction$Await.Update // (Native|Public|HasOutParms) // @ game+0xb050d94
};

// VerseClass VerseDevices.task_Devices_device_event_optional_agent$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Devices_device_event_optional_agent$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_device_event_optional_agent$Await.Update // (Native|Public|HasOutParms) // @ game+0xb050d9c
};

// VerseClass VerseDevices.task_Devices_device_event_optional_agent_int$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Devices_device_event_optional_agent_int$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_device_event_optional_agent_int$Await.Update // (Native|Public|HasOutParms) // @ game+0xb050da4
};

// VerseClass VerseDevices.task_Devices_device_event_void$Await
// Size: 0x170 (Inherited: 0x150)
struct Utask_Devices_device_event_void$Await : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseDevices.task_Devices_device_event_void$Await.Update // (Native|Public|HasOutParms) // @ game+0xb050dac
};

