// BlueprintGeneratedClass B_Small_Explosion_CameraShake.B_Small_Explosion_CameraShake_C
// Size: 0x210 (Inherited: 0x210)
struct UB_Small_Explosion_CameraShake_C : ULegacyCameraShake {
};

