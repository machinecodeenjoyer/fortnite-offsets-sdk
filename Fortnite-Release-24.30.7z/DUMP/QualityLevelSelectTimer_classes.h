// WidgetBlueprintGeneratedClass QualityLevelSelectTimer.QualityLevelSelectTimer_C
// Size: 0x318 (Inherited: 0x300)
struct UQualityLevelSelectTimer_C : UFortHUDQualityLevelSelectTimer {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_300[0x18]; // 0x300(0x18)

	void UpdateTextScale(); // Function QualityLevelSelectTimer.QualityLevelSelectTimer_C.UpdateTextScale // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnProgressStarted(); // Function QualityLevelSelectTimer.QualityLevelSelectTimer_C.OnProgressStarted // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnProgressEnded(); // Function QualityLevelSelectTimer.QualityLevelSelectTimer_C.OnProgressEnded // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnTimeRemainingChanged(); // Function QualityLevelSelectTimer.QualityLevelSelectTimer_C.OnTimeRemainingChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInitialized(); // Function QualityLevelSelectTimer.QualityLevelSelectTimer_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_QualityLevelSelectTimer(); // Function QualityLevelSelectTimer.QualityLevelSelectTimer_C.ExecuteUbergraph_QualityLevelSelectTimer // (Final|UbergraphFunction) // @ game+0x179ea74
};

