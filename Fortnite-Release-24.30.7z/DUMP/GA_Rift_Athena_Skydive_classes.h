// BlueprintGeneratedClass GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C
// Size: 0xc20 (Inherited: 0xb28)
struct UGA_Rift_Athena_Skydive_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0xf8]; // 0xb28(0xf8)

	void RemoveSkydivingGameplayEffect(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.RemoveSkydivingGameplayEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.K2_OnEndAbility // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCancelled_AA0523504B7CA4F488E1E6A11F48308A(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.OnCancelled_AA0523504B7CA4F488E1E6A11F48308A // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnInterrupted_AA0523504B7CA4F488E1E6A11F48308A(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.OnInterrupted_AA0523504B7CA4F488E1E6A11F48308A // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBlendOut_AA0523504B7CA4F488E1E6A11F48308A(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.OnBlendOut_AA0523504B7CA4F488E1E6A11F48308A // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCompleted_AA0523504B7CA4F488E1E6A11F48308A(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.OnCompleted_AA0523504B7CA4F488E1E6A11F48308A // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Added_C39EFBAB480B446A6927009E5953EC41(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.Added_C39EFBAB480B446A6927009E5953EC41 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void SetPlayerToSkydive(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.SetPlayerToSkydive // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void (); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C. // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPawnEnteredWater(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.OnPawnEnteredWater // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPawnLanded(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.OnPawnLanded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void HandleForceEnd(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.HandleForceEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Rift_Athena_Skydive(); // Function GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C.ExecuteUbergraph_GA_Rift_Athena_Skydive // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

