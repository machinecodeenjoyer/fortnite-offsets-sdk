// Class MeshNetwork.MeshBeaconClient
// Size: 0x398 (Inherited: 0x318)
struct AMeshBeaconClient : AOnlineBeaconClient {
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x95112420)
	 ; // 0x00(0x00)
	char pad_318[0x80]; // 0x318(0x80)

	void ServerUpdateMultipleLevelsVisibility(); // Function MeshNetwork.MeshBeaconClient.ServerUpdateMultipleLevelsVisibility // (Final|Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x87fbdc0
	void ServerUpdateLevelVisibility(); // Function MeshNetwork.MeshBeaconClient.ServerUpdateLevelVisibility // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x87fbc18
	void ServerSetClientId(); // Function MeshNetwork.MeshBeaconClient.ServerSetClientId // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x87fb994
	void OnRep_ParentIds(); // Function MeshNetwork.MeshBeaconClient.OnRep_ParentIds // (Final|Native|Protected) // @ game+0x87fb980
	void OnRep_MeshPingTime(); // Function MeshNetwork.MeshBeaconClient.OnRep_MeshPingTime // (Native|Protected) // @ game+0x31296c4
	void OnRep_ConnectedToRoot(); // Function MeshNetwork.MeshBeaconClient.OnRep_ConnectedToRoot // (Final|Native|Protected) // @ game+0x87fb96c
};

// Class MeshNetwork.MeshBeaconHost
// Size: 0x3d0 (Inherited: 0x3c8)
struct AMeshBeaconHost : AOnlineBeaconHost {
	int32_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40004200]; // 0x2c3(0x52142000)
	 ; // 0x00(0x00)
};

// Class MeshNetwork.MeshBeaconHostObject
// Size: 0x2c8 (Inherited: 0x2b0)
struct AMeshBeaconHostObject : AOnlineBeaconHostObject {
	char pad_2B0[0x18]; // 0x2b0(0x18)
};

// Class MeshNetwork.MeshConnection
// Size: 0x1e88 (Inherited: 0x1e88)
struct UMeshConnection : UIpConnection {
};

// Class MeshNetwork.MeshNetDriver
// Size: 0x868 (Inherited: 0x850)
struct UMeshNetDriver : UIpNetDriver {
	struct TArray<struct FNone*>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x88000000)
	 ; // 0x00(0x00)
};

// Class MeshNetwork.MeshNetworkComponent
// Size: 0x150 (Inherited: 0xa0)
struct UMeshNetworkComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)

	void IsConnectedToMeshRoot(); // Function MeshNetwork.MeshNetworkComponent.IsConnectedToMeshRoot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87fb914
	void GetMeshNetworkNodeType(); // Function MeshNetwork.MeshNetworkComponent.GetMeshNetworkNodeType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87fb1e4
};

// Class MeshNetwork.MeshNetworkSubsystem
// Size: 0x108 (Inherited: 0x30)
struct UMeshNetworkSubsystem : UGameInstanceSubsystem {
	char pad_30[0x293]; // 0x30(0x293)
	struct FMulticastInlineDelegate  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10080200]; // 0x2c3(0x20000000)
	 ; // 0x00(0x00)

	void SetMetaDataWithKey(); // Function MeshNetwork.MeshNetworkSubsystem.SetMetaDataWithKey // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87fc044
	void SetMetaData(); // Function MeshNetwork.MeshNetworkSubsystem.SetMetaData // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87fb220
	void GetMetaDataWithKey(); // Function MeshNetwork.MeshNetworkSubsystem.GetMetaDataWithKey // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87fb284
	void GetMetadata(); // Function MeshNetwork.MeshNetworkSubsystem.GetMetadata // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87fb220
	void GetMeshNetworkNodeType(); // Function MeshNetwork.MeshNetworkSubsystem.GetMeshNetworkNodeType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87fb208
	void GetGameServerNodeType(); // Function MeshNetwork.MeshNetworkSubsystem.GetGameServerNodeType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87fb1cc
	void GetConnectedToRoot(); // Function MeshNetwork.MeshNetworkSubsystem.GetConnectedToRoot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87fb1b4
	void EnableMeshReplication(); // Function MeshNetwork.MeshNetworkSubsystem.EnableMeshReplication // (Final|Native|Public|BlueprintCallable) // @ game+0x87faf38
	void DisableMeshReplication(); // Function MeshNetwork.MeshNetworkSubsystem.DisableMeshReplication // (Final|Native|Public|BlueprintCallable) // @ game+0x87fadcc
};

// Class MeshNetwork.MeshReplicationGraphConnection
// Size: 0x378 (Inherited: 0x378)
struct UMeshReplicationGraphConnection : UNetReplicationGraphConnection {
};

// Class MeshNetwork.MeshReplicationGraph
// Size: 0x570 (Inherited: 0x570)
struct UMeshReplicationGraph : UReplicationGraph {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x38002000)
	 ; // 0x00(0x00)
};

