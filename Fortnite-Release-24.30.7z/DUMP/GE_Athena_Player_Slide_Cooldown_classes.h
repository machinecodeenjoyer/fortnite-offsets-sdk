// BlueprintGeneratedClass GE_Athena_Player_Slide_Cooldown.GE_Athena_Player_Slide_Cooldown_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Athena_Player_Slide_Cooldown_C : UGameplayEffect {
};

