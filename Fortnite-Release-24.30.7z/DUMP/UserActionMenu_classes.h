// WidgetBlueprintGeneratedClass UserActionMenu.UserActionMenu_C
// Size: 0x500 (Inherited: 0x4d0)
struct UUserActionMenu_C : UFortSocialInteractionMenu {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_4D0[0x30]; // 0x4d0(0x30)

	void OnToggleConfirmation(); // Function UserActionMenu.UserActionMenu_C.OnToggleConfirmation // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnOpened(); // Function UserActionMenu.UserActionMenu_C.OnOpened // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_UserActionMenu(); // Function UserActionMenu.UserActionMenu_C.ExecuteUbergraph_UserActionMenu // (Final|UbergraphFunction) // @ game+0x179ea74
};

