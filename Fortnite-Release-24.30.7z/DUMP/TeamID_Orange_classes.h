// BlueprintGeneratedClass TeamID_Orange.TeamID_Orange_C
// Size: 0x38 (Inherited: 0x38)
struct UTeamID_Orange_C : UFortTeamIdentification {
};

