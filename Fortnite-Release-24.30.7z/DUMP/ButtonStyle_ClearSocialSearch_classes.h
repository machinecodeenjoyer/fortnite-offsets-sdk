// BlueprintGeneratedClass ButtonStyle_ClearSocialSearch.ButtonStyle_ClearSocialSearch_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_ClearSocialSearch_C : UButtonStyle-MediumTransparentNoCues_C {
};

