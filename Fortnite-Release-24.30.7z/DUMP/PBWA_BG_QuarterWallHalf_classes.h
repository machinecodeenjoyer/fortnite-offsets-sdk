// BlueprintGeneratedClass PBWA_BG_QuarterWallHalf.PBWA_BG_QuarterWallHalf_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_BG_QuarterWallHalf_C : ABuildingWall {
};

