// BlueprintGeneratedClass GA_SurfaceChange_Ice_IceCheckOnTimer.GA_SurfaceChange_Ice_IceCheckOnTimer_C
// Size: 0xb48 (Inherited: 0xb28)
struct UGA_SurfaceChange_Ice_IceCheckOnTimer_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x20]; // 0xb28(0x20)

	void K2_ActivateAbility(); // Function GA_SurfaceChange_Ice_IceCheckOnTimer.GA_SurfaceChange_Ice_IceCheckOnTimer_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_SurfaceChange_Ice_IceCheckOnTimer.GA_SurfaceChange_Ice_IceCheckOnTimer_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void TraceForTerrain(); // Function GA_SurfaceChange_Ice_IceCheckOnTimer.GA_SurfaceChange_Ice_IceCheckOnTimer_C.TraceForTerrain // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void RemoveIceGE(); // Function GA_SurfaceChange_Ice_IceCheckOnTimer.GA_SurfaceChange_Ice_IceCheckOnTimer_C.RemoveIceGE // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_SurfaceChange_Ice_IceCheckOnTimer(); // Function GA_SurfaceChange_Ice_IceCheckOnTimer.GA_SurfaceChange_Ice_IceCheckOnTimer_C.ExecuteUbergraph_GA_SurfaceChange_Ice_IceCheckOnTimer // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

