// WidgetBlueprintGeneratedClass SplashScreenWidget.SplashScreenWidget_C
// Size: 0x580 (Inherited: 0x520)
struct USplashScreenWidget_C : UFortSplashScreenWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_520[0x60]; // 0x520(0x60)

	void BP_OnActivated(); // Function SplashScreenWidget.SplashScreenWidget_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInputMethodChanged(); // Function SplashScreenWidget.SplashScreenWidget_C.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_SplashScreenWidget(); // Function SplashScreenWidget.SplashScreenWidget_C.ExecuteUbergraph_SplashScreenWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

