// BlueprintGeneratedClass FortVolumeManager_BP.FortVolumeManager_BP_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct AFortVolumeManager_BP_C : AFortVolumeManager {
};

