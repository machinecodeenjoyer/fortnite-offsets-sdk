// BlueprintGeneratedClass GE_NPC_Behavior_TargetSlots_Melee_Max.GE_NPC_Behavior_TargetSlots_Melee_Max_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_NPC_Behavior_TargetSlots_Melee_Max_C : UGameplayEffect {
};

