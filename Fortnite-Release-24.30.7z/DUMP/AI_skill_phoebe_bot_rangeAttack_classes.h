// BlueprintGeneratedClass AI_skill_phoebe_bot_rangeAttack.AI_skill_phoebe_bot_rangeAttack_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct UAI_skill_phoebe_bot_rangeAttack_C : UFortAthenaAIBotRangeAttackSkillSet {
};

