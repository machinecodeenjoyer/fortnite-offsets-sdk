// WidgetBlueprintGeneratedClass Cinematic-TeamMics.Cinematic-TeamMics_C
// Size: 0x540 (Inherited: 0x2c0)
struct UCinematic-TeamMics_C : UCommonUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2C0[0x280]; // 0x2c0(0x280)

	void Update(); // Function Cinematic-TeamMics.Cinematic-TeamMics_C.Update // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function Cinematic-TeamMics.Cinematic-TeamMics_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_Cinematic-TeamMics(); // Function Cinematic-TeamMics.Cinematic-TeamMics_C.ExecuteUbergraph_Cinematic-TeamMics // (Final|UbergraphFunction) // @ game+0x179ea74
};

