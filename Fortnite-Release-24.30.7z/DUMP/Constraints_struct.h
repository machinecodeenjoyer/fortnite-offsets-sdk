// Enum Constraints.EHandleEvent
enum class EHandleEvent : uint8 {
	LocalTransformUpdated = 0,
	GlobalTransformUpdated = 1,
	ComponentUpdated = 2,
	Max = 3
};

// ScriptStruct Constraints.MovieSceneConstraintChannel
// Size: 0x100 (Inherited: 0x100)
struct FMovieSceneConstraintChannel : FMovieSceneBoolChannel {
};

// ScriptStruct Constraints.ConstraintAndActiveChannel
// Size: 0x130 (Inherited: 0x00)
struct FConstraintAndActiveChannel {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_0[0x130]; // 0x00(0x130)
};

// ScriptStruct Constraints.ConstraintTickFunction
// Size: 0x40 (Inherited: 0x28)
struct FConstraintTickFunction : FTickFunction {
	char pad_28[0x18]; // 0x28(0x18)
};

