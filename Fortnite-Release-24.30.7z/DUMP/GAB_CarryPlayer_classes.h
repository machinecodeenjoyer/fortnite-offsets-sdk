// BlueprintGeneratedClass GAB_CarryPlayer.GAB_CarryPlayer_C
// Size: 0xb8c (Inherited: 0xb58)
struct UGAB_CarryPlayer_C : UFortGameplayAbility_CarryPlayer {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B58[0x34]; // 0xb58(0x34)

	void OnCancelled_C4440F1640E9A8D79E44FD8C23525824(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.OnCancelled_C4440F1640E9A8D79E44FD8C23525824 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnInterrupted_C4440F1640E9A8D79E44FD8C23525824(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.OnInterrupted_C4440F1640E9A8D79E44FD8C23525824 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBlendOut_C4440F1640E9A8D79E44FD8C23525824(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.OnBlendOut_C4440F1640E9A8D79E44FD8C23525824 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCompleted_C4440F1640E9A8D79E44FD8C23525824(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.OnCompleted_C4440F1640E9A8D79E44FD8C23525824 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnFortPlayerHitByVehicle_Event(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.OnFortPlayerHitByVehicle_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GAB_CarryPlayer(); // Function GAB_CarryPlayer.GAB_CarryPlayer_C.ExecuteUbergraph_GAB_CarryPlayer // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

