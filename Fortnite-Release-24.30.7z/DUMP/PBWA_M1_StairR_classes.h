// BlueprintGeneratedClass PBWA_M1_StairR.PBWA_M1_StairR_C
// Size: 0xd78 (Inherited: 0xd78)
struct APBWA_M1_StairR_C : ABuildingStairs {
};

