// BlueprintGeneratedClass FrontEndStore.FrontEndStore_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct AFrontEndStore_C : AFortLevelScriptActor {
};

