// Class VehicleAudioRuntime.VehicleAudioLifecycleInterface
// Size: 0x28 (Inherited: 0x28)
struct UVehicleAudioLifecycleInterface : UInterface {

	void OnUpdate(); // Function VehicleAudioRuntime.VehicleAudioLifecycleInterface.OnUpdate // (Native|Event|Public|BlueprintEvent) // @ game+0x272636c
	void OnShutdown(); // Function VehicleAudioRuntime.VehicleAudioLifecycleInterface.OnShutdown // (Native|Event|Public|BlueprintEvent) // @ game+0x28784dc
	void OnInit(); // Function VehicleAudioRuntime.VehicleAudioLifecycleInterface.OnInit // (Native|Event|Public|BlueprintEvent) // @ game+0x2851c0c
};

// Class VehicleAudioRuntime.FortVehicleAudioController
// Size: 0x2e8 (Inherited: 0x288)
struct AFortVehicleAudioController : AActor {
	char pad_288[0x3b]; // 0x288(0x3b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x215]; // 0x2c3(0x3a4c2150)
	 ; // 0x00(0x00)

	void UpdateMotorModelNative(); // Function VehicleAudioRuntime.FortVehicleAudioController.UpdateMotorModelNative // (Native|Protected|BlueprintCallable) // @ game+0x1386598
	void Update(); // Function VehicleAudioRuntime.FortVehicleAudioController.Update // (Native|Public|BlueprintCallable) // @ game+0xb1191ec
	void Shutdown(); // Function VehicleAudioRuntime.FortVehicleAudioController.Shutdown // (Native|Public|BlueprintCallable) // @ game+0x28e0634
	void SetVehicle(); // Function VehicleAudioRuntime.FortVehicleAudioController.SetVehicle // (Native|Public|BlueprintCallable) // @ game+0x927c8e4
	void SetRedlineActive(); // Function VehicleAudioRuntime.FortVehicleAudioController.SetRedlineActive // (Native|Public|BlueprintCallable) // @ game+0x8c34194
	void SetLayeredAudioComponent(); // Function VehicleAudioRuntime.FortVehicleAudioController.SetLayeredAudioComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x29ee5bc
	void IsNativizationEnabled(); // Function VehicleAudioRuntime.FortVehicleAudioController.IsNativizationEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4c9a098
	void Init(); // Function VehicleAudioRuntime.FortVehicleAudioController.Init // (Native|Public|BlueprintCallable) // @ game+0x1d64814
	void GetVehicleActor(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetVehicleActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27fbd60
	void GetThrottleNative(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetThrottleNative // (Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb1191c0
	void GetREVComponent(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetREVComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab33320
	void GetRedlineActive(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetRedlineActive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x76fd650
	void GetPhysicsVehicleConfigs(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetPhysicsVehicleConfigs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb119134
	void GetLayeredAudioComponent(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetLayeredAudioComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2c1c724
	void GetJitterTime(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetJitterTime // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb1190e4
	void GetBrakingNative(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetBrakingNative // (Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb1190b8
	void GetAudioParameterComponent(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetAudioParameterComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27c5a04
	void GetAudioMotorModelComponent(); // Function VehicleAudioRuntime.FortVehicleAudioController.GetAudioMotorModelComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3381edc
	void CacheJitterTime(); // Function VehicleAudioRuntime.FortVehicleAudioController.CacheJitterTime // (Native|Public|BlueprintCallable) // @ game+0x1386088
};

// Class VehicleAudioRuntime.FortVehicleSoundComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UFortVehicleSoundComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct TWeakObjectPtr<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40002200]; // 0x2c3(0xd9122000)
	 ; // 0x00(0x00)

	void Update(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.Update // (Native|Public|BlueprintCallable) // @ game+0x9c5d714
	void Shutdown(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.Shutdown // (Native|Public|BlueprintCallable) // @ game+0x7f89e10
	void Init(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.Init // (Native|Public|BlueprintCallable) // @ game+0x7a7fc1c
	void GetVehicleActor(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetVehicleActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1c58550
	void GetRootComponent(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetRootComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb11919c
	void GetREVComponent(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetREVComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb119178
	void GetPhysicsVehicleConfigs(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetPhysicsVehicleConfigs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb119154
	void GetMotorModelComponent(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetMotorModelComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb119110
	void GetLayeredAudioComponent(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetLayeredAudioComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1c58678
	void GetAudioParameterComponent(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetAudioParameterComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb119094
	void GetAudioController(); // Function VehicleAudioRuntime.FortVehicleSoundComponent.GetAudioController // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25586d8
};

// Class VehicleAudioRuntime.FortVehicleSoundComponent_Surface
// Size: 0x158 (Inherited: 0xb0)
struct UFortVehicleSoundComponent_Surface : UFortVehicleSoundComponent {
	char pad_B0[0x213]; // 0xb0(0x213)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500000)
	 ; // 0x00(0x00)

	void OnSurfaceChanged(); // Function VehicleAudioRuntime.FortVehicleSoundComponent_Surface.OnSurfaceChanged // (Final|Native|Public) // @ game+0x3003e1c
	void OnSkiddingChanged(); // Function VehicleAudioRuntime.FortVehicleSoundComponent_Surface.OnSkiddingChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnInAirChanged(); // Function VehicleAudioRuntime.FortVehicleSoundComponent_Surface.OnInAirChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnBrakingChanged(); // Function VehicleAudioRuntime.FortVehicleSoundComponent_Surface.OnBrakingChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
};

// Class VehicleAudioRuntime.FortVehicleSoundData
// Size: 0x70 (Inherited: 0x30)
struct UFortVehicleSoundData : UDataAsset {
	char pad_30[0x293]; // 0x30(0x293)
	struct TArray<struct FNone*>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x209]; // 0x2c3(0x20910480)
	 ; // 0x00(0x00)
};

