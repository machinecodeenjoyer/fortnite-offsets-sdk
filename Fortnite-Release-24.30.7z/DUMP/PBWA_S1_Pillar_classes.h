// BlueprintGeneratedClass PBWA_S1_Pillar.PBWA_S1_Pillar_C
// Size: 0xd70 (Inherited: 0xd70)
struct APBWA_S1_Pillar_C : ABuildingPillar {
};

