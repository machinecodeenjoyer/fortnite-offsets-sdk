// BlueprintGeneratedClass TextStyle-HeaderParent.TextStyle-HeaderParent_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-HeaderParent_C : UTextStyle-Base_C {
};

