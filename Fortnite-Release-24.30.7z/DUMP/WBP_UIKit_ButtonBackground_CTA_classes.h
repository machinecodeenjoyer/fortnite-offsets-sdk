// WidgetBlueprintGeneratedClass WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C
// Size: 0x360 (Inherited: 0x2eb)
struct UWBP_UIKit_ButtonBackground_CTA_C : UWBP_UIKit_Block_Base_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2EB[0x75]; // 0x2eb(0x75)

	void SetDisabled(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.SetDisabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetEnabled(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.SetEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetBorderMaterial(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.SetBorderMaterial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetBackgroundMaterial(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.SetBackgroundMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionEnabled(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.TransitionEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionDisabled(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.TransitionDisabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionReleased(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.TransitionReleased // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionPressed(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.TransitionPressed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionUnfocused(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.TransitionUnfocused // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TransitionFocused(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.TransitionFocused // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PreConstruct(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WBP_UIKit_ButtonBackground_CTA(); // Function WBP_UIKit_ButtonBackground_CTA.WBP_UIKit_ButtonBackground_CTA_C.ExecuteUbergraph_WBP_UIKit_ButtonBackground_CTA // (Final|UbergraphFunction) // @ game+0x179ea74
};

