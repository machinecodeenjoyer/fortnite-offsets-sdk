// BlueprintGeneratedClass BasicNotification.BasicNotification_C
// Size: 0x108 (Inherited: 0x108)
struct UBasicNotification_C : UFortUINotification {
};

