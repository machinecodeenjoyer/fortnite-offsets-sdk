// BlueprintGeneratedClass TextStyle-Base-S-Gray.TextStyle-Base-S-Gray_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-Base-S-Gray_C : UTextStyle-Base-S_C {
};

