// Class CraftingUI.FortCraftingListItem
// Size: 0x100 (Inherited: 0x28)
struct UFortCraftingListItem : UObject {
	char pad_28[0xd8]; // 0x28(0xd8)
};

// Class CraftingUI.AthenaCraftingQuickBarButton
// Size: 0x1440 (Inherited: 0x1420)
struct UAthenaCraftingQuickBarButton : UAthenaQuickBarSlotButtonBase {
	char pad_1420[0x20]; // 0x1420(0x20)

	void OnIsCraftableItemChanged(); // Function CraftingUI.AthenaCraftingQuickBarButton.OnIsCraftableItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCanCraftNowChanged(); // Function CraftingUI.AthenaCraftingQuickBarButton.OnCanCraftNowChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class CraftingUI.AthenaEquippedItemCraftingIndicator
// Size: 0x2e0 (Inherited: 0x2c0)
struct UAthenaEquippedItemCraftingIndicator : UCommonUserWidget {
	char pad_2C0[0x20]; // 0x2c0(0x20)

	void OnIsCraftableItemChanged(); // Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnIsCraftableItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCanCraftNowChanged(); // Function CraftingUI.AthenaEquippedItemCraftingIndicator.OnCanCraftNowChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleWeaponEquipped(); // Function CraftingUI.AthenaEquippedItemCraftingIndicator.HandleWeaponEquipped // (Final|Native|Private) // @ game+0xb201f94
};

// Class CraftingUI.AthenaInventoryItemInfoCraftingIndicator
// Size: 0x2e0 (Inherited: 0x2c0)
struct UAthenaInventoryItemInfoCraftingIndicator : UCommonUserWidget {
	char pad_2C0[0x20]; // 0x2c0(0x20)

	void OnIsCraftableItemChanged(); // Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnIsCraftableItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCanCraftNowChanged(); // Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.OnCanCraftNowChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleInventoryItemSelected(); // Function CraftingUI.AthenaInventoryItemInfoCraftingIndicator.HandleInventoryItemSelected // (Final|Native|Private) // @ game+0xb201cb4
};

// Class CraftingUI.AthenaQuickBarSlotCraftingIndicator
// Size: 0x2f8 (Inherited: 0x2c8)
struct UAthenaQuickBarSlotCraftingIndicator : UAthenaQuickBarSlotExtensionWidgetBase {
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)
	char pad_2C8[0x30]; // 0x2c8(0x30)

	void OnIsCraftableItemChanged(); // Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIsCraftableItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnIngredientChanged(); // Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnIngredientChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCanCraftNowChanged(); // Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.OnCanCraftNowChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleWeaponEquipped(); // Function CraftingUI.AthenaQuickBarSlotCraftingIndicator.HandleWeaponEquipped // (Final|Native|Private) // @ game+0xb202238
};

// Class CraftingUI.FortCookingScreen
// Size: 0x428 (Inherited: 0x3d8)
struct UFortCookingScreen : UCommonActivatableWidget {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x400010)
	 ; // 0x00(0x00)
};

// Class CraftingUI.FortCraftingFormulaIngredientsWidget
// Size: 0x2c8 (Inherited: 0x2c0)
struct UFortCraftingFormulaIngredientsWidget : UCommonUserWidget {
	char pad_2C0[0x3]; // 0x2c0(0x03)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)
};

// Class CraftingUI.FortCraftingIngredientWidget
// Size: 0x2e8 (Inherited: 0x2c0)
struct UFortCraftingIngredientWidget : UCommonUserWidget {
	char pad_2C0[0x3]; // 0x2c0(0x03)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void OnIngredientWidgetUpdated(); // Function CraftingUI.FortCraftingIngredientWidget.OnIngredientWidgetUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class CraftingUI.FortCraftingItemInfoWidget
// Size: 0x440 (Inherited: 0x3d8)
struct UFortCraftingItemInfoWidget : UCommonActivatableWidget {
	struct FText  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10001]; // 0x2c3(0x400000)
	 ; // 0x00(0x00)

	void OnItemRaritySet(); // Function CraftingUI.FortCraftingItemInfoWidget.OnItemRaritySet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class CraftingUI.FortCraftingListEntry
// Size: 0x1480 (Inherited: 0x1460)
struct UFortCraftingListEntry : UCommonButtonLegacy {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void OnCraftingListItemSet(); // Function CraftingUI.FortCraftingListEntry.OnCraftingListItemSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class CraftingUI.FortCraftingTab
// Size: 0x520 (Inherited: 0x3d8)
struct UFortCraftingTab : UCommonActivatableWidget {
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x90482010)
	 ; // 0x00(0x00)

	void OnFormulaListUpdated(); // Function CraftingUI.FortCraftingTab.OnFormulaListUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleInventoryItemSelected(); // Function CraftingUI.FortCraftingTab.HandleInventoryItemSelected // (Final|Native|Private) // @ game+0xb201e24
};

// Class CraftingUI.FortPotContentsPopup
// Size: 0x2c0 (Inherited: 0x298)
struct UFortPotContentsPopup : UUserWidget {
	char pad_298[0x2b]; // 0x298(0x2b)
	int32_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x90482010)
	 ; // 0x00(0x00)

	void SetOwningCraftingObject(); // Function CraftingUI.FortPotContentsPopup.SetOwningCraftingObject // (Final|Native|Public|BlueprintCallable) // @ game+0xb2024b4
};

// Class CraftingUI.FortPotContentsTile
// Size: 0x1470 (Inherited: 0x1460)
struct UFortPotContentsTile : UCommonButtonLegacy {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80208]; // 0x2c3(0x9ae02080)
	 ; // 0x00(0x00)
};

// Class CraftingUI.FortUIGameFeatureAction_SetCraftMenuWidget
// Size: 0x60 (Inherited: 0x28)
struct UFortUIGameFeatureAction_SetCraftMenuWidget : UFortUIGameFeatureAction {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x201]; // 0x2c3(0x984c2010)
	 ; // 0x00(0x00)
};

