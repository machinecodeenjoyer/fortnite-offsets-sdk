// BlueprintGeneratedClass GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C
// Size: 0xb90 (Inherited: 0xb58)
struct UGA_Action_ADS_GrindRail_C : UFortGameplayAbility_Action {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B58[0x38]; // 0xb58(0x38)

	void OnPress_01A3E1CF477913F9711F7E90D15EAD37(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.OnPress_01A3E1CF477913F9711F7E90D15EAD37 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRelease_F2AFF35A4A031EDEC04ECF9706FAA922(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.OnRelease_F2AFF35A4A031EDEC04ECF9706FAA922 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPress_C7DC18CB4B236FAE1117CE939CBC57AB(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.OnPress_C7DC18CB4B236FAE1117CE939CBC57AB // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRelease_E541412844A2A5A5D2D062A55EEC6C29(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.OnRelease_E541412844A2A5A5D2D062A55EEC6C29 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void FailedToActivatePassiveAbility(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.FailedToActivatePassiveAbility // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Action_ADS_GrindRail(); // Function GA_Action_ADS_GrindRail.GA_Action_ADS_GrindRail_C.ExecuteUbergraph_GA_Action_ADS_GrindRail // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

