// BlueprintGeneratedClass BP_ProjectileTrajectory_Athena.BP_ProjectileTrajectory_Athena_C
// Size: 0x301 (Inherited: 0x301)
struct ABP_ProjectileTrajectory_Athena_C : ABP_ProjectileTrajectory_C {
};

