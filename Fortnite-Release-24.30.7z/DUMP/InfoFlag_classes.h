// WidgetBlueprintGeneratedClass InfoFlag.InfoFlag_C
// Size: 0x310 (Inherited: 0x298)
struct UInfoFlag_C : UUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x78]; // 0x298(0x78)

	void UpdateText(); // Function InfoFlag.InfoFlag_C.UpdateText // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateGradientColor(); // Function InfoFlag.InfoFlag_C.UpdateGradientColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UpdateTrimColor(); // Function InfoFlag.InfoFlag_C.UpdateTrimColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PreConstruct(); // Function InfoFlag.InfoFlag_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function InfoFlag.InfoFlag_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_InfoFlag(); // Function InfoFlag.InfoFlag_C.ExecuteUbergraph_InfoFlag // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

