// BlueprintGeneratedClass GCNL_GrindBoostSlow.GCNL_GrindBoostSlow_C
// Size: 0x960 (Inherited: 0x960)
struct AGCNL_GrindBoostSlow_C : AFortGameplayCueNotify_Loop {
};

