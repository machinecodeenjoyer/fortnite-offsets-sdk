// WidgetBlueprintGeneratedClass windowchromebuttons.windowchromebuttons_C
// Size: 0x2e0 (Inherited: 0x2c0)
struct Uwindowchromebuttons_C : UCommonUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2C0[0x20]; // 0x2c0(0x20)

	void OnMouseEnter(); // Function windowchromebuttons.windowchromebuttons_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnMouseLeave(); // Function windowchromebuttons.windowchromebuttons_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_windowchromebuttons(); // Function windowchromebuttons.windowchromebuttons_C.ExecuteUbergraph_windowchromebuttons // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

