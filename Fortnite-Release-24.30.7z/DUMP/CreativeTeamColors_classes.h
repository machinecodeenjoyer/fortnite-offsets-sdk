// BlueprintGeneratedClass CreativeTeamColors.CreativeTeamColors_C
// Size: 0x2d0 (Inherited: 0x2a0)
struct UCreativeTeamColors_C : USceneComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_2A0[0x30]; // 0x2a0(0x30)
};

