// BlueprintGeneratedClass TextStyle-BurbankSmall-20-Black.TextStyle-BurbankSmall-20-Black_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-BurbankSmall-20-Black_C : UTextStyle-BaseParent_C {
};

