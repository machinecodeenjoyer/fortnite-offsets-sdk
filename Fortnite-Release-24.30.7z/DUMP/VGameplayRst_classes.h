// VerseClass VGameplayRst.$SolarisSignatureFunctionOuter
// Size: 0x28 (Inherited: 0x28)
struct U$SolarisSignatureFunctionOuter : UObject {
};

// VerseClass VGameplayRst.task_VGameplayRst_Components_dynamic_activation_component$WaitForTransitionBegin
// Size: 0x159 (Inherited: 0x150)
struct Utask_VGameplayRst_Components_dynamic_activation_component$WaitForTransitionBegin : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Components_dynamic_activation_component$WaitForTransitionBegin.Update // (Native|Public|HasOutParms) // @ game+0xaff21d0
};

// VerseClass VGameplayRst.task_VGameplayRst_Components_dynamic_activation_component$WaitForTransitionComplete
// Size: 0x159 (Inherited: 0x150)
struct Utask_VGameplayRst_Components_dynamic_activation_component$WaitForTransitionComplete : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Components_dynamic_activation_component$WaitForTransitionComplete.Update // (Native|Public|HasOutParms) // @ game+0xaff21d8
};

// VerseClass VGameplayRst.task_VGameplayRst_Messaging_debug_command_component$__WaitForCommand_L_N_Kchar_R
// Size: 0x178 (Inherited: 0x150)
struct Utask_VGameplayRst_Messaging_debug_command_component$__WaitForCommand_L_N_Kchar_R : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Messaging_debug_command_component$__WaitForCommand_L_N_Kchar_R.Update // (Native|Public|HasOutParms) // @ game+0xaff2598
};

// VerseClass VGameplayRst.task_VGameplayRst_Physics_collision_component$WaitBeginOverlap
// Size: 0x168 (Inherited: 0x150)
struct Utask_VGameplayRst_Physics_collision_component$WaitBeginOverlap : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Physics_collision_component$WaitBeginOverlap.Update // (Native|Public|HasOutParms) // @ game+0xaff21c0
};

// VerseClass VGameplayRst.task_VGameplayRst_Physics_collision_component$WaitEndOverlap
// Size: 0x168 (Inherited: 0x150)
struct Utask_VGameplayRst_Physics_collision_component$WaitEndOverlap : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Physics_collision_component$WaitEndOverlap.Update // (Native|Public|HasOutParms) // @ game+0xaff21c8
};

// VerseClass VGameplayRst.task_VGameplayRst_Physics_collision_component$WaitHit
// Size: 0x1a0 (Inherited: 0x150)
struct Utask_VGameplayRst_Physics_collision_component$WaitHit : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Physics_collision_component$WaitHit.Update // (Native|Public|HasOutParms) // @ game+0xaff21e0
};

// VerseClass VGameplayRst.task_VGameplayRst_Physics_physics_trace$WaitPhysicsTrace
// Size: 0x170 (Inherited: 0x150)
struct Utask_VGameplayRst_Physics_physics_trace$WaitPhysicsTrace : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VGameplayRst.task_VGameplayRst_Physics_physics_trace$WaitPhysicsTrace.Update // (Native|Public|HasOutParms) // @ game+0xaff21e8
};

// VerseClass VGameplayRst.VGameplayRst_Audio_audio_component
// Size: 0xd0 (Inherited: 0xa0)
struct UVGameplayRst_Audio_audio_component : UAudioComponentBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A0[0x30]; // 0xa0(0x30)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fAudio_2faudio__component_N_RSetSound_L_Nsound_R(); // Function VGameplayRst.VGameplayRst_Audio_audio_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fAudio_2faudio__component_N_RSetSound_L_Nsound_R // (Native|Public|BlueprintCallable) // @ game+0xaff2200
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fAudio_2faudio__component_N_REndSound(); // Function VGameplayRst.VGameplayRst_Audio_audio_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fAudio_2faudio__component_N_REndSound // (Native|Public|BlueprintCallable) // @ game+0xaff21f8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fAudio_2faudio__component_N_RBeginSound(); // Function VGameplayRst.VGameplayRst_Audio_audio_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fAudio_2faudio__component_N_RBeginSound // (Native|Public|BlueprintCallable) // @ game+0xaff21f0
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Audio_audio_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Audio_audio_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Audio_audio_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Components_dynamic_activation_component
// Size: 0x130 (Inherited: 0xb8)
struct UVGameplayRst_Components_dynamic_activation_component : UEntityDynamicActivationComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B8[0x78]; // 0xb8(0x78)

	void WaitForTransitionComplete(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component.WaitForTransitionComplete // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void WaitForTransitionBegin(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component.WaitForTransitionBegin // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RUnlinkComponent_L_Ncomponent_R(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RUnlinkComponent_L_Ncomponent_R // (Native|Public|BlueprintCallable) // @ game+0xaff2220
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RReset(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RReset // (Native|Public|BlueprintCallable) // @ game+0xaff2218
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RLinkComponent_L_Ncomponent_R(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RLinkComponent_L_Ncomponent_R // (Native|Public|BlueprintCallable) // @ game+0xaff2210
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RBeginTransition_L_Nfloat_M_Nactivation__state_R(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fdynamic__activation__component_N_RBeginTransition_L_Nfloat_M_Nactivation__state_R // (Native|Public|BlueprintCallable) // @ game+0xaff2208
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Components_dynamic_activation_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Components_script_component
// Size: 0x208 (Inherited: 0xb8)
struct UVGameplayRst_Components_script_component : UEntityScriptComponent {
	char pad_B8[0x20b]; // 0xb8(0x20b)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x800000)
	 ; // 0x00(0x00)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RSetTickEnabled_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RSetTickEnabled_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2260
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RSetEnabled_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RSetEnabled_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2258
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnTick_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnTick_L_Nfloat_R // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnPostCreate(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnPostCreate // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnEnd(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnEnd // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnEnabledChanged_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnEnabledChanged_L_Nlogic_R // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnCreate(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnCreate // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnBegin(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_ROnBegin // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RIsOwner_L_Nentity_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RIsOwner_L_Nentity_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2250
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RIsEnabled(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RIsEnabled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2248
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetName(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetName // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaf7f828
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetFullname(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetFullname // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaf7f820
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetComponentOfType_L_Ntype_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetComponentOfType_L_Ntype_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2240
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetAllComponentsOfType_L_Ntype_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RGetAllComponentsOfType_L_Ntype_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2238
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RAddToRequiredComponentList_L_N_Ksubtype_Lcomponent_R_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RAddToRequiredComponentList_L_N_Ksubtype_Lcomponent_R_R // (Native|Public|BlueprintCallable) // @ game+0xaff2230
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RAddToCreateComponentList_L_N_Ksubtype_Lcomponent_R_R(); // Function VGameplayRst.VGameplayRst_Components_script_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fComponents_2fscript__component_N_RAddToCreateComponentList_L_N_Ksubtype_Lcomponent_R_R // (Native|Public|BlueprintCallable) // @ game+0xaff2228
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Components_script_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Components_script_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Components_script_component.$InitCDO // (HasDefaults) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Datastore_datastore_component
// Size: 0x228 (Inherited: 0x228)
struct UVGameplayRst_Datastore_datastore_component : UDatastoreComponentBase {

	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Datastore_datastore_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Datastore_datastore_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Datastore_datastore_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Datastore_DatastoreComponent
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Datastore_DatastoreComponent : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDatastore_2fDatastoreComponent_N_RSetDatastoreValueInt_L_Nplayer__component_M_N_Kchar_M_Nint_R(); // Function VGameplayRst.VGameplayRst_Datastore_DatastoreComponent._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDatastore_2fDatastoreComponent_N_RSetDatastoreValueInt_L_Nplayer__component_M_N_Kchar_M_Nint_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2270
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDatastore_2fDatastoreComponent_N_RSetDatastoreValue_L_Nplayer__component_M_N_Kchar_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_Datastore_DatastoreComponent._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDatastore_2fDatastoreComponent_N_RSetDatastoreValue_L_Nplayer__component_M_N_Kchar_M_N_Kchar_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2278
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDatastore_2fDatastoreComponent_N_RClearAllDatastoreValues_L_Nplayer__component_R(); // Function VGameplayRst.VGameplayRst_Datastore_DatastoreComponent._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDatastore_2fDatastoreComponent_N_RClearAllDatastoreValues_L_Nplayer__component_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2268
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Datastore_DatastoreComponent.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_DebugDraw
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_DebugDraw : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RFlushPersistentDebugLines(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RFlushPersistentDebugLines // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff22c0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugSphere_L_Nvector3_M_Nsphere__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugSphere_L_Nvector3_M_Nsphere__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff22b8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugPoint_L_Nvector3_M_Npoint__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugPoint_L_Nvector3_M_Npoint__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff22b0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugLine_L_Nvector3_M_Nvector3_M_Nline__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugLine_L_Nvector3_M_Nvector3_M_Nline__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff22a8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugCylinder_L_Nvector3_M_Nvector3_M_Ncylinder__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugCylinder_L_Nvector3_M_Nvector3_M_Ncylinder__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff22a0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugCone_L_Nvector3_M_Nvector3_M_Ncone__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugCone_L_Nvector3_M_Nvector3_M_Ncone__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2298
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugCapsule_L_Nvector3_M_Nrotation_M_Ncapsule__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugCapsule_L_Nvector3_M_Nrotation_M_Ncapsule__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2290
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugBox_L_Nvector3_M_Nrotation_M_Nbox__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugBox_L_Nvector3_M_Nrotation_M_Nbox__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2288
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugArrow_L_Nvector3_M_Nvector3_M_Narrow__draw__params_R(); // Function VGameplayRst.VGameplayRst_DebugDraw._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fDebugDraw_N_RDrawDebugArrow_L_Nvector3_M_Nvector3_M_Narrow__draw__params_R // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaff2280
	void VGameplayRst_DebugDraw_arrow_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_arrow_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_sphere_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_sphere_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_point_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_point_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_line_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_line_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_cylinder_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_cylinder_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_cone_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_cone_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_capsule_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_capsule_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void VGameplayRst_DebugDraw_box_draw_params$Factory(); // Function VGameplayRst.VGameplayRst_DebugDraw.VGameplayRst_DebugDraw_box_draw_params$Factory // (Static|HasOutParms|HasDefaults) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_DebugDraw.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_EntityUtil
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_EntityUtil : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntityFromAsset_L_N_Kchar_M_Ntransform_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntityFromAsset_L_N_Kchar_M_Ntransform_M_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22e8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntity_L_Nvector3_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntity_L_Nvector3_M_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22f8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntity_L_Nvector3_M_Nvector3_M_Nvector3_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntity_L_Nvector3_M_Nvector3_M_Nvector3_M_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2300
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntity_L_Ntransform_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEntity_L_Ntransform_M_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22f0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEmptyEntity_L_Ntransform_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RSpawnEmptyEntity_L_Ntransform_M_N_Kchar_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22e0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RGetComponentOfTypeFromComponentForEntity_L_Ncomponent_M_Nint_M_Ntype_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RGetComponentOfTypeFromComponentForEntity_L_Ncomponent_M_Nint_M_Ntype_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22d0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RGetComponentOfTypeFromComponent_L_Ncomponent_M_Ntype_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RGetComponentOfTypeFromComponent_L_Ncomponent_M_Ntype_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22d8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RCreateAndAddComponent_L_Nint_M_Nsubtype_Lcomponent_R_R(); // Function VGameplayRst.VGameplayRst_EntityUtil._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fEntityUtil_N_RCreateAndAddComponent_L_Nint_M_Nsubtype_Lcomponent_R_R // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xaff22c8
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_EntityUtil.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_GameObjects
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_GameObjects : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Nvector3_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Ntag_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Ntag_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Nentity_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Nentity_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Nvector3_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateWorldAnchor_L_Nvector3_M_N_Kchar_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_N_Ksubtype_Lcomponent_R_M_Nvector3_M_Nrotation_M_Nvector3_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_N_Ksubtype_Lcomponent_R_M_Nvector3_M_Nrotation_M_Nvector3_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nvector3_M_Nrotation_M_Nvector3_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nvector3_M_Nrotation_M_Nvector3_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nvector3_M_Nrotation_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nvector3_M_Nrotation_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nvector3_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nvector3_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_N_Ksubtype_Lcomponent_R_M_Ntransform_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_N_Ksubtype_Lcomponent_R_M_Ntransform_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Ntransform_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Ntransform_M_N_Kchar_M_Nstatic__mesh_M_Nmaterial_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_N_Ksubtype_Lcomponent_R_M_Ntransform_M_N_Kchar_M_Nstatic__mesh_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_N_Ksubtype_Lcomponent_R_M_Ntransform_M_N_Kchar_M_Nstatic__mesh_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Ntransform_M_N_Kchar_M_Nstatic__mesh_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Ntransform_M_N_Kchar_M_Nstatic__mesh_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nentity_M_N_Ksubtype_Lcomponent_R_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nentity_M_N_Ksubtype_Lcomponent_R_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Ntag_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Ntag_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nentity_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateModel_L_Nentity_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateImmutableModel_L_Nentity_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateImmutableModel_L_Nentity_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateImmutableModel_L_Ntag_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateImmutableModel_L_Ntag_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateImmutableModel_L_Nentity_M_N_Ksubtype_Lcomponent_R_R(); // Function VGameplayRst.VGameplayRst_GameObjects._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_N_RCreateImmutableModel_L_Nentity_M_N_Ksubtype_Lcomponent_R_R // (Final|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_GameObjects.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_GameObjects_immutable_model
// Size: 0xd8 (Inherited: 0x28)
struct UVGameplayRst_GameObjects_immutable_model : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x81208]; // 0x2c3(0xb4d12080)
	 ; // 0x00(0x00)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fimmutable__model_N_RIsVisible(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fimmutable__model_N_RIsVisible // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fimmutable__model_N_RGetTransform(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fimmutable__model_N_RGetTransform // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_GameObjects_immutable_model.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_GameObjects_model
// Size: 0x188 (Inherited: 0x28)
struct UVGameplayRst_GameObjects_model : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x81208]; // 0x2c3(0xb4d12080)
	 ; // 0x00(0x00)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RShow(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RShow // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RSetTransform_L_Ntransform_R(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RSetTransform_L_Ntransform_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__scalable_N_RSetScale_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__scalable_N_RSetScale_L_Nvector3_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetRotation_L_Nrotation_R(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetRotation_L_Nrotation_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetForwardVectorFromXY_L_Nvector3_M_Nvector3_R(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetForwardVectorFromXY_L_Nvector3_M_Nvector3_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RIsVisible(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RIsVisible // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RHide(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RHide // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RGetTransform(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RGetTransform // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_REnableCollision(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_REnableCollision // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RDisableCollision(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RDisableCollision // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RDestroy(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fmodel_N_RDestroy // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RApplyAdditionalRotation_L_Nrotation_R(); // Function VGameplayRst.VGameplayRst_GameObjects_model._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RApplyAdditionalRotation_L_Nrotation_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_GameObjects_model.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_GameObjects_model.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_GameObjects_model.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_GameObjects_model_interface
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_GameObjects_model_interface : UObject {
};

// VerseClass VGameplayRst.VGameplayRst_GameObjects_mutable_model_interface
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_GameObjects_mutable_model_interface : UObject {
};

// VerseClass VGameplayRst.VGameplayRst_GameObjects_world_anchor
// Size: 0x78 (Inherited: 0x28)
struct UVGameplayRst_GameObjects_world_anchor : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x81208]; // 0x2c3(0xb4d12080)
	 ; // 0x00(0x00)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fworld__anchor_N_RGetComponent(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fworld__anchor_N_RGetComponent // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fworld__anchor_N_RDestroy(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGameObjects_2fworld__anchor_N_RDestroy // (Public|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_GameObjects_world_anchor.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component
// Size: 0x130 (Inherited: 0xa8)
struct UVGameplayRst_Geometry_fixed_mesh_component : UEntityActorStaticMeshRenderComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A8[0x88]; // 0xa8(0x88)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetVisibility_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetVisibility_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2340
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetStaticMesh_L_Nstatic__mesh_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetStaticMesh_L_Nstatic__mesh_R // (Native|Public|BlueprintCallable) // @ game+0xaff2338
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetMaterialAtIndex_L_Nmaterial_M_Nint_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetMaterialAtIndex_L_Nmaterial_M_Nint_R // (Native|Public|BlueprintCallable) // @ game+0xaff2328
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetMaterial_L_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetMaterial_L_Nmaterial_R // (Native|Public|BlueprintCallable) // @ game+0xaff2330
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetEnableCollision_L_Ncollision__type_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetEnableCollision_L_Ncollision__type_R // (Native|Public|BlueprintCallable) // @ game+0xaff2320
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetDefaultStaticMesh_L_Ndefault__mesh__type_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetDefaultStaticMesh_L_Ndefault__mesh__type_R // (Native|Public|BlueprintCallable) // @ game+0xaff2318
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetAsRootComponent_L_Nlogic_M_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RSetAsRootComponent_L_Nlogic_M_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2310
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RIsVisible(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2ffixed__mesh__component_N_RIsVisible // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2308
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Geometry_fixed_mesh_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component
// Size: 0x150 (Inherited: 0x80)
struct UVGameplayRst_Geometry_skeletal_mesh_component : UEntityActorSkeletalMeshRenderComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_80[0xd0]; // 0x80(0xd0)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetSkeletalMesh_L_Nskeletal__mesh_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetSkeletalMesh_L_Nskeletal__mesh_R // (Native|Public|BlueprintCallable) // @ game+0xaff23a8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetMaterial_L_Nmaterial_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetMaterial_L_Nmaterial_R // (Native|Public|BlueprintCallable) // @ game+0xaff23a0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationPosition__FIXME_L_Nfloat_M_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationPosition__FIXME_L_Nfloat_M_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2390
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationPlayRate__FIXME_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationPlayRate__FIXME_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2388
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationMode_L_Ndefault__animation__mode__type_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationMode_L_Ndefault__animation__mode__type_R // (Native|Public|BlueprintCallable) // @ game+0xaff2380
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationInstance_L_Nanimation__instance_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationInstance_L_Nanimation__instance_R // (Native|Public|BlueprintCallable) // @ game+0xaff2378
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationBlueprint_L_Nanimation__blueprint_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimationBlueprint_L_Nanimation__blueprint_R // (Native|Public|BlueprintCallable) // @ game+0xaff2370
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimation_L_Nanimation_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RSetAnimation_L_Nanimation_R // (Native|Public|BlueprintCallable) // @ game+0xaff2398
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RIsPlayingAnimation(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RIsPlayingAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2368
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RGetAnimationPosition__FIXME(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RGetAnimationPosition__FIXME // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2360
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RGetAnimationPlayRate__FIXME(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RGetAnimationPlayRate__FIXME // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2358
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_REndAnimation(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_REndAnimation // (Native|Public|BlueprintCallable) // @ game+0xaff2350
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RBeginAnimation_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fGeometry_2fskeletal__mesh__component_N_RBeginAnimation_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2348
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Geometry_skeletal_mesh_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_LevelStreaming_level_streaming_component
// Size: 0x158 (Inherited: 0x138)
struct UVGameplayRst_LevelStreaming_level_streaming_component : UVerseLevelStreamingComponentBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_138[0x20]; // 0x138(0x20)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLevelStreaming_2flevel__streaming__component_N_RRequestUnloadLevel_L_Ntime__span_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_LevelStreaming_level_streaming_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLevelStreaming_2flevel__streaming__component_N_RRequestUnloadLevel_L_Ntime__span_M_N_Kchar_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23b8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLevelStreaming_2flevel__streaming__component_N_RRequestLoadLevel_L_Nlevel_M_Ntime__span_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_LevelStreaming_level_streaming_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLevelStreaming_2flevel__streaming__component_N_RRequestLoadLevel_L_Nlevel_M_Ntime__span_M_N_Kchar_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23b0
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_LevelStreaming_level_streaming_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_LevelStreaming_level_streaming_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_LevelStreaming_level_streaming_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Lights_point_light_component
// Size: 0x138 (Inherited: 0x98)
struct UVGameplayRst_Lights_point_light_component : UPointLightComponentBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_98[0xa0]; // 0x98(0xa0)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetSourceRadius_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetSourceRadius_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2408
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetSourceLength_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetSourceLength_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2400
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetIntensity_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetIntensity_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff23f8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetColor_L_Ncolor_R(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetColor_L_Ncolor_R // (Native|Public|BlueprintCallable) // @ game+0xaff23f0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetAttenuationRadius_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RSetAttenuationRadius_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff23e8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetSourceRadius(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetSourceRadius // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23e0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetSourceLength(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetSourceLength // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23d8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetIntensity(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetIntensity // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23d0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetColor(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetColor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23c8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetAttenuationRadius(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fpoint__light__component_N_RGetAttenuationRadius // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff23c0
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Lights_point_light_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Lights_spot_light_component
// Size: 0x178 (Inherited: 0x98)
struct UVGameplayRst_Lights_spot_light_component : USpotLightComponentBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_98[0xe0]; // 0x98(0xe0)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetSourceRadius_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetSourceRadius_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2478
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetSourceLength_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetSourceLength_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2470
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetOuterConeAngle_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetOuterConeAngle_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2468
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetIntensity_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetIntensity_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2460
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetInnerConeAngle_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetInnerConeAngle_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2458
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetColor_L_Ncolor_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetColor_L_Ncolor_R // (Native|Public|BlueprintCallable) // @ game+0xaff2450
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetAttenuationRadius_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RSetAttenuationRadius_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2448
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetSourceRadius(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetSourceRadius // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2440
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetSourceLength(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetSourceLength // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2438
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetOuterConeAngle(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetOuterConeAngle // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2430
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetIntensity(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetIntensity // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2428
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetInnerConeAngle(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetInnerConeAngle // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2420
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetColor(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetColor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2418
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetAttenuationRadius(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fLights_2fspot__light__component_N_RGetAttenuationRadius // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2410
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Lights_spot_light_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Messaging_debug_command_component
// Size: 0xd8 (Inherited: 0x60)
struct UVGameplayRst_Messaging_debug_command_component : UEntityComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_60[0x78]; // 0x60(0x78)

	void __WaitForCommand_L_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_Messaging_debug_command_component.__WaitForCommand_L_N_Kchar_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Messaging_debug_command_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Messaging_debug_command_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Messaging_debug_command_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Physics
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Physics : UObject {

	void VGameplayRst_Physics_hit_result$Factory(); // Function VGameplayRst.VGameplayRst_Physics.VGameplayRst_Physics_hit_result$Factory // (Static|HasOutParms) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Physics.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Physics_collision_component
// Size: 0x2c8 (Inherited: 0x100)
struct UVGameplayRst_Physics_collision_component : UEntityActorCollisionComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_100[0x1c8]; // 0x100(0x1c8)

	void WaitHit(); // Function VGameplayRst.VGameplayRst_Physics_collision_component.WaitHit // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void WaitEndOverlap(); // Function VGameplayRst.VGameplayRst_Physics_collision_component.WaitEndOverlap // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void WaitBeginOverlap(); // Function VGameplayRst.VGameplayRst_Physics_collision_component.WaitBeginOverlap // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetUseContinuousCollisionDetection_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetUseContinuousCollisionDetection_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2520
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetSphereCollisionShapeMode_L_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetSphereCollisionShapeMode_L_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff2518
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetSendOverlapEvents_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetSendOverlapEvents_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2510
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetSendHitEventsOnCollide_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetSendHitEventsOnCollide_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2508
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetMovable_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetMovable_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2500
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetMeshCollisionShapeMode(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetMeshCollisionShapeMode // (Native|Public|BlueprintCallable) // @ game+0xaff24f8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetMeshCollisionShapeMode_L_Nstatic__mesh_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetMeshCollisionShapeMode_L_Nstatic__mesh_R // (Native|Public|BlueprintCallable) // @ game+0xaff24f0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetGravityEnabled_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetGravityEnabled_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff24e8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetEnabled_L_Nlogic_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetEnabled_L_Nlogic_R // (Native|Public|BlueprintCallable) // @ game+0xaff2348
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetDegreeOfFreedomContraint_L_Ndof__movement__mode_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetDegreeOfFreedomContraint_L_Ndof__movement__mode_R // (Native|Public|BlueprintCallable) // @ game+0xaff24e0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetCustomDegreeOfFreedomConstrain_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetCustomDegreeOfFreedomConstrain_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff24d8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetCollisionProfileName_L_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetCollisionProfileName_L_N_Kchar_R // (Native|Public|BlueprintCallable) // @ game+0xaff24d0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetCapsuleCollisionShapeMode_L_Nfloat_M_Nfloat_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetCapsuleCollisionShapeMode_L_Nfloat_M_Nfloat_R // (Native|Public|BlueprintCallable) // @ game+0xaff24c8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetBoxCollisionShapeMode_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RSetBoxCollisionShapeMode_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff24c0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetUseContinuousCollisionDetection(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetUseContinuousCollisionDetection // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff24b8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetSendOverlapEvents(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetSendOverlapEvents // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff24b0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetSendHitEventsOnCollide(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetSendHitEventsOnCollide // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff24a8
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetMovable(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetMovable // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff24a0
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetGravityEnabled(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetGravityEnabled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2498
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetEnabled(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetEnabled // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2490
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetCollisionShapeMode(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetCollisionShapeMode // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2488
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetCollisionProfileName(); // Function VGameplayRst.VGameplayRst_Physics_collision_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fcollision__component_N_RGetCollisionProfileName // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2480
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Physics_collision_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Physics_collision_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Physics_collision_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Physics_overlap_result
// Size: 0x70 (Inherited: 0x28)
struct UVGameplayRst_Physics_overlap_result : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	int64_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40080200]; // 0x2c3(0x10802000)
	 ; // 0x00(0x00)

	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Physics_overlap_result.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Physics_overlap_result.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Physics_overlap_result.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Physics_physics_trace
// Size: 0x110 (Inherited: 0x28)
struct UVGameplayRst_Physics_physics_trace : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0xe8]; // 0x28(0xe8)

	void WaitPhysicsTrace(); // Function VGameplayRst.VGameplayRst_Physics_physics_trace.WaitPhysicsTrace // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fphysics__trace_N_RInitPhysicsTrace_L_Ncomponent_M_Nphysics__trace__category_M_Nphysics__trace__type_M_Nphysics__trace__shape_M_Nphysics__trace__channel_M_Nvector3_M_Nvector3_M_Nlogic_M_Nvector3_M_Nfloat_M_N_Kchar_R(); // Function VGameplayRst.VGameplayRst_Physics_physics_trace._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fPhysics_2fphysics__trace_N_RInitPhysicsTrace_L_Ncomponent_M_Nphysics__trace__category_M_Nphysics__trace__type_M_Nphysics__trace__shape_M_Nphysics__trace__channel_M_Nvector3_M_Nvector3_M_Nlogic_M_Nvector3_M_Nfloat_M_N_Kchar_R // (Native|Public|BlueprintCallable) // @ game+0xaff2528
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Physics_physics_trace.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Physics_physics_trace.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Physics_physics_trace.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_mutable_positionable
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Transform_mutable_positionable : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_mutable_positionable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R // (Public|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_mutable_rotatable
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Transform_mutable_rotatable : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetRotation_L_Nrotation_R(); // Function VGameplayRst.VGameplayRst_Transform_mutable_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetRotation_L_Nrotation_R // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetForwardVectorFromXY_L_Nvector3_M_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_mutable_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetForwardVectorFromXY_L_Nvector3_M_Nvector3_R // (Public|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RApplyAdditionalRotation_L_Nrotation_R(); // Function VGameplayRst.VGameplayRst_Transform_mutable_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RApplyAdditionalRotation_L_Nrotation_R // (Public|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_mutable_scalable
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Transform_mutable_scalable : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__scalable_N_RSetScale_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_mutable_scalable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__scalable_N_RSetScale_L_Nvector3_R // (Public|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_position_component
// Size: 0xd8 (Inherited: 0x88)
struct UVGameplayRst_Transform_position_component : UEntityActorPositionComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_88[0x50]; // 0x88(0x50)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_position_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__positionable_N_RSetPosition_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff2530
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition(); // Function VGameplayRst.VGameplayRst_Transform_position_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2560
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fposition__component_N_RAddToPosition_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_position_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fposition__component_N_RAddToPosition_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff2558
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Transform_position_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Transform_position_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Transform_position_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_positionable
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Transform_positionable : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition(); // Function VGameplayRst.VGameplayRst_Transform_positionable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fpositionable_N_RGetPosition // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_rotatable
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Transform_rotatable : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector(); // Function VGameplayRst.VGameplayRst_Transform_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation(); // Function VGameplayRst.VGameplayRst_Transform_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector(); // Function VGameplayRst.VGameplayRst_Transform_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector(); // Function VGameplayRst.VGameplayRst_Transform_rotatable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_rotation_component
// Size: 0x130 (Inherited: 0x90)
struct UVGameplayRst_Transform_rotation_component : UEntityActorRotationComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_90[0xa0]; // 0x90(0xa0)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RUpVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetRotation_L_Nrotation_R(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetRotation_L_Nrotation_R // (Native|Public|BlueprintCallable) // @ game+0xaff2548
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetForwardVectorFromXY_L_Nvector3_M_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RSetForwardVectorFromXY_L_Nvector3_M_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff2540
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRotation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2568
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RRightVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2frotatable_N_RForwardVector // (Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x179ea74
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RApplyAdditionalRotation_L_Nrotation_R(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__rotatable_N_RApplyAdditionalRotation_L_Nrotation_R // (Native|Public|BlueprintCallable) // @ game+0xaff2538
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Transform_rotation_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_scalable
// Size: 0x28 (Inherited: 0x28)
struct UVGameplayRst_Transform_scalable : UObject {

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale(); // Function VGameplayRst.VGameplayRst_Transform_scalable._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_Transform_scale_component
// Size: 0xd8 (Inherited: 0x88)
struct UVGameplayRst_Transform_scale_component : UEntityActorScaleComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_88[0x50]; // 0x88(0x50)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__scalable_N_RSetScale_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_scale_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fmutable__scalable_N_RSetScale_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff2550
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale(); // Function VGameplayRst.VGameplayRst_Transform_scale_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscalable_N_RGetScale // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaff2570
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscale__component_N_RAddToScale_L_Nvector3_R(); // Function VGameplayRst.VGameplayRst_Transform_scale_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fTransform_2fscale__component_N_RAddToScale_L_Nvector3_R // (Native|Public|BlueprintCallable) // @ game+0xaff2578
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_Transform_scale_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_Transform_scale_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_Transform_scale_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VGameplayRst.VGameplayRst_VFX_particle_system_component
// Size: 0xd0 (Inherited: 0xa0)
struct UVGameplayRst_VFX_particle_system_component : UParticleSystemComponentBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A0[0x30]; // 0xa0(0x30)

	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fVFX_2fparticle__system__component_N_RSetParticleSystem_L_Nparticle__system_R(); // Function VGameplayRst.VGameplayRst_VFX_particle_system_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fVFX_2fparticle__system__component_N_RSetParticleSystem_L_Nparticle__system_R // (Native|Public|BlueprintCallable) // @ game+0xaff2590
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fVFX_2fparticle__system__component_N_RDeactivate(); // Function VGameplayRst.VGameplayRst_VFX_particle_system_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fVFX_2fparticle__system__component_N_RDeactivate // (Native|Public|BlueprintCallable) // @ game+0xaff2588
	void _L_2fUnrealEngine_2ecom_2fVGameplayRst_2fVFX_2fparticle__system__component_N_RActivate(); // Function VGameplayRst.VGameplayRst_VFX_particle_system_component._L_2fUnrealEngine_2ecom_2fVGameplayRst_2fVFX_2fparticle__system__component_N_RActivate // (Native|Public|BlueprintCallable) // @ game+0xaff2580
	void $InitInstance(); // Function VGameplayRst.VGameplayRst_VFX_particle_system_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VGameplayRst.VGameplayRst_VFX_particle_system_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VGameplayRst.VGameplayRst_VFX_particle_system_component.$InitCDO // (None) // @ game+0x179ea74
};

