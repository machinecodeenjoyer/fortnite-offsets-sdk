// BlueprintGeneratedClass BP_SurfaceTypeSoundComponent.BP_SurfaceTypeSoundComponent_C
// Size: 0x119 (Inherited: 0xa0)
struct UBP_SurfaceTypeSoundComponent_C : UActorComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A0[0x79]; // 0xa0(0x79)

	void ActuallyPlaySound(); // Function BP_SurfaceTypeSoundComponent.BP_SurfaceTypeSoundComponent_C.ActuallyPlaySound // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetSurfaceType(); // Function BP_SurfaceTypeSoundComponent.BP_SurfaceTypeSoundComponent_C.SetSurfaceType // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PlaySound(); // Function BP_SurfaceTypeSoundComponent.BP_SurfaceTypeSoundComponent_C.PlaySound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Test Delay(); // Function BP_SurfaceTypeSoundComponent.BP_SurfaceTypeSoundComponent_C.Test Delay // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_BP_SurfaceTypeSoundComponent(); // Function BP_SurfaceTypeSoundComponent.BP_SurfaceTypeSoundComponent_C.ExecuteUbergraph_BP_SurfaceTypeSoundComponent // (Final|UbergraphFunction) // @ game+0x179ea74
};

