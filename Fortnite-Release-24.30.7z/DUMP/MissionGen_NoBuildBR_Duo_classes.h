// BlueprintGeneratedClass MissionGen_NoBuildBR_Duo.MissionGen_NoBuildBR_Duo_C
// Size: 0x850 (Inherited: 0x850)
struct UMissionGen_NoBuildBR_Duo_C : UFortMissionGenerator {
};

