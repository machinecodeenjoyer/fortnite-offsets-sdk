// BlueprintGeneratedClass PBWA_W1_HalfWallS.PBWA_W1_HalfWallS_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_W1_HalfWallS_C : ABuildingWall {
};

