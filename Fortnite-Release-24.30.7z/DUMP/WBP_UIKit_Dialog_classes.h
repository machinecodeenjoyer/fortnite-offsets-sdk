// WidgetBlueprintGeneratedClass WBP_UIKit_Dialog.WBP_UIKit_Dialog_C
// Size: 0x428 (Inherited: 0x3d8)
struct UWBP_UIKit_Dialog_C : UUIKitDialogWidgetBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_3D8[0x50]; // 0x3d8(0x50)

	void SetUIKitDialogViewModel(); // Function WBP_UIKit_Dialog.WBP_UIKit_Dialog_C.SetUIKitDialogViewModel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FNameToNumText(); // Function WBP_UIKit_Dialog.WBP_UIKit_Dialog_C.FNameToNumText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void ArrayLengthToText(); // Function WBP_UIKit_Dialog.WBP_UIKit_Dialog_C.ArrayLengthToText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x179ea74
	void BndEvt__WBP_UIKit_Dialog_Button_Confirm_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_UIKit_Dialog.WBP_UIKit_Dialog_C.BndEvt__WBP_UIKit_Dialog_Button_Confirm_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BndEvt__WBP_UIKit_Dialog_Button_Decline_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_UIKit_Dialog.WBP_UIKit_Dialog_C.BndEvt__WBP_UIKit_Dialog_Button_Decline_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WBP_UIKit_Dialog(); // Function WBP_UIKit_Dialog.WBP_UIKit_Dialog_C.ExecuteUbergraph_WBP_UIKit_Dialog // (Final|UbergraphFunction) // @ game+0x179ea74
};

