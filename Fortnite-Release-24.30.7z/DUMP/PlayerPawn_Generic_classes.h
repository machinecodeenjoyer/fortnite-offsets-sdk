// BlueprintGeneratedClass PlayerPawn_Generic.PlayerPawn_Generic_C
// Size: 0x4ba8 (Inherited: 0x45b0)
struct APlayerPawn_Generic_C : APlayerPawn_Generic_Parent_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_45B0[0x5f8]; // 0x45b0(0x5f8)

	void Melee_Effect_Color(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Melee_Effect_Color // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void On Set Material Part(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.On Set Material Part // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Set Part Material(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Set Part Material // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Find Shield MID Array(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Find Shield MID Array // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Setup Duplicate FX Mesh(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Setup Duplicate FX Mesh // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetHealthPercent2(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GetHealthPercent2 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetShieldPercent2(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GetShieldPercent2 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_BlockedByPawns(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnRep_BlockedByPawns // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PlayHitSound(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.PlayHitSound // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void EnableWaterAudio(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.EnableWaterAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Set Body Type Sounds(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Set Body Type Sounds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Set Scalar Parameter on Duplicate Mesh MIDs(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Set Scalar Parameter on Duplicate Mesh MIDs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Restore Previous Materials on Weapons Mesh(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Restore Previous Materials on Weapons Mesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Restore Previous Materials on Character Mesh(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Restore Previous Materials on Character Mesh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Override Materials and Copy Parameters on Weapons Mesh(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Override Materials and Copy Parameters on Weapons Mesh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void TriggerGameplayWindEmitter(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.TriggerGameplayWindEmitter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Are the wind and water RTT passes enabled(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Are the wind and water RTT passes enabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void DisableWaterLevelTick(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.DisableWaterLevelTick // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_On_Player_Built_Floor(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnRep_On_Player_Built_Floor // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Create and Duplicate Effect Poseable Skeletal Mesh(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Create and Duplicate Effect Poseable Skeletal Mesh // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SlaveAMeshToTheBody(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SlaveAMeshToTheBody // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetShieldMids_InternalLoop(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SetShieldMids_InternalLoop // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetShieldMids(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SetShieldMids // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FindShieldOpacity(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.FindShieldOpacity // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Create and Duplicate Effect Skeletal Meshes Parent(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Create and Duplicate Effect Skeletal Meshes Parent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UserConstructionScript(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ShatterShield__FinishedFunc(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ShatterShield__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void ShatterShield__UpdateFunc(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ShatterShield__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void OnDamagePlayEffects(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnDamagePlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnLanded(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnLanded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnWeaponEquipped(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnWeaponEquipped // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ReceiveTick(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void FootStepLeft(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.FootStepLeft // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FootStepRight(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.FootStepRight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnCharacterPartsReinitialized(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnCharacterPartsReinitialized // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Abilities.Activation.Generic.HarvestBuff.Tier1(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Abilities.Activation.Generic.HarvestBuff.Tier1 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Abilities.Activation.Generic.HarvestBuff.Tier2(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Abilities.Activation.Generic.HarvestBuff.Tier2 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetFirstPersonCamera(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SetFirstPersonCamera // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void InternalSetFirstPersonCamera(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.InternalSetFirstPersonCamera // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBaseChanged(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnBaseChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ReceivePossessed(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ReceivePossessed // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnDisplaySentence(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnDisplaySentence // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnClearSentence(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnClearSentence // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ClientBindWeaponSwap(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ClientBindWeaponSwap // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BindWeaponSwap(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.BindWeaponSwap // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MultiSwapWeapon(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.MultiSwapWeapon // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UnBindWeaponSwap(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.UnBindWeaponSwap // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MultiEndSwap(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.MultiEndSwap // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnDeathServer(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void PlayGameplayWindEffect(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.PlayGameplayWindEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Entered Water Volume(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Entered Water Volume // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Player Creates a Splash(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Player Creates a Splash // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReinitializeWeaponMaterials(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ReinitializeWeaponMaterials // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnDeathPlayEffects(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Shield.FullyCharged(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Shield.FullyCharged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Damage.Shielded(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Damage.Shielded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Shield.Destroyed(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Shield.Destroyed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Damage(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Damage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnEnteredVehicle(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnEnteredVehicle // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnExitedVehicle(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnExitedVehicle // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingLeft(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.MeleeSwingLeft // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingRight(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.MeleeSwingRight // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingLeft_End(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.MeleeSwingLeft_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void MeleeSwingRight_End(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.MeleeSwingRight_End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnEnteredWaterVolume(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnEnteredWaterVolume // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnExitedWaterVolume(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnExitedWaterVolume // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void SetBlockedByPawns(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SetBlockedByPawns // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ToggleLandFX(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ToggleLandFX // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ToggleShieldVisibility(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ToggleShieldVisibility // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPartApplied(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnPartApplied // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBackpack(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnBackpack // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Set Scalar Parameter on Character MIDs(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.Set Scalar Parameter on Character MIDs // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMeshPart(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnMeshPart // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GameplayCue.Athena.Equipping(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.GameplayCue.Athena.Equipping // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLand_CE(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnLand_CE // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMeshPart3(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnMeshPart3 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMeshPartComplete(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnMeshPartComplete // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMeshPart2(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnMeshPart2 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBackpackPart(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.OnBackpackPart // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AnimTrailsDisable(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.AnimTrailsDisable // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AnimTrailsSetup(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.AnimTrailsSetup // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AnimTrailsNotify(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.AnimTrailsNotify // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PlayerPawn_Generic(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.ExecuteUbergraph_PlayerPawn_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
	void SwingLeft2__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SwingLeft2__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwingRight2__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SwingRight2__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AnimNotify_End__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.AnimNotify_End__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AnimNotify_Begin__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.AnimNotify_Begin__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwingLeftEnd__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SwingLeftEnd__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwingLeft__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SwingLeft__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwingRightEnd__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SwingRightEnd__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SwingRight__DelegateSignature(); // Function PlayerPawn_Generic.PlayerPawn_Generic_C.SwingRight__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

