// BlueprintGeneratedClass GCN_Sliding_Oneshot.GCN_Sliding_Oneshot_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Sliding_Oneshot_C : UFortGameplayCueNotify_Burst {

	void OnBurstGeneric(); // Function GCN_Sliding_Oneshot.GCN_Sliding_Oneshot_C.OnBurstGeneric // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
};

