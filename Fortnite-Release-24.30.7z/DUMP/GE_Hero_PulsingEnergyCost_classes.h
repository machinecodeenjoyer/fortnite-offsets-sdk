// BlueprintGeneratedClass GE_Hero_PulsingEnergyCost.GE_Hero_PulsingEnergyCost_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Hero_PulsingEnergyCost_C : UGET_EnergyCost_C {
};

