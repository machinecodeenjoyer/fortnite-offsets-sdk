// BlueprintGeneratedClass Border-ModalHeader.Border-ModalHeader_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-ModalHeader_C : UCommonBorderStyle {
};

