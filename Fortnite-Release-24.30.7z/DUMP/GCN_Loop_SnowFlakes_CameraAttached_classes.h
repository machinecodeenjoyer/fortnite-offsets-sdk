// BlueprintGeneratedClass GCN_Loop_SnowFlakes_CameraAttached.GCN_Loop_SnowFlakes_CameraAttached_C
// Size: 0x968 (Inherited: 0x960)
struct AGCN_Loop_SnowFlakes_CameraAttached_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x8]; // 0x960(0x08)

	void OnLoopingStart(); // Function GCN_Loop_SnowFlakes_CameraAttached.GCN_Loop_SnowFlakes_CameraAttached_C.OnLoopingStart // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_Loop_SnowFlakes_CameraAttached(); // Function GCN_Loop_SnowFlakes_CameraAttached.GCN_Loop_SnowFlakes_CameraAttached_C.ExecuteUbergraph_GCN_Loop_SnowFlakes_CameraAttached // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

