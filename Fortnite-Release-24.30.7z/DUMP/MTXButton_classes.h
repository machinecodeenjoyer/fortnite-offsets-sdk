// WidgetBlueprintGeneratedClass MTXButton.MTXButton_C
// Size: 0x14b8 (Inherited: 0x1470)
struct UMTXButton_C : UFortMTXButton {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1470[0x48]; // 0x1470(0x48)

	void GetHoverAnimation(); // Function MTXButton.MTXButton_C.GetHoverAnimation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void Construct(); // Function MTXButton.MTXButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function MTXButton.MTXButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnUnhovered(); // Function MTXButton.MTXButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnPressed(); // Function MTXButton.MTXButton_C.BP_OnPressed // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnReleased(); // Function MTXButton.MTXButton_C.BP_OnReleased // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_MTXButton(); // Function MTXButton.MTXButton_C.ExecuteUbergraph_MTXButton // (Final|UbergraphFunction) // @ game+0x179ea74
};

