// BlueprintGeneratedClass TextStyle-Base-S-B-Gray50.TextStyle-Base-S-B-Gray50_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-Base-S-B-Gray50_C : UTextStyle-Base-S-B-Gray_C {
};

