// UserDefinedEnum ModularButtonSize.ModularButtonSize
enum class ModularButtonSize : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ModularButtonSize_MAX = 3
};

