// BlueprintGeneratedClass v3_PlayerCameraModeTargetingAssault.v3_PlayerCameraModeTargetingAssault_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct Uv3_PlayerCameraModeTargetingAssault_C : Uv3_PlayerCameraModeRanged_C {
};

