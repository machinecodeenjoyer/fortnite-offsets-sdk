// BlueprintGeneratedClass B_PlayerHealthDamage_CameraLensEffect.B_PlayerHealthDamage_CameraLensEffect_C
// Size: 0x378 (Inherited: 0x370)
struct AB_PlayerHealthDamage_CameraLensEffect_C : AEmitterCameraLensEffectBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_370[0x8]; // 0x370(0x08)

	void PassParticle_Parameter(); // Function B_PlayerHealthDamage_CameraLensEffect.B_PlayerHealthDamage_CameraLensEffect_C.PassParticle_Parameter // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_B_PlayerHealthDamage_CameraLensEffect(); // Function B_PlayerHealthDamage_CameraLensEffect.B_PlayerHealthDamage_CameraLensEffect_C.ExecuteUbergraph_B_PlayerHealthDamage_CameraLensEffect // (Final|UbergraphFunction) // @ game+0x179ea74
};

