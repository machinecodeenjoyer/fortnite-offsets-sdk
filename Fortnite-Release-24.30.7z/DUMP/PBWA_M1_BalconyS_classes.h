// BlueprintGeneratedClass PBWA_M1_BalconyS.PBWA_M1_BalconyS_C
// Size: 0xd70 (Inherited: 0xd70)
struct APBWA_M1_BalconyS_C : ABuildingFloor {
};

