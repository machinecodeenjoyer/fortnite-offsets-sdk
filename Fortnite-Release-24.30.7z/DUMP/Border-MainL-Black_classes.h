// BlueprintGeneratedClass Border-MainL-Black.Border-MainL-Black_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-MainL-Black_C : UBorder-MainL_C {
};

