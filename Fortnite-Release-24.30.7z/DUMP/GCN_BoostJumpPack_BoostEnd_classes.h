// BlueprintGeneratedClass GCN_BoostJumpPack_BoostEnd.GCN_BoostJumpPack_BoostEnd_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_BoostJumpPack_BoostEnd_C : UFortGameplayCueNotify_Burst {
};

