// BlueprintGeneratedClass GE_SurfaceChange_Ice_Suppress.GE_SurfaceChange_Ice_Suppress_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_SurfaceChange_Ice_Suppress_C : UGameplayEffect {
};

