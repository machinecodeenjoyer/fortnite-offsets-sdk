// BlueprintGeneratedClass TextStyle-BurbankSmall-S-Teal.TextStyle-BurbankSmall-S-Teal_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-BurbankSmall-S-Teal_C : UTextStyle-BaseParent_C {
};

