// WidgetBlueprintGeneratedClass Athena_ProgressModal.Athena_ProgressModal_C
// Size: 0x420 (Inherited: 0x3e8)
struct UAthena_ProgressModal_C : UAthenaProgressModal {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_3E8[0x38]; // 0x3e8(0x38)

	void BP_OnActivated(); // Function Athena_ProgressModal.Athena_ProgressModal_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_Athena_ProgressModal(); // Function Athena_ProgressModal.Athena_ProgressModal_C.ExecuteUbergraph_Athena_ProgressModal // (Final|UbergraphFunction) // @ game+0x179ea74
};

