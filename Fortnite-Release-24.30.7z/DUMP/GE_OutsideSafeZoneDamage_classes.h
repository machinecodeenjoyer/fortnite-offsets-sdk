// BlueprintGeneratedClass GE_OutsideSafeZoneDamage.GE_OutsideSafeZoneDamage_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_OutsideSafeZoneDamage_C : UGET_PeriodicEnergyDamage_C {
};

