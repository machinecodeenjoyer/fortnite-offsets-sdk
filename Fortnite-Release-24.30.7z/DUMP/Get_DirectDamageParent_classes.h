// BlueprintGeneratedClass Get_DirectDamageParent.Get_DirectDamageParent_C
// Size: 0x858 (Inherited: 0x858)
struct UGet_DirectDamageParent_C : UGET_DamageParent_C {
};

