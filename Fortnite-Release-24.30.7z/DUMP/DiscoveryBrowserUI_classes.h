// Class DiscoveryBrowserUI.FortActivityBrowserTabButton
// Size: 0x1440 (Inherited: 0x1440)
struct UFortActivityBrowserTabButton : UFortTabButton {

	void OnFavoriteChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserTabButton.OnFavoriteChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityBrowser
// Size: 0x630 (Inherited: 0x3d8)
struct UFortActivityBrowser : UCommonActivatableWidget {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void OnSwapColorScheme(); // Function DiscoveryBrowserUI.FortActivityBrowser.OnSwapColorScheme // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnPlayerQueueTypeChanged(); // Function DiscoveryBrowserUI.FortActivityBrowser.OnPlayerQueueTypeChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnEnableColorScheme(); // Function DiscoveryBrowserUI.FortActivityBrowser.OnEnableColorScheme // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnActivitySelected(); // Function DiscoveryBrowserUI.FortActivityBrowser.OnActivitySelected // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleTabChanged(); // Function DiscoveryBrowserUI.FortActivityBrowser.HandleTabChanged // (Final|Native|Private) // @ game+0xb4d2ca4
};

// Class DiscoveryBrowserUI.FortActivityBrowserColorSchemeAsset
// Size: 0x80 (Inherited: 0x30)
struct UFortActivityBrowserColorSchemeAsset : UDataAsset {
	char pad_30[0x293]; // 0x30(0x293)
	struct TMap<struct FNone, None>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x2c3(0x2a0a800)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivityBrowserListView
// Size: 0x498 (Inherited: 0x290)
struct UFortActivityBrowserListView : UListViewBase {
	char pad_290[0x33]; // 0x290(0x33)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivityBrowserTileBase
// Size: 0x1470 (Inherited: 0x1410)
struct UFortActivityBrowserTileBase : UCommonButtonBase {
	char pad_1410[0x60]; // 0x1410(0x60)
};

// Class DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile
// Size: 0x14c0 (Inherited: 0x1470)
struct UFortActivityBrowserPlayWithFriendsTile : UFortActivityBrowserTileBase {
	int32_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40004201]; // 0x2c3(0x523c2810)
	 ; // 0x00(0x00)

	void UpdateSingleFriendName(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateSingleFriendName // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void UpdateRichPresence(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateRichPresence // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void UpdatePartyMemberNames(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdatePartyMemberNames // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void UpdatePartyInformation(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdatePartyInformation // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void UpdateLastInteraction(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateLastInteraction // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void UpdateJoinablePartySubText(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateJoinablePartySubText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void UpdateIslandInformationAndThumbnail(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateIslandInformationAndThumbnail // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void UpdateIslandInformation(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateIslandInformation // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnTileActiveSet(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.OnTileActiveSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnTextureLoadingComplete(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.OnTextureLoadingComplete // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnTextureBeginLoading(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.OnTextureBeginLoading // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleCTAButtonClicked(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.HandleCTAButtonClicked // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4d2c34
};

// Class DiscoveryBrowserUI.FortActivityBrowserRow
// Size: 0x368 (Inherited: 0x2c0)
struct UFortActivityBrowserRow : UCommonUserWidget {
	char pad_2C0[0x3]; // 0x2c0(0x03)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void OnRowPeekStateChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowPeekStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnRowMoveUp(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveUp // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnRowMoveDown(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveDown // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnRowIsSelectedChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsSelectedChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnRowIsActiveChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsActiveChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCategoryItemChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnCategoryItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void GetIsSelected(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2aac
	void GetIsInPeekState(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsInPeekState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2a84
	void GetIsActive(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9bdb0
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowHero
// Size: 0x3e8 (Inherited: 0x368)
struct UFortActivityBrowserRowHero : UFortActivityBrowserRow {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0x986021c0)
	 ; // 0x00(0x00)

	void OnVideoStarted(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoStarted // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnVideoEndReached(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoEndReached // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnUpdateDetailsDisplay(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnUpdateDetailsDisplay // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnRowHeroFocusChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnRowHeroFocusChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnQueryStatusChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryStatusChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnQueryActivitiesFinished(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryActivitiesFinished // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPreviewImageChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPreviewImageChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPlayKeyArtOutro(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtOutro // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPlayKeyArtIntro(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtIntro // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnListViewFinishedAddingEntries(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnListViewFinishedAddingEntries // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnActivityUpdated // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void IsShowingSeasonalContent(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsShowingSeasonalContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d31f0
	void IsInOutroState(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsInOutroState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x93af0e8
	void IsImageLoading(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsImageLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a59dc8
	void HandleActivityVideoCycleStarted(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleStarted // (Final|Native|Private) // @ game+0xb4d2bec
	void HandleActivityVideoCycleEndReached(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleEndReached // (Final|Native|Private) // @ game+0xb4d2ba4
	void GetKeyArtOutroAnimation(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetKeyArtOutroAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xb4d2ad4
	void GetCurrentTexture(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCurrentTexture // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xb4d2968
	void CycleNextActivity(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CycleNextActivity // (Final|Native|Public|BlueprintCallable) // @ game+0xb4d292c
	void CheckUpdateDetailsDelay(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CheckUpdateDetailsDelay // (Final|Native|Private) // @ game+0xb4d2904
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowList
// Size: 0x388 (Inherited: 0x368)
struct UFortActivityBrowserRowList : UFortActivityBrowserRow {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void OnQueryStatusChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRowList.OnQueryStatusChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowPromoted
// Size: 0x370 (Inherited: 0x368)
struct UFortActivityBrowserRowPromoted : UFortActivityBrowserRow {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void OnPreviewImageChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRowPromoted.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityBrowserView
// Size: 0x4b8 (Inherited: 0x428)
struct UFortActivityBrowserView : UFortActivityView {
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)
	char pad_428[0x90]; // 0x428(0x90)

	void OnSurfaceDataDirty(); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnSurfaceDataDirty // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityBrowserView.GetInvalidActivityReason // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2a00
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowView
// Size: 0x650 (Inherited: 0x4b8)
struct UFortActivityBrowserRowView : UFortActivityBrowserView {
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)

	void OnRowChanged(); // Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnRowChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnQueryActivitiesFinished(); // Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnQueryActivitiesFinished // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnActivityUpdated // (Event|Public|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityBrowserTile
// Size: 0x14b0 (Inherited: 0x1470)
struct UFortActivityBrowserTile : UFortActivityBrowserTileBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void HandleActivitySelected(); // Function DiscoveryBrowserUI.FortActivityBrowserTile.HandleActivitySelected // (Final|Native|Private) // @ game+0xb4d2b7c
};

// Class DiscoveryBrowserUI.FortActivityPlayerBrowserView
// Size: 0x5f0 (Inherited: 0x4b8)
struct UFortActivityPlayerBrowserView : UFortActivityBrowserView {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x58102000)
	 ; // 0x00(0x00)

	void PlayViewIntro(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.PlayViewIntro // (Final|Native|Public|BlueprintCallable) // @ game+0xb4d352c
	void OnQueryActivitiesStarted(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnQueryActivitiesStarted // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnQueryActivitiesComplete(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnQueryActivitiesComplete // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnPlayViewIntro(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnPlayViewIntro // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnTileViewUpdated(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.BP_OnTileViewUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityCategoryPageView
// Size: 0x630 (Inherited: 0x5f0)
struct UFortActivityCategoryPageView : UFortActivityPlayerBrowserView {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80208]; // 0x2c3(0x99f06080)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivityTileViewTileBase
// Size: 0x14a0 (Inherited: 0x1410)
struct UFortActivityTileViewTileBase : UCommonButtonBase {
	char pad_1410[0x90]; // 0x1410(0x90)
};

// Class DiscoveryBrowserUI.FortActivityCategoryTile
// Size: 0x14b0 (Inherited: 0x14a0)
struct UFortActivityCategoryTile : UFortActivityTileViewTileBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80208]; // 0x2c3(0x9ae02080)
	 ; // 0x00(0x00)

	void OnTileActiveSet(); // Function DiscoveryBrowserUI.FortActivityCategoryTile.OnTileActiveSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityCategoryTilePanel
// Size: 0x330 (Inherited: 0x2c0)
struct UFortActivityCategoryTilePanel : UCommonUserWidget {
	char pad_2C0[0x3]; // 0x2c0(0x03)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivityCategoryView
// Size: 0x5e0 (Inherited: 0x4b8)
struct UFortActivityCategoryView : UFortActivityBrowserView {
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40010201]; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)

	void OnSurfaceDataReady(); // Function DiscoveryBrowserUI.FortActivityCategoryView.OnSurfaceDataReady // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCategoryTilePanelSelected(); // Function DiscoveryBrowserUI.FortActivityCategoryView.OnCategoryTilePanelSelected // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void NavigateFromPanel(); // Function DiscoveryBrowserUI.FortActivityCategoryView.NavigateFromPanel // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4d3294
	void GetTopMostVisiblePanel(); // Function DiscoveryBrowserUI.FortActivityCategoryView.GetTopMostVisiblePanel // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0xb4d2b54
	void GetCurrentSelectedPanel(); // Function DiscoveryBrowserUI.FortActivityCategoryView.GetCurrentSelectedPanel // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa3a3960
};

// Class DiscoveryBrowserUI.FortActivityCreateView
// Size: 0x5e0 (Inherited: 0x4b8)
struct UFortActivityCreateView : UFortActivityBrowserView {
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40010201]; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)

	void OnCreativeActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityCreateView.OnCreativeActivityUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void GetInvalidCreativeActivityReason(); // Function DiscoveryBrowserUI.FortActivityCreateView.GetInvalidCreativeActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2a60
};

// Class DiscoveryBrowserUI.FortActivityCreatorPageView
// Size: 0x6a0 (Inherited: 0x630)
struct UFortActivityCreatorPageView : UFortActivityCategoryPageView {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2200]; // 0x2c3(0x18022000)
	 ; // 0x00(0x00)

	void OnNoContentFoundForCreator(); // Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnNoContentFoundForCreator // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnCreatorActivitiesQueryFinished(); // Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnCreatorActivitiesQueryFinished // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityDiscoverView
// Size: 0x6f0 (Inherited: 0x650)
struct UFortActivityDiscoverView : UFortActivityBrowserRowView {
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)
	char pad_650[0xa0]; // 0x650(0xa0)

	void OnUpdateDetailsDisplay(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnUpdateDetailsDisplay // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPreviewImageChanged(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPreviewImageChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPlayKeyArtOutro(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtOutro // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPlayKeyArtIntro(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtIntro // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnMoviePreEndEvent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePreEndEvent // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnMoviePlayingChanged(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePlayingChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void IsShowingSeasonalContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingSeasonalContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d3268
	void IsShowingPromotedContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingPromotedContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d31c4
	void IsInOutroState(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsInOutroState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d316c
	void IsImageLoading(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsImageLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d3154
	void HandleMovieWidgetMediaStarted(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaStarted // (Final|Native|Private) // @ game+0xb4d2c90
	void HandleMovieWidgetMediaPreEndEvent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaPreEndEvent // (Final|Native|Private) // @ game+0xb4d2c48
	void GetPromotedMovieWidget(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetPromotedMovieWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2b3c
	void GetMovieWidget(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetMovieWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2b24
	void GetKeyArtOutroAnimation(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetKeyArtOutroAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xb4d2afc
	void GetCurrentTexture(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetCurrentTexture // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xb4d2990
	void CheckUpdateDetailsDelay(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.CheckUpdateDetailsDelay // (Final|Native|Private) // @ game+0xb4d2918
};

// Class DiscoveryBrowserUI.FortActivityDiscoverViewV2
// Size: 0x680 (Inherited: 0x650)
struct UFortActivityDiscoverViewV2 : UFortActivityBrowserRowView {
	char pad_650[0x30]; // 0x650(0x30)

	void IsShowingSeasonalContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingSeasonalContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d3268
	void IsShowingPromotedContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingPromotedContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d31c4
};

// Class DiscoveryBrowserUI.FortActivityFavoriteBrowserView
// Size: 0x5f0 (Inherited: 0x5f0)
struct UFortActivityFavoriteBrowserView : UFortActivityPlayerBrowserView {
};

// Class DiscoveryBrowserUI.FortActivityListItemWrapper
// Size: 0x40 (Inherited: 0x28)
struct UFortActivityListItemWrapper : UObject {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2200]; // 0x00(0x18022000)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivityListView
// Size: 0x408 (Inherited: 0x290)
struct UFortActivityListView : UListViewBase {
	char pad_290[0x33]; // 0x290(0x33)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)

	void GetInViewCount(); // Function DiscoveryBrowserUI.FortActivityListView.GetInViewCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d29b8
};

// Class DiscoveryBrowserUI.FortActivityLobbyTile
// Size: 0x14d0 (Inherited: 0x1460)
struct UFortActivityLobbyTile : UCommonButtonLegacy {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void TrySendFirstTimeNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.TrySendFirstTimeNotification // (Final|Native|Public|BlueprintCallable) // @ game+0xb4d3758
	void ShowModeSetSelectionModal(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.ShowModeSetSelectionModal // (Final|Native|Public|BlueprintCallable) // @ game+0xb4d371c
	void OnShowChildActivityFirstTimeNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityFirstTimeNotification // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnShowChildActivityChangedNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityChangedNotification // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnPreviewImageChanged(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnHideChildActivityFirstTimeNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnHideChildActivityFirstTimeNotification // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnDetailsUpdated(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void IsModeSetActivity(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.IsModeSetActivity // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1a6e7a0
	void IsActivityEpicCreated(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.IsActivityEpicCreated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d30d4
	void GetChildActivityDisplayName(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.GetChildActivityDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1a6e7c4
};

// Class DiscoveryBrowserUI.FortActivityModeSetSelectionModal
// Size: 0x448 (Inherited: 0x3d8)
struct UFortActivityModeSetSelectionModal : UCommonActivatableWidget {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void SaveSelectionAndClose(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SaveSelectionAndClose // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4d3574
	void OnSubModeSelectionChanged(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSubModeSelected(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelected // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnPreviewImageChanged(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnActivityChanged(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnActivityChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class DiscoveryBrowserUI.FortActivityPlayerBrowserTile
// Size: 0x14f0 (Inherited: 0x14a0)
struct UFortActivityPlayerBrowserTile : UFortActivityTileViewTileBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)

	void HandleActivitySelected(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserTile.HandleActivitySelected // (Final|Native|Private) // @ game+0xb4d2b90
};

// Class DiscoveryBrowserUI.FortActivityPlayerView
// Size: 0x600 (Inherited: 0x4b8)
struct UFortActivityPlayerView : UFortActivityBrowserView {
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40010201]; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivityPlayerViewTabButton
// Size: 0x1440 (Inherited: 0x1440)
struct UFortActivityPlayerViewTabButton : UFortTabButton {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80208]; // 0x2c3(0x9ae02080)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortActivitySearchView
// Size: 0x620 (Inherited: 0x4b8)
struct UFortActivitySearchView : UFortActivityBrowserView {
	struct FName  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40010201]; // 0x2c3(0x90582010)
	 ; // 0x00(0x00)

	void OnActivityValidated(); // Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityValidated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnActivityClear(); // Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityClear // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleTextCommitted(); // Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextCommitted // (Final|Native|Private|HasOutParms) // @ game+0xb4d2ed0
	void HandleTextChanged(); // Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextChanged // (Final|Native|Private|HasOutParms) // @ game+0xb4d2e10
};

// Class DiscoveryBrowserUI.FortActivitySeasonalBrowserView
// Size: 0x5f0 (Inherited: 0x5f0)
struct UFortActivitySeasonalBrowserView : UFortActivityPlayerBrowserView {
};

// Class DiscoveryBrowserUI.FortActivityTileDetailsDisplay
// Size: 0x1550 (Inherited: 0x1410)
struct UFortActivityTileDetailsDisplay : UCommonButtonBase {
	struct FMulticastInlineDelegate  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10080200]; // 0x2c3(0x80100000)
	 ; // 0x00(0x00)

	void UpdateCCU(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.UpdateCCU // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void StopTileVideo(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.StopTileVideo // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4d3744
	void StartTileVideo(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.StartTileVideo // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4d3730
	void ShouldPlayTileVideo(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.ShouldPlayTileVideo // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void OnUpdateColumnSize(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnUpdateColumnSize // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnTileActiveSet(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnTileActiveSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnRequiresPurchaseChanged(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnRequiresPurchaseChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnPreviewImageChanged(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnPartySizeChanged(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPartySizeChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnLogoImageChanged(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLogoImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnLocalPlayerPromotedToLeader(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerPromotedToLeader // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnLocalPlayerDemoted(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerDemoted // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnIsFavoriteChanged(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnIsFavoriteChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnFriendsPlayingChanged(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnFriendsPlayingChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnDetailsUpdated(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnActivityUnSelected__DelegateSignature(); // DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x179ea74
	void OnActivitySelected__DelegateSignature(); // DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x179ea74
	void IsModeSetActivity(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsModeSetActivity // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d3184
	void IsActivityFavorited(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityFavorited // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d3130
	void IsActivityEpicCreated(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityEpicCreated // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d310c
	void GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetInvalidActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2a34
	void DoesActivityRequirePurchase(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.DoesActivityRequirePurchase // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d2944
};

// Class DiscoveryBrowserUI.FortActivityTileView
// Size: 0xbe0 (Inherited: 0xbe0)
struct UFortActivityTileView : UCommonTileView {

	void SetListenForMouseWheelInput(); // Function DiscoveryBrowserUI.FortActivityTileView.SetListenForMouseWheelInput // (Final|Native|Public|BlueprintCallable) // @ game+0xb4d35ac
};

// Class DiscoveryBrowserUI.FortDiscoverItemBrowserRow
// Size: 0x388 (Inherited: 0x368)
struct UFortDiscoverItemBrowserRow : UFortActivityBrowserRow {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0xa0d021c0)
	 ; // 0x00(0x00)
};

// Class DiscoveryBrowserUI.FortDiscoverItemListView
// Size: 0x3c0 (Inherited: 0x290)
struct UFortDiscoverItemListView : UListViewBase {
	char pad_290[0x33]; // 0x290(0x33)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)

	void GetInViewCount(); // Function DiscoveryBrowserUI.FortDiscoverItemListView.GetInViewCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4d29dc
};

// Class DiscoveryBrowserUI.ActivityLibraryComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UActivityLibraryComponent : UActorComponent {
	char pad_A0[0x10]; // 0xa0(0x10)
};

// Class DiscoveryBrowserUI.FortActivityBrowserContext
// Size: 0x48 (Inherited: 0x30)
struct UFortActivityBrowserContext : UGameInstanceSubsystem {
	char pad_30[0x18]; // 0x30(0x18)
};

// Class DiscoveryBrowserUI.OverrideMatchmakingUIComponent
// Size: 0x118 (Inherited: 0xa0)
struct UOverrideMatchmakingUIComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10001]; // 0x2c3(0x400000)
	 ; // 0x00(0x00)
};

