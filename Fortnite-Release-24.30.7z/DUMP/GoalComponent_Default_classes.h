// BlueprintGeneratedClass GoalComponent_Default.GoalComponent_Default_C
// Size: 0x158 (Inherited: 0x158)
struct UGoalComponent_Default_C : UFortAIGoalComponent {
};

