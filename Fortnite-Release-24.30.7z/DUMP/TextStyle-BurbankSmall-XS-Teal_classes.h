// BlueprintGeneratedClass TextStyle-BurbankSmall-XS-Teal.TextStyle-BurbankSmall-XS-Teal_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-BurbankSmall-XS-Teal_C : UTextStyle-BaseParent_C {
};

