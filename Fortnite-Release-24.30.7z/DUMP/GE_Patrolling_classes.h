// BlueprintGeneratedClass GE_Patrolling.GE_Patrolling_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Patrolling_C : UGameplayEffect {
};

