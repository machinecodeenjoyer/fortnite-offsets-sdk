// BlueprintGeneratedClass BP_SprayDecal.BP_SprayDecal_C
// Size: 0xe52 (Inherited: 0xd98)
struct ABP_SprayDecal_C : AFortSprayDecalInstance {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_D98[0xba]; // 0xd98(0xba)

	void Initialize Spray Spawned from Gameplay(); // Function BP_SprayDecal.BP_SprayDecal_C.Initialize Spray Spawned from Gameplay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AddBoxCollisionForCreative(); // Function BP_SprayDecal.BP_SprayDecal_C.AddBoxCollisionForCreative // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FindNearbyBuildingActorsAndBindDelegates(); // Function BP_SprayDecal.BP_SprayDecal_C.FindNearbyBuildingActorsAndBindDelegates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UnbindAndClearNearbyBuildingActors(); // Function BP_SprayDecal.BP_SprayDecal_C.UnbindAndClearNearbyBuildingActors // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRep_DecalFadeoutTime(); // Function BP_SprayDecal.BP_SprayDecal_C.OnRep_DecalFadeoutTime // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetInstigatorPlayerId(); // Function BP_SprayDecal.BP_SprayDecal_C.GetInstigatorPlayerId // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CreateDecalComponents(); // Function BP_SprayDecal.BP_SprayDecal_C.CreateDecalComponents // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void UserConstructionScript(); // Function BP_SprayDecal.BP_SprayDecal_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoaded_F8AB699B4D8DD22B5A0409B608B7D6FA(); // Function BP_SprayDecal.BP_SprayDecal_C.OnLoaded_F8AB699B4D8DD22B5A0409B608B7D6FA // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoaded_F925FF00475A018319C73E9FB1540BC6(); // Function BP_SprayDecal.BP_SprayDecal_C.OnLoaded_F925FF00475A018319C73E9FB1540BC6 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnReady_B252FED346EAB98D54D786BD15C1CC7B(); // Function BP_SprayDecal.BP_SprayDecal_C.OnReady_B252FED346EAB98D54D786BD15C1CC7B // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveBeginPlay(); // Function BP_SprayDecal.BP_SprayDecal_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSprayAssetReplicatedDown(); // Function BP_SprayDecal.BP_SprayDecal_C.OnSprayAssetReplicatedDown // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnSprayInfoReady(); // Function BP_SprayDecal.BP_SprayDecal_C.OnSprayInfoReady // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void StartSprayFadeOutDueToNewPlacement(); // Function BP_SprayDecal.BP_SprayDecal_C.StartSprayFadeOutDueToNewPlacement // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnNearbyWallDied(); // Function BP_SprayDecal.BP_SprayDecal_C.OnNearbyWallDied // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnNearbyWallDamaged(); // Function BP_SprayDecal.BP_SprayDecal_C.OnNearbyWallDamaged // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnBounceOccurs(); // Function BP_SprayDecal.BP_SprayDecal_C.OnBounceOccurs // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnNearbyTrapPlaced(); // Function BP_SprayDecal.BP_SprayDecal_C.OnNearbyTrapPlaced // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PostLevelSaveSpawnCleanup(); // Function BP_SprayDecal.BP_SprayDecal_C.PostLevelSaveSpawnCleanup // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnWallDestoryed(); // Function BP_SprayDecal.BP_SprayDecal_C.OnWallDestoryed // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_BP_SprayDecal(); // Function BP_SprayDecal.BP_SprayDecal_C.ExecuteUbergraph_BP_SprayDecal // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

