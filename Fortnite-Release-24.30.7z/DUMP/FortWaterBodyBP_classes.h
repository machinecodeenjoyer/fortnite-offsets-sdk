// BlueprintGeneratedClass FortWaterBodyBP.FortWaterBodyBP_C
// Size: 0x3b8 (Inherited: 0x3a8)
struct AFortWaterBodyBP_C : AFortWaterBodyActor {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_3A8[0x10]; // 0x3a8(0x10)

	void ReceiveBeginPlay(); // Function FortWaterBodyBP.FortWaterBodyBP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnReceivedBulletImpact(); // Function FortWaterBodyBP.FortWaterBodyBP_C.OnReceivedBulletImpact // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_FortWaterBodyBP(); // Function FortWaterBodyBP.FortWaterBodyBP_C.ExecuteUbergraph_FortWaterBodyBP // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

