// BlueprintGeneratedClass _BorderStyle_ModalHeader._BorderStyle_ModalHeader_C
// Size: 0xf0 (Inherited: 0xf0)
struct U_BorderStyle_ModalHeader_C : UCommonBorderStyle {
};

