// BlueprintGeneratedClass GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C
// Size: 0xb92 (Inherited: 0xb58)
struct UGA_Action_Sprint_GrindRail_C : UFortGameplayAbility_Action {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B58[0x3a]; // 0xb58(0x3a)

	void OnPress_BBDAB9B94E9778E3575BD1A1551EA10E(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.OnPress_BBDAB9B94E9778E3575BD1A1551EA10E // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRelease_5B08467A452F5716E7C96290186D3E19(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.OnRelease_5B08467A452F5716E7C96290186D3E19 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnPress_EB1E0A904B5B510E2C8590AD3B367EDD(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.OnPress_EB1E0A904B5B510E2C8590AD3B367EDD // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRelease_CFE6F71C4CB50BE9AD6253AFAA0862C2(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.OnRelease_CFE6F71C4CB50BE9AD6253AFAA0862C2 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void FailedToActivatePassiveAbility(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.FailedToActivatePassiveAbility // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Action_Sprint_GrindRail(); // Function GA_Action_Sprint_GrindRail.GA_Action_Sprint_GrindRail_C.ExecuteUbergraph_GA_Action_Sprint_GrindRail // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

