// WidgetBlueprintGeneratedClass FortOwningPlayerSocialNameTextBlock.FortOwningPlayerSocialNameTextBlock_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct UFortOwningPlayerSocialNameTextBlock_C : UFortOwningPlayerSocialNameTextBlock {
};

