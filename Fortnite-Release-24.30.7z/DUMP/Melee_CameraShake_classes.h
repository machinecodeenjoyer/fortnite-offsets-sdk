// BlueprintGeneratedClass Melee_CameraShake.Melee_CameraShake_C
// Size: 0x210 (Inherited: 0x210)
struct UMelee_CameraShake_C : ULegacyCameraShake {
};

