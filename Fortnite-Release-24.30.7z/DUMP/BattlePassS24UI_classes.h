// Class BattlePassS24UI.BattlePassBulkBuyPageS24
// Size: 0x560 (Inherited: 0x560)
struct UBattlePassBulkBuyPageS24 : UFortBattlePassBulkBuyPageBase {
};

// Class BattlePassS24UI.BattlePassLandingPageS24
// Size: 0x578 (Inherited: 0x518)
struct UBattlePassLandingPageS24 : UBattlePassLandingPageBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0x9d6101c0)
	 ; // 0x00(0x00)

	void OnBattlePassSubscriptionAllowed(); // Function BattlePassS24UI.BattlePassLandingPageS24.OnBattlePassSubscriptionAllowed // (Event|Public|BlueprintEvent) // @ game+0x179ea74
};

// Class BattlePassS24UI.BattlePassRewardPageS24
// Size: 0x580 (Inherited: 0x4e0)
struct UBattlePassRewardPageS24 : UBattlePassRewardPageBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x985c2010)
	 ; // 0x00(0x00)

	void OnPageChanged(); // Function BattlePassS24UI.BattlePassRewardPageS24.OnPageChanged // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnLoadingScreenSelectedChanged(); // Function BattlePassS24UI.BattlePassRewardPageS24.OnLoadingScreenSelectedChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInputMethodChanged(); // Function BattlePassS24UI.BattlePassRewardPageS24.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInitForPageType(); // Function BattlePassS24UI.BattlePassRewardPageS24.OnInitForPageType // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void HandleRewardTracksBoundaryNavigation(); // Function BattlePassS24UI.BattlePassRewardPageS24.HandleRewardTracksBoundaryNavigation // (Final|Native|Private) // @ game+0xb164238
	void GetRewardPageBackgroundData(); // Function BattlePassS24UI.BattlePassRewardPageS24.GetRewardPageBackgroundData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb163e38
};

// Class BattlePassS24UI.BattlePassScreenS24
// Size: 0xda0 (Inherited: 0x8c8)
struct UBattlePassScreenS24 : UBattlePassScreenBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x201]; // 0x2c3(0x583c2810)
	 ; // 0x00(0x00)

	void OverviewShowAnimationFinished(); // Function BattlePassS24UI.BattlePassScreenS24.OverviewShowAnimationFinished // (Final|Native|Public|BlueprintCallable) // @ game+0x29cdec8
	void OnUpdateStatusBar(); // Function BattlePassS24UI.BattlePassScreenS24.OnUpdateStatusBar // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnUpdateBattlePassRequiredBar(); // Function BattlePassS24UI.BattlePassScreenS24.OnUpdateBattlePassRequiredBar // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnTransitionItemDetails(); // Function BattlePassS24UI.BattlePassScreenS24.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSetWeeklyRewardsInfo(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetWeeklyRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x179ea74
	void OnSetResourcePrice(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetResourcePrice // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSetQuestRewardsInfo(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetQuestRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x179ea74
	void OnSetPrerequisiteInfo(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetPrerequisiteInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnSetItemPrice(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetItemPrice // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSetCrewInfo(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetCrewInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x179ea74
	void OnSetCoverPageData(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetCoverPageData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnSetBonusRewardsInfo(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetBonusRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnSetBaseRewardsInfo(); // Function BattlePassS24UI.BattlePassScreenS24.OnSetBaseRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnItemDelayed(); // Function BattlePassS24UI.BattlePassScreenS24.OnItemDelayed // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x179ea74
	void OnInsufficientResource(); // Function BattlePassS24UI.BattlePassScreenS24.OnInsufficientResource // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnInsufficientFunds(); // Function BattlePassS24UI.BattlePassScreenS24.OnInsufficientFunds // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnBattlePassOwned(); // Function BattlePassS24UI.BattlePassScreenS24.OnBattlePassOwned // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnBattlePassGiftingAllowed(); // Function BattlePassS24UI.BattlePassScreenS24.OnBattlePassGiftingAllowed // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void IsSeasonalCustomizationItemOwned(); // Function BattlePassS24UI.BattlePassScreenS24.IsSeasonalCustomizationItemOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb1643e0
	void HandleSwitcherVisibilityShown(); // Function BattlePassS24UI.BattlePassScreenS24.HandleSwitcherVisibilityShown // (Final|Native|Public|BlueprintCallable) // @ game+0xb1643b8
	void HandleFullScreenMapToggled(); // Function BattlePassS24UI.BattlePassScreenS24.HandleFullScreenMapToggled // (Final|Native|Private) // @ game+0xb1640b8
	void HandleClaimRewardComplete(); // Function BattlePassS24UI.BattlePassScreenS24.HandleClaimRewardComplete // (Final|Native|Private|HasOutParms) // @ game+0xb163f04
	void GoBackOneScreen(); // Function BattlePassS24UI.BattlePassScreenS24.GoBackOneScreen // (Final|Native|Public|BlueprintCallable) // @ game+0xb163ed4
	void GetQuestPageDelay(); // Function BattlePassS24UI.BattlePassScreenS24.GetQuestPageDelay // (Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb163e0c
};

// Class BattlePassS24UI.FortBattlePassCustomSkinPageS24
// Size: 0x5a8 (Inherited: 0x590)
struct UFortBattlePassCustomSkinPageS24 : UFortBattlePassCustomSkinPageBase {
	struct FString  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x58380800)
	 ; // 0x00(0x00)
};

// Class BattlePassS24UI.FortBattlePassResourcesWidgetS24
// Size: 0x2f0 (Inherited: 0x2d0)
struct UFortBattlePassResourcesWidgetS24 : UFortBattlePassResourcesWidgetBase {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0x9d6101c0)
	 ; // 0x00(0x00)

	void OnStylePointsRewardsSet(); // Function BattlePassS24UI.FortBattlePassResourcesWidgetS24.OnStylePointsRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnBattleStarRewardsSet(); // Function BattlePassS24UI.FortBattlePassResourcesWidgetS24.OnBattleStarRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

// Class BattlePassS24UI.FortBattlePassTutorialTooltipS24
// Size: 0x2d0 (Inherited: 0x2c0)
struct UFortBattlePassTutorialTooltipS24 : UCommonUserWidget {
	char pad_2C0[0x3]; // 0x2c0(0x03)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x8021c]; // 0x2c3(0x9d6101c0)
	 ; // 0x00(0x00)

	void ShowTooltip(); // Function BattlePassS24UI.FortBattlePassTutorialTooltipS24.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void SetText(); // Function BattlePassS24UI.FortBattlePassTutorialTooltipS24.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0xb150934
	void HideTooltip(); // Function BattlePassS24UI.FortBattlePassTutorialTooltipS24.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

