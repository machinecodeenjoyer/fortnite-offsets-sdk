// BlueprintGeneratedClass GA_BoostJumpPack_Jump.GA_BoostJumpPack_Jump_C
// Size: 0xb58 (Inherited: 0xb58)
struct UGA_BoostJumpPack_Jump_C : UFortGameplayAbility_Jump {
};

