// BlueprintGeneratedClass PBWA_W1_RoofC.PBWA_W1_RoofC_C
// Size: 0xd70 (Inherited: 0xd70)
struct APBWA_W1_RoofC_C : ABuildingRoof {
};

