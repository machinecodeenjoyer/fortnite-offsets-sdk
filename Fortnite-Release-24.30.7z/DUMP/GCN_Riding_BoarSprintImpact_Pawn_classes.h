// BlueprintGeneratedClass GCN_Riding_BoarSprintImpact_Pawn.GCN_Riding_BoarSprintImpact_Pawn_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Riding_BoarSprintImpact_Pawn_C : UFortGameplayCueNotify_Burst {
};

