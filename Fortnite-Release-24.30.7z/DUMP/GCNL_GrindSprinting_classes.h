// BlueprintGeneratedClass GCNL_GrindSprinting.GCNL_GrindSprinting_C
// Size: 0x978 (Inherited: 0x960)
struct AGCNL_GrindSprinting_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x18]; // 0x960(0x18)

	void OnLoopingStartGeneric(); // Function GCNL_GrindSprinting.GCNL_GrindSprinting_C.OnLoopingStartGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCNL_GrindSprinting.GCNL_GrindSprinting_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_GrindSprinting(); // Function GCNL_GrindSprinting.GCNL_GrindSprinting_C.ExecuteUbergraph_GCNL_GrindSprinting // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

