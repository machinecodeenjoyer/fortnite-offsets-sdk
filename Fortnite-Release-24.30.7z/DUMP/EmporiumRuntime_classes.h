// Class EmporiumRuntime.EmporiumAssetsPaths
// Size: 0x4b0 (Inherited: 0x28)
struct UEmporiumAssetsPaths : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x488]; // 0x28(0x488)
};

