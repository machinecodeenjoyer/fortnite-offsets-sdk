// Class AmbientAudio.AmbientAudioComponent
// Size: 0xd8 (Inherited: 0xa8)
struct UAmbientAudioComponent : UAudioGameplayComponent {
	char pad_A8[0x21b]; // 0xa8(0x21b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x205]; // 0x2c3(0x997c2050)
	 ; // 0x00(0x00)

	void SetPriority(); // Function AmbientAudio.AmbientAudioComponent.SetPriority // (Final|Native|Public|BlueprintCallable) // @ game+0x884e75c
	void SetCrossfadeTime(); // Function AmbientAudio.AmbientAudioComponent.SetCrossfadeTime // (Final|Native|Public|BlueprintCallable) // @ game+0x884e5e8
	void SetAmbientAsset(); // Function AmbientAudio.AmbientAudioComponent.SetAmbientAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x884e468
};

// Class AmbientAudio.AmbientAudioDataAsset
// Size: 0x58 (Inherited: 0x30)
struct UAmbientAudioDataAsset : UDataAsset {
	char pad_30[0x293]; // 0x30(0x293)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x20100000)
	 ; // 0x00(0x00)
};

// Class AmbientAudio.AmbientAudioSubsystem
// Size: 0x258 (Inherited: 0x30)
struct UAmbientAudioSubsystem : UWorldSubsystem {
	char pad_30[0x293]; // 0x30(0x293)
	struct FMulticastInlineDelegate  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10080200]; // 0x2c3(0x20000000)
	 ; // 0x00(0x00)

	void RemoveGameplayTag(); // Function AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag // (Final|Native|Public|BlueprintCallable) // @ game+0x2845a5c
	void RemoveAmbientEntry(); // Function AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x2a75020
	void GetAudioParameterComponent(); // Function AmbientAudio.AmbientAudioSubsystem.GetAudioParameterComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x884e440
	void AddGameplayTag(); // Function AmbientAudio.AmbientAudioSubsystem.AddGameplayTag // (Final|Native|Public|BlueprintCallable) // @ game+0x884e2ac
	void AddAmbientEntry(); // Function AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x29d9850
};

// Class AmbientAudio.AmbientAudioParameterActor
// Size: 0x290 (Inherited: 0x288)
struct AAmbientAudioParameterActor : AActor {
	char pad_288[0x3b]; // 0x288(0x3b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x82208]; // 0x2c3(0xb9622080)
	 ; // 0x00(0x00)
};

