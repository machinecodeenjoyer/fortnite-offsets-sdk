// BlueprintGeneratedClass GE_Commando_ClusterBombDamage.GE_Commando_ClusterBombDamage_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Commando_ClusterBombDamage_C : UGET_DirectPhysicalDamage_C {
};

