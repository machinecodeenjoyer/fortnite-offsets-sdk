// Class MeshCosmetics.MeshCosmeticsApparelItemDefinition
// Size: 0x800 (Inherited: 0x7d8)
struct UMeshCosmeticsApparelItemDefinition : UFortApparelItemDefinition {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x2c3(0x348a950)
	 ; // 0x00(0x00)
};

// Class MeshCosmetics.FortCustomizableObjectParameterVariant
// Size: 0x88 (Inherited: 0x78)
struct UFortCustomizableObjectParameterVariant : UFortCosmeticVariantBackedByArray {
	char pad_78[0x24b]; // 0x78(0x24b)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x201]; // 0x2c3(0x40300800)
	 ; // 0x00(0x00)

	void ApplyVariants(); // Function MeshCosmetics.FortCustomizableObjectParameterVariant.ApplyVariants // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0xb561370
};

// Class MeshCosmetics.FortCustomizableObjectSprayVariant
// Size: 0x268 (Inherited: 0x78)
struct UFortCustomizableObjectSprayVariant : UFortCosmeticVariant {
	char pad_78[0x24b]; // 0x78(0x24b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x280810)
	 ; // 0x00(0x00)
};

// Class MeshCosmetics.MeshCosmeticsStep_ComponentRemoval
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_ComponentRemoval : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsOption_ApplyCustomizableObject
// Size: 0x30 (Inherited: 0x30)
struct UMeshCosmeticsOption_ApplyCustomizableObject : UFortCosmeticFlowOption {
};

// Class MeshCosmetics.MeshCosmeticsStep_RemoveCustomizableSkeletalComponents
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_RemoveCustomizableSkeletalComponents : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_ApplyParameters
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_ApplyParameters : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_CompileObjects
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_CompileObjects : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_ManageComponents
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_ManageComponents : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_ProcessVariantAssets
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_ProcessVariantAssets : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_ChooseParameters
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_ChooseParameters : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_CommitChosenParams
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_CommitChosenParams : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_HandleGeneratedMesh
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_HandleGeneratedMesh : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_PlaceComponent
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_PlaceComponent : UFortCosmeticStep {
};

// Class MeshCosmetics.GameFeatureAction_MeshCosmeticsCompileSchemaDepenencies
// Size: 0x28 (Inherited: 0x28)
struct UGameFeatureAction_MeshCosmeticsCompileSchemaDepenencies : UGameFeatureAction {
};

// Class MeshCosmetics.InstanceCache_FortGameInstance
// Size: 0x30 (Inherited: 0x30)
struct UInstanceCache_FortGameInstance : UGameInstanceSubsystem {

	void OnPreLoadMap(); // Function MeshCosmetics.InstanceCache_FortGameInstance.OnPreLoadMap // (Final|Native|Private|HasOutParms|Const) // @ game+0xb56195c
	void OnGameStateChanged(); // Function MeshCosmetics.InstanceCache_FortGameInstance.OnGameStateChanged // (Final|Native|Private) // @ game+0xb5617ec
	void OnGamePhaseChanged(); // Function MeshCosmetics.InstanceCache_FortGameInstance.OnGamePhaseChanged // (Final|Native|Private) // @ game+0x25c5c00
	void OnGameInstanceWorldChanged(); // Function MeshCosmetics.InstanceCache_FortGameInstance.OnGameInstanceWorldChanged // (Final|Native|Private) // @ game+0xb561568
};

// Class MeshCosmetics.MeshCosmeticTagInterface
// Size: 0x28 (Inherited: 0x28)
struct UMeshCosmeticTagInterface : UInterface {

	void OnPostCustomizationAnimGameplayTags_BP(); // Function MeshCosmetics.MeshCosmeticTagInterface.OnPostCustomizationAnimGameplayTags_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
};

// Class MeshCosmetics.FortCustomizableInstanceLODManagement
// Size: 0x28 (Inherited: 0x28)
struct UFortCustomizableInstanceLODManagement : UCustomizableInstanceLODManagementBase {
};

// Class MeshCosmetics.MeshCosmeticsLayoutSchema
// Size: 0x448 (Inherited: 0x3a8)
struct UMeshCosmeticsLayoutSchema : UFortApparelLayoutItemDefinition {
	struct TMap<struct FNone, None>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x2c3(0x2a0a800)
	 ; // 0x00(0x00)
};

// Class MeshCosmetics.MeshCosmeticsAppliedSchemaData
// Size: 0x50 (Inherited: 0x28)
struct UMeshCosmeticsAppliedSchemaData : UFortCosmeticItemAdditionalData {
	struct TSoftObjectPtr<FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x00(0x1c0000)
	 ; // 0x00(0x00)
};

// Class MeshCosmetics.MeshCosmeticsSupportedSchemaData
// Size: 0x38 (Inherited: 0x28)
struct UMeshCosmeticsSupportedSchemaData : UFortCosmeticItemAdditionalData {
	struct TArray<struct TSoftObjectPtr<FNone>>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x201]; // 0x00(0x28140000)
	 ; // 0x00(0x00)
};

