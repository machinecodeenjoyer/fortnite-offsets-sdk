// WidgetBlueprintGeneratedClass PrimarySkewButton.PrimarySkewButton_C
// Size: 0x14b0 (Inherited: 0x1460)
struct UPrimarySkewButton_C : UCommonButtonLegacy {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1460[0x50]; // 0x1460(0x50)

	void OnMouseButtonUp(); // Function PrimarySkewButton.PrimarySkewButton_C.OnMouseButtonUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnMouseButtonDown(); // Function PrimarySkewButton.PrimarySkewButton_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Construct(); // Function PrimarySkewButton.PrimarySkewButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function PrimarySkewButton.PrimarySkewButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnUnhovered(); // Function PrimarySkewButton.PrimarySkewButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnClicked(); // Function PrimarySkewButton.PrimarySkewButton_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__CommonActionWidgetAction_K2Node_ComponentBoundEvent_0_OnInputMethodChanged__DelegateSignature(); // Function PrimarySkewButton.PrimarySkewButton_C.BndEvt__CommonActionWidgetAction_K2Node_ComponentBoundEvent_0_OnInputMethodChanged__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void PreConstruct(); // Function PrimarySkewButton.PrimarySkewButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PrimarySkewButton(); // Function PrimarySkewButton.PrimarySkewButton_C.ExecuteUbergraph_PrimarySkewButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

