// BlueprintGeneratedClass CommonUI_XboxBrushData.CommonUI_XboxBrushData_C
// Size: 0xf8 (Inherited: 0xf8)
struct UCommonUI_XboxBrushData_C : UFortInputControllerData {
};

