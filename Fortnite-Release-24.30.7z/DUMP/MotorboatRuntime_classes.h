// Class MotorboatRuntime.FortMeatballVehicleAnimInstance
// Size: 0x6e0 (Inherited: 0x5f0)
struct UFortMeatballVehicleAnimInstance : UFortVehicleAnimInstance {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2214]; // 0x2c3(0xba322140)
	 ; // 0x00(0x00)
};

// Class MotorboatRuntime.FortMeatballPontoonsComponent
// Size: 0x2c0 (Inherited: 0x2c0)
struct UFortMeatballPontoonsComponent : UFortVehiclePontoonsComponent {
};

// Class MotorboatRuntime.FortMeatballVehicle
// Size: 0x1da0 (Inherited: 0x1ab0)
struct AFortMeatballVehicle : AFortAthenaSKVehicle {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x2c3(0x1500000)
	 ; // 0x00(0x00)

	void UpdateSnowAndDirtParams(); // Function MotorboatRuntime.FortMeatballVehicle.UpdateSnowAndDirtParams // (Final|Native|Protected|BlueprintCallable) // @ game+0xb422708
	void StopTurnRumble(); // Function MotorboatRuntime.FortMeatballVehicle.StopTurnRumble // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4226f4
	void StopLandRumble(); // Function MotorboatRuntime.FortMeatballVehicle.StopLandRumble // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4226e0
	void StopDriverCameraShake(); // Function MotorboatRuntime.FortMeatballVehicle.StopDriverCameraShake // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4226cc
	void SmashedThroughBuildingPiece(); // Function MotorboatRuntime.FortMeatballVehicle.SmashedThroughBuildingPiece // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x179ea74
	void ShowCooldownCue(); // Function MotorboatRuntime.FortMeatballVehicle.ShowCooldownCue // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnBoostStarted(); // Function MotorboatRuntime.FortMeatballVehicle.OnBoostStarted // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnBoostReady(); // Function MotorboatRuntime.FortMeatballVehicle.OnBoostReady // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnBoostFinished(); // Function MotorboatRuntime.FortMeatballVehicle.OnBoostFinished // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnBoostFailed(); // Function MotorboatRuntime.FortMeatballVehicle.OnBoostFailed // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void LandShakeEnd(); // Function MotorboatRuntime.FortMeatballVehicle.LandShakeEnd // (Final|Native|Protected|BlueprintCallable) // @ game+0xb4226b8
	void GetSeatRotation(); // Function MotorboatRuntime.FortMeatballVehicle.GetSeatRotation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb422690
	void GetSeatOffset(); // Function MotorboatRuntime.FortMeatballVehicle.GetSeatOffset // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb422668
	void GetBoostCharge(); // Function MotorboatRuntime.FortMeatballVehicle.GetBoostCharge // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb422650
	void CacheGroundFXComponent(); // Function MotorboatRuntime.FortMeatballVehicle.CacheGroundFXComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xb4224e0
	void CacheAudioPointers(); // Function MotorboatRuntime.FortMeatballVehicle.CacheAudioPointers // (Final|Native|Public|BlueprintCallable) // @ game+0xb421da4
};

// Class MotorboatRuntime.FortMeatballVehicleConfigs
// Size: 0x978 (Inherited: 0x8a8)
struct UFortMeatballVehicleConfigs : UFortPhysicsVehicleConfigs {
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40004205]; // 0x2c3(0x307c2050)
	 ; // 0x00(0x00)
};

