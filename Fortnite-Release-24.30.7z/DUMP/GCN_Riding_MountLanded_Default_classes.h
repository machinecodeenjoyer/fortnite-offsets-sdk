// BlueprintGeneratedClass GCN_Riding_MountLanded_Default.GCN_Riding_MountLanded_Default_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Riding_MountLanded_Default_C : UFortGameplayCueNotify_Burst {
};

