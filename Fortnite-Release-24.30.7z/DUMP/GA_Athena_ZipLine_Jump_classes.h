// BlueprintGeneratedClass GA_Athena_ZipLine_Jump.GA_Athena_ZipLine_Jump_C
// Size: 0xbc8 (Inherited: 0xb28)
struct UGA_Athena_ZipLine_Jump_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0xa0]; // 0xb28(0xa0)

	void K2_ActivateAbility(); // Function GA_Athena_ZipLine_Jump.GA_Athena_ZipLine_Jump_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Athena_ZipLine_Jump.GA_Athena_ZipLine_Jump_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Athena_ZipLine_Jump(); // Function GA_Athena_ZipLine_Jump.GA_Athena_ZipLine_Jump_C.ExecuteUbergraph_GA_Athena_ZipLine_Jump // (Final|UbergraphFunction) // @ game+0x179ea74
};

