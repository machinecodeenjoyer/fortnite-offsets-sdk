// BlueprintGeneratedClass TextStyle-BurbReg-Black-22.TextStyle-BurbReg-Black-22_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct UTextStyle-BurbReg-Black-22_C : UTextStyle-Base-M-B_C {
};

