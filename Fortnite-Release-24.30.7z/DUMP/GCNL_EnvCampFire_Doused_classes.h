// BlueprintGeneratedClass GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C
// Size: 0x9a0 (Inherited: 0x960)
struct AGCNL_EnvCampFire_Doused_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x40]; // 0x960(0x40)

	void Fade Doused Smoke__FinishedFunc(); // Function GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C.Fade Doused Smoke__FinishedFunc // (BlueprintEvent) // @ game+0x179ea74
	void Fade Doused Smoke__UpdateFunc(); // Function GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C.Fade Doused Smoke__UpdateFunc // (BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStart(); // Function GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C.OnLoopingStart // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemoval(); // Function GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C.OnRemoval // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void DestroyOnDestroy(); // Function GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C.DestroyOnDestroy // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCNL_EnvCampFire_Doused(); // Function GCNL_EnvCampFire_Doused.GCNL_EnvCampFire_Doused_C.ExecuteUbergraph_GCNL_EnvCampFire_Doused // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

