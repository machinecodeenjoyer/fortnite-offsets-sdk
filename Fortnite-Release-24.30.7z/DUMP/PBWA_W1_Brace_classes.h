// BlueprintGeneratedClass PBWA_W1_Brace.PBWA_W1_Brace_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_W1_Brace_C : ABuildingWall {
};

