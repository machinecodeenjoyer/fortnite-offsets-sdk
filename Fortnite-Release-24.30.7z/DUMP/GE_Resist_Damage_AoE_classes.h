// BlueprintGeneratedClass GE_Resist_Damage_AoE.GE_Resist_Damage_AoE_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Resist_Damage_AoE_C : UGameplayEffect {
};

