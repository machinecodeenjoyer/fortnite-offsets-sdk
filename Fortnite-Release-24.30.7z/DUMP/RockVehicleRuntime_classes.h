// Class RockVehicleRuntime.RockVehicle_InteractionOverrideComponent
// Size: 0xa0 (Inherited: 0xa0)
struct URockVehicle_InteractionOverrideComponent : UFortVehicleInteractionOverrideComponent {
};

// Class RockVehicleRuntime.FortCheatManager_RockVehicle
// Size: 0x28 (Inherited: 0x28)
struct UFortCheatManager_RockVehicle : UChildCheatManager {

	void RockVehicleSetVelocity(); // Function RockVehicleRuntime.FortCheatManager_RockVehicle.RockVehicleSetVelocity // (Final|Exec|Native|Public) // @ game+0x995ae34
	void RockVehicleSetRotation(); // Function RockVehicleRuntime.FortCheatManager_RockVehicle.RockVehicleSetRotation // (Final|Exec|Native|Public) // @ game+0x995ae34
	void RockVehicleSetLocation(); // Function RockVehicleRuntime.FortCheatManager_RockVehicle.RockVehicleSetLocation // (Final|Exec|Native|Public) // @ game+0x995ae34
	void RockVehicleSetBalboaVelocity(); // Function RockVehicleRuntime.FortCheatManager_RockVehicle.RockVehicleSetBalboaVelocity // (Final|Exec|Native|Public) // @ game+0x995ae34
};

// Class RockVehicleRuntime.RockVehicle
// Size: 0x1cf0 (Inherited: 0x1ab0)
struct ARockVehicle : AFortAthenaSKVehicle {
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40002214]; // 0x2c3(0x31e22140)
	 ; // 0x00(0x00)

	void ServerToggleFreeCam(); // Function RockVehicleRuntime.RockVehicle.ServerToggleFreeCam // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0xbaa7acc
	void ServerSetLegacyDamageValues(); // Function RockVehicleRuntime.RockVehicle.ServerSetLegacyDamageValues // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xbaa75d0
	void RockFreeCamToggledDelegate__DelegateSignature(); // DelegateFunction RockVehicleRuntime.RockVehicle.RockFreeCamToggledDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x179ea74
	void OnSpringImpact__DelegateSignature(); // DelegateFunction RockVehicleRuntime.RockVehicle.OnSpringImpact__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x179ea74
	void OnRep_FreeLookCamera(); // Function RockVehicleRuntime.RockVehicle.OnRep_FreeLookCamera // (Final|Native|Public) // @ game+0xbaa6ebc
	void GetThrottleState(); // Function RockVehicleRuntime.RockVehicle.GetThrottleState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb176afc
	void GetDriverInput(); // Function RockVehicleRuntime.RockVehicle.GetDriverInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbaa5f48
	void GetCurrentRockRuntimeConfigOverrides(); // Function RockVehicleRuntime.RockVehicle.GetCurrentRockRuntimeConfigOverrides // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbaa5f30
};

// Class RockVehicleRuntime.RockVehicleAbility
// Size: 0xb0 (Inherited: 0xa0)
struct URockVehicleAbility : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x58102000)
	 ; // 0x00(0x00)

	void GetVehicle(); // Function RockVehicleRuntime.RockVehicleAbility.GetVehicle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x29dfbfc
	void GetInactiveSeconds(); // Function RockVehicleRuntime.RockVehicleAbility.GetInactiveSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbaa5f94
	void GetActiveSeconds(); // Function RockVehicleRuntime.RockVehicleAbility.GetActiveSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3168f04
};

// Class RockVehicleRuntime.RockVehicleAbility_Physics
// Size: 0x108 (Inherited: 0xb0)
struct URockVehicleAbility_Physics : URockVehicleAbility {
	char pad_B0[0x213]; // 0xb0(0x213)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x51122000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_AirControl
// Size: 0x168 (Inherited: 0x108)
struct URockVehicleAbility_AirControl : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000205]; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_AutoUpright
// Size: 0x210 (Inherited: 0x108)
struct URockVehicleAbility_AutoUpright : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0xa02800)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_Boost
// Size: 0x170 (Inherited: 0x108)
struct URockVehicleAbility_Boost : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleBoostTank
// Size: 0x128 (Inherited: 0xa0)
struct URockVehicleBoostTank : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FMulticastInlineDelegate  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10080200]; // 0x2c3(0x20000000)
	 ; // 0x00(0x00)

	void OnRep_SecondsRemaining(); // Function RockVehicleRuntime.RockVehicleBoostTank.OnRep_SecondsRemaining // (Final|Native|Protected) // @ game+0xbaa6ef0
	void IsBoostFull(); // Function RockVehicleRuntime.RockVehicleBoostTank.IsBoostFull // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbaa619c
	void HasBoost(); // Function RockVehicleRuntime.RockVehicleBoostTank.HasBoost // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbaa617c
	void GiveBoost(); // Function RockVehicleRuntime.RockVehicleBoostTank.GiveBoost // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xbaa6008
	void GetPercentRemaining(); // Function RockVehicleRuntime.RockVehicleBoostTank.GetPercentRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbaa5fe8
	void GetMaxBoostInSeconds(); // Function RockVehicleRuntime.RockVehicleBoostTank.GetMaxBoostInSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8012748
};

// Class RockVehicleRuntime.RockVehicleAbility_Dodge
// Size: 0x438 (Inherited: 0x108)
struct URockVehicleAbility_Dodge : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_DoubleJump
// Size: 0x158 (Inherited: 0x108)
struct URockVehicleAbility_DoubleJump : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_Flip
// Size: 0x1f0 (Inherited: 0x108)
struct URockVehicleAbility_Flip : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_GroundTrails
// Size: 0x108 (Inherited: 0xb0)
struct URockVehicleAbility_GroundTrails : URockVehicleAbility {
	char pad_B0[0x213]; // 0xb0(0x213)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x200800)
	 ; // 0x00(0x00)

	void SetEnabled(); // Function RockVehicleRuntime.RockVehicleAbility_GroundTrails.SetEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x98b5de0
	void OnSurfaceChanged(); // Function RockVehicleRuntime.RockVehicleAbility_GroundTrails.OnSurfaceChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0xbaa742c
};

// Class RockVehicleRuntime.RockVehicleAbility_Jump
// Size: 0x1e0 (Inherited: 0x108)
struct URockVehicleAbility_Jump : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0x500000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_StickyWheels
// Size: 0x1a0 (Inherited: 0x108)
struct URockVehicleAbility_StickyWheels : URockVehicleAbility_Physics {
	char pad_108[0x1bb]; // 0x108(0x1bb)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x2c3(0xa02800)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAbility_Supersonic
// Size: 0x178 (Inherited: 0xb0)
struct URockVehicleAbility_Supersonic : URockVehicleAbility {
	char pad_B0[0x213]; // 0xb0(0x213)
	struct FMulticastInlineDelegate  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10080200]; // 0x2c3(0x20000000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAnalyticsComponent
// Size: 0xd8 (Inherited: 0xa0)
struct URockVehicleAnalyticsComponent : UActorComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2000]; // 0x2c3(0x20000)
	 ; // 0x00(0x00)

	void OnSupersonicStart(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnSupersonicStart // (Final|Native|Private) // @ game+0xbaa71cc
	void OnSupersonicEnd(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnSupersonicEnd // (Final|Native|Private) // @ game+0xbaa707c
	void OnPawnExitedSeat(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnPawnExitedSeat // (Final|Native|Private|HasOutParms) // @ game+0xbaa6bd8
	void OnPawnEnteredSeat(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnPawnEnteredSeat // (Final|Native|Private|HasOutParms) // @ game+0xbaa68f4
	void OnJumped(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnJumped // (Final|Native|Private) // @ game+0xbaa6694
	void OnDoubleJumped(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnDoubleJumped // (Final|Native|Private) // @ game+0xbaa6434
	void OnDodged(); // Function RockVehicleRuntime.RockVehicleAnalyticsComponent.OnDodged // (Final|Native|Private) // @ game+0xbaa61d4
};

// Class RockVehicleRuntime.RockVehicleAnimInstance
// Size: 0x770 (Inherited: 0x5f0)
struct URockVehicleAnimInstance : UFortVehicleAnimInstance {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x14]; // 0x2c3(0x1400140)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleAudioController
// Size: 0x3d8 (Inherited: 0x2e8)
struct ARockVehicleAudioController : AFortVehicleAudioController {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x100000)
	 ; // 0x00(0x00)

	void SetSurfaceTypeParam(); // Function RockVehicleRuntime.RockVehicleAudioController.SetSurfaceTypeParam // (Final|Native|Public|BlueprintCallable) // @ game+0xbaa7c88
	void SetBoosting(); // Function RockVehicleRuntime.RockVehicleAudioController.SetBoosting // (Final|Native|Public|BlueprintCallable) // @ game+0xbaa7b18
	void OnInAirUpdated(); // Function RockVehicleRuntime.RockVehicleAudioController.OnInAirUpdated // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GetMotorSimComponent(); // Function RockVehicleRuntime.RockVehicleAudioController.GetMotorSimComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x938b1c8
};

// Class RockVehicleRuntime.RockVehicleCameraMode
// Size: 0x1d30 (Inherited: 0x1b30)
struct URockVehicleCameraMode : UFortCameraMode_AthenaVehicle {
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40004205]; // 0x2c3(0x307c2050)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleConfigs
// Size: 0xeb0 (Inherited: 0x8a8)
struct URockVehicleConfigs : UFortPhysicsVehicleConfigs {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4005]; // 0x2c3(0x540050)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleManager
// Size: 0x2a8 (Inherited: 0x288)
struct ARockVehicleManager : AActor {
	char pad_288[0x3b]; // 0x288(0x3b)
	struct TArray<struct FNone*>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x2c3(0x80000000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.RockVehicleWorldSubsystem
// Size: 0x38 (Inherited: 0x30)
struct URockVehicleWorldSubsystem : UWorldSubsystem {
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x200]; // 0x00(0x58102000)
	 ; // 0x00(0x00)
};

// Class RockVehicleRuntime.StreamingRadioPlayerComponent_Rock
// Size: 0x450 (Inherited: 0x450)
struct UStreamingRadioPlayerComponent_Rock : UStreamingRadioPlayerComponent {

	void VehicleExploded(); // Function RockVehicleRuntime.StreamingRadioPlayerComponent_Rock.VehicleExploded // (Final|Native|Protected) // @ game+0xbaa7dfc
};

