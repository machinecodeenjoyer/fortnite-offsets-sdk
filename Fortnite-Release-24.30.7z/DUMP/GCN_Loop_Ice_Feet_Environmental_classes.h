// BlueprintGeneratedClass GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C
// Size: 0x998 (Inherited: 0x960)
struct AGCN_Loop_Ice_Feet_Environmental_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x38]; // 0x960(0x38)

	void AttachFX(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.AttachFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ReceiveTick(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnPawnMovementModeChanged(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.OnPawnMovementModeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void On Footstep Event(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.On Footstep Event // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStartGeneric(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.OnLoopingStartGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_Loop_Ice_Feet_Environmental(); // Function GCN_Loop_Ice_Feet_Environmental.GCN_Loop_Ice_Feet_Environmental_C.ExecuteUbergraph_GCN_Loop_Ice_Feet_Environmental // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

