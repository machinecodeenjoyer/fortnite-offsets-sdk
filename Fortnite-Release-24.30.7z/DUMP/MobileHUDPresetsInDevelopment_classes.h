// BlueprintGeneratedClass MobileHUDPresetsInDevelopment.MobileHUDPresetsInDevelopment_C
// Size: 0x40 (Inherited: 0x40)
struct UMobileHUDPresetsInDevelopment_C : UFortMobileHUDPresetContainer {
};

