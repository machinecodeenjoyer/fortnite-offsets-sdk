// AnimBlueprintGeneratedClass Player_Sprint_AnimBP.Player_Sprint_AnimBP_C
// Size: 0x1878 (Inherited: 0x6c0)
struct UPlayer_Sprint_AnimBP_C : UFortSprintAnimInstance {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_6C0[0x11b8]; // 0x6c0(0x11b8)

	void AnimGraph(); // Function Player_Sprint_AnimBP.Player_Sprint_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_Player_Sprint_AnimBP(); // Function Player_Sprint_AnimBP.Player_Sprint_AnimBP_C.ExecuteUbergraph_Player_Sprint_AnimBP // (Final|UbergraphFunction) // @ game+0x179ea74
};

