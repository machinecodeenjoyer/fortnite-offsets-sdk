// WidgetBlueprintGeneratedClass PlayerSurveyHorizontalIndicator.PlayerSurveyHorizontalIndicator_C
// Size: 0x2a8 (Inherited: 0x298)
struct UPlayerSurveyHorizontalIndicator_C : UUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x10]; // 0x298(0x10)

	void UpdateGamepadControlsVisibility(); // Function PlayerSurveyHorizontalIndicator.PlayerSurveyHorizontalIndicator_C.UpdateGamepadControlsVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__InputActionWidget_Move_K2Node_ComponentBoundEvent_0_OnInputMethodChanged__DelegateSignature(); // Function PlayerSurveyHorizontalIndicator.PlayerSurveyHorizontalIndicator_C.BndEvt__InputActionWidget_Move_K2Node_ComponentBoundEvent_0_OnInputMethodChanged__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_PlayerSurveyHorizontalIndicator(); // Function PlayerSurveyHorizontalIndicator.PlayerSurveyHorizontalIndicator_C.ExecuteUbergraph_PlayerSurveyHorizontalIndicator // (Final|UbergraphFunction) // @ game+0x179ea74
};

