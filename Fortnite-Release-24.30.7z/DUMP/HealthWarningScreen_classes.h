// WidgetBlueprintGeneratedClass HealthWarningScreen.HealthWarningScreen_C
// Size: 0x588 (Inherited: 0x548)
struct UHealthWarningScreen_C : UHealthWarningScreen {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_548[0x40]; // 0x548(0x40)

	void HandleShowTimerComplete(); // Function HealthWarningScreen.HealthWarningScreen_C.HandleShowTimerComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_HealthWarningScreen(); // Function HealthWarningScreen.HealthWarningScreen_C.ExecuteUbergraph_HealthWarningScreen // (Final|UbergraphFunction) // @ game+0x179ea74
	void HealthWarningCompleted__DelegateSignature(); // Function HealthWarningScreen.HealthWarningScreen_C.HealthWarningCompleted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
};

