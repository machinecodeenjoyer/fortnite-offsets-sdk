// BlueprintGeneratedClass PBWA_S1_RoofWall.PBWA_S1_RoofWall_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_S1_RoofWall_C : ABuildingWall {
};

