// Class AudioModulation.AudioModulationStyle
// Size: 0x28 (Inherited: 0x28)
struct UAudioModulationStyle : UBlueprintFunctionLibrary {

	void GetPatchColor(); // Function AudioModulation.AudioModulationStyle.GetPatchColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x8ba31a4
	void GetParameterColor(); // Function AudioModulation.AudioModulationStyle.GetParameterColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x8ba3184
	void GetModulationGeneratorColor(); // Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x8ba2b6c
	void GetControlBusMixColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusMixColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x8ba2b4c
	void GetControlBusColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x8ba2b2c
};

// Class AudioModulation.AudioModulationSettings
// Size: 0x40 (Inherited: 0x30)
struct UAudioModulationSettings : UDeveloperSettings {
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4201]; // 0x00(0x20100000)
	 ; // 0x00(0x00)
};

// Class AudioModulation.AudioModulationStatics
// Size: 0x28 (Inherited: 0x28)
struct UAudioModulationStatics : UBlueprintFunctionLibrary {

	void UpdateModulator(); // Function AudioModulation.AudioModulationStatics.UpdateModulator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba55d4
	void UpdateMixFromObject(); // Function AudioModulation.AudioModulationStatics.UpdateMixFromObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba51f8
	void UpdateMixByFilter(); // Function AudioModulation.AudioModulationStatics.UpdateMixByFilter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba47c4
	void UpdateMix(); // Function AudioModulation.AudioModulationStatics.UpdateMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba4110
	void SetGlobalBusMixValue(); // Function AudioModulation.AudioModulationStatics.SetGlobalBusMixValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba3bd0
	void SaveMixToProfile(); // Function AudioModulation.AudioModulationStatics.SaveMixToProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba3818
	void LoadMixFromProfile(); // Function AudioModulation.AudioModulationStatics.LoadMixFromProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba31c4
	void GetModulatorValue(); // Function AudioModulation.AudioModulationStatics.GetModulatorValue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8ba2b8c
	void GetModulatorsFromDestination(); // Function AudioModulation.AudioModulationStatics.GetModulatorsFromDestination // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8ba2e40
	void DeactivateGenerator(); // Function AudioModulation.AudioModulationStatics.DeactivateGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba281c
	void DeactivateBusMix(); // Function AudioModulation.AudioModulationStatics.DeactivateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba257c
	void DeactivateBus(); // Function AudioModulation.AudioModulationStatics.DeactivateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba22dc
	void CreateModulationParameter(); // Function AudioModulation.AudioModulationStatics.CreateModulationParameter // (Final|Native|Static|Public) // @ game+0x8ba1dcc
	void CreateLFOGenerator(); // Function AudioModulation.AudioModulationStatics.CreateLFOGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba19f4
	void CreateEnvelopeFollowerGenerator(); // Function AudioModulation.AudioModulationStatics.CreateEnvelopeFollowerGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba1608
	void CreateBusMixStage(); // Function AudioModulation.AudioModulationStatics.CreateBusMixStage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba0fc4
	void CreateBusMix(); // Function AudioModulation.AudioModulationStatics.CreateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba09ec
	void CreateBus(); // Function AudioModulation.AudioModulationStatics.CreateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba051c
	void ClearGlobalBusMixValue(); // Function AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ba0140
	void ClearAllGlobalBusMixValues(); // Function AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8b9fec0
	void ActivateGenerator(); // Function AudioModulation.AudioModulationStatics.ActivateGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8b9fc0c
	void ActivateBusMix(); // Function AudioModulation.AudioModulationStatics.ActivateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8b9f96c
	void ActivateBus(); // Function AudioModulation.AudioModulationStatics.ActivateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8b9f6cc
};

// Class AudioModulation.SoundModulationGenerator
// Size: 0x30 (Inherited: 0x30)
struct USoundModulationGenerator : USoundModulatorBase {
};

// Class AudioModulation.SoundModulationGeneratorEnvelopeFollower
// Size: 0x50 (Inherited: 0x30)
struct USoundModulationGeneratorEnvelopeFollower : USoundModulationGenerator {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x00(0x500050)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundModulationGeneratorLFO
// Size: 0x50 (Inherited: 0x30)
struct USoundModulationGeneratorLFO : USoundModulationGenerator {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x00(0x500050)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundControlBus
// Size: 0x60 (Inherited: 0x30)
struct USoundControlBus : USoundModulatorBase {
	char pad_30[0x293]; // 0x30(0x293)
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x2c3(0x30782050)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundControlBusMix
// Size: 0x40 (Inherited: 0x28)
struct USoundControlBusMix : UObject {
	char pad_28[0x29b]; // 0x28(0x29b)
	uint32_t  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40002201]; // 0x2c3(0x301a2010)
	 ; // 0x00(0x00)

	void SoloMix(); // Function AudioModulation.SoundControlBusMix.SoloMix // (Final|Native|Protected) // @ game+0x8ba40d4
	void SaveMixToProfile(); // Function AudioModulation.SoundControlBusMix.SaveMixToProfile // (Final|Native|Protected) // @ game+0x8ba3bb8
	void LoadMixFromProfile(); // Function AudioModulation.SoundControlBusMix.LoadMixFromProfile // (Final|Native|Protected) // @ game+0x8ba37e4
	void DeactivateMix(); // Function AudioModulation.SoundControlBusMix.DeactivateMix // (Final|Native|Protected) // @ game+0x8ba2af0
	void DeactivateAllMixes(); // Function AudioModulation.SoundControlBusMix.DeactivateAllMixes // (Final|Native|Protected) // @ game+0x8ba22a0
	void ActivateMix(); // Function AudioModulation.SoundControlBusMix.ActivateMix // (Final|Native|Protected) // @ game+0x8b9feac
};

// Class AudioModulation.SoundModulationParameter
// Size: 0x38 (Inherited: 0x28)
struct USoundModulationParameter : UObject {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x15]; // 0x00(0x1500150)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundModulationParameterScaled
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterScaled : USoundModulationParameter {
	char pad_38[0x28b]; // 0x38(0x28b)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x2c3(0x31f82150)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundModulationParameterFrequencyBase
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterFrequencyBase : USoundModulationParameter {
};

// Class AudioModulation.SoundModulationParameterFrequency
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterFrequency : USoundModulationParameterFrequencyBase {
	char pad_38[0x28b]; // 0x38(0x28b)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x2c3(0x31f82150)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundModulationParameterFilterFrequency
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterFilterFrequency : USoundModulationParameterFrequencyBase {
};

// Class AudioModulation.SoundModulationParameterLPFFrequency
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterLPFFrequency : USoundModulationParameterFilterFrequency {
};

// Class AudioModulation.SoundModulationParameterHPFFrequency
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterHPFFrequency : USoundModulationParameterFilterFrequency {
};

// Class AudioModulation.SoundModulationParameterBipolar
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterBipolar : USoundModulationParameter {
	char pad_38[0x28b]; // 0x38(0x28b)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x2c3(0x31f82150)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundModulationParameterVolume
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterVolume : USoundModulationParameter {
	char pad_38[0x28b]; // 0x38(0x28b)
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000215]; // 0x2c3(0x31f82150)
	 ; // 0x00(0x00)
};

// Class AudioModulation.SoundModulationPatch
// Size: 0x50 (Inherited: 0x30)
struct USoundModulationPatch : USoundModulatorBase {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x5]; // 0x00(0x500000)
	 ; // 0x00(0x00)
};

