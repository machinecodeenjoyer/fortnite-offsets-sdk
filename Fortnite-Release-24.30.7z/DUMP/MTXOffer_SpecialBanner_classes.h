// WidgetBlueprintGeneratedClass MTXOffer_SpecialBanner.MTXOffer_SpecialBanner_C
// Size: 0x300 (Inherited: 0x298)
struct UMTXOffer_SpecialBanner_C : UUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x68]; // 0x298(0x68)

	void SetupSpecialOfferBanner(); // Function MTXOffer_SpecialBanner.MTXOffer_SpecialBanner_C.SetupSpecialOfferBanner // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_MTXOffer_SpecialBanner(); // Function MTXOffer_SpecialBanner.MTXOffer_SpecialBanner_C.ExecuteUbergraph_MTXOffer_SpecialBanner // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

