// BlueprintGeneratedClass GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C
// Size: 0xb98 (Inherited: 0xb28)
struct UGA_Athena_TillLandFallDamageImmunity_Parent_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x70]; // 0xb28(0x70)

	void Added_3DBE819D4ED6A0A0909A7690321F9B09(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.Added_3DBE819D4ED6A0A0909A7690321F9B09 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Added_15DBA1504E74C72F22BBCBAD8E3CD31E(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.Added_15DBA1504E74C72F22BBCBAD8E3CD31E // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Added_052C8416489756AFAF2C5391148ABB52(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.Added_052C8416489756AFAF2C5391148ABB52 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Added_1195BCDD4C66168D5746C2BD02970859(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.Added_1195BCDD4C66168D5746C2BD02970859 // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void CallEnd(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.CallEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetUpWaits(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.SetUpWaits // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetUpBinds(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.SetUpBinds // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void PawnLanded(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.PawnLanded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FailedToActivatePassiveAbility(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.FailedToActivatePassiveAbility // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Athena_TillLandFallDamageImmunity_Parent(); // Function GA_Athena_TillLandFallDamageImmunity_Parent.GA_Athena_TillLandFallDamageImmunity_Parent_C.ExecuteUbergraph_GA_Athena_TillLandFallDamageImmunity_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

