// Class MotorboatUI.FortAthenaVehicleDashboardWidget_Meatball
// Size: 0x468 (Inherited: 0x468)
struct UFortAthenaVehicleDashboardWidget_Meatball : UFortAthenaVehicleDashboardWidget {

	void GetMeatballVehicle(); // Function MotorboatUI.FortAthenaVehicleDashboardWidget_Meatball.GetMeatballVehicle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb422ae4
};

