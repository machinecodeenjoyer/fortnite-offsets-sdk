// BlueprintGeneratedClass GCN_Physics_Tree_Destruction_Burst.GCN_Physics_Tree_Destruction_Burst_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Physics_Tree_Destruction_Burst_C : UFortGameplayCueNotify_Burst {

	void OnBurstGeneric(); // Function GCN_Physics_Tree_Destruction_Burst.GCN_Physics_Tree_Destruction_Burst_C.OnBurstGeneric // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
};

