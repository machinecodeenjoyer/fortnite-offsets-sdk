// Class FortniteConversationRuntime.FortConversationMarkerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationMarkerInterface : UInterface {
};

// Class FortniteConversationRuntime.FortConversationParticipantComponent
// Size: 0x1a0 (Inherited: 0x1a0)
struct UFortConversationParticipantComponent : UConversationParticipantComponent {
};

// Class FortniteConversationRuntime.FortConversationContextCondition
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationContextCondition : UObject {

	void DoesContextPass(); // Function FortniteConversationRuntime.FortConversationContextCondition.DoesContextPass // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb166504
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantHasCID
// Size: 0x40 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantHasCID : UFortConversationContextCondition {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x480010)
	 ; // 0x00(0x00)
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantHasMetaTag
// Size: 0x30 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantHasMetaTag : UFortConversationContextCondition {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x480010)
	 ; // 0x00(0x00)
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantHasOwnedTag
// Size: 0x30 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantHasOwnedTag : UFortConversationContextCondition {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x480010)
	 ; // 0x00(0x00)
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantControllerMeetsRequirement
// Size: 0x38 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantControllerMeetsRequirement : UFortConversationContextCondition {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .; // 0x2c3(0x480010)
	 ; // 0x00(0x00)
};

// Class FortniteConversationRuntime.FortConversationContextConditionHelpers
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationContextConditionHelpers : UBlueprintFunctionLibrary {

	void GetMessageForContext(); // Function FortniteConversationRuntime.FortConversationContextConditionHelpers.GetMessageForContext // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0xb166a30
};

// Class FortniteConversationRuntime.FortConversationParamLibrary
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationParamLibrary : UBlueprintFunctionLibrary {

	void ExtractConversationParameterValue(); // Function FortniteConversationRuntime.FortConversationParamLibrary.ExtractConversationParameterValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb16667c
};

// Class FortniteConversationRuntime.FortniteConversationGlobals
// Size: 0x28 (Inherited: 0x28)
struct UFortniteConversationGlobals : UObject {
};

// Class FortniteConversationRuntime.FortPlayerConversationComponent
// Size: 0x2c8 (Inherited: 0x1a0)
struct UFortPlayerConversationComponent : UFortConversationParticipantComponent {
	char pad_1A0[0x123]; // 0x1a0(0x123)
	struct TArray<struct FNone*>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2208]; // 0x2c3(0xa310400)
	 ; // 0x00(0x00)

	void RequestServerAbortConversationWithParticipant(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.RequestServerAbortConversationWithParticipant // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0xa983694
	void RequestServerAbortConversation(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.RequestServerAbortConversation // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x916a5f8
	void HandleWeaponEquipped(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleWeaponEquipped // (Final|Native|Private) // @ game+0x7a88778
	void HandleViewTargetChanged(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleViewTargetChanged // (Final|Native|Private) // @ game+0xb166f24
	void HandleFollowedPlayerChanged(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleFollowedPlayerChanged // (Final|Native|Private) // @ game+0xb166c98
	void HandleDBNOChanged(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleDBNOChanged // (Final|Native|Private) // @ game+0x91fc804
	void ClientSpectatorOpenUI(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.ClientSpectatorOpenUI // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x8013358
	void ClientSpectatorCloseUI(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.ClientSpectatorCloseUI // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x28e357c
	void ClientReceiveConversationGiftUINotification(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.ClientReceiveConversationGiftUINotification // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xb166368
};

