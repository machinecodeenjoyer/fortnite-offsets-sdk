// BlueprintGeneratedClass NavLink_FloorS.NavLink_FloorS_C
// Size: 0x80 (Inherited: 0x80)
struct UNavLink_FloorS_C : UFortNavLinkDefinition {
};

