// BlueprintGeneratedClass GAB_DropPlayer.GAB_DropPlayer_C
// Size: 0xb68 (Inherited: 0xb58)
struct UGAB_DropPlayer_C : UFortGameplayAbility_CarryPlayer {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B58[0x10]; // 0xb58(0x10)

	void Completed_89F288114D44792D5568298354B7216C(); // Function GAB_DropPlayer.GAB_DropPlayer_C.Completed_89F288114D44792D5568298354B7216C // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Cancelled_89F288114D44792D5568298354B7216C(); // Function GAB_DropPlayer.GAB_DropPlayer_C.Cancelled_89F288114D44792D5568298354B7216C // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void Triggered_89F288114D44792D5568298354B7216C(); // Function GAB_DropPlayer.GAB_DropPlayer_C.Triggered_89F288114D44792D5568298354B7216C // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbility(); // Function GAB_DropPlayer.GAB_DropPlayer_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void K2_OnEndAbility(); // Function GAB_DropPlayer.GAB_DropPlayer_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GAB_DropPlayer(); // Function GAB_DropPlayer.GAB_DropPlayer_C.ExecuteUbergraph_GAB_DropPlayer // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

