// BlueprintGeneratedClass GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C
// Size: 0x990 (Inherited: 0x960)
struct AGCN_Loop_PlayerWorldPFX_Persistent_C : AFortGameplayCueNotify_Loop {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_960[0x30]; // 0x960(0x30)

	void SpawnNiagara(); // Function GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C.SpawnNiagara // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStartGeneric(); // Function GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C.OnLoopingStartGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnApplicationGeneric(); // Function GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C.OnApplicationGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnLoopingStartNiagara(); // Function GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C.OnLoopingStartNiagara // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void OnRemovalGeneric(); // Function GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C.OnRemovalGeneric // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_Loop_PlayerWorldPFX_Persistent(); // Function GCN_Loop_PlayerWorldPFX_Persistent.GCN_Loop_PlayerWorldPFX_Persistent_C.ExecuteUbergraph_GCN_Loop_PlayerWorldPFX_Persistent // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

