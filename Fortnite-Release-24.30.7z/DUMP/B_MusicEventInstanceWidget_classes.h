// WidgetBlueprintGeneratedClass B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C
// Size: 0x2c0 (Inherited: 0x298)
struct UB_MusicEventInstanceWidget_C : UUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x28]; // 0x298(0x28)

	void GetTextColor(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.GetTextColor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void GetFormatText(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.GetFormatText // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x179ea74
	void BP_OnEntryReleased(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnItemExpansionChanged(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnItemSelectionChanged(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void Tick(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x179ea74
	void OnListItemObjectSet(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_B_MusicEventInstanceWidget(); // Function B_MusicEventInstanceWidget.B_MusicEventInstanceWidget_C.ExecuteUbergraph_B_MusicEventInstanceWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

