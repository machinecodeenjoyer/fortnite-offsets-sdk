// BlueprintGeneratedClass PBWA_M1_RoofD.PBWA_M1_RoofD_C
// Size: 0xd70 (Inherited: 0xd70)
struct APBWA_M1_RoofD_C : ABuildingRoof {
};

