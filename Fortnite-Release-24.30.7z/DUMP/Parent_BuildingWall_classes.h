// BlueprintGeneratedClass Parent_BuildingWall.Parent_BuildingWall_C
// Size: 0xf18 (Inherited: 0xf18)
struct AParent_BuildingWall_C : ABuildingWall {
};

