// BlueprintGeneratedClass GA_Riding_Creature_EnergyDepleted_Grandma.GA_Riding_Creature_EnergyDepleted_Grandma_C
// Size: 0xe68 (Inherited: 0xe68)
struct UGA_Riding_Creature_EnergyDepleted_Grandma_C : UGA_Riding_Creature_EnergyDepleted_Base_C {
};

