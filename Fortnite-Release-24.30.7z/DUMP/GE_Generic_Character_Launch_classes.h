// BlueprintGeneratedClass GE_Generic_Character_Launch.GE_Generic_Character_Launch_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Generic_Character_Launch_C : UGameplayEffect {
};

