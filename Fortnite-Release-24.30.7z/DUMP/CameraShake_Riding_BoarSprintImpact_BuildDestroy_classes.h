// BlueprintGeneratedClass CameraShake_Riding_BoarSprintImpact_BuildDestroy.CameraShake_Riding_BoarSprintImpact_BuildDestroy_C
// Size: 0x210 (Inherited: 0x210)
struct UCameraShake_Riding_BoarSprintImpact_BuildDestroy_C : ULegacyCameraShake {
};

