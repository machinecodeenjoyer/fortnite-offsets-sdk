// UserDefinedEnum GrindRail_ResourceSpawns_Type.GrindRail_ResourceSpawns_Type
enum class GrindRail_ResourceSpawns_Type : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	GrindRail_ResourceSpawns_MAX = 3
};

