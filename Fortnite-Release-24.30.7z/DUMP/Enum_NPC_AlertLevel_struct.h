// UserDefinedEnum Enum_NPC_AlertLevel.Enum_NPC_AlertLevel
enum class Enum_NPC_AlertLevel : uint8 {
	NewEnumerator4 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	Enum_NPC_MAX = 5
};

