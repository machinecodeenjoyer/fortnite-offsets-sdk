// BlueprintGeneratedClass NavLink_RoofD.NavLink_RoofD_C
// Size: 0x80 (Inherited: 0x80)
struct UNavLink_RoofD_C : UFortNavLinkDefinition {
};

