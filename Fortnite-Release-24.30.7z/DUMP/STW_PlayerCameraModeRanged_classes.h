// BlueprintGeneratedClass STW_PlayerCameraModeRanged.STW_PlayerCameraModeRanged_C
// Size: 0x1b20 (Inherited: 0x1b20)
struct USTW_PlayerCameraModeRanged_C : UAthena_PlayerCameraModeRanged_C {
};

