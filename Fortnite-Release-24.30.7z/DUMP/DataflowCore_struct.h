// ScriptStruct DataflowCore.DataflowConnection
// Size: 0x38 (Inherited: 0x00)
struct FDataflowConnection {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DataflowCore.DataflowInput
// Size: 0x40 (Inherited: 0x38)
struct FDataflowInput : FDataflowConnection {
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct DataflowCore.DataflowOutput
// Size: 0x60 (Inherited: 0x38)
struct FDataflowOutput : FDataflowConnection {
	char pad_38[0x28]; // 0x38(0x28)
};

// ScriptStruct DataflowCore.DataflowNode
// Size: 0xe8 (Inherited: 0x00)
struct FDataflowNode {
	char  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ . : 0; // 0x00(0x30182010)
	 ; // 0x00(0x00)
	char pad_0[0xe8]; // 0x00(0xe8)
};

// ScriptStruct DataflowCore.DataflowSelection
// Size: 0x20 (Inherited: 0x00)
struct FDataflowSelection {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct DataflowCore.DataflowTransformSelection
// Size: 0x20 (Inherited: 0x20)
struct FDataflowTransformSelection : FDataflowSelection {
};

// ScriptStruct DataflowCore.DataflowVertexSelection
// Size: 0x20 (Inherited: 0x20)
struct FDataflowVertexSelection : FDataflowSelection {
};

// ScriptStruct DataflowCore.DataflowFaceSelection
// Size: 0x20 (Inherited: 0x20)
struct FDataflowFaceSelection : FDataflowSelection {
};

// ScriptStruct DataflowCore.NodeColors
// Size: 0x20 (Inherited: 0x00)
struct FNodeColors {
	char pad_0[0x2c3]; // 0x00(0x2c3)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x30182010)
	 ; // 0x00(0x00)
};

// ScriptStruct DataflowCore.DataflowTerminalNode
// Size: 0xe8 (Inherited: 0xe8)
struct FDataflowTerminalNode : FDataflowNode {
};

