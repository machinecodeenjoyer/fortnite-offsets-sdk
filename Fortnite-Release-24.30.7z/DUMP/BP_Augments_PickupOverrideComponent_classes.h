// BlueprintGeneratedClass BP_Augments_PickupOverrideComponent.BP_Augments_PickupOverrideComponent_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBP_Augments_PickupOverrideComponent_C : UFortPickupInteractOverrideComponent_Augments {
};

