// BlueprintGeneratedClass PBWA_S1_StairW.PBWA_S1_StairW_C
// Size: 0xd78 (Inherited: 0xd78)
struct APBWA_S1_StairW_C : ABuildingStairs {
};

