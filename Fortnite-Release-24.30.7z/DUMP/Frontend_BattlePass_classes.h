// BlueprintGeneratedClass Frontend_BattlePass.Frontend_BattlePass_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct AFrontend_BattlePass_C : AFortLevelScriptActor {
};

