// BlueprintGeneratedClass GA_BoostJumpPack_Papaya.GA_BoostJumpPack_Papaya_C
// Size: 0xd7c (Inherited: 0xd7c)
struct UGA_BoostJumpPack_Papaya_C : UGA_BoostJumpPack_C {
};

