// BlueprintGeneratedClass GCN_Athena_HidingProp_WilliePete_Exit.GCN_Athena_HidingProp_WilliePete_Exit_C
// Size: 0x210 (Inherited: 0x210)
struct UGCN_Athena_HidingProp_WilliePete_Exit_C : UFortGameplayCueNotify_Burst {

	void OnBurst(); // Function GCN_Athena_HidingProp_WilliePete_Exit.GCN_Athena_HidingProp_WilliePete_Exit_C.OnBurst // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
};

