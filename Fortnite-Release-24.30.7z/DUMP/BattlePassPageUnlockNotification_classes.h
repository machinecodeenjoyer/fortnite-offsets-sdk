// BlueprintGeneratedClass BattlePassPageUnlockNotification.BattlePassPageUnlockNotification_C
// Size: 0x138 (Inherited: 0x138)
struct UBattlePassPageUnlockNotification_C : UFortUIBattlePassPageUnlockNotification {
};

