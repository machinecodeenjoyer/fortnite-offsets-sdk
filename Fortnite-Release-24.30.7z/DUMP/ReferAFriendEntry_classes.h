// WidgetBlueprintGeneratedClass ReferAFriendEntry.ReferAFriendEntry_C
// Size: 0x14e0 (Inherited: 0x1490)
struct UReferAFriendEntry_C : UFortReferFriendListEntry {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1490[0x50]; // 0x1490(0x50)

	void BP_OnUnhovered(); // Function ReferAFriendEntry.ReferAFriendEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(); // Function ReferAFriendEntry.ReferAFriendEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function ReferAFriendEntry.ReferAFriendEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_ReferAFriendEntry(); // Function ReferAFriendEntry.ReferAFriendEntry_C.ExecuteUbergraph_ReferAFriendEntry // (Final|UbergraphFunction) // @ game+0x179ea74
};

