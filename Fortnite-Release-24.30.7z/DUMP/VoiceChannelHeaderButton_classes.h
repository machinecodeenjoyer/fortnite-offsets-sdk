// WidgetBlueprintGeneratedClass VoiceChannelHeaderButton.VoiceChannelHeaderButton_C
// Size: 0x1568 (Inherited: 0x14c0)
struct UVoiceChannelHeaderButton_C : UFortVoiceChannelHeaderButton {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_14C0[0xa8]; // 0x14c0(0xa8)

	void OnUpdateVisuals(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.OnUpdateVisuals // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnUnhovered(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnDisabled(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.BP_OnDisabled // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnEnabled(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.BP_OnEnabled // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void (); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C. // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BP_OnItemExpansionChanged(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_VoiceChannelHeaderButton(); // Function VoiceChannelHeaderButton.VoiceChannelHeaderButton_C.ExecuteUbergraph_VoiceChannelHeaderButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

