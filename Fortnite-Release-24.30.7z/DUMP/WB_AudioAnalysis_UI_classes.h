// WidgetBlueprintGeneratedClass WB_AudioAnalysis_UI.WB_AudioAnalysis_UI_C
// Size: 0x2b8 (Inherited: 0x298)
struct UWB_AudioAnalysis_UI_C : UFortAudioAnalysisDebugWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x20]; // 0x298(0x20)

	void AddScalarParameter(); // Function WB_AudioAnalysis_UI.WB_AudioAnalysis_UI_C.AddScalarParameter // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void AddVectorParameter(); // Function WB_AudioAnalysis_UI.WB_AudioAnalysis_UI_C.AddVectorParameter // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ClearParameters(); // Function WB_AudioAnalysis_UI.WB_AudioAnalysis_UI_C.ClearParameters // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_WB_AudioAnalysis_UI(); // Function WB_AudioAnalysis_UI.WB_AudioAnalysis_UI_C.ExecuteUbergraph_WB_AudioAnalysis_UI // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

