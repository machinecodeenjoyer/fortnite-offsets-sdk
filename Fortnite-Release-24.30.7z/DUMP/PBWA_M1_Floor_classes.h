// BlueprintGeneratedClass PBWA_M1_Floor.PBWA_M1_Floor_C
// Size: 0xd70 (Inherited: 0xd70)
struct APBWA_M1_Floor_C : ABuildingFloor {
};

