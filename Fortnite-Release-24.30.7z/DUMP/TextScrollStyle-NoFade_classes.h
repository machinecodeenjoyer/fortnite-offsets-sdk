// BlueprintGeneratedClass TextScrollStyle-NoFade.TextScrollStyle-NoFade_C
// Size: 0x40 (Inherited: 0x40)
struct UTextScrollStyle-NoFade_C : UCommonTextScrollStyle {
};

