// VerseClass VerseCreature.$SolarisSignatureFunctionOuter
// Size: 0x28 (Inherited: 0x28)
struct U$SolarisSignatureFunctionOuter : UObject {
};

// VerseClass VerseCreature.task_VerseCreature_creature_component$MoveInRangeToAttack
// Size: 0x15a (Inherited: 0x150)
struct Utask_VerseCreature_creature_component$MoveInRangeToAttack : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseCreature.task_VerseCreature_creature_component$MoveInRangeToAttack.Update // (Native|Public|HasOutParms) // @ game+0xb1bccf0
};

// VerseClass VerseCreature.task_VerseCreature_creature_component$NavigateTo_L_Nnavigation__target_M_Nfloat_M_Nlogic_R
// Size: 0x171 (Inherited: 0x150)
struct Utask_VerseCreature_creature_component$NavigateTo_L_Nnavigation__target_M_Nfloat_M_Nlogic_R : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseCreature.task_VerseCreature_creature_component$NavigateTo_L_Nnavigation__target_M_Nfloat_M_Nlogic_R.Update // (Native|Public|HasOutParms) // @ game+0xb1bbc5c
};

// VerseClass VerseCreature.task_VerseCreature_creature_component$RoamAround
// Size: 0x15a (Inherited: 0x150)
struct Utask_VerseCreature_creature_component$RoamAround : UConcurrency_task {
	char pad_150[0x173]; // 0x150(0x173)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x280]; // 0x2c3(0x14002800)
	 ; // 0x00(0x00)

	void Update(); // Function VerseCreature.task_VerseCreature_creature_component$RoamAround.Update // (Native|Public|HasOutParms) // @ game+0xb1bccf8
};

// VerseClass VerseCreature.VerseCreature_creature_component
// Size: 0x108 (Inherited: 0xb8)
struct UVerseCreature_creature_component : UAIActionsComponent {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B8[0x50]; // 0xb8(0x50)

	void _L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2fnavigation__interface_N_RStopNavigation(); // Function VerseCreature.VerseCreature_creature_component._L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2fnavigation__interface_N_RStopNavigation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb1bbd4c
	void RoamAround(); // Function VerseCreature.VerseCreature_creature_component.RoamAround // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void NavigateTo_L_Nnavigation__target_M_Nfloat_M_Nlogic_R(); // Function VerseCreature.VerseCreature_creature_component.NavigateTo_L_Nnavigation__target_M_Nfloat_M_Nlogic_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void MoveInRangeToAttack(); // Function VerseCreature.VerseCreature_creature_component.MoveInRangeToAttack // (Public|HasOutParms|BlueprintCallable) // @ game+0x179ea74
	void _L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2fnavigation__interface_N_RGetCurrentDestination(); // Function VerseCreature.VerseCreature_creature_component._L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2fnavigation__interface_N_RGetCurrentDestination // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb1bcd10
	void $InitInstance(); // Function VerseCreature.VerseCreature_creature_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseCreature.VerseCreature_creature_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseCreature.VerseCreature_creature_component.$InitCDO // (None) // @ game+0x179ea74
};

// VerseClass VerseCreature.VerseCreature_creature_perception_component
// Size: 0xd0 (Inherited: 0xa8)
struct UVerseCreature_creature_perception_component : UCreaturePerceptionComponentBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_A8[0x28]; // 0xa8(0x28)

	void _L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2ffort__threat__perception__interface_N_RGetThreatsInfo(); // Function VerseCreature.VerseCreature_creature_perception_component._L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2ffort__threat__perception__interface_N_RGetThreatsInfo // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb1bcd08
	void _L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2ffort__threat__perception__interface_N_RGetThreatInfo_L_Nagent_R(); // Function VerseCreature.VerseCreature_creature_perception_component._L_2fFortnite_2ecom_2fAI_2fVerseAIBase_2ffort__threat__perception__interface_N_RGetThreatInfo_L_Nagent_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb1bcd00
	void $InitInstance(); // Function VerseCreature.VerseCreature_creature_perception_component.$InitInstance // (None) // @ game+0x179ea74
	void $Block(); // Function VerseCreature.VerseCreature_creature_perception_component.$Block // (None) // @ game+0x179ea74
	void $InitCDO(); // Function VerseCreature.VerseCreature_creature_perception_component.$InitCDO // (None) // @ game+0x179ea74
};

