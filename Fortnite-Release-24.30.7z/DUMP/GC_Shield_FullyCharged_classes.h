// BlueprintGeneratedClass GC_Shield_FullyCharged.GC_Shield_FullyCharged_C
// Size: 0x210 (Inherited: 0x210)
struct UGC_Shield_FullyCharged_C : UFortGameplayCueNotify_Burst {

	void OnBurst(); // Function GC_Shield_FullyCharged.GC_Shield_FullyCharged_C.OnBurst // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
};

