// BlueprintGeneratedClass GE_NPC_Behavior_TargetSlots_Ranged_SlotOwner.GE_NPC_Behavior_TargetSlots_Ranged_SlotOwner_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_NPC_Behavior_TargetSlots_Ranged_SlotOwner_C : UGameplayEffect {
};

