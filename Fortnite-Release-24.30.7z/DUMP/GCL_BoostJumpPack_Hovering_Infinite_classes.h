// BlueprintGeneratedClass GCL_BoostJumpPack_Hovering_Infinite.GCL_BoostJumpPack_Hovering_Infinite_C
// Size: 0xae0 (Inherited: 0xaa0)
struct AGCL_BoostJumpPack_Hovering_Infinite_C : AGameplayCueNotify_Jetpack_Hovering {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_AA0[0x40]; // 0xaa0(0x40)

	void SetJetpackAudioEnabled(); // Function GCL_BoostJumpPack_Hovering_Infinite.GCL_BoostJumpPack_Hovering_Infinite_C.SetJetpackAudioEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRemove(); // Function GCL_BoostJumpPack_Hovering_Infinite.GCL_BoostJumpPack_Hovering_Infinite_C.OnRemove // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnActive(); // Function GCL_BoostJumpPack_Hovering_Infinite.GCL_BoostJumpPack_Hovering_Infinite_C.OnActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void On Pawn Landed(); // Function GCL_BoostJumpPack_Hovering_Infinite.GCL_BoostJumpPack_Hovering_Infinite_C.On Pawn Landed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCL_BoostJumpPack_Hovering_Infinite(); // Function GCL_BoostJumpPack_Hovering_Infinite.GCL_BoostJumpPack_Hovering_Infinite_C.ExecuteUbergraph_GCL_BoostJumpPack_Hovering_Infinite // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

