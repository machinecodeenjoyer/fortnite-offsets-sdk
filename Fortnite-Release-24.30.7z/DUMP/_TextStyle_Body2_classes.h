// BlueprintGeneratedClass _TextStyle_Body2._TextStyle_Body2_C
// Size: 0x1a0 (Inherited: 0x1a0)
struct U_TextStyle_Body2_C : UCommonTextStyle {
};

