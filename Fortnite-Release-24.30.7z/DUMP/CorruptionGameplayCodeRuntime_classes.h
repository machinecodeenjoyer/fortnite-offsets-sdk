// Class CorruptionGameplayCodeRuntime.WarEffortFundingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWarEffortFundingLibrary : UBlueprintFunctionLibrary {

	void WriteTextToBuffer(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.WriteTextToBuffer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb23d17c
	void IsOption2ChoiceWinner(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption2ChoiceWinner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb23b13c
	void IsOption1ChoiceWinner(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsOption1ChoiceWinner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb23ad98
	void IsIndexFunded(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.IsIndexFunded // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb23a6d0
	void GetIndexFundedPercent(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.GetIndexFundedPercent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb23a22c
	void DoesChoiceHaveWinner(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.DoesChoiceHaveWinner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb239d84
	void AdjustDonation(); // Function CorruptionGameplayCodeRuntime.WarEffortFundingLibrary.AdjustDonation // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb239a94
};

// Class CorruptionGameplayCodeRuntime.CorruptionCoverageMap
// Size: 0x90 (Inherited: 0x28)
struct UCorruptionCoverageMap : UObject {
	char pad_28[0x68]; // 0x28(0x68)

	void UpdateCorruptionCoverageMap(); // Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.UpdateCorruptionCoverageMap // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb23c1dc
	void IsLocationCorrupted(); // Function CorruptionGameplayCodeRuntime.CorruptionCoverageMap.IsLocationCorrupted // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb23ab98
};

// Class CorruptionGameplayCodeRuntime.FortCorruptionSequenceData
// Size: 0x50 (Inherited: 0x30)
struct UFortCorruptionSequenceData : UPrimaryDataAsset {
	char pad_30[0x293]; // 0x30(0x293)
	struct TArray<struct FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10201]; // 0x2c3(0x20100000)
	 ; // 0x00(0x00)
};

// Class CorruptionGameplayCodeRuntime.CubeMovementStaticPath
// Size: 0x510 (Inherited: 0x4e0)
struct ACubeMovementStaticPath : AScriptedObjectMovement_StaticPath {
	float  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000201]; // 0x2c3(0x50382810)
	 ; // 0x00(0x00)

	void EditorGetCorruptionGenerationData(); // Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.EditorGetCorruptionGenerationData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb23a138
	void ClearAllGeneratedSplinesAndLockedData(); // Function CorruptionGameplayCodeRuntime.CubeMovementStaticPath.ClearAllGeneratedSplinesAndLockedData // (Final|Native|Protected) // @ game+0xb239d70
};

// Class CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort
// Size: 0x4b8 (Inherited: 0x450)
struct AFortAthenaMutator_WarEffort : AFortAthenaMutator_GameModeBase {
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x4]; // 0x2c3(0x802000)
	 ; // 0x00(0x00)

	void SetTryBeforeYouBuyItemState(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetTryBeforeYouBuyItemState // (Final|Native|Public|BlueprintCallable) // @ game+0xb23bf58
	void SetItemFundedState(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedState // (Final|Native|Public|BlueprintCallable) // @ game+0xb23bcd4
	void SetItemFundedPercent(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedPercent // (Final|Native|Public|BlueprintCallable) // @ game+0xb23ba4c
	void SetItemFundedAmount(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetItemFundedAmount // (Final|Native|Public|BlueprintCallable) // @ game+0xb23b6a0
	void SetFundingManagerReady(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.SetFundingManagerReady // (Final|Native|Public|BlueprintCallable) // @ game+0xb23b530
	void OnRep_PreloadedItemList(); // Function CorruptionGameplayCodeRuntime.FortAthenaMutator_WarEffort.OnRep_PreloadedItemList // (Final|Native|Protected) // @ game+0xb23b51c
};

// Class CorruptionGameplayCodeRuntime.WarEffortMeshActor
// Size: 0x310 (Inherited: 0x288)
struct AWarEffortMeshActor : AInfo {
	char pad_288[0x3b]; // 0x288(0x3b)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x80208]; // 0x2c3(0x39602080)
	 ; // 0x00(0x00)

	void OnRep_CurrentFundingData(); // Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_CurrentFundingData // (Final|Native|Protected) // @ game+0xb23b508
	void OnRep_ActiveTryBeforeYouBuyItems(); // Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveTryBeforeYouBuyItems // (Final|Native|Protected) // @ game+0xb23b4f4
	void OnRep_ActiveFundedItems(); // Function CorruptionGameplayCodeRuntime.WarEffortMeshActor.OnRep_ActiveFundedItems // (Final|Native|Protected) // @ game+0xb23b4e0
};

