// WidgetBlueprintGeneratedClass SuggestedFriendListEntry.SuggestedFriendListEntry_C
// Size: 0x1560 (Inherited: 0x1500)
struct USuggestedFriendListEntry_C : UFortConnectionsUserListEntry {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_1500[0x60]; // 0x1500(0x60)

	void BP_OnUnhovered(); // Function SuggestedFriendListEntry.SuggestedFriendListEntry_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(); // Function SuggestedFriendListEntry.SuggestedFriendListEntry_C.BndEvt__MenuAnchor_Actions_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x179ea74
	void BP_OnHovered(); // Function SuggestedFriendListEntry.SuggestedFriendListEntry_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_SuggestedFriendListEntry(); // Function SuggestedFriendListEntry.SuggestedFriendListEntry_C.ExecuteUbergraph_SuggestedFriendListEntry // (Final|UbergraphFunction) // @ game+0x179ea74
};

