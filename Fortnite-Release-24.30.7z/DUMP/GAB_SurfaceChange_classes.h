// BlueprintGeneratedClass GAB_SurfaceChange.GAB_SurfaceChange_C
// Size: 0xdc0 (Inherited: 0xb28)
struct UGAB_SurfaceChange_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x298]; // 0xb28(0x298)

	void OnRep_ReplicatedRandomAngle(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.OnRep_ReplicatedRandomAngle // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SurfaceCleanup(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.SurfaceCleanup // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void LavaBounce(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.LavaBounce // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void HotfixableGEApplication(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.HotfixableGEApplication // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SurfaceCleanupSpecial(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.SurfaceCleanupSpecial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ActivateAbilityFromEvent(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.K2_ActivateAbilityFromEvent // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void MovementModeChanged(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.MovementModeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void GamePhaseChanged(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.GamePhaseChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GAB_SurfaceChange(); // Function GAB_SurfaceChange.GAB_SurfaceChange_C.ExecuteUbergraph_GAB_SurfaceChange // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

