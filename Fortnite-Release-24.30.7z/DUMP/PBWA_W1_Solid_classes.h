// BlueprintGeneratedClass PBWA_W1_Solid.PBWA_W1_Solid_C
// Size: 0xf18 (Inherited: 0xf18)
struct APBWA_W1_Solid_C : ABuildingWall {
};

