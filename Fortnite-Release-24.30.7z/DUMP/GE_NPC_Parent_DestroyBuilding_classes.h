// BlueprintGeneratedClass GE_NPC_Parent_DestroyBuilding.GE_NPC_Parent_DestroyBuilding_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_NPC_Parent_DestroyBuilding_C : UGE_NPC_Parent_DirectDamage_C {
};

