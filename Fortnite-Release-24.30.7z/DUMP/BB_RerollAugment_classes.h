// BlueprintGeneratedClass BB_RerollAugment.BB_RerollAugment_C
// Size: 0x118 (Inherited: 0x118)
struct UBB_RerollAugment_C : UFortMobileActionButtonBehavior_RerollAugments {
};

