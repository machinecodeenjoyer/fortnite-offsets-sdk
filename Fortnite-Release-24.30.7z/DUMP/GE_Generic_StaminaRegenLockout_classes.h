// BlueprintGeneratedClass GE_Generic_StaminaRegenLockout.GE_Generic_StaminaRegenLockout_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Generic_StaminaRegenLockout_C : UGameplayEffect {
};

