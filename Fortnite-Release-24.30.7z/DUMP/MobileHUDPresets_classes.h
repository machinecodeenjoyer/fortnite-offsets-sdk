// BlueprintGeneratedClass MobileHUDPresets.MobileHUDPresets_C
// Size: 0x40 (Inherited: 0x40)
struct UMobileHUDPresets_C : UFortMobileHUDPresetContainer {
};

