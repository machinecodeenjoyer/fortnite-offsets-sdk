// BlueprintGeneratedClass TwitchNotification.TwitchNotification_C
// Size: 0x150 (Inherited: 0x150)
struct UTwitchNotification_C : UFortUIFriendNotification {
};

