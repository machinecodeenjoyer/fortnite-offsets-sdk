// BlueprintGeneratedClass GA_Athena_Player_PreSlideFeedback.GA_Athena_Player_PreSlideFeedback_C
// Size: 0xb30 (Inherited: 0xb28)
struct UGA_Athena_Player_PreSlideFeedback_C : UFortGameplayAbility {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B28[0x8]; // 0xb28(0x08)

	void K2_ActivateAbility(); // Function GA_Athena_Player_PreSlideFeedback.GA_Athena_Player_PreSlideFeedback_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void (); // Function GA_Athena_Player_PreSlideFeedback.GA_Athena_Player_PreSlideFeedback_C. // (BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void FailedToActivatePassiveAbility(); // Function GA_Athena_Player_PreSlideFeedback.GA_Athena_Player_PreSlideFeedback_C.FailedToActivatePassiveAbility // (Event|Public|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Athena_Player_PreSlideFeedback(); // Function GA_Athena_Player_PreSlideFeedback.GA_Athena_Player_PreSlideFeedback_C.ExecuteUbergraph_GA_Athena_Player_PreSlideFeedback // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

