// Class MusterConsumablesUI.EnergyDrinkStaminaBarOverlayWidget
// Size: 0x310 (Inherited: 0x300)
struct UEnergyDrinkStaminaBarOverlayWidget : UFortHUDElementWidget {
	char pad_300[0x10]; // 0x300(0x10)

	void OnPlayerStateSet(); // Function MusterConsumablesUI.EnergyDrinkStaminaBarOverlayWidget.OnPlayerStateSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnPlayerDeadStateChanged(); // Function MusterConsumablesUI.EnergyDrinkStaminaBarOverlayWidget.OnPlayerDeadStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
};

