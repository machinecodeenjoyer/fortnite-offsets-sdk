// BlueprintGeneratedClass GCL_Rift_Teleport.GCL_Rift_Teleport_C
// Size: 0x368 (Inherited: 0x368)
struct AGCL_Rift_Teleport_C : AFortGameplayCueNotify_Looping {

	void WhileActive(); // Function GCL_Rift_Teleport.GCL_Rift_Teleport_C.WhileActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnRemove(); // Function GCL_Rift_Teleport.GCL_Rift_Teleport_C.OnRemove // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void OnWhileActiveParticleSystemDeactivate(); // Function GCL_Rift_Teleport.GCL_Rift_Teleport_C.OnWhileActiveParticleSystemDeactivate // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void OnStartParticleSystemSpawned(); // Function GCL_Rift_Teleport.GCL_Rift_Teleport_C.OnStartParticleSystemSpawned // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
};

