// BlueprintGeneratedClass GCN_NPC_Interaction_RezOut_Glitch.GCN_NPC_Interaction_RezOut_Glitch_C
// Size: 0x728 (Inherited: 0x718)
struct AGCN_NPC_Interaction_RezOut_Glitch_C : AGCN_RezOut_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_718[0x10]; // 0x718(0x10)

	void Spawn Dissolve VFX(); // Function GCN_NPC_Interaction_RezOut_Glitch.GCN_NPC_Interaction_RezOut_Glitch_C.Spawn Dissolve VFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GCN_NPC_Interaction_RezOut_Glitch(); // Function GCN_NPC_Interaction_RezOut_Glitch.GCN_NPC_Interaction_RezOut_Glitch_C.ExecuteUbergraph_GCN_NPC_Interaction_RezOut_Glitch // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

