// BlueprintGeneratedClass GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C
// Size: 0xba4 (Inherited: 0xb60)
struct UGA_Creative_OnKillSiphon_C : UGAT_Creative_TriggeredAbility_Pawn_C {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_B60[0x44]; // 0xb60(0x44)

	void GiveResourcesToPlayer(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.GiveResourcesToPlayer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void CalculateResources(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.CalculateResources // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttemptMats(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.AttemptMats // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AttemptHeal(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.AttemptHeal // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void SetupRestoreModes(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.SetupRestoreModes // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void DetermineHealthDelta(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.DetermineHealthDelta // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void AddShields(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.AddShields // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void RestoreHealth(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.RestoreHealth // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void K2_ShouldAbilityRespondToEvent(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.K2_ShouldAbilityRespondToEvent // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x179ea74
	void K2_ActivateAbilityFromEvent(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.K2_ActivateAbilityFromEvent // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_GA_Creative_OnKillSiphon(); // Function GA_Creative_OnKillSiphon.GA_Creative_OnKillSiphon_C.ExecuteUbergraph_GA_Creative_OnKillSiphon // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

