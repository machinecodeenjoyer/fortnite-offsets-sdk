// WidgetBlueprintGeneratedClass HomebaseRatingBar.HomebaseRatingBar_C
// Size: 0x3c0 (Inherited: 0x3c0)
struct UHomebaseRatingBar_C : UFortMaterialProgressBar {
};

