// Class SidewaysCodeRuntime.SidewaysCheatManager
// Size: 0x28 (Inherited: 0x28)
struct USidewaysCheatManager : UChildCheatManager {

	void SetSidewaysState(); // Function SidewaysCodeRuntime.SidewaysCheatManager.SetSidewaysState // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x916b7b4
};

// Class SidewaysCodeRuntime.FortControllerComponent_Sideways
// Size: 0xb0 (Inherited: 0xa8)
struct UFortControllerComponent_Sideways : UFortControllerComponent {
	char pad_A8[0x21b]; // 0xa8(0x21b)
	struct FNone  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2000]; // 0x2c3(0x20000)
	 ; // 0x00(0x00)
};

// Class SidewaysCodeRuntime.PlayspaceComponent_SidewaysDimension
// Size: 0x148 (Inherited: 0xf8)
struct UPlayspaceComponent_SidewaysDimension : UFortPlayspaceComponent {
	char pad_F8[0x1cb]; // 0xf8(0x1cb)
	struct FNone*  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x2200]; // 0x2c3(0x18022000)
	 ; // 0x00(0x00)
};

// Class SidewaysCodeRuntime.PlayspaceComponent_SidewaysEncounter
// Size: 0xf8 (Inherited: 0xf8)
struct UPlayspaceComponent_SidewaysEncounter : UFortPlayspaceComponent {
};

// Class SidewaysCodeRuntime.SidewaysStateComponent
// Size: 0xc8 (Inherited: 0xa0)
struct USidewaysStateComponent : UGameFrameworkComponent {
	char pad_A0[0x223]; // 0xa0(0x223)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40000220]; // 0x2c3(0x95112420)
	 ; // 0x00(0x00)

	void SetSidewaysState(); // Function SidewaysCodeRuntime.SidewaysStateComponent.SetSidewaysState // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xb2143b8
	void OnRep_SidewaysState(); // Function SidewaysCodeRuntime.SidewaysStateComponent.OnRep_SidewaysState // (Final|Native|Protected) // @ game+0xb2141ec
	void OnRep_SidewaysPlayspace(); // Function SidewaysCodeRuntime.SidewaysStateComponent.OnRep_SidewaysPlayspace // (Final|Native|Protected) // @ game+0x78fcd08
	void HandleSidewaysStateChanged(); // Function SidewaysCodeRuntime.SidewaysStateComponent.HandleSidewaysStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void GetSidewaysState(); // Function SidewaysCodeRuntime.SidewaysStateComponent.GetSidewaysState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8f27354
};

// Class SidewaysCodeRuntime.SidewaysStateComponent_Player
// Size: 0x118 (Inherited: 0xc8)
struct USidewaysStateComponent_Player : USidewaysStateComponent {
	char pad_C8[0x1fb]; // 0xc8(0x1fb)
	struct TSoftObjectPtr<FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10001]; // 0x2c3(0x4c0000)
	 ; // 0x00(0x00)
};

// Class SidewaysCodeRuntime.SidewaysFeatureAction_HoldGlobalData
// Size: 0x60 (Inherited: 0x28)
struct USidewaysFeatureAction_HoldGlobalData : UGameFeatureAction {
	char pad_28[0x29b]; // 0x28(0x29b)
	struct TSoftObjectPtr<FNone>  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x10001]; // 0x2c3(0x4c0000)
	 ; // 0x00(0x00)
};

// Class SidewaysCodeRuntime.SidewaysLibrary
// Size: 0x28 (Inherited: 0x28)
struct USidewaysLibrary : UBlueprintFunctionLibrary {

	void GetSidewaysStateComponent(); // Function SidewaysCodeRuntime.SidewaysLibrary.GetSidewaysStateComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb21406c
};

// Class SidewaysCodeRuntime.SidewaysPlayspace
// Size: 0x678 (Inherited: 0x678)
struct ASidewaysPlayspace : AFortPlayspace {

	void RefreshActorsInSideways(); // Function SidewaysCodeRuntime.SidewaysPlayspace.RefreshActorsInSideways // (Final|Native|Public|BlueprintCallable) // @ game+0xb21435c
	void NotifySizeChanged(); // Function SidewaysCodeRuntime.SidewaysPlayspace.NotifySizeChanged // (Final|Native|Public|BlueprintCallable) // @ game+0xb2141d8
};

// Class SidewaysCodeRuntime.SidewaysVolume
// Size: 0x318 (Inherited: 0x318)
struct ASidewaysVolume : AGameplayVolume {
};

