// AnimBlueprintGeneratedClass F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint.F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint_C
// Size: 0x8f8 (Inherited: 0x6f0)
struct UF_MED_Ramirez_Fallback_Skeleton_AnimBlueprint_C : UCustomCharacterPartAnimInstance {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_6F0[0x208]; // 0x6f0(0x208)

	void AnimGraph(); // Function F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint.F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint(); // Function F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint.F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint_C.ExecuteUbergraph_F_MED_Ramirez_Fallback_Skeleton_AnimBlueprint // (Final|UbergraphFunction) // @ game+0x179ea74
};

