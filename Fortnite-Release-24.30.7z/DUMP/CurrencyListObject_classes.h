// BlueprintGeneratedClass CurrencyListObject.CurrencyListObject_C
// Size: 0x78 (Inherited: 0x28)
struct UCurrencyListObject_C : UObject {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_28[0x50]; // 0x28(0x50)
};

