// BlueprintGeneratedClass B_CameraLens_SwimBoost.B_CameraLens_SwimBoost_C
// Size: 0x378 (Inherited: 0x370)
struct AB_CameraLens_SwimBoost_C : AEmitterCameraLensEffectBase {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_370[0x8]; // 0x370(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_SwimBoost.B_CameraLens_SwimBoost_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_B_CameraLens_SwimBoost(); // Function B_CameraLens_SwimBoost.B_CameraLens_SwimBoost_C.ExecuteUbergraph_B_CameraLens_SwimBoost // (Final|UbergraphFunction) // @ game+0x179ea74
};

