// BlueprintGeneratedClass PBWA_BG_RoofD.PBWA_BG_RoofD_C
// Size: 0xd70 (Inherited: 0xd70)
struct APBWA_BG_RoofD_C : ABuildingRoof {
};

