// WidgetBlueprintGeneratedClass CurrencyListViewItem.CurrencyListViewItem_C
// Size: 0x2c0 (Inherited: 0x298)
struct UCurrencyListViewItem_C : UUserWidget {
	 ; // 0x00(0x00)
	 ; // 0x00(0x00)
	char pad_298[0x28]; // 0x298(0x28)

	void SetQuantityAndType(); // Function CurrencyListViewItem.CurrencyListViewItem_C.SetQuantityAndType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x179ea74
	void BP_OnEntryReleased(); // Function CurrencyListViewItem.CurrencyListViewItem_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnItemExpansionChanged(); // Function CurrencyListViewItem.CurrencyListViewItem_C.BP_OnItemExpansionChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_OnItemSelectionChanged(); // Function CurrencyListViewItem.CurrencyListViewItem_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void OnListItemObjectSet(); // Function CurrencyListViewItem.CurrencyListViewItem_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void ExecuteUbergraph_CurrencyListViewItem(); // Function CurrencyListViewItem.CurrencyListViewItem_C.ExecuteUbergraph_CurrencyListViewItem // (Final|UbergraphFunction|HasDefaults) // @ game+0x179ea74
};

