// BlueprintGeneratedClass GE_Athena_TillLandFallDamageImmunity.GE_Athena_TillLandFallDamageImmunity_C
// Size: 0x858 (Inherited: 0x858)
struct UGE_Athena_TillLandFallDamageImmunity_C : UGameplayEffect {
};

