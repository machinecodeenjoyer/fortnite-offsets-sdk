// Class ClamberingCodeRuntime.ClamberingAnalytics
// Size: 0x28 (Inherited: 0x28)
struct UClamberingAnalytics : UObject {
};

// Class ClamberingCodeRuntime.ClamberingComponent
// Size: 0xac0 (Inherited: 0xa8)
struct UClamberingComponent : UFortPawnOverrideComponent {
	char pad_A8[0x21b]; // 0xa8(0x21b)
	enum class None  � 뮣深偁灤祱ˀ 겨壱䵣癳|̴ 궣擪偁灤祱Ͷ 꺧槪牥東瑷x β ꂮ淯噲牮牠筵 ̄ ꎯ淨偁灤祱Ь ꞥ淩䍶灑灪灤祵Έ 궥櫰䝽牮牠筵 ͮ 날槷牨東瑷x ΢ 뚲緷噲牮牠筵 Ζ ꞷ糦偾牮牠筵 ώ 궳槱䵥퀳浳敵癳xˢ 뚲壷䵣癳|̌ ꞵ糽偁灤祱ю 겨深䑣剤潷東瑳x ـ 랬糩䅸䙵池敤瑠剤杷東瑳x Ұ ꎭ燿䁞癢牕牮牤筵 ҄ 궲糣䁞癢牕牮牤筵 ͬ 겨㻱爥東瑷x ͖ 겨㯱爣東瑷x ͈ 겨㧱爧東瑷x ̪ 겨ヱ偁灤祱Έ 讴糫ᘧ牮牠筵 Ψ 讴糫ဢ牮牠筵 Π 讴糫ᐠ牮牠筵 ˈ ꎬ壵䵣癳|˜ Ʝ壱䵣癳|Ħ 궢混ƺ 겤懢䝿 Ɗ ꚤ糬偾 ˌ .[0x40002200]; // 0x2c3(0x51122000)
	 ; // 0x00(0x00)

	void UnregisterMutatorUpdatedDelegate(); // Function ClamberingCodeRuntime.ClamberingComponent.UnregisterMutatorUpdatedDelegate // (Final|Native|Protected) // @ game+0xb159e24
	void ShouldShowClamberIndicator(); // Function ClamberingCodeRuntime.ClamberingComponent.ShouldShowClamberIndicator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb159e00
	void SetTutorialModeEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.SetTutorialModeEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0xb159c90
	void ServerStartClambering(); // Function ClamberingCodeRuntime.ClamberingComponent.ServerStartClambering // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xb15992c
	void RegisterMutatorUpdatedDelegate(); // Function ClamberingCodeRuntime.ClamberingComponent.RegisterMutatorUpdatedDelegate // (Final|Native|Protected) // @ game+0xb1595bc
	void OnRep_ReplicatedTargetingData(); // Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedTargetingData // (Final|Native|Protected) // @ game+0xef5354
	void OnRep_ReplicatedLastTeleportTime(); // Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedLastTeleportTime // (Final|Native|Protected) // @ game+0x147927c
	void OnRep_ReplicatedClamberingState(); // Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedClamberingState // (Final|Native|Protected) // @ game+0x147a168
	void OnPlayerStatePawnSet(); // Function ClamberingCodeRuntime.ClamberingComponent.OnPlayerStatePawnSet // (Final|Native|Protected) // @ game+0x1478338
	void OnMutatorUpdated(); // Function ClamberingCodeRuntime.ClamberingComponent.OnMutatorUpdated // (Final|Native|Protected) // @ game+0xef2af4
	void NetMulticast_ClamberingLedgeFailed(); // Function ClamberingCodeRuntime.ClamberingComponent.NetMulticast_ClamberingLedgeFailed // (Net|NetReliableNative|Event|NetMulticast|Protected) // @ game+0x1a863c4
	void IsTutorialModeEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.IsTutorialModeEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb1593c8
	void IsClamberingEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.IsClamberingEnabled // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb1593a4
	void IsAutoClamberingEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.IsAutoClamberingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb159380
	void HandleTargetingDataValid(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataValid // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void HandleTargetingDataInvalid(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataInvalid // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleTargetActorHealthChanged(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorHealthChanged // (Final|Native|Protected) // @ game+0xb15936c
	void HandleTargetActorDestroyed(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorDestroyed // (Final|Native|Protected) // @ game+0xb1591fc
	void HandleOwnerTeleported(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerTeleported // (Final|Native|Protected|BlueprintCallable) // @ game+0xb15908c
	void HandleOwnerMovementModeChanged(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerMovementModeChanged // (Final|Native|Protected) // @ game+0x147a368
	void HandleOwnerJumpInput(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerJumpInput // (Final|Native|Protected) // @ game+0xb158f1c
	void HandleOwnerDied(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDied // (Final|Native|Protected) // @ game+0xb158dac
	void HandleOwnerDBNO(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDBNO // (Final|Native|Protected) // @ game+0x2ecc450
	void HandleOwnerASCInvalidated(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInvalidated // (Final|Native|Protected) // @ game+0x1478890
	void HandleOwnerASCInitialized(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInitialized // (Final|Native|Protected) // @ game+0x2a13f34
	void HandleClamberingTargetOutOfActivationRange(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetOutOfActivationRange // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void HandleClamberingTargetInActivationRange(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetInActivationRange // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void DrawDebugHUD(); // Function ClamberingCodeRuntime.ClamberingComponent.DrawDebugHUD // (Final|Native|Protected) // @ game+0x7a88778
	void BP_TutorialModeEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeEnabled // (Event|Protected|BlueprintEvent|Const) // @ game+0x179ea74
	void BP_TutorialModeDisabled(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeDisabled // (Event|Protected|BlueprintEvent|Const) // @ game+0x179ea74
	void BP_IsValidTargetActor(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_IsValidTargetActor // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x179ea74
	void BP_HandleSynchedActionStarted(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleSynchedActionStarted // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x179ea74
	void BP_HandleClamberingStateChanged(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleClamberingStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x179ea74
	void BP_CanStartTargeting(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartTargeting // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x179ea74
	void BP_CanStartClambering(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartClambering // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x179ea74
};

// Class ClamberingCodeRuntime.ClamberingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UClamberingLibrary : UBlueprintFunctionLibrary {

	void PerformClamberingTargeting(); // Function ClamberingCodeRuntime.ClamberingLibrary.PerformClamberingTargeting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb1593ec
};

