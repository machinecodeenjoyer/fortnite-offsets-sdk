// WidgetBlueprintGeneratedClass SidebarSocialTagList.SidebarSocialTagList_C
// Size: 0x490 (Inherited: 0x490)
struct USidebarSocialTagList_C : USidebarSocialTagListBase {
};

